<?php
declare(strict_types=1);

// Reached only when the web server serves this project directory without the
// rewrite rules (.htaccess, web.config or deploy/nginx.conf). It loads nothing.
http_response_code(503);
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');
?>
<!doctype html>
<html lang="zh-CN">
<meta charset="utf-8">
<title>站点配置未完成</title>
<body style="font-family: sans-serif; max-width: 40em; margin: 4em auto; line-height: 1.7">
<h1>站点配置未完成（FD-REWRITE-MISSING）</h1>
<p>网站运行目录指向了程序根目录，但 URL 重写规则没有生效。为避免暴露程序文件，站点暂不提供服务。</p>
<p>请任选其一：</p>
<ol>
  <li>把网站运行目录设为 <code>public</code>（推荐）；</li>
  <li>Apache / LiteSpeed：开启 URL 重写（mod_rewrite），并允许读取 <code>.htaccess</code>；</li>
  <li>Nginx：把 <code>deploy/nginx.conf</code> 的内容填入「伪静态」；</li>
  <li>IIS：安装 URL Rewrite 模块，使用根目录的 <code>web.config</code>。</li>
</ol>
</body>
</html>
