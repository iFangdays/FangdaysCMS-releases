# 第三方样式来源

- `public/assets/theme/aoyun.css`：从本机 PbootCMS 3.2.10 的 `template/default/css/aoyun.css` 复制，用于 FangdaysCMS 默认前台主题。该样式归原作者所有，遵循 PbootCMS 仓库所附 Apache License 2.0；许可全文见 `public/assets/theme/PbootCMS-LICENSE.txt`。FangdaysCMS 的 PHP 模板与 `templates/default/` HTML 片段由本项目重新编写，仅解析文档列出的 Pboot 风格运营标签子集。
- `public/assets/theme/bootstrap.min.css`：从本机 PbootCMS 默认模板所附 Bootstrap 4.4.1 复制。Bootstrap 版权声明保留在 CSS 文件开头，MIT 许可全文见 `public/assets/theme/Bootstrap-LICENSE.txt`。
- `public/assets/images/`：从本机 PbootCMS 默认模板复制六张小型图片，以保证 `aoyun.css` 的相对路径资源可用；同样保留 PbootCMS 的 Apache License 2.0 来源说明。

默认前台只加载上述样式与 CSS 所需的图片；原站后端程序、授权文件和内容数据未复制。后台富文本编辑器的浏览器资源另见下文。

## 后台界面资源

- `public/assets/pboot-admin/css/comm.css`、`css/login.css` 和 `images/bg.jpg`：原样复制本机 PbootCMS 3.2.10 的对应文件。后台外壳与内容页参考该版本的 `common/head.html`、`content/content.html`、`content/contentsort.html` 和 `system/home.html` 结构，PHP 路由及数据绑定由 FangdaysCMS 实现。许可见 `public/assets/pboot-admin/PbootCMS-LICENSE.txt`。
- `public/assets/pboot-admin/layui/`：从上述后台复制 Layui 2.5.7 CSS 和图标字体。MIT 许可见 `public/assets/pboot-admin/Layui-LICENSE.txt`。没有复制或执行 PbootCMS 后台脚本。
- `public/assets/pboot-admin/font-awesome/`：从上述后台复制 Font Awesome 4.7.0 CSS 与字体。CSS 按 MIT 许可，字体按 SIL OFL 1.1 许可；许可文本分别见 `public/assets/pboot-admin/FontAwesome-CSS-MIT.txt` 和 `public/assets/pboot-admin/FontAwesome-Font-OFL.txt`。

## 富文本编辑资源

- `public/assets/hugerte/`：从 npm 包 [hugerte@1.0.15](https://github.com/hugerte/hugerte) 选取压缩后的核心、模型、主题、图标、hugerte-5 明暗皮肤及所用插件。HugeRTE 是 TinyMCE 6 的 MIT 分支，遵循 MIT 许可证，许可文本见 `public/assets/hugerte/license.txt`。
- `public/assets/hugerte/langs/zh-Hans.js`：来自 npm 包 [tinymce-i18n@26.10.26](https://github.com/mklkj/tinymce-i18n) 的 `langs6/zh-Hans.js`（对应 TinyMCE 6），首行改为注册到 `hugerte`。该包的 NOTICE 说明语言文件版权归 Tiny Technologies Inc.，按 TinyMCE 的许可条款提供；调整部分遵循 MIT。
- `third_party/htmlpurifier/library/`：从 [HTML Purifier 4.19.0](https://github.com/ezyang/htmlpurifier/tree/v4.19.0) 的发布标签复制 PHP 清理库，Git 提交 `b287d2a`；遵循 LGPL 2.1，许可见 `third_party/htmlpurifier/LICENSE`。用于保存与展示文章富文本时过滤危险标签、属性及 URL。

## 模板代码编辑资源

- `public/assets/monaco/`：从 [Monaco Editor 0.57.0](https://github.com/microsoft/monaco-editor) 的 npm 发布包复制 `min/vs`，仅保留 HTML、CSS、JavaScript 所需文件和简体中文语言包。MIT 许可与第三方声明见同目录 `LICENSE`、`ThirdPartyNotices.txt`。

## 前台轮播资源

- `public/assets/splide/`：从 [Splide 4.1.4](https://github.com/Splidejs/splide) 的 npm 发布包复制压缩 CSS 和 JavaScript，用于首页轮播；无运行时依赖，MIT 许可见 `public/assets/splide/LICENSE`。图片、标题和链接仍由 FangdaysCMS 数据库管理。

## PbootCMS 默认主题

- `templates/themes/default/html/`：原样复制本机 PbootCMS 3.2.10 的 `template/default/html/` 模板，由 `src/Cms/Pboot/` 按原版标签语义解析；HTML 不在公开目录，不会被直接访问。
- `public/template/default/`：原样复制同一主题的 `css/`、`js/`、`images/`，以及随附的 Bootstrap 4.4.1（MIT）、Font Awesome 4.7.0（CSS MIT / 字体 SIL OFL 1.1）、Swiper 4.3.5（MIT）、bootstrap-datetimepicker（Apache-2.0）、bootstrap-fileinput（BSD-3-Clause）；各库许可声明保留在其文件头部。PbootCMS 部分遵循 Apache License 2.0，见 `public/template/default/PbootCMS-LICENSE.txt`。
- `public/static/images/logo.png`、`nopic.png` 与 `public/images/nobanner.jpg`：复制自 PbootCMS 3.2.10 的同名路径，作为标签缺省图片（路径与原版一致）。
- `src/Cms/Pboot/LabelParser.php`、`Paging.php`：参照 PbootCMS 3.2.10 `apps/home/controller/ParserController.php` 与 `core/view/Paging.php` 的逻辑移植（Apache License 2.0），数据访问、转义与安全处理由 FangdaysCMS 重写。
- `third_party/sodium_compat/`：从 [sodium_compat 2.5.2](https://github.com/paragonie/sodium_compat/tree/v2.5.2) 的发布标签复制 `src/`、`lib/`、`autoload.php` 和 `LICENSE`，未改动，用于主机没有 `sodium` 扩展时校验授权签名。ISC 许可见该目录的 `LICENSE`。
- `third_party/phpqrcode/phpqrcode.php`：从本机 PbootCMS 3.2.10 的 `core/extend/qrcode/phpqrcode.php` 原样复制的 PHP QR Code（合并版，Dominik Dzienia），用于 `{pboot:qrcode}` 生成二维码图片；遵循 LGPL 3，许可见 `third_party/phpqrcode/LICENSE`（LGPL-3.0）与 `third_party/phpqrcode/COPYING-GPL3`。 唯一改动：删除了 `ImageDestroy()` 调用，它自 PHP 8.0 起无实际作用，在 PHP 8.5 上的废弃提示会破坏 PNG 输出。
- `src/Cms/Captcha.php`、`src/Cms/ImageTools.php`：参照 PbootCMS 3.2.10 `core/code.php`、`core/extend/code/Code.php` 与 `core/function/file.php`（`watermark_img`、`resize_img`、`cut_img`）的逻辑移植（Apache License 2.0）。原版验证码所附 `elephant.ttf` 为商业字体、未随原版提供再分发许可，未复制；验证码改用 GD 内置字体。
- `public/apps/admin/view/default/images/logo.png`：复制自 PbootCMS 3.2.10 同名路径，原版留言与评论标签用它作为默认头像（路径与原版一致）。

