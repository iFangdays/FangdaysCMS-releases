/* FangdaysCMS admin login: particles assemble into the product's slogans. */
(function () {
  'use strict';

  var canvas = document.getElementById('login-particles');
  var form = document.getElementById('login-form');
  var panel = document.querySelector('.login-panel');
  var submit = document.getElementById('login-submit');
  var gl = canvas && canvas.getContext('webgl', { alpha: true, antialias: false, powerPreference: 'low-power' });
  if (!gl) return;

  // Each slogan is drawn on two lines; the first is also the page's written slogan.
  var SLOGANS = [['AI 建站', '快人一步'], ['说出想法', '网站就绪'], ['让 AI', '读懂你的网站']];
  var HOLD_MS = 5200;
  var FONT = '"PingFang SC","Hiragino Sans GB","Microsoft YaHei","Noto Sans CJK SC","Source Han Sans SC",sans-serif';
  var reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var dpr = Math.min(window.devicePixelRatio || 1, 2);
  var width = 0, height = 0, centerX = 0, centerY = 0, stageWidth = 0, stageHeight = 0, glyphSize = 0;
  var count = 0, px, py, vx, vy, tx, ty, delay, render, phases;
  var shapes = {}, sloganIndex = 0, nextMorph = 0, held = null;
  var pointer = { x: -9999, y: -9999 };
  var tint = document.querySelector('.login-panel .error') ? 1 : 0;
  var implode = 0, last = 0;

  function compile(type, source) {
    var shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    return shader;
  }

  var program = gl.createProgram();
  gl.attachShader(program, compile(gl.VERTEX_SHADER, [
    'attribute vec3 aState;attribute float aSeed;',
    'uniform vec2 uView;uniform float uDpr;varying float vSeed;varying float vHeat;',
    'void main(){',
    '  vec2 clip=aState.xy/uView*2.0-1.0;',
    '  gl_Position=vec4(clip.x,-clip.y,0.0,1.0);',
    '  vSeed=aSeed;vHeat=clamp(aState.z/9.0,0.0,1.0);',
    '  gl_PointSize=(1.8+aSeed*2.6+vHeat*1.8)*uDpr;',
    '}'
  ].join('\n')));
  gl.attachShader(program, compile(gl.FRAGMENT_SHADER, [
    'precision mediump float;',
    'uniform float uTint;varying float vSeed;varying float vHeat;',
    'void main(){',
    '  float d=length(gl_PointCoord-0.5)*2.0;',
    '  float glow=pow(max(1.0-d,0.0),1.8);',
    '  vec3 color=mix(vec3(0.12,0.46,1.0),vec3(0.40,0.72,1.0),smoothstep(0.35,0.95,vSeed));',
    '  color=mix(color,vec3(0.78,0.90,1.0),vHeat);',
    '  color=mix(color,vec3(1.0,0.26,0.42),uTint);',
    '  gl_FragColor=vec4(color*glow*0.85,glow*0.85);',
    '}'
  ].join('\n')));
  gl.linkProgram(program);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) return;
  gl.useProgram(program);
  gl.enable(gl.BLEND);
  gl.blendFunc(gl.ONE, gl.ONE);
  gl.clearColor(0, 0, 0, 0);

  var uView = gl.getUniformLocation(program, 'uView');
  var uDpr = gl.getUniformLocation(program, 'uDpr');
  var uTint = gl.getUniformLocation(program, 'uTint');
  var aState = gl.getAttribLocation(program, 'aState');
  var aSeed = gl.getAttribLocation(program, 'aSeed');
  var stateBuffer = gl.createBuffer();
  var seedBuffer = gl.createBuffer();

  function shuffle(points) {
    for (var i = points.length / 2 - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var a = points[i * 2], b = points[i * 2 + 1];
      points[i * 2] = points[j * 2]; points[i * 2 + 1] = points[j * 2 + 1];
      points[j * 2] = a; points[j * 2 + 1] = b;
    }
    return points;
  }

  function sampleSlogan(lines) {
    var sheetWidth = Math.round(stageWidth), sheetHeight = Math.round(stageHeight);
    var sheet = document.createElement('canvas');
    sheet.width = sheetWidth;
    sheet.height = sheetHeight;
    var ctx = sheet.getContext('2d', { willReadFrequently: true });
    var fontSize = sheetHeight / (lines.length * 1.25);
    ctx.font = '600 ' + fontSize + 'px ' + FONT;
    var widest = Math.max.apply(null, lines.map(function (line) { return ctx.measureText(line).width; }));
    fontSize *= Math.min(1, sheetWidth * 0.96 / widest);
    ctx.font = '600 ' + fontSize + 'px ' + FONT;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#fff';
    lines.forEach(function (line, index) {
      ctx.fillText(line, sheetWidth / 2, sheetHeight / 2 + (index - (lines.length - 1) / 2) * fontSize * 1.25);
    });
    var pixels = ctx.getImageData(0, 0, sheetWidth, sheetHeight).data;
    var points = [], step = Math.max(1, Math.round(Math.sqrt(sheetWidth * sheetHeight) / 480));
    for (var y = 0; y < sheetHeight; y += step) {
      for (var x = 0; x < sheetWidth; x += step) {
        if (pixels[(y * sheetWidth + x) * 4 + 3] > 128) points.push(x - sheetWidth / 2, y - sheetHeight / 2);
      }
    }
    return shuffle(points);
  }

  // The hollow square that stands in for the slogan while a password is typed.
  function sampleSquare() {
    var points = [], half = glyphSize * 0.36, band = glyphSize * 0.035;
    for (var i = 0; i < 6000; i++) {
      var along = (Math.random() * 2 - 1) * half;
      var across = half + (Math.random() - 0.5) * band * 2;
      var side = i % 4;
      points.push(side < 2 ? along : (side === 2 ? across : -across), side < 2 ? (side === 0 ? across : -across) : along);
    }
    return points;
  }

  function setTargets(points, stagger) {
    var pairs = points.length / 2;
    for (var i = 0; i < count; i++) {
      // Every twelfth particle stays loose as dust around the slogan.
      if (i % 12 === 0) {
        tx[i] = Math.random() * width;
        ty[i] = Math.random() * height;
        delay[i] = 0;
        continue;
      }
      var p = (i % pairs) * 2;
      tx[i] = centerX + points[p] + (Math.random() - 0.5) * 1.2;
      ty[i] = centerY + points[p + 1] + (Math.random() - 0.5) * 1.2;
      delay[i] = stagger ? ((points[p] / stageWidth + 0.5) * 0.45 + Math.random() * 0.12) : 0;
    }
  }

  function showCurrentSlogan(stagger) {
    setTargets(shapes[sloganIndex], stagger);
    nextMorph = performance.now() + HOLD_MS;
  }

  function layout() {
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = Math.round(width * dpr);
    canvas.height = Math.round(height * dpr);
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.uniform2f(uView, width, height);
    gl.uniform1f(uDpr, dpr);

    var stacked = width <= 860;
    centerX = stacked ? width / 2 : (width - panel.offsetWidth) / 2;
    centerY = stacked ? height * 0.18 : height / 2;
    // A tab opened in a zero-size pane still needs drawable shapes until its first resize.
    stageWidth = Math.max(8, stacked ? width * 0.88 : centerX * 1.72);
    stageHeight = Math.max(8, stacked ? height * 0.24 : Math.min(height * 0.62, centerX * 1.1));
    glyphSize = Math.min(stageWidth, stageHeight);

    var wanted = Math.round(Math.min(36000, Math.max(12000, stageWidth * stageHeight * 0.05)));
    if (wanted !== count) allocate(wanted);
    SLOGANS.forEach(function (lines, index) { shapes[index] = sampleSlogan(lines); });
    shapes.square = sampleSquare();
    if (held) setTargets(shapes[held], false); else showCurrentSlogan(false);
  }

  function allocate(size) {
    count = size;
    px = new Float32Array(size); py = new Float32Array(size);
    vx = new Float32Array(size); vy = new Float32Array(size);
    tx = new Float32Array(size); ty = new Float32Array(size);
    delay = new Float32Array(size); phases = new Float32Array(size);
    render = new Float32Array(size * 3);
    var seeds = new Float32Array(size);
    for (var i = 0; i < size; i++) {
      px[i] = Math.random() * width;
      py[i] = Math.random() * height;
      seeds[i] = Math.random();
      phases[i] = Math.random() * Math.PI * 2;
    }
    gl.bindBuffer(gl.ARRAY_BUFFER, seedBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, seeds, gl.STATIC_DRAW);
    gl.enableVertexAttribArray(aSeed);
    gl.vertexAttribPointer(aSeed, 1, gl.FLOAT, false, 0, 0);
    gl.bindBuffer(gl.ARRAY_BUFFER, stateBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, render, gl.DYNAMIC_DRAW);
    gl.enableVertexAttribArray(aState);
    gl.vertexAttribPointer(aState, 3, gl.FLOAT, false, 0, 0);
  }

  function step(dt, time) {
    var repelRadius = Math.max(70, glyphSize * 0.16), repel2 = repelRadius * repelRadius;
    var pull = implode > 0 ? 0.11 : 0.026;
    var drag = Math.pow(0.86, dt);
    var t = time * 0.0006;
    for (var i = 0; i < count; i++) {
      if (delay[i] > 0) delay[i] -= dt / 60;
      var x = px[i], y = py[i], ax = 0, ay = 0;
      if (delay[i] <= 0) {
        var goalX = implode > 0 ? centerX : tx[i], goalY = implode > 0 ? centerY : ty[i];
        ax = (goalX - x) * pull;
        ay = (goalY - y) * pull;
      }
      // A slow breathing flow keeps the assembled glyph alive.
      ax += Math.sin(y * 0.012 + t + phases[i]) * 0.09;
      ay += Math.cos(x * 0.012 - t + phases[i]) * 0.09;
      var dx = x - pointer.x, dy = y - pointer.y, d2 = dx * dx + dy * dy;
      if (d2 < repel2 && d2 > 1) {
        var force = (1 - d2 / repel2) * 2.4 / Math.sqrt(d2);
        ax += dx * force;
        ay += dy * force;
      }
      vx[i] = (vx[i] + ax * dt) * drag;
      vy[i] = (vy[i] + ay * dt) * drag;
      px[i] = x + vx[i] * dt;
      py[i] = y + vy[i] * dt;
      render[i * 3] = px[i];
      render[i * 3 + 1] = py[i];
      render[i * 3 + 2] = Math.abs(vx[i]) + Math.abs(vy[i]);
    }
  }

  function draw() {
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.uniform1f(uTint, tint);
    gl.bindBuffer(gl.ARRAY_BUFFER, stateBuffer);
    gl.bufferSubData(gl.ARRAY_BUFFER, 0, render);
    gl.drawArrays(gl.POINTS, 0, count);
  }

  function loop(time) {
    requestAnimationFrame(loop);
    var dt = Math.min((time - last) / 16.67 || 1, 2.5);
    last = time;
    if (!held && implode === 0 && time > nextMorph) {
      sloganIndex = (sloganIndex + 1) % SLOGANS.length;
      showCurrentSlogan(true);
    }
    if (tint > 0) tint = Math.max(0, tint - dt * 0.006);
    if (implode > 0) implode -= 1;
    step(dt, time);
    draw();
  }

  function pulse(strength) {
    if (reducedMotion) return;
    for (var i = 0; i < count; i++) {
      var dx = px[i] - centerX, dy = py[i] - centerY, d = Math.sqrt(dx * dx + dy * dy) || 1;
      var falloff = strength * (0.5 + Math.random() * 0.5);
      vx[i] += dx / d * falloff;
      vy[i] += dy / d * falloff;
    }
  }

  function settleStill() {
    for (var i = 0; i < count; i++) {
      render[i * 3] = px[i] = tx[i];
      render[i * 3 + 1] = py[i] = ty[i];
      render[i * 3 + 2] = 0;
    }
    draw();
  }

  function refresh() {
    layout();
    if (reducedMotion) settleStill();
  }

  function holdShape(name) {
    held = name;
    if (name) setTargets(shapes[name], !reducedMotion); else showCurrentSlogan(!reducedMotion);
    if (reducedMotion) settleStill();
  }

  layout();
  var resizeTimer = 0;
  window.addEventListener('resize', function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(refresh, 120);
  });

  if (form) {
    var password = form.querySelector('input[type="password"]');
    password.addEventListener('focus', function () { holdShape('square'); });
    password.addEventListener('blur', function () { if (!submit.disabled) holdShape(null); });
    form.addEventListener('input', function () { pulse(1.1); });
    form.addEventListener('submit', function (event) {
      submit.disabled = true;
      submit.textContent = '正在登录…';
      if (reducedMotion) return;
      event.preventDefault();
      implode = 26;
      setTimeout(function () { pulse(24); }, 360);
      setTimeout(function () { form.submit(); }, 520);
    });
  }

  // A page restored from the back/forward cache must be able to log in again.
  window.addEventListener('pageshow', function (event) {
    if (!event.persisted) return;
    submit.disabled = false;
    submit.textContent = '登录后台';
    implode = 0;
    holdShape(null);
  });

  if (reducedMotion) {
    settleStill();
    return;
  }
  window.addEventListener('pointermove', function (event) { pointer.x = event.clientX; pointer.y = event.clientY; });
  document.documentElement.addEventListener('pointerleave', function () { pointer.x = pointer.y = -9999; });
  requestAnimationFrame(function (time) { last = time; loop(time); });
})();
