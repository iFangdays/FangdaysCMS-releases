/* FangdaysCMS admin light/dark switch; views/layout.php applies the saved choice before first paint. */
document.addEventListener('click', function (event) {
  if (!event.target.closest('[data-theme-toggle]')) return;
  var root = document.documentElement;
  var next = root.dataset.theme === 'dark' ? 'light' : 'dark';
  root.dataset.theme = next;
  try {
    localStorage.setItem('fangdays-admin-theme', next);
  } catch (error) {
    // Private windows may refuse storage; the theme still applies to this page.
  }
});
