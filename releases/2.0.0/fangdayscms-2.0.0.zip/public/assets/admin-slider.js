/* FangdaysCMS admin login: password reveal and the drag-to-verify slider (see SliderCaptcha.php). */
(function () {
  'use strict';

  var form = document.getElementById('login-form');
  var password = document.getElementById('admin-password');
  var reveal = document.getElementById('login-password-toggle');
  if (password && reveal) {
    reveal.addEventListener('click', function () {
      var shown = password.type === 'text';
      password.type = shown ? 'password' : 'text';
      reveal.setAttribute('aria-pressed', String(!shown));
      reveal.setAttribute('aria-label', shown ? '显示密码' : '隐藏密码');
      reveal.firstElementChild.className = 'fa ' + (shown ? 'fa-eye-slash' : 'fa-eye');
    });
  }

  var slider = document.getElementById('login-slider');
  if (!slider || !form) return;
  var handle = slider.querySelector('.login-slider-handle');
  var fill = slider.querySelector('.login-slider-fill');
  var text = document.getElementById('login-slider-text');
  var pass = document.getElementById('login-slider-pass');
  var IDLE_TEXT = text.textContent;
  var KEY_STEP = 0.1;
  var state = 'idle';
  var start = 0, startOffset = 0, offset = 0, expiry = 0;

  function reach() {
    return slider.clientWidth - handle.offsetWidth;
  }

  function place(value) {
    offset = Math.max(0, Math.min(reach(), value));
    handle.style.transform = 'translateX(' + offset + 'px)';
    fill.style.width = (offset + handle.offsetWidth / 2) + 'px';
    handle.setAttribute('aria-valuenow', String(Math.round(offset / reach() * 100)));
  }

  function setState(next, message) {
    state = next;
    slider.dataset.state = next;
    text.textContent = message;
  }

  function reset(message, failed) {
    clearTimeout(expiry);
    pass.value = '';
    handle.tabIndex = 0;
    handle.firstElementChild.className = 'fa fa-angle-double-right';
    slider.classList.add('is-returning');
    place(0);
    setState(failed ? 'failed' : 'idle', message || IDLE_TEXT);
  }

  function verify() {
    setState('verifying', '正在验证…');
    var body = new FormData();
    body.append('_csrf', form.elements._csrf.value);
    fetch(slider.dataset.verify, { method: 'POST', body: body, credentials: 'same-origin' })
      .then(function (response) { return response.json(); })
      .then(function (result) {
        if (!result.ok) throw new Error('rejected');
        pass.value = result.pass;
        handle.tabIndex = -1;
        handle.firstElementChild.className = 'fa fa-check';
        setState('passed', '验证通过');
        expiry = setTimeout(function () { reset('验证已过期，请重新拖动', true); }, result.expires_in * 1000);
      })
      .catch(function () { reset('验证未通过，请重新拖动', true); });
  }

  function release() {
    if (offset >= reach() - 1) verify(); else reset();
  }

  handle.addEventListener('pointerdown', function (event) {
    if (state === 'verifying' || state === 'passed') return;
    handle.setPointerCapture(event.pointerId);
    slider.classList.remove('is-returning');
    setState('dragging', IDLE_TEXT);
    start = event.clientX;
    startOffset = offset;
  });
  handle.addEventListener('pointermove', function (event) {
    if (state === 'dragging') place(startOffset + event.clientX - start);
  });
  handle.addEventListener('pointerup', function () {
    if (state === 'dragging') release();
  });
  handle.addEventListener('pointercancel', function () {
    if (state === 'dragging') reset();
  });

  handle.addEventListener('keydown', function (event) {
    if (state === 'verifying' || state === 'passed') return;
    var moves = { ArrowRight: offset + reach() * KEY_STEP, ArrowUp: offset + reach() * KEY_STEP, ArrowLeft: offset - reach() * KEY_STEP, ArrowDown: offset - reach() * KEY_STEP, Home: 0, End: reach() };
    if (!(event.key in moves)) return;
    event.preventDefault();
    slider.classList.remove('is-returning');
    place(moves[event.key]);
    if (offset >= reach() - 1) verify();
  });

  // Runs ahead of the particle stage's submit handler, which must not start without a pass.
  form.addEventListener('submit', function (event) {
    if (pass.value !== '') return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (state !== 'verifying') {
      reset('请先拖动滑块完成验证', true);
      handle.focus();
    }
  });

  window.addEventListener('resize', function () {
    if (state === 'passed') place(reach()); else if (state !== 'verifying') place(0);
  });
  // The pass is spent by the submit that left this page, so a restored page starts over.
  window.addEventListener('pageshow', function (event) {
    if (event.persisted) reset();
  });
})();
