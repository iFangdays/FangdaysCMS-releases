/* FangdaysCMS rich text: HugeRTE on a textarea, following the admin theme and using the shared image picker. */
(() => {
  const BASE = '/assets/hugerte';
  const FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "Segoe UI", Roboto, sans-serif';
  const mounted = new Set();
  const isDark = () => document.documentElement.dataset.theme === 'dark';

  // Imported content often pins black text or white cells inline, which would vanish on the dark canvas.
  const INK = ['#000', '#000000', '#111', '#222', '#333', '#333333', 'black', 'rgb(0, 0, 0)', 'rgb(0,0,0)', 'rgb(51, 51, 51)', 'rgb(51,51,51)'];
  const PAPER = ['#fff', '#ffffff', 'white', 'rgb(255, 255, 255)', 'rgb(255,255,255)'];
  const pinned = (property, values) => values.flatMap((value) => [
    `[style*="${property}: ${value}" i]`,
    `[style*="${property}:${value}" i]`,
  ]).join(',');
  const contentStyle = () => {
    const base = `body{font-family:${FONT};font-size:15px;line-height:1.75;margin:16px 20px}img{max-width:100%;height:auto}table{border-collapse:collapse;max-width:100%}p{margin:0 0 .8em}`;
    if (!isDark()) return base;
    return `${base}html{color-scheme:dark}body{background:#1b1d22;color:#ededed}a{color:#66a8ff}table,td,th{border-color:#4a4d55}`
      + `${pinned('color', INK)}{color:#ededed!important}${pinned('background-color', PAPER)},${pinned('background', PAPER)}{background-color:transparent!important}`;
  };

  const insertImages = async (editor) => {
    const items = await window.FangdaysMedia.pick({ title: '插入图片', multiple: true });
    items.forEach((item) => editor.insertContent(editor.dom.createHTML('img', { src: item.path, alt: item.name })));
    editor.focus();
  };

  const init = (entry) => {
    const dark = isDark();
    return window.hugerte.init({
      target: entry.textarea,
      base_url: BASE,
      suffix: '.min',
      language: 'zh-Hans',
      language_url: `${BASE}/langs/zh-Hans.js`,
      skin: dark ? 'hugerte-5-dark' : 'hugerte-5',
      content_css: dark ? 'hugerte-5-dark' : 'hugerte-5',
      content_style: contentStyle(),
      height: entry.height,
      min_height: 320,
      resize: true,
      menubar: false,
      branding: false,
      promotion: false,
      elementpath: false,
      plugins: 'advlist anchor autolink charmap code fullscreen image link lists preview quickbars searchreplace table visualblocks wordcount',
      toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough forecolor backcolor removeformat | alignleft aligncenter alignright alignjustify lineheight | bullist numlist outdent indent | link fangdaysmedia table hr charmap | searchreplace visualblocks code preview fullscreen',
      toolbar_mode: 'wrap',
      quickbars_insert_toolbar: false,
      quickbars_selection_toolbar: 'bold italic underline forecolor backcolor | link blockquote',
      quickbars_image_toolbar: 'alignleft aligncenter alignright | image',
      contextmenu: 'link image table',
      font_family_formats: `默认字体=${FONT}; 宋体=SimSun,serif; 黑体=SimHei,sans-serif; 微软雅黑=Microsoft YaHei,sans-serif; 楷体=KaiTi,serif; 仿宋=FangSong,serif; Arial=arial,helvetica,sans-serif; Times New Roman=times new roman,times,serif`,
      font_size_formats: '12px 13px 14px 15px 16px 18px 20px 24px 28px 32px 36px 48px',
      block_formats: '正文=p; 标题 1=h1; 标题 2=h2; 标题 3=h3; 标题 4=h4; 标题 5=h5; 标题 6=h6; 引用=blockquote; 预设格式=pre',
      convert_urls: false,
      relative_urls: false,
      remove_script_host: false,
      entity_encoding: 'raw',
      image_caption: false,
      image_advtab: true,
      table_advtab: true,
      table_cell_advtab: true,
      table_row_advtab: true,
      automatic_uploads: true,
      paste_data_images: window.FangdaysMedia?.canUpload ?? false,
      images_file_types: 'jpeg,jpg,png,gif,webp',
      images_upload_handler: async (blobInfo) => (await window.FangdaysMedia.upload(new File([blobInfo.blob()], blobInfo.filename(), { type: blobInfo.blob().type }))).path,
      file_picker_types: 'image',
      file_picker_callback: async (callback) => {
        const [item] = await window.FangdaysMedia.pick({ title: '选择图片' });
        if (item) callback(item.path, { alt: item.name });
      },
      setup(editor) {
        entry.editor = editor;
        editor.ui.registry.addButton('fangdaysmedia', { icon: 'image', tooltip: '插入图片', onAction: () => insertImages(editor) });
        editor.on('init', () => {
          editor.setContent(entry.html);
          editor.undoManager.clear();
          editor.undoManager.add();
        });
      },
    });
  };

  const mount = (textarea, { html, form = textarea.form, format = null, height = 560 } = {}) => {
    if (!window.hugerte) return null;
    const entry = { textarea, html: html ?? textarea.value, format, height, editor: null };
    mounted.add(entry);
    init(entry);
    form?.addEventListener('submit', () => {
      if (!entry.editor?.initialized) return;
      entry.editor.save();
      if (entry.format) entry.format.value = 'html';
    });
    return entry;
  };

  // A skin cannot be swapped on a live editor, so a theme change rebuilds each one with its current content.
  new MutationObserver(() => {
    mounted.forEach((entry) => {
      if (!entry.editor?.initialized) return;
      entry.html = entry.editor.getContent();
      entry.editor.remove();
      init(entry);
    });
  }).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });

  window.FangdaysEditor = { mount };
})();
