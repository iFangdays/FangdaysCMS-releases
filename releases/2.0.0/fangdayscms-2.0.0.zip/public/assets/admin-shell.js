/* FangdaysCMS admin shell: sidebar, visited-page tabs, fullscreen and the Pboot in-form tabs. */
(() => {
  const root = document.documentElement;
  const toggle = document.querySelector('.admin-nav-toggle');
  const scrim = document.querySelector('.admin-scrim');
  const remember = (key, value) => {
    try {
      if (value === null) localStorage.removeItem(key); else localStorage.setItem(key, value);
    } catch (error) {
      // Storage can be blocked; the layout simply starts from its defaults next time.
    }
  };

  if (toggle && scrim) {
    const mobile = () => window.matchMedia('(max-width: 750px)').matches;
    const sync = () => toggle.setAttribute('aria-expanded', String(mobile() ? document.body.classList.contains('admin-nav-open') : !root.classList.contains('admin-nav-collapsed')));
    const close = () => { document.body.classList.remove('admin-nav-open'); scrim.hidden = true; sync(); };
    toggle.addEventListener('click', () => {
      if (mobile()) {
        if (document.body.classList.contains('admin-nav-open')) { close(); return; }
        document.body.classList.add('admin-nav-open');
        scrim.hidden = false;
      } else {
        remember('fangdays-admin-nav', root.classList.toggle('admin-nav-collapsed') ? 'collapsed' : null);
      }
      sync();
    });
    scrim.addEventListener('click', close);
    document.addEventListener('keydown', (event) => { if (event.key === 'Escape') close(); });
    window.addEventListener('resize', close);
    sync();
  }

  document.querySelectorAll('.admin-group-toggle').forEach((button) => button.addEventListener('click', () => {
    const open = button.closest('.admin-nav-group').classList.toggle('is-open');
    button.setAttribute('aria-expanded', String(open));
  }));

  // The collapsed rail's flyouts are positioned from their group, so lift any that would run off the screen.
  document.querySelectorAll('.admin-nav-group').forEach((group) => {
    const flyout = group.querySelector('.admin-nav-child');
    const fit = () => {
      flyout.style.top = '';
      if (!root.classList.contains('admin-nav-collapsed') || window.matchMedia('(max-width: 750px)').matches) return;
      const overflow = flyout.getBoundingClientRect().bottom - window.innerHeight + 8;
      if (overflow > 0) flyout.style.top = -overflow + 'px';
    };
    group.addEventListener('mouseenter', fit);
    group.addEventListener('focusin', fit);
  });

  document.querySelector('.admin-fullscreen')?.addEventListener('click', () => {
    if (document.fullscreenElement) document.exitFullscreen(); else document.documentElement.requestFullscreen?.();
  });

  // Visited pages, kept per browser tab. Each page load is a full navigation, so the strip is redrawn from storage.
  const strip = document.getElementById('admin-tabs');
  if (strip) {
    const STORE = 'fangdays-admin-tabs';
    const MAX_TABS = 12;
    const here = { key: strip.dataset.key, title: strip.dataset.title, href: location.pathname + location.search };
    const home = strip.dataset.home ? { key: strip.dataset.home, title: '工作台', href: strip.dataset.home } : null;
    const read = () => {
      try {
        const saved = JSON.parse(sessionStorage.getItem(STORE) || '[]');
        return Array.isArray(saved) ? saved.filter((tab) => tab && typeof tab.key === 'string' && typeof tab.title === 'string' && typeof tab.href === 'string' && tab.href.startsWith('/admin')) : [];
      } catch (error) {
        return [];
      }
    };
    const save = (tabs) => {
      try {
        sessionStorage.setItem(STORE, JSON.stringify(tabs));
      } catch (error) {
        // Without storage the strip shows only the current page.
      }
    };
    let tabs = read();
    const existing = tabs.find((tab) => tab.key === here.key);
    if (existing) Object.assign(existing, here); else tabs.push(here);
    while (tabs.length > MAX_TABS) tabs.splice(tabs.findIndex((tab) => tab.key !== here.key), 1);
    save(tabs);

    const draw = () => {
      strip.replaceChildren();
      const shown = home ? [home, ...tabs.filter((tab) => tab.key !== home.key)] : tabs;
      if (home && here.key === home.key) shown[0] = { ...home, href: here.href };
      shown.forEach((tab) => {
        const item = document.createElement('div');
        item.className = 'admin-tab';
        const link = document.createElement('a');
        link.href = tab.href;
        link.textContent = tab.title;
        item.append(link);
        if (tab.key === here.key) {
          item.classList.add('is-current');
          link.setAttribute('aria-current', 'page');
        }
        if (!home || tab.key !== home.key) {
          const close = document.createElement('button');
          close.type = 'button';
          close.setAttribute('aria-label', '关闭 ' + tab.title);
          close.innerHTML = '<i class="fa fa-times" aria-hidden="true"></i>';
          close.addEventListener('click', () => {
            const index = shown.indexOf(tab);
            tabs = tabs.filter((entry) => entry.key !== tab.key);
            save(tabs);
            if (tab.key === here.key) {
              const next = shown[index + 1] || shown[index - 1];
              location.href = next ? next.href : '/admin';
              return;
            }
            draw();
          });
          item.append(close);
        }
        strip.append(item);
      });
      strip.querySelector('.is-current')?.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    };
    draw();
    document.querySelector('form[action="/logout"]')?.addEventListener('submit', () => save([]));
  }

  // Sidebar position survives the full page load that every menu click causes.
  const menu = document.querySelector('.admin-menu');
  if (menu) {
    try {
      menu.scrollTop = Number(sessionStorage.getItem('fangdays-admin-menu-top')) || 0;
    } catch (error) {
      // Without storage the menu starts at the top.
    }
    window.addEventListener('pagehide', () => {
      try {
        sessionStorage.setItem('fangdays-admin-menu-top', String(menu.scrollTop));
      } catch (error) {
        // Nothing to keep.
      }
    });
  }

  // Page change: browsers with cross-document view transitions run admin.css's fade-slide; others animate in on load.
  if (!('onpagereveal' in window) && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    document.getElementById('main-content')?.classList.add('admin-page-enter');
  }
  const progress = document.getElementById('admin-progress');
  if (progress) {
    let stop = 0;
    const start = () => {
      progress.classList.add('is-active');
      clearTimeout(stop);
      stop = setTimeout(() => progress.classList.remove('is-active'), 10000); // Downloads never leave the page.
    };
    document.addEventListener('click', (event) => {
      const link = event.target.closest('a[href]');
      if (!link || event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      if (link.target === '_blank' || link.hasAttribute('download') || link.origin !== location.origin || link.getAttribute('href').startsWith('#')) return;
      start();
    });
    document.addEventListener('submit', (event) => { if (!event.defaultPrevented) start(); });
    window.addEventListener('pageshow', () => progress.classList.remove('is-active'));
  }

  // Linked fields: data-show-when="type=select,radio&gcode!=" shows an element only while its form matches.
  // `,` lists values, `!=` negates, `&` means and, `|` means or. Hidden fields keep their values and are still submitted.
  const linked = [...document.querySelectorAll('[data-show-when]')];
  if (linked.length) {
    const valueOf = (scope, name) => {
      const controls = [...scope.querySelectorAll('[name="' + name + '"]')];
      const control = controls.find((item) => !['radio', 'checkbox'].includes(item.type) || item.checked);
      return control ? control.value : '';
    };
    const matches = (scope, rule) => rule.split('|').some((options) => options.split('&').every((term) => {
      const [, name, negated, values] = term.match(/^([^!=]+)(!?)=(.*)$/);
      return values.split(',').includes(valueOf(scope, name)) !== Boolean(negated);
    }));
    const sync = () => linked.forEach((element) => {
      const show = matches(element.closest('form') || document, element.dataset.showWhen);
      element.hidden = !show;
      // A required field nobody can see would block the submit without saying why.
      element.querySelectorAll(show ? '[data-hidden-required]' : '[required]').forEach((field) => {
        field.required = show;
        field.toggleAttribute('data-hidden-required', !show);
      });
    });
    document.addEventListener('input', sync);
    document.addEventListener('change', sync);
    document.addEventListener('reset', () => setTimeout(sync));
    sync();
  }

  // Tree tables: rows name their parent; a fold hides every descendant and is remembered per browser.
  document.querySelectorAll('[data-tree]').forEach((table) => {
    const KEY = 'fangdays-tree-' + table.dataset.tree;
    const rows = [...table.querySelectorAll('tbody tr[data-tt-id]')];
    const byId = new Map(rows.map((row) => [row.dataset.ttId, row]));
    const parents = rows.filter((row) => row.querySelector('.admin-tree-toggle'));
    const ancestors = (row) => {
      const found = [];
      for (let up = byId.get(row.dataset.ttParentId); up && !found.includes(up); up = byId.get(up.dataset.ttParentId)) found.push(up);
      return found;
    };
    let folded = new Set();
    try {
      const saved = localStorage.getItem(KEY);
      folded = new Set(saved === null ? (rows.length > 20 ? parents.map((row) => row.dataset.ttId) : []) : JSON.parse(saved));
    } catch (error) {
      // Without storage every menu starts open.
    }
    const search = document.querySelector('[data-tree-search="' + table.dataset.tree + '"]');
    const draw = () => {
      const query = (search?.value || '').trim().toLowerCase();
      const hits = new Set(query ? rows.filter((row) => row.dataset.ttName.toLowerCase().includes(query)).flatMap((row) => [row, ...ancestors(row)]) : []);
      rows.forEach((row) => { row.hidden = query ? !hits.has(row) : ancestors(row).some((up) => folded.has(up.dataset.ttId)); });
      parents.forEach((row) => {
        const open = query !== '' || !folded.has(row.dataset.ttId);
        row.querySelector('.admin-tree-toggle').setAttribute('aria-expanded', String(open));
      });
    };
    const keep = () => {
      try {
        localStorage.setItem(KEY, JSON.stringify([...folded]));
      } catch (error) {
        // The fold simply lasts until the next page load.
      }
    };
    parents.forEach((row) => row.querySelector('.admin-tree-toggle').addEventListener('click', () => {
      if (!folded.delete(row.dataset.ttId)) folded.add(row.dataset.ttId);
      keep();
      draw();
    }));
    document.querySelectorAll('[data-tree-all="' + table.dataset.tree + '"]').forEach((button) => button.addEventListener('click', () => {
      folded = new Set(button.dataset.treeFold === '1' ? parents.map((row) => row.dataset.ttId) : []);
      keep();
      draw();
    }));
    search?.addEventListener('input', draw);
    draw();
  });

  // Copy chips for template tags; clipboard access needs HTTPS or localhost, so older copying stays as a fallback.
  document.addEventListener('click', async (event) => {
    const chip = event.target.closest('[data-copy]');
    if (!chip) return;
    try {
      await navigator.clipboard.writeText(chip.dataset.copy);
    } catch (error) {
      const area = Object.assign(document.createElement('textarea'), { value: chip.dataset.copy });
      document.body.append(area);
      area.select();
      document.execCommand('copy');
      area.remove();
    }
    chip.classList.add('is-copied');
    setTimeout(() => chip.classList.remove('is-copied'), 1200);
  });

  // Pboot in-form tabs (基本内容/高级内容): [data-tabs] with [data-tab] titles and [data-pane] items.
  document.querySelectorAll('[data-tabs]').forEach((tabs) => {
    const titles = [...tabs.querySelectorAll(':scope > .layui-tab-title [data-tab]')];
    const panes = [...tabs.querySelectorAll(':scope > .layui-tab-content > [data-pane]')];
    const show = (index) => {
      titles.forEach((title, i) => { title.classList.toggle('layui-this', i === index); title.setAttribute('aria-selected', String(i === index)); title.tabIndex = i === index ? 0 : -1; });
      panes.forEach((pane, i) => pane.classList.toggle('layui-show', i === index));
    };
    titles.forEach((title, i) => {
      title.addEventListener('click', () => show(i));
      title.addEventListener('keydown', (event) => {
        if (event.key !== 'ArrowRight' && event.key !== 'ArrowLeft') return;
        const next = (i + (event.key === 'ArrowRight' ? 1 : titles.length - 1)) % titles.length;
        show(next);
        titles[next].focus();
      });
    });
    tabs.closest('form')?.addEventListener('invalid', (event) => {
      const pane = event.target.closest('[data-pane]');
      if (pane && !pane.classList.contains('layui-show')) show(panes.indexOf(pane));
    }, true);
  });

  // Non-blocking background check for vendor-signed updates when the cache TTL expires.
  if (document.body.dataset.upgradeCheck === '1' && document.body.dataset.csrf) {
    const body = new URLSearchParams({ _csrf: document.body.dataset.csrf });
    fetch('/admin/upgrade/check', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'X-CSRF-Token': document.body.dataset.csrf, 'X-Requested-With': 'XMLHttpRequest' }, body })
      .then((response) => (response.ok ? response.json() : null))
      .then((data) => {
        if (!data || !data.has_update || !data.version) return;
        if (window.location.pathname === '/admin/upgrade') {
          window.location.reload();
          return;
        }
        const main = document.getElementById('main-content');
        if (!main || main.querySelector('.admin-update-notice')) return;
        const notice = document.createElement('div');
        notice.className = 'admin-update-notice';
        notice.setAttribute('role', 'status');
        const icon = document.createElement('i');
        icon.className = 'fa fa-cloud-upload';
        icon.setAttribute('aria-hidden', 'true');
        const text = document.createElement('span');
        text.append('发现新版本 FangdaysCMS ', Object.assign(document.createElement('strong'), { textContent: String(data.version) }), '（当前 ' + String(data.current_version || '') + '），已通过厂商签名校验。');
        const link = Object.assign(document.createElement('a'), { className: 'layui-btn layui-btn-sm', href: '/admin/upgrade', textContent: '前往升级' });
        notice.append(icon, text, link);
        main.prepend(notice);
      })
      .catch(() => {});
  }
})();
