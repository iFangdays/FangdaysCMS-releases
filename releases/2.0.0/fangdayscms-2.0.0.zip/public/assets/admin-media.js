/* FangdaysCMS admin images: the library picker, direct upload, image fields and gallery rows. */
(() => {
  const TYPES = 'image/jpeg,image/png,image/webp,image/gif';
  const GALLERY_LIMIT = 30;
  const FIELDS = 'select[name="cover_media_id"], select[name="media_id"], select[name="thumbnail_media_id"], select[name="banner_media_id"], select[data-extra-image]';
  const GALLERY_SELECTS = 'select[name="gallery_media_ids[]"], select[data-extra-gallery-image]';
  const canUpload = document.body.dataset.mediaUpload === '1';

  const element = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  };
  const button = (className, text) => {
    const node = element('button', className, text);
    node.type = 'button';
    return node;
  };

  async function upload(file) {
    const data = new FormData();
    data.append('_csrf', document.body.dataset.csrf);
    data.append('image', file);
    const response = await fetch('/admin/media/editor-upload', { method: 'POST', body: data, credentials: 'same-origin' });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.error || '上传失败，请重试。');
    return result;
  }

  const library = async (query) => {
    const response = await fetch('/admin/media/library?' + new URLSearchParams(query), { credentials: 'same-origin' });
    if (!response.ok) throw new Error('媒体库加载失败。');
    return response.json();
  };

  // Single dialog shared by every field and editor on the page.
  const picker = {
    dialog: null,
    resolve: null,
    multiple: false,
    limit: Infinity,
    chosen: new Map(),
    page: 1,
    query: '',
    build() {
      const dialog = element('dialog', 'admin-media-picker');
      const head = element('div', 'admin-media-picker-head');
      this.title = element('h2', '', '选择图片');
      const close = button('admin-icon-button');
      close.setAttribute('aria-label', '关闭');
      close.innerHTML = '<i class="fa fa-times" aria-hidden="true"></i>';
      head.append(this.title, close);
      const tools = element('div', 'admin-media-picker-tools');
      this.search = element('input', 'layui-input');
      this.search.type = 'search';
      this.search.placeholder = '搜索图片名称';
      this.search.setAttribute('aria-label', '搜索图片名称');
      tools.append(this.search);
      if (canUpload) {
        const add = button('layui-btn');
        add.innerHTML = '<i class="fa fa-upload" aria-hidden="true"></i> 上传图片';
        this.file = element('input');
        this.file.type = 'file';
        this.file.accept = TYPES;
        this.file.multiple = true;
        this.file.hidden = true;
        add.addEventListener('click', () => this.file.click());
        this.file.addEventListener('change', () => { this.send([...this.file.files]); this.file.value = ''; });
        tools.append(add, this.file);
      }
      this.status = element('p', 'admin-media-picker-status');
      this.status.setAttribute('aria-live', 'polite');
      this.grid = element('div', 'admin-media-picker-grid');
      this.more = button('layui-btn layui-btn-primary admin-media-more', '加载更多');
      const foot = element('div', 'admin-media-picker-foot');
      this.count = element('span', 'muted');
      this.confirm = button('layui-btn', '确定');
      foot.append(this.count, this.confirm);
      dialog.append(head, tools, this.status, this.grid, this.more, foot);
      document.body.append(dialog);
      this.dialog = dialog;

      close.addEventListener('click', () => dialog.close());
      dialog.addEventListener('close', () => this.finish([]));
      this.confirm.addEventListener('click', () => this.finish([...this.chosen.values()]));
      this.more.addEventListener('click', () => { this.page += 1; this.load(); });
      let timer = 0;
      this.search.addEventListener('input', () => {
        clearTimeout(timer);
        timer = setTimeout(() => { this.query = this.search.value.trim(); this.page = 1; this.load(); }, 250);
      });
      this.grid.addEventListener('click', (event) => {
        const tile = event.target.closest('[data-id]');
        if (tile) this.toggle(tile);
      });
      if (canUpload) {
        dialog.addEventListener('dragover', (event) => { event.preventDefault(); dialog.classList.add('is-dropping'); });
        dialog.addEventListener('dragleave', (event) => { if (!dialog.contains(event.relatedTarget)) dialog.classList.remove('is-dropping'); });
        dialog.addEventListener('drop', (event) => {
          event.preventDefault();
          dialog.classList.remove('is-dropping');
          this.send([...event.dataTransfer.files]);
        });
        dialog.addEventListener('paste', (event) => {
          const files = [...event.clipboardData.files];
          if (files.length) { event.preventDefault(); this.send(files); }
        });
      }
    },
    tile(item) {
      const tile = button('admin-media-choice');
      tile.dataset.id = item.id;
      tile.setAttribute('aria-pressed', String(this.chosen.has(item.id)));
      tile.title = item.name;
      tile.item = item;
      const image = element('img');
      image.src = item.path;
      image.alt = '';
      image.loading = 'lazy';
      tile.append(image, element('span', '', item.name));
      return tile;
    },
    async load() {
      this.status.textContent = this.page === 1 ? '正在加载…' : '';
      this.more.hidden = true;
      const query = { page: this.page };
      if (this.query) query.q = this.query;
      const requested = this.query;
      try {
        const result = await library(query);
        if (requested !== this.query) return;
        if (this.page === 1) this.grid.replaceChildren();
        this.grid.append(...result.items.map((item) => this.tile(item)));
        this.more.hidden = this.page * result.per_page >= result.total;
        this.status.textContent = result.total ? '' : (this.query ? '没有找到匹配的图片。' : '媒体库还没有图片' + (canUpload ? '，可以直接上传或把图片拖到这里。' : '。'));
      } catch (error) {
        this.status.textContent = error.message;
      }
    },
    toggle(tile) {
      const item = tile.item;
      if (!this.multiple) { this.finish([item]); return; }
      if (this.chosen.has(item.id)) this.chosen.delete(item.id);
      else if (this.chosen.size < this.limit) this.chosen.set(item.id, item);
      else { this.status.textContent = '最多再选 ' + this.limit + ' 张。'; return; }
      tile.setAttribute('aria-pressed', String(this.chosen.has(item.id)));
      this.counter();
    },
    counter() {
      this.count.textContent = '已选 ' + this.chosen.size + ' 张';
      this.confirm.disabled = this.chosen.size === 0;
    },
    async send(files) {
      const images = files.filter((file) => file.type.startsWith('image/'));
      for (const [index, file] of images.entries()) {
        this.status.textContent = '正在上传 ' + (index + 1) + ' / ' + images.length + '…';
        try {
          const item = await upload(file);
          if (!this.multiple) { this.finish([item]); return; }
          const tile = this.tile(item);
          this.grid.prepend(tile);
          this.toggle(tile);
        } catch (error) {
          this.status.textContent = file.name + '：' + error.message;
          return;
        }
      }
      this.status.textContent = images.length ? '上传完成。' : '只能上传 JPG、PNG、WebP、GIF 图片。';
    },
    finish(items) {
      const resolve = this.resolve;
      this.resolve = null;
      if (this.dialog.open) this.dialog.close();
      resolve?.(items);
    },
    open({ title = '选择图片', multiple = false, limit = Infinity } = {}) {
      if (!this.dialog) this.build();
      this.finish([]);
      this.multiple = multiple;
      this.limit = limit;
      this.chosen.clear();
      this.title.textContent = title;
      this.search.value = '';
      this.query = '';
      this.page = 1;
      this.dialog.classList.toggle('is-multiple', multiple);
      this.counter();
      this.dialog.showModal();
      this.load();
      return new Promise((resolve) => { this.resolve = resolve; });
    },
  };

  window.FangdaysMedia = { pick: (options) => picker.open(options), upload, canUpload };

  // A select keeps the value for the form (and the server's validation); these helpers read and write it.
  const usesPath = (select) => select.matches('[data-extra-image], [data-extra-gallery-image]');
  const pathOf = (select) => {
    if (!select.value) return '';
    if (usesPath(select)) return select.value;
    return select.selectedOptions[0]?.dataset.path || '';
  };
  const choose = (select, item) => {
    const value = usesPath(select) ? item.path : String(item.id);
    let option = [...select.options].find((entry) => entry.value === value);
    if (!option) {
      option = new Option(item.name + ' (#' + item.id + ')', value);
      select.add(option);
    }
    option.dataset.path = item.path;
    option.dataset.name = item.name;
    select.value = value;
    select.dispatchEvent(new Event('change', { bubbles: true }));
  };

  function enhanceField(select) {
    if (select.dataset.mediaField) return;
    select.dataset.mediaField = '1';
    select.classList.add('admin-media-native');
    select.tabIndex = -1;
    const field = element('div', 'admin-media-field');
    const thumb = button('admin-media-thumb');
    thumb.setAttribute('aria-label', '选择图片');
    const image = element('img');
    image.alt = '';
    const empty = element('i', 'fa fa-plus');
    empty.setAttribute('aria-hidden', 'true');
    thumb.append(image, empty);
    const side = element('div', 'admin-media-side');
    const name = element('span', 'admin-media-name');
    const actions = element('div', 'admin-btn-row');
    const file = element('input');
    file.type = 'file';
    file.accept = TYPES;
    file.hidden = true;
    const status = element('span', 'admin-media-status');
    status.setAttribute('aria-live', 'polite');
    const pickButton = button('layui-btn layui-btn-primary layui-btn-sm', '从媒体库选择');
    const remove = button('layui-btn layui-btn-primary layui-btn-sm', '移除');
    if (canUpload) {
      const send = button('layui-btn layui-btn-sm', '上传图片');
      send.addEventListener('click', () => file.click());
      actions.append(send);
    }
    actions.append(pickButton, remove);
    side.append(name, actions, status);
    field.append(thumb, side, file);
    select.after(field);

    const placeholder = select.options[0] && select.options[0].value === '' ? select.options[0].textContent : '未选择图片';
    const render = () => {
      const path = pathOf(select);
      field.classList.toggle('has-image', Boolean(path));
      if (path) image.src = path; else image.removeAttribute('src');
      const option = select.selectedOptions[0];
      name.textContent = select.value ? (option?.dataset.name || option?.textContent.replace(/\s*[(·]\s*#\d+\)?\s*$/, '') || '') : placeholder;
      remove.hidden = !select.value;
    };
    const send = async (files) => {
      const [image] = files;
      if (!image) return;
      status.textContent = '正在上传…';
      try {
        choose(select, await upload(image));
        status.textContent = '';
      } catch (error) {
        status.textContent = error.message;
      }
    };
    const browse = async () => {
      const [item] = await picker.open({ title: '选择图片' });
      if (item) choose(select, item);
    };
    thumb.addEventListener('click', browse);
    pickButton.addEventListener('click', browse);
    remove.addEventListener('click', () => {
      select.value = '';
      select.dispatchEvent(new Event('change', { bubbles: true }));
    });
    file.addEventListener('change', () => { send([...file.files]); file.value = ''; });
    if (canUpload) {
      field.addEventListener('dragover', (event) => { event.preventDefault(); field.classList.add('is-dropping'); });
      field.addEventListener('dragleave', () => field.classList.remove('is-dropping'));
      field.addEventListener('drop', (event) => {
        event.preventDefault();
        field.classList.remove('is-dropping');
        send([...event.dataTransfer.files]);
      });
    }
    select.addEventListener('change', render);
    select.mediaRender = render;
    render();
  }

  function syncRow(row) {
    const select = row.querySelector('select');
    const preview = row.querySelector('img.admin-gallery-preview');
    const path = pathOf(select);
    preview.hidden = !path;
    if (path) preview.src = path; else preview.removeAttribute('src');
    row.classList.toggle('is-empty', !path);
  }

  function enhanceRow(row) {
    if (row.dataset.mediaRow) return;
    row.dataset.mediaRow = '1';
    const select = row.querySelector('select');
    select.classList.add('admin-media-native');
    select.tabIndex = -1;
    const change = button('admin-gallery-pick');
    change.setAttribute('aria-label', '更换图片');
    change.innerHTML = '<i class="fa fa-plus" aria-hidden="true"></i><span>选择图片</span>';
    row.prepend(change);
    change.append(row.querySelector('img.admin-gallery-preview'));
    change.addEventListener('click', async () => {
      const [item] = await picker.open({ title: '选择图片' });
      if (item) choose(select, item);
    });
    row.querySelectorAll('[data-gallery-action="up"], [data-extra-gallery-action="up"]').forEach((node) => { node.textContent = '←'; node.setAttribute('aria-label', '前移'); });
    row.querySelectorAll('[data-gallery-action="down"], [data-extra-gallery-action="down"]').forEach((node) => { node.textContent = '→'; node.setAttribute('aria-label', '后移'); });
    select.addEventListener('change', () => syncRow(row));
    syncRow(row);
  }

  function enhanceGallery(rows) {
    const scope = rows.closest('[data-extra-gallery]') || rows.parentElement;
    const add = scope.querySelector('#gallery-add, [data-extra-gallery-add]');
    const template = document.getElementById('gallery-row-template');
    const isExtra = Boolean(rows.closest('[data-extra-gallery]'));
    const blankRow = () => {
      if (!isExtra && template) return template.content.firstElementChild.cloneNode(true);
      const row = rows.firstElementChild.cloneNode(true);
      row.querySelector('.admin-gallery-pick')?.replaceWith(row.querySelector('img.admin-gallery-preview'));
      delete row.dataset.mediaRow;
      row.querySelector('select').value = '';
      row.querySelector('input').value = '';
      return row;
    };
    const room = () => GALLERY_LIMIT - [...rows.children].filter((row) => row.querySelector('select').value).length;
    const place = (items) => {
      items.forEach((item) => {
        let row = [...rows.children].find((entry) => !entry.querySelector('select').value);
        if (!row) {
          if (rows.children.length >= GALLERY_LIMIT) return;
          row = blankRow();
          rows.append(row);
          enhanceRow(row);
        }
        choose(row.querySelector('select'), item);
      });
    };
    [...rows.children].forEach(enhanceRow);
    add?.addEventListener('click', async () => {
      if (room() <= 0) return;
      place(await picker.open({ title: '选择图片', multiple: true, limit: room() }));
    });
    if (add && canUpload) {
      const send = button('layui-btn layui-btn-sm', '上传图片');
      const file = element('input');
      file.type = 'file';
      file.accept = TYPES;
      file.multiple = true;
      file.hidden = true;
      const status = element('span', 'admin-media-status');
      status.setAttribute('aria-live', 'polite');
      send.addEventListener('click', () => file.click());
      file.addEventListener('change', async () => {
        const files = [...file.files].slice(0, room());
        file.value = '';
        for (const [index, image] of files.entries()) {
          status.textContent = '正在上传 ' + (index + 1) + ' / ' + files.length + '…';
          try {
            place([await upload(image)]);
          } catch (error) {
            status.textContent = image.name + '：' + error.message;
            return;
          }
        }
        status.textContent = '';
      });
      add.before(send);
      add.after(file, status);
    }
    rows.addEventListener('click', (event) => {
      const action = event.target.closest('[data-gallery-action], [data-extra-gallery-action]');
      if (!action) return;
      const row = action.closest('.admin-gallery-row');
      const kind = action.dataset.galleryAction || action.dataset.extraGalleryAction;
      if (kind === 'up' && row.previousElementSibling) rows.insertBefore(row, row.previousElementSibling);
      if (kind === 'down' && row.nextElementSibling) rows.insertBefore(row.nextElementSibling, row);
      if (kind === 'remove') {
        if (!isExtra || rows.children.length > 1) { row.remove(); return; }
        row.querySelector('select').value = '';
        row.querySelector('input').value = '';
        syncRow(row);
      }
    });
  }

  const selects = [...document.querySelectorAll(FIELDS)];
  selects.forEach(enhanceField);
  document.querySelectorAll('.admin-gallery-rows').forEach(enhanceGallery);

  // Options are rendered with id and name only, so ask for the paths of what is already selected.
  const known = selects.concat([...document.querySelectorAll(GALLERY_SELECTS)]).filter((select) => select.value && !usesPath(select) && !select.selectedOptions[0]?.dataset.path);
  const ids = [...new Set(known.map((select) => select.value))];
  if (ids.length) {
    library({ ids: ids.join(',') }).then(({ items }) => {
      known.forEach((select) => {
        const item = items.find((entry) => String(entry.id) === select.value);
        if (!item) return;
        select.selectedOptions[0].dataset.path = item.path;
        select.selectedOptions[0].dataset.name = item.name;
        select.dispatchEvent(new Event('change', { bubbles: true }));
      });
    }).catch(() => {});
  }
})();
