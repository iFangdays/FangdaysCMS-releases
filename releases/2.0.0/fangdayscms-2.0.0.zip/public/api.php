<?php
declare(strict_types=1);

// PbootCMS API entry (/api.php/cms/site, /api.php?p=/cms/site); App routes it to Pboot\Api.
require __DIR__ . '/index.php';
