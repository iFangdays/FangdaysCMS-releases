<?php
declare(strict_types=1);

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$file = realpath(__DIR__ . $path);
if ((str_starts_with($path, '/assets/') || str_starts_with($path, '/uploads/') || str_starts_with($path, '/template/') || str_starts_with($path, '/static/') || str_starts_with($path, '/images/') || str_starts_with($path, '/runtime/') || str_starts_with($path, '/apps/')) && $file !== false && str_starts_with($file, __DIR__ . DIRECTORY_SEPARATOR) && is_file($file)) {
    return false;
}
require __DIR__ . '/index.php';
