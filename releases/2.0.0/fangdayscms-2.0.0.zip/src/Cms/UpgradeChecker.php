<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;
use PDO;
use Throwable;

/** Checks the vendor-signed remote update feed, caches the result, and surfaces newer releases in the admin. */
final class UpgradeChecker
{
    public const SETTING_FEED_URL = 'upgrade_feed_url';
    public const SETTING_AUTO_CHECK = 'upgrade_auto_check';
    private const CACHE_TTL_OK = 21600;
    private const CACHE_TTL_ERROR = 1800;

    public static function feedUrl(PDO $pdo): string
    {
        $value = self::setting($pdo, self::SETTING_FEED_URL);
        if ($value !== null && $value !== '') {
            try {
                UpgradeManifest::assertHttpsUrl($value, '更新源地址必须使用 HTTPS。');
                return $value;
            } catch (InvalidArgumentException) {
            }
        }
        return UpgradeManifest::DEFAULT_FEED_URL;
    }

    public static function autoCheckEnabled(PDO $pdo): bool
    {
        $value = self::setting($pdo, self::SETTING_AUTO_CHECK);
        return $value === null ? true : $value !== '0';
    }

    public static function saveSettings(PDO $pdo, string $feedUrl, bool $autoCheck): void
    {
        $feedUrl = trim($feedUrl);
        if ($feedUrl === '') {
            $feedUrl = UpgradeManifest::DEFAULT_FEED_URL;
        }
        UpgradeManifest::assertHttpsUrl($feedUrl, '更新源地址必须使用 HTTPS。');
        if (strlen($feedUrl) > 500) {
            throw new InvalidArgumentException('更新源地址过长。');
        }
        self::writeSetting($pdo, self::SETTING_FEED_URL, $feedUrl);
        self::writeSetting($pdo, self::SETTING_AUTO_CHECK, $autoCheck ? '1' : '0');
    }

    /** Reads the cached check result without network I/O. */
    public static function cached(string $root, string $currentVersion): ?array
    {
        $path = self::cachePath($root);
        if (! is_file($path) || is_link($path)) {
            return null;
        }
        $raw = @file_get_contents($path);
        if (! is_string($raw) || $raw === '') {
            return null;
        }
        $data = json_decode($raw, true);
        if (! is_array($data) || ! is_int($data['checked_at'] ?? null)) {
            return null;
        }
        $manifest = is_array($data['manifest'] ?? null) ? $data['manifest'] : null;
        $hasUpdate = false;
        $status = (string) ($data['status'] ?? 'error');
        if ($manifest !== null && is_string($manifest['version'] ?? null)) {
            $hasUpdate = version_compare($manifest['version'], $currentVersion, '>');
            $status = $hasUpdate ? 'update' : 'up_to_date';
        }
        return array(
            'checked_at' => $data['checked_at'],
            'feed_url' => (string) ($data['feed_url'] ?? UpgradeManifest::DEFAULT_FEED_URL),
            'status' => $status,
            'has_update' => $hasUpdate,
            'manifest' => $manifest,
            'raw_manifest' => is_string($data['raw_manifest'] ?? null) ? $data['raw_manifest'] : null,
            'error' => is_string($data['error'] ?? null) ? $data['error'] : null,
        );
    }

    /** Returns the verified available update manifest from cache if newer than the running version. */
    public static function availableUpdate(string $root, string $currentVersion): ?array
    {
        $cached = self::cached($root, $currentVersion);
        if ($cached === null || ! $cached['has_update'] || ! is_array($cached['manifest'])) {
            return null;
        }
        return $cached['manifest'];
    }

    public static function shouldAutoCheck(string $root, PDO $pdo, string $currentVersion, ?int $now = null): bool
    {
        if (! self::autoCheckEnabled($pdo)) {
            return false;
        }
        $now ??= time();
        $cached = self::cached($root, $currentVersion);
        if ($cached === null) {
            return true;
        }
        $ttl = $cached['status'] === 'error' ? self::CACHE_TTL_ERROR : self::CACHE_TTL_OK;
        return ($now - $cached['checked_at']) >= $ttl;
    }

    /** Fetches, verifies and caches the latest vendor-signed manifest from the configured HTTPS feed. */
    public static function check(string $root, PDO $pdo, string $currentVersion, array $publicKeys, bool $force = false, int $timeout = 6, ?callable $fetcher = null): array
    {
        $feedUrl = self::feedUrl($pdo);
        $now = time();
        if (! $force) {
            $cached = self::cached($root, $currentVersion);
            if ($cached !== null && $cached['feed_url'] === $feedUrl) {
                $ttl = $cached['status'] === 'error' ? self::CACHE_TTL_ERROR : self::CACHE_TTL_OK;
                if (($now - $cached['checked_at']) < $ttl) {
                    return $cached;
                }
            }
        }
        try {
            $rawManifest = $fetcher !== null ? (string) $fetcher($feedUrl, $timeout) : UpgradeManifest::fetch($feedUrl, $timeout);
            $manifest = UpgradeManifest::inspect($rawManifest, $publicKeys);
            $hasUpdate = version_compare($manifest['version'], $currentVersion, '>');
            $result = array(
                'checked_at' => $now,
                'feed_url' => $feedUrl,
                'status' => $hasUpdate ? 'update' : 'up_to_date',
                'has_update' => $hasUpdate,
                'manifest' => $manifest,
                'raw_manifest' => trim($rawManifest),
                'error' => null,
            );
        } catch (Throwable $error) {
            $result = array(
                'checked_at' => $now,
                'feed_url' => $feedUrl,
                'status' => 'error',
                'has_update' => false,
                'manifest' => null,
                'raw_manifest' => null,
                'error' => $error->getMessage(),
            );
        }
        self::writeCache($root, $result);
        return $result;
    }

    public static function clearCache(string $root): void
    {
        $path = self::cachePath($root);
        if (is_file($path) && ! is_link($path)) {
            @unlink($path);
        }
    }

    private static function cachePath(string $root): string
    {
        return rtrim($root, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'var' . DIRECTORY_SEPARATOR . 'upgrade-check.json';
    }

    private static function writeCache(string $root, array $payload): void
    {
        $path = self::cachePath($root);
        $dir = dirname($path);
        if (is_link($dir) || is_link($path)) {
            return;
        }
        if (! is_dir($dir) && ! @mkdir($dir, 0700, true) && ! is_dir($dir)) {
            return;
        }
        $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (! is_string($json)) {
            return;
        }
        $temp = $path . '.tmp-' . bin2hex(random_bytes(6));
        if (@file_put_contents($temp, $json . PHP_EOL, LOCK_EX) !== false) {
            if (function_exists('chmod')) {
                @chmod($temp, 0600);
            }
            if (! @rename($temp, $path) && is_file($temp)) {
                @unlink($temp);
            }
        }
    }

    private static function setting(PDO $pdo, string $name): ?string
    {
        try {
            $stmt = $pdo->prepare('SELECT value FROM site_settings WHERE name = ?');
            $stmt->execute(array($name));
            $value = $stmt->fetchColumn();
            return $value === false ? null : (string) $value;
        } catch (Throwable) {
            return null;
        }
    }

    private static function writeSetting(PDO $pdo, string $name, string $value): void
    {
        $pdo->prepare('DELETE FROM site_settings WHERE name = ?')->execute(array($name));
        $pdo->prepare('INSERT INTO site_settings (name, value) VALUES (?, ?)')->execute(array($name, $value));
    }
}
