<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

/**
 * FangdaysCMS template tags use the {fd:*} prefix. Templates written for
 * PbootCMS ({pboot:*}) keep working: their tags are renamed when a trusted
 * template file is read, never in stored content.
 */
final class TemplateTags
{
    public const PREFIX = 'fd';

    public static function normalize(string $source): string
    {
        if (! str_contains($source, 'pboot:')) {
            return $source;
        }
        return preg_replace('~\{(/?)pboot:~', '{$1' . self::PREFIX . ':', $source) ?? $source;
    }
}
