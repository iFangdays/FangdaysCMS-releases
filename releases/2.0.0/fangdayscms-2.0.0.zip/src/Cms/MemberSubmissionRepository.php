<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;
use PDO;

final class MemberSubmissionRepository
{
    public function __construct(private readonly PDO $pdo) {}

    public function create(int $memberId, string $title, string $body, string $status = 'draft', ?int $groupId = null): int
    {
        return $this->save(null, $memberId, $title, $body, $status, $groupId);
    }

    public function save(?int $id, int $memberId, string $title, string $body, string $status, ?int $groupId = null): int
    {
        $title = trim($title); $body = trim($body);
        if ($title === '' || mb_strlen($title) > 191 || $body === '' || mb_strlen($body) > 2000000 || !in_array($status, ['draft','pending','approved','rejected'], true)) {
            throw new InvalidArgumentException('投稿标题、正文或状态无效。');
        }
        if ($groupId !== null) {
            $q = $this->pdo->prepare("SELECT COUNT(*) FROM member_groups WHERE id = ? AND status = 'active'"); $q->execute([$groupId]);
            if ((int)$q->fetchColumn() !== 1) throw new InvalidArgumentException('访问会员组无效。');
            $membership = $this->pdo->prepare('SELECT COUNT(*) FROM member_group_members WHERE group_id = ? AND member_id = ?');
            $membership->execute([$groupId, $memberId]);
            if ((int) $membership->fetchColumn() !== 1) throw new InvalidArgumentException('无权选择该会员组。');
        }
        $now = time();
        $slug = $id === null ? $this->uniqueSlug($title) : (string)($this->byId($id)['slug'] ?? $this->uniqueSlug($title));
        if ($id === null) {
            $s = $this->pdo->prepare('INSERT INTO member_submissions (member_id,title,slug,body,status,access_group_id,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)');
            $s->execute([$memberId,$title,$slug,$body,$status,$groupId,$now,$now]); return (int)$this->pdo->lastInsertId();
        }
        $s = $this->pdo->prepare('UPDATE member_submissions SET title=?,body=?,status=?,access_group_id=?,updated_at=? WHERE id=? AND member_id=?');
        $s->execute([$title,$body,$status,$groupId,$now,$id,$memberId]);
        if ($s->rowCount() === 0) throw new InvalidArgumentException('投稿不存在或无权编辑。');
        return $id;
    }

    public function byId(int $id): ?array { $s=$this->pdo->prepare('SELECT * FROM member_submissions WHERE id=?'); $s->execute([$id]); return $s->fetch() ?: null; }
    public function bySlug(string $slug, ?int $memberId = null, ?int $groupId = null): ?array
    {
        $s=$this->pdo->prepare("SELECT s.*, m.display_name AS author_name FROM member_submissions s JOIN members m ON m.id=s.member_id WHERE s.slug=? AND s.status='approved'"); $s->execute([$slug]); $row=$s->fetch();
        return $row && $this->authorized($row, $memberId, $groupId) ? $row : null;
    }
    public function all(?string $status=null): array { $sql='SELECT s.*,m.display_name AS author_name,g.name AS group_name FROM member_submissions s JOIN members m ON m.id=s.member_id LEFT JOIN member_groups g ON g.id=s.access_group_id'; $p=[]; if($status!==null){$sql.=' WHERE s.status=?';$p[]=$status;} $sql.=' ORDER BY s.updated_at DESC,s.id DESC';$s=$this->pdo->prepare($sql);$s->execute($p);return $s->fetchAll(); }
    public function forMember(int $memberId): array { $s=$this->pdo->prepare('SELECT s.*,g.name AS group_name FROM member_submissions s LEFT JOIN member_groups g ON g.id=s.access_group_id WHERE s.member_id=? ORDER BY s.updated_at DESC,s.id DESC');$s->execute([$memberId]);return $s->fetchAll(); }
    public function publicList(?int $memberId=null, ?int $groupId=null): array { $rows=$this->pdo->query("SELECT s.*,m.display_name AS author_name FROM member_submissions s JOIN members m ON m.id=s.member_id WHERE s.status='approved' ORDER BY s.updated_at DESC,s.id DESC")->fetchAll(); return array_values(array_filter($rows,fn(array $r):bool=>$this->authorized($r,$memberId,$groupId))); }
    public function review(int $id,string $status): void { if(!in_array($status,['draft','pending','approved','rejected'],true))throw new InvalidArgumentException('投稿状态无效。');$s=$this->pdo->prepare('UPDATE member_submissions SET status=?,updated_at=? WHERE id=?');$s->execute([$status,time(),$id]);if($s->rowCount()===0)throw new InvalidArgumentException('投稿不存在。'); }
    public function delete(int $id, ?int $memberId=null): void { $sql='DELETE FROM member_submissions WHERE id=?';$p=[$id];if($memberId!==null){$sql.=' AND member_id=?';$p[]=$memberId;}$s=$this->pdo->prepare($sql);$s->execute($p);if($s->rowCount()===0)throw new InvalidArgumentException('投稿不存在或无权删除。'); }
    private function authorized(array $row, ?int $memberId, ?int $groupId): bool { $required=(int)($row['access_group_id']??0); if($required===0)return true; return $groupId!==null && $groupId===$required; }
    private function uniqueSlug(string $title): string { $base=preg_replace('/[^a-z0-9]+/i','-',strtolower($title));$base=trim((string)$base,'-')?:'submission';$slug=$base;for($i=2;;$i++){ $s=$this->pdo->prepare('SELECT COUNT(*) FROM member_submissions WHERE slug=?');$s->execute([$slug]);if(!(int)$s->fetchColumn())return $slug;$slug=$base.'-'.$i; } }
}
