<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;
use PDO;

final class GuestbookRepository
{
    public function __construct(private readonly PDO $pdo)
    {
    }

    public function create(string $name, string $email, string $phone, string $content, ?int $memberId = null): int
    {
        $name = trim($name);
        $email = trim($email);
        $phone = trim($phone);
        $content = trim($content);
        if ($name === '' || mb_strlen($name) > 100) {
            throw new InvalidArgumentException('称呼不能为空且不超过 100 个字。');
        }
        if ($email !== '' && (mb_strlen($email) > 191 || ! filter_var($email, FILTER_VALIDATE_EMAIL))) {
            throw new InvalidArgumentException('邮箱格式无效。');
        }
        if (mb_strlen($phone) > 50) {
            throw new InvalidArgumentException('联系电话不能超过 50 个字符。');
        }
        if ($content === '' || mb_strlen($content) > 2000) {
            throw new InvalidArgumentException('留言内容不能为空且不超过 2000 个字。');
        }
        $stmt = $this->pdo->prepare('INSERT INTO guestbook_messages (member_id, name, email, phone, content, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        $now = time();
        $stmt->execute(array($memberId, $name, $email, $phone, $content, 'pending', $now, $now));
        return (int) $this->pdo->lastInsertId();
    }

    public function all(?string $status = null): array
    {
        $sql = 'SELECT * FROM guestbook_messages';
        $params = array();
        if ($status !== null && in_array($status, array('pending', 'approved', 'rejected'), true)) {
            $sql .= ' WHERE status = ?';
            $params[] = $status;
        }
        $sql .= ' ORDER BY created_at DESC, id DESC';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function approved(int $limit = 20): array
    {
        $limit = max(1, min(100, $limit));
        $stmt = $this->pdo->query('SELECT id, name, content, created_at FROM guestbook_messages WHERE status = \'approved\' ORDER BY created_at DESC, id DESC LIMIT ' . $limit);
        return $stmt->fetchAll();
    }

    public function count(?string $status = null): int
    {
        if ($status === null) {
            return (int) $this->pdo->query('SELECT COUNT(*) FROM guestbook_messages')->fetchColumn();
        }
        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM guestbook_messages WHERE status = ?');
        $stmt->execute(array($status));
        return (int) $stmt->fetchColumn();
    }

    /** Pboot 留言回复 (recontent): shown under the message by the theme; empty clears the reply. */
    public function reply(int $id, string $text): void
    {
        $text = trim($text);
        if (mb_strlen($text) > 2000) {
            throw new InvalidArgumentException('回复内容不能超过 2000 个字。');
        }
        $stmt = $this->pdo->prepare('UPDATE guestbook_messages SET recontent = ?, replied_at = ?, updated_at = ? WHERE id = ?');
        $stmt->execute(array($text, $text === '' ? 0 : time(), time(), $id));
        if ($stmt->rowCount() === 0) {
            throw new InvalidArgumentException('留言不存在。');
        }
    }

    public function updateStatus(int $id, string $status): void
    {
        if (! in_array($status, array('pending', 'approved', 'rejected'), true)) {
            throw new InvalidArgumentException('留言状态无效。');
        }
        $stmt = $this->pdo->prepare('UPDATE guestbook_messages SET status = ?, updated_at = ? WHERE id = ?');
        $stmt->execute(array($status, time(), $id));
        if ($stmt->rowCount() === 0) {
            throw new InvalidArgumentException('留言不存在。');
        }
    }

    public function delete(int $id): void
    {
        $stmt = $this->pdo->prepare('DELETE FROM guestbook_messages WHERE id = ?');
        $stmt->execute(array($id));
        if ($stmt->rowCount() === 0) {
            throw new InvalidArgumentException('留言不存在。');
        }
    }
}
