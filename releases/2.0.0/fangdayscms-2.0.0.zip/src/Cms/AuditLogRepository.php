<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use PDO;

final class AuditLogRepository
{
    public function __construct(private readonly PDO $pdo)
    {
    }

    public function record(?int $userId, string $username, string $method, string $path, string $ip): void
    {
        $stmt = $this->pdo->prepare('INSERT INTO audit_logs (user_id, username, method, path, ip_address, created_at, user_os, user_bs) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute(array($userId, mb_substr($username, 0, 100), mb_substr($method, 0, 10), mb_substr($path, 0, 255), mb_substr($ip, 0, 64), time(), Pboot\Interaction::userOs(), Pboot\Interaction::userBs()));
        $this->prune(10000);
    }

    public function all(string $keyword = '', int $page = 1, int $perPage = 50): array
    {
        $keyword = trim($keyword);
        $page = max(1, $page);
        $perPage = max(1, min(100, $perPage));
        $offset = ($page - 1) * $perPage;
        $sql = 'SELECT * FROM audit_logs';
        $params = array();
        if ($keyword !== '') {
            $sql .= ' WHERE username LIKE ? OR method LIKE ? OR path LIKE ? OR ip_address LIKE ?';
            $like = '%' . $keyword . '%';
            $params = array($like, $like, $like, $like);
        }
        $sql .= ' ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?';
        $stmt = $this->pdo->prepare($sql);
        foreach ($params as $index => $value) {
            $stmt->bindValue($index + 1, $value, PDO::PARAM_STR);
        }
        $stmt->bindValue(count($params) + 1, $perPage, PDO::PARAM_INT);
        $stmt->bindValue(count($params) + 2, $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function count(string $keyword = ''): int
    {
        $keyword = trim($keyword);
        if ($keyword === '') {
            return (int) $this->pdo->query('SELECT COUNT(*) FROM audit_logs')->fetchColumn();
        }
        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM audit_logs WHERE username LIKE ? OR method LIKE ? OR path LIKE ? OR ip_address LIKE ?');
        $like = '%' . $keyword . '%';
        $stmt->execute(array($like, $like, $like, $like));
        return (int) $stmt->fetchColumn();
    }

    private function prune(int $keep): void
    {
        $keep = max(100, $keep);
        // MySQL rejects LIMIT inside IN and deleting from a table the subquery reads, so find the oldest row to keep.
        $oldest = $this->pdo->query('SELECT id, created_at FROM audit_logs ORDER BY created_at DESC, id DESC LIMIT 1 OFFSET ' . ($keep - 1))->fetch();
        if ($oldest !== false) {
            $stmt = $this->pdo->prepare('DELETE FROM audit_logs WHERE created_at < ? OR (created_at = ? AND id < ?)');
            $stmt->execute(array((int) $oldest['created_at'], (int) $oldest['created_at'], (int) $oldest['id']));
        }
    }

    public function csv(string $keyword = ''): string
    {
        $rows = $this->all($keyword, 1, 10000);
        $handle = fopen('php://temp', 'w+');
        fputcsv($handle, array('id', 'user_id', 'username', 'method', 'path', 'ip_address', 'created_at'));
        foreach ($rows as $row) {
            fputcsv($handle, array($row['id'], $row['user_id'], self::cell((string) $row['username']), self::cell((string) $row['method']), self::cell((string) $row['path']), self::cell((string) $row['ip_address']), date('c', (int) $row['created_at'])));
        }
        rewind($handle);
        $csv = stream_get_contents($handle);
        fclose($handle);
        return is_string($csv) ? $csv : '';
    }
    /** Failed logins store whatever user name was typed; spreadsheets must not read it as a formula. */
    private static function cell(string $value): string
    {
        return preg_match('/^[=+\-@\t\r]/', $value) === 1 ? "'" . $value : $value;
    }

    public function clear(): void
    {
        $this->pdo->exec('DELETE FROM audit_logs');
    }
}
