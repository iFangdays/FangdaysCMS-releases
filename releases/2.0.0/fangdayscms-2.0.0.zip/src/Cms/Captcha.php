<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

/**
 * Image captcha for the front-end forms, served at /core/code.php as PbootCMS core/code.php: 4 characters from Pboot's set,
 * 120×45 PNG with noise, kept lower-case in the session. Drawn with GD's built-in font because the
 * TrueType font Pboot bundles has no redistribution licence.
 */
final class Captcha
{
    private const CHARSET = 'abcdefghkmnprtuvwxy23456789ABCDEFGHKMNPRTUVWXY';
    private const MAX_TRIES = 5;
    /** Config key per form that can require a captcha. */
    private const SWITCHES = array('admin' => 'admin_check_code', 'message' => 'message_check_code', 'form' => 'form_check_code', 'comment' => 'comment_check_code', 'login' => 'login_check_code', 'register' => 'register_check_code');

    /** @var array<string, bool> */
    private static array $required = array();

    public static function configure(Pboot\PbootConfig $config): void
    {
        foreach (self::SWITCHES as $form => $key) {
            // register_check_code 2 is Pboot's e-mail code, handled with member registration.
            self::$required[$form] = $config->get($key) === '1';
        }
    }

    public static function required(string $form): bool
    {
        return self::$required[$form] ?? false;
    }

    /** Error message when $form needs a captcha and the submitted one is missing or wrong, else null. */
    public static function error(string $form, string $input): ?string
    {
        if (! self::required($form)) {
            return null;
        }
        if (trim($input) === '') {
            return '验证码不能为空！';
        }
        return self::check($input) ? null : '验证码错误！';
    }

    public static function render(): void
    {
        $code = '';
        for ($i = 0; $i < 4; $i++) {
            $code .= self::CHARSET[random_int(0, strlen(self::CHARSET) - 1)];
        }
        $_SESSION['checkcode'] = strtolower($code);
        $_SESSION['checkcode_tries'] = 0;
        $width = 120;
        $height = 45;
        $image = imagecreatetruecolor($width, $height);
        imagefilledrectangle($image, 0, 0, $width, $height, (int) imagecolorallocate($image, random_int(200, 255), random_int(200, 255), random_int(200, 255)));
        for ($i = 0; $i < 6; $i++) {
            imageline($image, random_int(0, $width), random_int(0, $height), random_int(0, $width), random_int(0, $height), (int) imagecolorallocate($image, random_int(100, 200), random_int(100, 200), random_int(100, 200)));
        }
        for ($i = 0; $i < 100; $i++) {
            imagestring($image, random_int(1, 5), random_int(0, $width), random_int(0, $height), '*', (int) imagecolorallocate($image, random_int(200, 255), random_int(200, 255), random_int(200, 255)));
        }
        $step = ($width - 10) / 4;
        foreach (str_split($code) as $i => $char) {
            // Draw the glyph small, then enlarge and tilt it so it reads like Pboot's 18px TrueType text.
            $glyph = imagecreatetruecolor(10, 15);
            $transparent = (int) imagecolorallocatealpha($glyph, 0, 0, 0, 127);
            imagealphablending($glyph, false);
            imagefill($glyph, 0, 0, $transparent);
            imagesavealpha($glyph, true);
            $color = (int) imagecolorallocate($glyph, random_int(0, 80), random_int(0, 80), random_int(0, 80));
            imagestring($glyph, 5, 0, 0, $char, $color);
            imagestring($glyph, 5, 1, 0, $char, $color);
            $rotated = imagerotate($glyph, random_int(-20, 20), $transparent);
            $big = imagescale($rotated !== false ? $rotated : $glyph, 22, 34);
            if ($big !== false) {
                imagecopy($image, $big, (int) ($step * $i + $step / 4), random_int(3, 8), 0, 0, imagesx($big), imagesy($big));
            }
        }
        header('Content-Type: image/png');
        header('Cache-Control: no-store, no-cache, must-revalidate');
        imagepng($image);
    }

    /** Check a submitted code; the code is consumed on success and after repeated failures. */
    public static function check(string $input): bool
    {
        $expected = $_SESSION['checkcode'] ?? '';
        if (! is_string($expected) || $expected === '') {
            return false;
        }
        if (hash_equals($expected, strtolower(trim($input)))) {
            unset($_SESSION['checkcode'], $_SESSION['checkcode_tries']);
            return true;
        }
        $_SESSION['checkcode_tries'] = (int) ($_SESSION['checkcode_tries'] ?? 0) + 1;
        if ($_SESSION['checkcode_tries'] >= self::MAX_TRIES) {
            unset($_SESSION['checkcode'], $_SESSION['checkcode_tries']);
        }
        return false;
    }

    /** The captcha field for $form when it is required, else an empty string. */
    public static function fieldFor(string $form): string
    {
        return self::required($form) ? self::field() : '';
    }

    /** Form field shown by the built-in pages when a captcha is required. */
    public static function field(): string
    {
        return '<label>验证码<span style="display:flex;gap:8px;align-items:center"><input name="checkcode" required autocomplete="off" maxlength="8" style="max-width:10em">'
            . '<img src="/core/code.php" alt="验证码" title="点击刷新" style="height:38px;cursor:pointer" onclick="this.src=\'/core/code.php?\'+Date.now()"></span></label>';
    }
}
