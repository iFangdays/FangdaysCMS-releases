<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Geo;

use InvalidArgumentException;
use PDO;

/** Drafts for other platforms, published by a person, and a record of where they went. */
final class GeoPack
{
    public const PLATFORMS = array('zhihu' => '知乎', 'wechat' => '公众号', 'baijiahao' => '百家号');
    private const SIMILAR = 0.85;

    public function __construct(private readonly PDO $pdo)
    {
    }

    /** @return array<string, string> platform => draft text */
    public static function drafts(string $title, string $body, array $meta, string $url): array
    {
        $text = self::plain($body);
        $summary = $meta['summary'] !== '' ? $meta['summary'] . "\n\n" : '';
        $faq = '';
        foreach ($meta['faq'] as $item) {
            $faq .= "\n\n" . $item['q'] . "\n" . $item['a'];
        }
        return array(
            'zhihu' => '# ' . $title . "\n\n" . $summary . $text . ($faq === '' ? '' : "\n\n## 常见问题" . $faq) . "\n\n原文：" . $url,
            'wechat' => $title . "\n\n" . $summary . $text . ($faq === '' ? '' : "\n\n常见问题" . $faq) . "\n\n阅读原文：" . $url,
            'baijiahao' => $title . "\n\n" . $summary . $text . $faq . "\n\n来源：" . $url,
        );
    }

    public static function similarity(string $a, string $b): float
    {
        $grams = static function (string $text): array {
            $chars = preg_split('//u', (string) preg_replace('/\s+/u', '', $text), -1, PREG_SPLIT_NO_EMPTY) ?: array();
            $set = array();
            for ($i = 0, $last = count($chars) - 1; $i < $last; $i++) {
                $set[$chars[$i] . $chars[$i + 1]] = true;
            }
            return $set;
        };
        [$left, $right] = array($grams($a), $grams($b));
        $union = count($left + $right);
        return $union === 0 ? 0.0 : count(array_intersect_key($left, $right)) / $union;
    }

    /** @return list<string> platforms holding a near copy; the record is kept, the editor decides. */
    public function record(int $postId, string $platform, string $url, string $content, int $userId): array
    {
        $url = trim($url);
        if (! isset(self::PLATFORMS[$platform])) {
            throw new InvalidArgumentException('发布平台无效。');
        }
        if (preg_match('#^https?://#i', $url) !== 1 || mb_strlen($url) > 500) {
            throw new InvalidArgumentException('发布地址必须以 http 或 https 开头。');
        }
        $duplicates = array();
        if (trim($content) !== '') {
            foreach ($this->records($postId) as $record) {
                if ($record['content'] !== '' && self::similarity($content, (string) $record['content']) >= self::SIMILAR) {
                    $duplicates[] = self::PLATFORMS[$record['platform']] ?? (string) $record['platform'];
                }
            }
        }
        $this->pdo->prepare('INSERT INTO geo_pack_records (post_id, platform, url, content, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?)')->execute(array($postId, $platform, $url, $content, $userId, time()));
        return array_values(array_unique($duplicates));
    }

    public function records(int $postId): array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM geo_pack_records WHERE post_id = ? ORDER BY id DESC');
        $stmt->execute(array($postId));
        return $stmt->fetchAll();
    }

    public static function prompt(string $mode, string $title, string $body, array $facts): string
    {
        $rules = '只能使用给出的正文和事实，不得新增数字、案例、引语或主张；缺少信息时写【待补充】。';
        $task = match ($mode) {
            'meta' => '请根据内容写一句话结论（不超过 120 字）和 3 到 5 条常见问题。只输出 JSON，格式：{"summary":"","faq":[{"q":"","a":""}]}。' . $rules,
            'zhihu' => '请把内容改写成知乎回答：先给结论，再分点说明，语气客观。' . $rules,
            'wechat' => '请把内容改写成公众号文章：标题吸引人但不夸张，段落简短。' . $rules,
            'baijiahao' => '请把内容改写成百家号文章：信息完整，小标题清晰。' . $rules,
            default => '请改写内容，使其结论先行、小标题清晰、便于被 AI 搜索引用。' . $rules,
        };
        return $task . "\n\n已确认事实：\n" . implode("\n", $facts) . "\n\n标题：" . $title . "\n\n正文：\n" . mb_substr(strip_tags($body), 0, 8000);
    }

    /** @return array{summary: string, faq: string}|null form values; models often wrap JSON in a code fence */
    public static function parseMeta(string $answer): ?array
    {
        $start = strpos($answer, '{');
        $end = strrpos($answer, '}');
        $data = $start === false || $end === false ? null : json_decode(substr($answer, $start, $end - $start + 1), true);
        if (! is_array($data) || ! is_string($data['summary'] ?? null) || ! is_array($data['faq'] ?? null)) {
            return null;
        }
        $faq = array();
        foreach ($data['faq'] as $item) {
            if (is_string($item['q'] ?? null) && is_string($item['a'] ?? null)) {
                $faq[] = str_replace(array("\n", '|'), ' ', $item['q']) . ' | ' . str_replace("\n", ' ', $item['a']);
            }
        }
        return array('summary' => $data['summary'], 'faq' => implode("\n", $faq));
    }

    /** Figures in a suggestion that appear in neither the post nor the confirmed facts. */
    public static function unverified(string $suggestion, string $source): array
    {
        preg_match_all('/\d[\d.,]*\s*(?:%|％|万|亿|年|人|家|倍)?/u', $suggestion, $found);
        $missing = array();
        foreach (array_unique(array_map('trim', $found[0])) as $figure) {
            if (! str_contains($source, $figure)) {
                $missing[] = $figure;
            }
        }
        return $missing;
    }

    /** Plain reading copy of a post for agents; the HTML page stays canonical. */
    public static function markdown(string $title, string $body, array $meta, string $url, int $updatedAt): string
    {
        $text = '# ' . $title . "\n\n来源：" . $url . "\n更新：" . date('Y-m-d', $updatedAt) . "\n\n";
        if ($meta['summary'] !== '') {
            $text .= '> ' . $meta['summary'] . "\n\n";
        }
        $text .= self::plain($body) . "\n";
        if ($meta['faq']) {
            $text .= "\n## 常见问题\n";
            foreach ($meta['faq'] as $item) {
                $text .= "\n### " . $item['q'] . "\n\n" . $item['a'] . "\n";
            }
        }
        return $text;
    }

    private static function plain(string $body): string
    {
        $text = (string) preg_replace(array('/<br\s*\/?>/i', '/<\/(?:p|div|h[1-6]|li|tr|blockquote)>/i'), "\n", $body);
        $text = html_entity_decode(strip_tags($text), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        return trim((string) preg_replace("/\n{2,}/", "\n\n", (string) preg_replace('/[ \t]+\n/', "\n", $text)));
    }
}
