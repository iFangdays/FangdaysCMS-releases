<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Geo;

use FangdaysCMS\Cms\Pboot\PbootConfig;
use FangdaysCMS\Cms\RegionRepository;
use FangdaysCMS\Cms\View;
use PDO;
use Throwable;

/** Canonical, Open Graph and JSON-LD of the page being rendered, for built-in views and every theme. */
final class GeoHead
{
    private static ?self $current = null;

    private ?array $context = null;
    private ?array $meta = null;
    private bool $faqShown = false;
    private readonly GeoUrl $urls;
    private readonly GeoRepository $repository;

    private function __construct(private readonly PDO $pdo, private readonly string $locale, private readonly string $origin)
    {
        $this->urls = new GeoUrl($pdo, $locale);
        $this->repository = new GeoRepository($pdo);
    }

    public static function boot(PDO $pdo, string $locale, string $origin): void
    {
        self::$current = new self($pdo, $locale, $origin);
    }

    public static function reset(): void
    {
        self::$current = null;
    }

    /** @param string $type home, post, page or category */
    public static function mark(string $type, int $id = 0, string $slug = ''): void
    {
        if (self::$current !== null) {
            self::$current->context = array('type' => $type, 'id' => $id, 'slug' => $slug);
            self::$current->meta = null;
            self::$current->faqShown = false;
        }
    }

    /** Built-in views say what they show through their data. */
    public static function markView(string $template, array $data): void
    {
        if (is_array($data['post'] ?? null)) {
            self::mark('post', (int) ($data['post']['id'] ?? 0), (string) ($data['post']['slug'] ?? ''));
        } elseif (is_array($data['page'] ?? null)) {
            self::mark('page', (int) ($data['page']['id'] ?? 0), (string) ($data['page']['slug'] ?? ''));
        } elseif (is_array($data['category'] ?? null)) {
            self::mark('category', (int) ($data['category']['id'] ?? 0), (string) ($data['category']['slug'] ?? ''));
        } elseif ($template === 'site/home') {
            self::mark('home');
        }
    }

    public static function summaryHtml(): string
    {
        $summary = self::$current?->pageMeta()['summary'] ?? '';
        return $summary === '' ? '' : '<p class="geo-summary">' . View::e($summary) . '</p>';
    }

    public static function faqHtml(): string
    {
        $faq = self::$current?->pageMeta()['faq'] ?? array();
        if (! $faq) {
            return '';
        }
        self::$current->faqShown = true;
        $items = array_map(static fn (array $item): string => '<dt>' . View::e($item['q']) . '</dt><dd>' . View::e($item['a']) . '</dd>', $faq);
        return '<section class="geo-faq"><h2>常见问题</h2><dl>' . implode('', $items) . '</dl></section>';
    }

    public static function html(): string
    {
        if (self::$current === null || self::$current->context === null) {
            return '';
        }
        try {
            return self::$current->build();
        } catch (Throwable $error) {
            // Metadata must never take a public page down.
            error_log('FangdaysCMS GEO head: ' . $error->getMessage());
            return '';
        }
    }

    /** Whole-document themes skip the layout; a theme's own canonical wins. */
    public static function inject(string $html): string
    {
        $head = self::html();
        $position = stripos($html, '</head>');
        if ($head === '' || $position === false) {
            return $html;
        }
        if (preg_match('/<link\b[^>]*rel=["\']?canonical/i', substr($html, 0, $position)) === 1) {
            $head = (string) preg_replace('/<link rel="canonical"[^>]*>\n?/', '', $head);
        }
        return substr($html, 0, $position) . $head . substr($html, $position);
    }

    private function pageMeta(): array
    {
        $empty = array('summary' => '', 'faq' => array(), 'schema_type' => '', 'reviewed_by' => '', 'reviewed_at' => 0);
        if ($this->context === null || $this->context['id'] <= 0 || $this->context['type'] === 'home') {
            return $empty;
        }
        return $this->meta ??= $this->repository->meta($this->context['type'], $this->context['id'], $this->locale);
    }

    private function build(): string
    {
        $page = match ($this->context['type']) {
            'home' => $this->home(),
            'post' => $this->post(),
            'page' => $this->singlePage(),
            'category' => $this->category(),
            default => null,
        };
        if ($page === null) {
            return '';
        }
        $url = $this->origin . $page['path'];
        $lines = array('<link rel="canonical" href="' . View::e($url) . '">');
        foreach ($this->alternates($page['path']) as $locale => $path) {
            $lines[] = '<link rel="alternate" hreflang="' . View::e($locale) . '" href="' . View::e($this->origin . $path) . '">';
        }
        if (isset($page['markdown'])) {
            $lines[] = '<link rel="alternate" type="text/markdown" href="' . View::e($this->origin . $page['markdown']) . '">';
        }
        $autoPush = (new PbootConfig($this->pdo))->get('geo_360_js');
        if (preg_match('#^https://[^\s"\'<>]+$#D', $autoPush) === 1) {
            $lines[] = '<script src="' . View::e($autoPush) . '" id="sozz"></script>';
        }
        $tags = array('og:type' => $this->context['type'] === 'post' ? 'article' : 'website', 'og:site_name' => $this->urls->site()['title'], 'og:title' => $page['title'], 'og:description' => $page['description'], 'og:url' => $url, 'og:image' => $page['image'] ?? '');
        foreach ($tags as $property => $content) {
            if ((string) $content !== '') {
                $lines[] = '<meta property="' . $property . '" content="' . View::e($content) . '">';
            }
        }
        $graph = $page['graph'];
        $faq = $this->pageMeta()['faq'];
        // Structured FAQ must match what readers can see on the page.
        if ($faq && $this->faqShown) {
            $graph[] = array('@type' => 'FAQPage', 'mainEntity' => array_map(static fn (array $item): array => array('@type' => 'Question', 'name' => $item['q'], 'acceptedAnswer' => array('@type' => 'Answer', 'text' => $item['a'])), $faq));
        }
        if ($graph) {
            $json = json_encode(array('@context' => 'https://schema.org', '@graph' => $graph), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_INVALID_UTF8_SUBSTITUTE);
            $lines[] = '<script type="application/ld+json">' . $json . '</script>';
        }
        return implode("\n", $lines) . "\n";
    }

    private function home(): array
    {
        $path = View::localizedPath('/');
        $url = $this->origin . $path;
        $site = $this->urls->site();
        $name = (string) $site['title'];
        $description = (string) $site['description'];
        return array('path' => $path, 'title' => $name, 'description' => $description, 'graph' => array(
            array('@type' => 'WebSite', '@id' => $url . '#website', 'url' => $url, 'name' => $name, 'inLanguage' => $this->locale),
            $this->organization($url, $name, $description),
        ));
    }

    private function organization(string $url, string $name, string $description): array
    {
        $company = $this->urls->company();
        $organization = array('@type' => 'Organization', '@id' => $url . '#organization', 'name' => (string) (($company['name'] ?? '') ?: $name), 'url' => $url);
        $offers = array();
        foreach ($this->repository->facts($this->locale, 'confirmed') as $fact) {
            if ($fact['category'] === 'brand' && ! isset($organization['description']) && $fact['label'] !== '公司名称') {
                $organization['description'] = (string) $fact['value'];
            }
            if ($fact['category'] === 'product' || $fact['category'] === 'service') {
                $offers[] = array('@type' => 'Offer', 'itemOffered' => array('@type' => $fact['category'] === 'product' ? 'Product' : 'Service', 'name' => (string) $fact['label'], 'description' => (string) $fact['value']));
            }
        }
        if (! isset($organization['description']) && $description !== '') {
            $organization['description'] = $description;
        }
        foreach (array('telephone' => (($company['phone'] ?? '') ?: ($company['mobile'] ?? '')), 'email' => $company['email'] ?? '', 'address' => $company['address'] ?? '') as $key => $value) {
            if ((string) $value !== '') {
                $organization[$key] = (string) $value;
            }
        }
        if ($offers) {
            $organization['makesOffer'] = $offers;
        }
        return $organization;
    }

    private function post(): ?array
    {
        $english = $this->locale === 'en-US';
        if ($this->context['id'] <= 0) {
            // A record that exists only in this region has no shared metadata yet.
            return array('path' => View::localizedPath('/post/' . rawurlencode($this->context['slug'])), 'title' => '', 'description' => '', 'graph' => array());
        }
        $public = $this->urls->publicPosts($this->context['id'])[0] ?? null;
        if ($public === null) {
            return null;
        }
        $stmt = $this->pdo->prepare("SELECT p.title, p.title_en, p.body, p.body_en, COALESCE(pm.author, '') AS author, COALESCE(pm.seo_description, '') AS seo_description, COALESCE(pm.seo_description_en, '') AS seo_description_en, m.path AS cover FROM posts p LEFT JOIN post_meta pm ON pm.post_id = p.id LEFT JOIN post_cover c ON c.post_id = p.id LEFT JOIN media m ON m.id = c.media_id WHERE p.id = ?");
        $stmt->execute(array($this->context['id']));
        $row = $stmt->fetch();
        $title = (string) ($english && $row['title_en'] !== '' ? $row['title_en'] : $row['title']);
        $meta = $this->pageMeta();
        $description = (string) (($english && $row['seo_description_en'] !== '' ? $row['seo_description_en'] : $row['seo_description']) ?: ($meta['summary'] ?: self::excerpt((string) ($english && $row['body_en'] !== '' ? $row['body_en'] : $row['body']))));
        $url = $this->origin . $public['path'];
        $image = $row['cover'] ? $this->absolute((string) $row['cover']) : '';
        $article = array('@type' => $meta['schema_type'] ?: 'Article', '@id' => $url . '#content', 'url' => $url, 'name' => $title, 'description' => $description, 'inLanguage' => $this->locale, 'datePublished' => date('c', (int) ($public['published_at'] ?: $public['created_at'])), 'dateModified' => date('c', (int) $public['lastmod']));
        if (in_array($article['@type'], array('Article', 'NewsArticle', 'BlogPosting'), true)) {
            $article['headline'] = mb_substr($title, 0, 110);
            $article['publisher'] = array('@type' => 'Organization', 'name' => (string) $this->urls->site()['title']);
            if ($row['author'] !== '') {
                $article['author'] = array('@type' => 'Person', 'name' => (string) $row['author']);
            }
        } else {
            unset($article['datePublished'], $article['dateModified'], $article['inLanguage']);
        }
        if ($image !== '') {
            $article['image'] = $image;
        }
        if ($meta['reviewed_by'] !== '' && isset($article['headline'])) {
            $article['reviewedBy'] = array('@type' => 'Person', 'name' => $meta['reviewed_by']);
        }
        $trail = $public['category_id'] === null ? array() : $this->urls->trail((int) $public['category_id']);
        return array('path' => $public['path'], 'markdown' => View::localizedPath('/post/' . rawurlencode((string) $public['slug']) . '.md'), 'title' => $title, 'description' => $description, 'image' => $image, 'graph' => array($article, $this->breadcrumb(array_merge($trail, array(array('name' => $title, 'path' => $public['path']))))));
    }

    private function singlePage(): ?array
    {
        $path = View::localizedPath('/page/' . rawurlencode($this->context['slug']));
        if ($this->context['id'] <= 0) {
            return array('path' => $path, 'title' => '', 'description' => '', 'graph' => array());
        }
        $stmt = $this->pdo->prepare("SELECT title, title_en, body, body_en, seo_description, seo_description_en, updated_at FROM pages WHERE id = ? AND status = 'published'");
        $stmt->execute(array($this->context['id']));
        $row = $stmt->fetch();
        if ($row === false) {
            return null;
        }
        $english = $this->locale === 'en-US';
        $title = (string) ($english && ($row['title_en'] ?? '') !== '' ? $row['title_en'] : $row['title']);
        $description = (string) (($english && ($row['seo_description_en'] ?? '') !== '' ? $row['seo_description_en'] : ($row['seo_description'] ?? '')) ?: ($this->pageMeta()['summary'] ?: self::excerpt((string) $row['body'])));
        return array('path' => $path, 'title' => $title, 'description' => $description, 'graph' => array(
            array('@type' => 'WebPage', 'url' => $this->origin . $path, 'name' => $title, 'description' => $description, 'inLanguage' => $this->locale, 'dateModified' => date('c', (int) $row['updated_at'])),
            $this->breadcrumb(array(array('name' => $title, 'path' => $path))),
        ));
    }

    private function category(): ?array
    {
        if ($this->context['id'] <= 0) {
            return array('path' => View::localizedPath('/category/' . rawurlencode($this->context['slug'])), 'title' => '', 'description' => '', 'graph' => array());
        }
        if (! $this->urls->categoryIsPublic($this->context['id'])) {
            return null;
        }
        $trail = $this->urls->trail($this->context['id']);
        if (! $trail) {
            return null;
        }
        $current = $trail[count($trail) - 1];
        return array('path' => $current['path'], 'title' => $current['name'], 'description' => $current['description'], 'graph' => array(
            array('@type' => 'CollectionPage', 'url' => $this->origin . $current['path'], 'name' => $current['name'], 'inLanguage' => $this->locale),
            $this->breadcrumb($trail),
        ));
    }

    private function breadcrumb(array $trail): array
    {
        array_unshift($trail, array('name' => (string) $this->urls->site()['title'], 'path' => View::localizedPath('/')));
        $items = array();
        foreach ($trail as $position => $item) {
            $items[] = array('@type' => 'ListItem', 'position' => $position + 1, 'name' => $item['name'], 'item' => $this->origin . $item['path']);
        }
        return array('@type' => 'BreadcrumbList', 'itemListElement' => $items);
    }

    /** @return array<string, string> locale => address of this page there; only for plain, prefix-based routes. */
    private function alternates(string $path): array
    {
        $regions = (new RegionRepository($this->pdo))->all(true);
        if (count($regions) < 2 || ! $this->urls->plainRoutes()) {
            return array();
        }
        $current = rtrim(View::localizedPath('/'), '/');
        $bare = $current !== '' && str_starts_with($path, $current . '/') ? substr($path, strlen($current)) : $path;
        $paths = array();
        foreach ($regions as $region) {
            $prefix = $region['locale'] === 'zh-CN' || (string) $region['prefix'] === '' ? '' : '/' . $region['prefix'];
            $paths[(string) $region['locale']] = $prefix . $bare;
        }
        return $paths;
    }

    private function absolute(string $path): string
    {
        return str_starts_with($path, '/') && ! str_starts_with($path, '//') ? $this->origin . $path : $path;
    }

    private static function excerpt(string $body): string
    {
        $text = trim((string) preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags($body), ENT_QUOTES | ENT_HTML5, 'UTF-8')));
        return mb_substr($text, 0, 160);
    }
}
