<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Geo;

use FangdaysCMS\Cms\OperationsRepository;
use FangdaysCMS\Cms\Pboot\PbootConfig;
use PDO;

/** What the site itself can check. Results describe readiness, not AI rankings. */
final class GeoAudit
{
    private const STALE_POST_DAYS = 365;
    private const STALE_FACT_DAYS = 180;
    private const SAMPLE = 500;

    private array $pages = array();
    private bool $unreachable = false;

    public function __construct(private readonly PDO $pdo, private readonly string $origin)
    {
    }

    /** @return list<array{group: string, level: string, title: string, detail: string}> level is ok, warn or fail */
    public function run(): array
    {
        return array_merge($this->pages(), $this->content(), $this->facts());
    }

    private function pages(): array
    {
        $results = array();
        $config = new PbootConfig($this->pdo);
        $blocked = preg_match('/^\s*disallow:\s*\/\s*$/mi', $config->get('geo_robots_extra')) === 1;
        $results[] = self::item('可访问', $blocked ? 'warn' : 'ok', 'robots.txt 规则', $blocked ? '追加规则中有整站 Disallow，请确认只针对特定爬虫。' : '未发现整站封禁规则。');
        $posts = (new GeoUrl($this->pdo))->publicPosts();
        $paths = array('/');
        if ($posts) {
            $paths[] = (string) $posts[0]['path'];
        }
        foreach ($paths as $path) {
            $html = $this->fetch($path);
            if ($html === null) {
                $results[] = self::item('可访问', 'warn', '页面抓取 ' . $path, '站点无法访问自身，请用外部工具确认该地址可打开。');
                continue;
            }
            $results[] = self::item('可读取', str_contains($html, 'rel="canonical"') ? 'ok' : 'warn', '规范地址 ' . $path, str_contains($html, 'rel="canonical"') ? '已输出 canonical。' : '未输出 canonical，主题可能缺少 </head>。');
            $json = preg_match('#<script type="application/ld\+json">(.*?)</script>#s', $html, $found) === 1 ? json_decode($found[1], true) : null;
            $results[] = self::item('结构化', is_array($json) ? 'ok' : 'warn', 'JSON-LD ' . $path, is_array($json) ? 'JSON-LD 可解析。' : '未找到可解析的 JSON-LD。');
        }
        if ($posts) {
            $stmt = $this->pdo->prepare('SELECT body FROM posts WHERE id = ?');
            $stmt->execute(array($posts[0]['id']));
            $text = mb_substr(trim(strip_tags((string) $stmt->fetchColumn())), 0, 20);
            $html = $this->fetch((string) $posts[0]['path']);
            if ($html !== null && $text !== '') {
                $found = str_contains($html, $text);
                $results[] = self::item('可读取', $found ? 'ok' : 'fail', '正文在原始 HTML 中', $found ? '不执行 JS 也能读到正文。' : '原始 HTML 中找不到正文，AI 和搜索引擎可能读不到。');
            }
        }
        return $results;
    }

    private function content(): array
    {
        $posts = (new GeoUrl($this->pdo))->publicPosts();
        if (! $posts) {
            return array(self::item('内容', 'warn', '公开内容', '还没有公开文章。'));
        }
        $ids = array_map('intval', array_column(array_slice($posts, 0, self::SAMPLE), 'id'));
        $marks = implode(',', $ids);
        $total = count($ids);
        $withSummary = (int) $this->pdo->query("SELECT COUNT(*) FROM geo_entity_meta WHERE entity_type = 'post' AND summary <> '' AND entity_id IN ($marks)")->fetchColumn();
        $withAuthor = (int) $this->pdo->query("SELECT COUNT(*) FROM post_meta WHERE author <> '' AND post_id IN ($marks)")->fetchColumn();
        $stale = count(array_filter($posts, static fn (array $post): bool => (int) $post['lastmod'] < time() - self::STALE_POST_DAYS * 86400));
        $images = 0;
        foreach ($this->pdo->query("SELECT body FROM posts WHERE id IN ($marks)") as $row) {
            preg_match_all('/<img\b(?![^>]*\balt=["\'][^"\']+["\'])[^>]*>/i', (string) $row['body'], $found);
            $images += count($found[0]);
        }
        return array(
            self::item('内容', $withSummary === $total ? 'ok' : 'warn', 'GEO 摘要', $withSummary . '/' . $total . ' 篇已填写。'),
            self::item('内容', $withAuthor === $total ? 'ok' : 'warn', '作者信息', $withAuthor . '/' . $total . ' 篇已填写。'),
            self::item('内容', $stale === 0 ? 'ok' : 'warn', '内容更新', $stale . ' 篇超过一年未更新。'),
            self::item('内容', $images === 0 ? 'ok' : 'warn', '图片 alt', $images . ' 张图片缺少 alt 描述。'),
        );
    }

    private function facts(): array
    {
        $repository = new GeoRepository($this->pdo);
        $company = (new OperationsRepository($this->pdo))->company();
        $missing = array_keys(array_filter(array('公司名称' => $company['name'] ?? '', '地址' => $company['address'] ?? '', '电话' => ($company['phone'] ?? '') ?: ($company['mobile'] ?? '')), static fn ($value): bool => trim((string) $value) === ''));
        $drafts = count($repository->facts(null, 'draft'));
        $old = count(array_filter($repository->facts(null, 'confirmed'), static fn (array $fact): bool => (int) $fact['confirmed_at'] < time() - self::STALE_FACT_DAYS * 86400));
        return array(
            self::item('事实', $missing ? 'warn' : 'ok', '公司信息', $missing ? '缺少：' . implode('、', $missing) . '。' : '基础信息完整。'),
            self::item('事实', $drafts === 0 ? 'ok' : 'warn', '待确认事实', $drafts . ' 条草稿未确认，确认前不会对外输出。'),
            self::item('事实', $old === 0 ? 'ok' : 'warn', '事实复核', $old . ' 条事实超过 180 天未复核。'),
        );
    }

    private static function item(string $group, string $level, string $title, string $detail): array
    {
        return array('group' => $group, 'level' => $level, 'title' => $title, 'detail' => $detail);
    }

    /** A single-worker server cannot answer itself: give up after the first miss rather than stall the page. */
    private function fetch(string $path): ?string
    {
        if ($this->unreachable) {
            return null;
        }
        if (array_key_exists($path, $this->pages)) {
            return $this->pages[$path];
        }
        $html = @file_get_contents($this->origin . $path, false, stream_context_create(array('http' => array('timeout' => 2, 'follow_location' => 1, 'max_redirects' => 3, 'header' => "User-Agent: FangdaysCMS-GEO-Audit\r\n"))));
        $this->unreachable = ! is_string($html);
        return $this->pages[$path] = is_string($html) ? $html : null;
    }
}
