<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Geo;

use InvalidArgumentException;
use PDO;

/** GEO fields of content pages and the brand fact library. */
final class GeoRepository
{
    public const SCHEMA_TYPES = array('Article' => '文章', 'NewsArticle' => '新闻', 'BlogPosting' => '博客', 'Product' => '产品', 'Service' => '服务');
    public const FACT_CATEGORIES = array('brand' => '品牌简介', 'product' => '产品', 'service' => '服务', 'contact' => '联系方式', 'other' => '其他');
    private const MAX_FAQ = 20;

    public function __construct(private readonly PDO $pdo)
    {
    }

    /** The admin edits the site's default language; other regions keep their own rows. */
    private function siteLocale(): string
    {
        $locale = $this->pdo->query("SELECT value FROM site_settings WHERE name = 'locale'")->fetchColumn();
        return is_string($locale) && $locale !== '' ? $locale : 'zh-CN';
    }

    /** @return array{summary: string, faq: list<array{q: string, a: string}>, schema_type: string, reviewed_by: string, reviewed_at: int} */
    public function meta(string $type, int $id, ?string $locale = null): array
    {
        $locale ??= $this->siteLocale();
        $stmt = $this->pdo->prepare('SELECT summary, faq_json, schema_type, reviewed_by, reviewed_at FROM geo_entity_meta WHERE entity_type = ? AND entity_id = ? AND locale = ?');
        $stmt->execute(array($type, $id, $locale));
        $row = $stmt->fetch();
        if ($row === false) {
            return array('summary' => '', 'faq' => array(), 'schema_type' => '', 'reviewed_by' => '', 'reviewed_at' => 0);
        }
        $faq = json_decode((string) $row['faq_json'], true);
        return array('summary' => (string) $row['summary'], 'faq' => is_array($faq) ? $faq : array(), 'schema_type' => (string) $row['schema_type'], 'reviewed_by' => (string) $row['reviewed_by'], 'reviewed_at' => (int) $row['reviewed_at']);
    }

    /** Form text: one FAQ per line as "问题 | 答案". */
    public static function parseFaq(string $text): array
    {
        $faq = array();
        foreach (preg_split('/\R/u', $text) ?: array() as $line) {
            if (trim($line) === '') {
                continue;
            }
            $parts = array_map('trim', explode('|', $line, 2));
            if (count($parts) !== 2 || $parts[0] === '' || $parts[1] === '') {
                throw new InvalidArgumentException('FAQ 每行格式应为：问题 | 答案');
            }
            if (mb_strlen($parts[0]) > 200 || mb_strlen($parts[1]) > 1000) {
                throw new InvalidArgumentException('FAQ 问题或答案过长。');
            }
            $faq[] = array('q' => $parts[0], 'a' => $parts[1]);
        }
        if (count($faq) > self::MAX_FAQ) {
            throw new InvalidArgumentException('FAQ 最多 ' . self::MAX_FAQ . ' 条。');
        }
        return $faq;
    }

    public static function faqText(array $faq): string
    {
        return implode("\n", array_map(static fn (array $item): string => $item['q'] . ' | ' . $item['a'], $faq));
    }

    public function saveMeta(string $type, int $id, string $summary, string $faqText, string $schemaType, string $reviewedBy, ?string $locale = null): void
    {
        $locale ??= $this->siteLocale();
        $summary = trim($summary);
        $reviewedBy = trim($reviewedBy);
        if (mb_strlen($summary) > 300 || mb_strlen($reviewedBy) > 100) {
            throw new InvalidArgumentException('GEO 摘要或审核人过长。');
        }
        if ($schemaType !== '' && ! isset(self::SCHEMA_TYPES[$schemaType])) {
            throw new InvalidArgumentException('内容类型无效。');
        }
        $faq = self::parseFaq($faqText);
        $current = $this->meta($type, $id, $locale);
        $reviewedAt = $reviewedBy === '' ? 0 : ($reviewedBy === $current['reviewed_by'] ? $current['reviewed_at'] : time());
        $this->pdo->prepare('DELETE FROM geo_entity_meta WHERE entity_type = ? AND entity_id = ? AND locale = ?')->execute(array($type, $id, $locale));
        if ($summary === '' && ! $faq && $schemaType === '' && $reviewedBy === '') {
            return;
        }
        $this->pdo->prepare('INSERT INTO geo_entity_meta (entity_type, entity_id, locale, summary, faq_json, schema_type, reviewed_by, reviewed_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute(array($type, $id, $locale, $summary, json_encode($faq, JSON_UNESCAPED_UNICODE), $schemaType, $reviewedBy, $reviewedAt, time()));
    }

    public function facts(?string $locale = null, ?string $status = null): array
    {
        $locale ??= $this->siteLocale();
        $sql = 'SELECT * FROM geo_facts WHERE locale = ?';
        $params = array($locale);
        if ($status !== null) {
            $sql .= ' AND status = ?';
            $params[] = $status;
        } else {
            $sql .= " AND status <> 'archived'";
        }
        $stmt = $this->pdo->prepare($sql . ' ORDER BY category, id');
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /** A saved change always returns to draft: only a person confirms what is published. */
    public function saveFact(?int $id, string $category, string $label, string $value, string $sourceUrl, ?string $locale = null): void
    {
        $locale ??= $this->siteLocale();
        [$label, $value, $sourceUrl] = array(trim($label), trim($value), trim($sourceUrl));
        if (! isset(self::FACT_CATEGORIES[$category])) {
            throw new InvalidArgumentException('事实分类无效。');
        }
        if ($label === '' || mb_strlen($label) > 100 || $value === '' || mb_strlen($value) > 2000 || mb_strlen($sourceUrl) > 500) {
            throw new InvalidArgumentException('事实名称或内容长度无效。');
        }
        if ($sourceUrl !== '' && preg_match('#^https?://#i', $sourceUrl) !== 1) {
            throw new InvalidArgumentException('来源地址必须以 http 或 https 开头。');
        }
        if ($id === null) {
            $this->pdo->prepare("INSERT INTO geo_facts (locale, category, label, value, source_url, status, confirmed_by, confirmed_at, updated_at) VALUES (?, ?, ?, ?, ?, 'draft', 0, 0, ?)")
                ->execute(array($locale, $category, $label, $value, $sourceUrl, time()));
            return;
        }
        $this->pdo->prepare("UPDATE geo_facts SET category = ?, label = ?, value = ?, source_url = ?, status = 'draft', confirmed_by = 0, confirmed_at = 0, updated_at = ? WHERE id = ?")
            ->execute(array($category, $label, $value, $sourceUrl, time(), $id));
    }

    public function confirmFact(int $id, int $userId): void
    {
        $this->pdo->prepare("UPDATE geo_facts SET status = 'confirmed', confirmed_by = ?, confirmed_at = ? WHERE id = ? AND status <> 'archived'")->execute(array($userId, time(), $id));
    }

    public function archiveFact(int $id): void
    {
        $this->pdo->prepare("UPDATE geo_facts SET status = 'archived', updated_at = ? WHERE id = ?")->execute(array(time(), $id));
    }

    /** First visit only: turn the company profile into drafts for a person to confirm. */
    public function seedFacts(array $company, ?string $locale = null): void
    {
        $locale ??= $this->siteLocale();
        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM geo_facts WHERE locale = ?');
        $stmt->execute(array($locale));
        if ((int) $stmt->fetchColumn() > 0) {
            return;
        }
        foreach (array('name' => array('brand', '公司名称'), 'address' => array('contact', '公司地址'), 'phone' => array('contact', '联系电话'), 'mobile' => array('contact', '手机'), 'email' => array('contact', '邮箱')) as $field => [$category, $label]) {
            if (trim((string) ($company[$field] ?? '')) !== '') {
                $this->saveFact(null, $category, $label, (string) $company[$field], '', $locale);
            }
        }
    }
}
