<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Geo;

use FangdaysCMS\Cms\Pboot\PbootConfig;
use PDO;
use RuntimeException;

/** OpenAI-compatible chat calls with the customer's own keys, capped per day. */
final class GeoAi
{
    /** key => [name, default endpoint]; a site can override the endpoint in 配置参数. */
    public const PROVIDERS = array(
        'doubao' => array('豆包', 'https://ark.cn-beijing.volces.com/api/v3'),
        'qwen' => array('千问', 'https://dashscope.aliyuncs.com/compatible-mode/v1'),
        'deepseek' => array('DeepSeek', 'https://api.deepseek.com/v1'),
        'ernie' => array('文心', 'https://qianfan.baidubce.com/v2'),
        'yuanbao' => array('元宝（混元）', 'https://api.hunyuan.cloud.tencent.com/v1'),
    );

    private readonly PbootConfig $config;

    public function __construct(private readonly PDO $pdo)
    {
        $this->config = new PbootConfig($pdo);
    }

    /** @return array<string, string> provider => name, for those with a key and a model */
    public function configured(): array
    {
        $ready = array();
        foreach (self::PROVIDERS as $key => [$name]) {
            if ($this->config->get('geo_api_' . $key . '_key') !== '' && $this->config->get('geo_api_' . $key . '_model') !== '') {
                $ready[$key] = $name;
            }
        }
        return $ready;
    }

    public function assistant(): ?string
    {
        $provider = $this->config->get('geo_ai_provider');
        return isset($this->configured()[$provider]) ? $provider : null;
    }

    public function endpointHost(string $provider): string
    {
        try {
            return (string) parse_url($this->endpoint($provider), PHP_URL_HOST);
        } catch (RuntimeException) {
            return '接口地址无效';
        }
    }

    public function usedToday(): int
    {
        $stmt = $this->pdo->prepare('SELECT calls FROM geo_ai_usage WHERE day = ?');
        $stmt->execute(array(date('Y-m-d')));
        return (int) $stmt->fetchColumn();
    }

    public function dailyLimit(): int
    {
        return (int) $this->config->get('geo_ai_daily_limit');
    }

    /** @throws GeoBudgetExceeded when today's calls are spent
     *  @throws RuntimeException when the provider cannot answer */
    public function chat(string $provider, string $prompt, string $system = ''): array
    {
        if (! isset($this->configured()[$provider])) {
            throw new RuntimeException('接口未配置。');
        }
        if ($this->usedToday() >= $this->dailyLimit()) {
            throw new GeoBudgetExceeded('今日 AI 调用次数已用完。');
        }
        $mysql = $this->pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql';
        $this->pdo->prepare('INSERT INTO geo_ai_usage (day, calls) VALUES (?, 1) ' . ($mysql ? 'ON DUPLICATE KEY UPDATE calls = calls + 1' : 'ON CONFLICT(day) DO UPDATE SET calls = calls + 1'))->execute(array(date('Y-m-d')));
        $messages = $system === '' ? array() : array(array('role' => 'system', 'content' => $system));
        $messages[] = array('role' => 'user', 'content' => $prompt);
        [$status, $data] = self::call('POST', $this->endpoint($provider) . '/chat/completions', $this->config->get('geo_api_' . $provider . '_key'), array('model' => $this->config->get('geo_api_' . $provider . '_model'), 'messages' => $messages), 60);
        $answer = $data['choices'][0]['message']['content'] ?? null;
        if (! is_string($answer)) {
            throw new RuntimeException(self::describe($status, $data));
        }
        return array('answer' => $answer, 'citations' => array_values(array_filter((array) ($data['citations'] ?? array()), 'is_string')));
    }

    /**
     * Model ids the provider lists. Form values win over what is stored, so settings can be tried
     * before they are saved. Not every provider offers this; the model field also takes free text.
     * @return list<string>
     */
    public function models(string $provider, string $key = '', string $url = ''): array
    {
        [$status, $data] = self::call('GET', $this->endpoint($provider, $url) . '/models', $this->key($provider, $key), null, 15);
        $ids = array_values(array_filter(array_column(is_array($data['data'] ?? null) ? $data['data'] : array(), 'id'), 'is_string'));
        if (! $ids) {
            throw new RuntimeException($status === 200 ? '接口没有返回模型列表，请手动填写模型名。' : self::describe($status, $data) . ' 该平台可能不支持列出模型，可手动填写。');
        }
        sort($ids);
        return $ids;
    }

    /** One small real request, outside the daily cap because a person pressed the button. */
    public function test(string $provider, string $model, string $key = '', string $url = ''): array
    {
        $model = trim($model) !== '' ? trim($model) : $this->config->get('geo_api_' . $provider . '_model');
        if ($model === '') {
            throw new RuntimeException('请先填写或选择模型。');
        }
        $started = microtime(true);
        [$status, $data] = self::call('POST', $this->endpoint($provider, $url) . '/chat/completions', $this->key($provider, $key), array('model' => $model, 'messages' => array(array('role' => 'user', 'content' => '请回复：连接成功')), 'max_tokens' => 16), 30);
        if (! is_string($data['choices'][0]['message']['content'] ?? null)) {
            throw new RuntimeException(self::describe($status, $data));
        }
        return array('model' => $model, 'ms' => (int) round((microtime(true) - $started) * 1000));
    }

    private function key(string $provider, string $key): string
    {
        $key = trim($key) !== '' ? trim($key) : $this->config->get('geo_api_' . $provider . '_key');
        if ($key === '') {
            throw new RuntimeException('请先填写 API Key。');
        }
        return $key;
    }

    private function endpoint(string $provider, string $url = ''): string
    {
        if (! isset(self::PROVIDERS[$provider])) {
            throw new RuntimeException('平台无效。');
        }
        $test = getenv('FANGDAYS_GEO_API_BASE');
        if (is_string($test) && $test !== '') {
            return rtrim($test, '/');
        }
        $custom = trim($url) !== '' ? trim($url) : $this->config->get('geo_api_' . $provider . '_url');
        if ($custom === '') {
            return self::PROVIDERS[$provider][1];
        }
        // The key travels in a header: require encryption and keep it away from internal hosts.
        $host = (string) parse_url($custom, PHP_URL_HOST);
        if (preg_match('#^https://#i', $custom) !== 1 || $host === '') {
            throw new RuntimeException('自定义接口地址必须使用 https。');
        }
        $ip = gethostbyname($host);
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
            throw new RuntimeException('自定义接口地址不能指向内网。');
        }
        return rtrim($custom, '/');
    }

    /** @return array{0: int, 1: array<string, mixed>} */
    private static function call(string $method, string $url, string $key, ?array $body, int $timeout): array
    {
        $response = @file_get_contents($url, false, stream_context_create(array('http' => array('method' => $method, 'timeout' => $timeout, 'ignore_errors' => true, 'header' => "Content-Type: application/json\r\nAuthorization: Bearer " . $key . "\r\n", 'content' => $body === null ? '' : (string) json_encode($body, JSON_UNESCAPED_UNICODE)))));
        $status = isset($http_response_header[0]) && preg_match('#\s(\d{3})\s?#', $http_response_header[0], $found) === 1 ? (int) $found[1] : 0;
        $data = is_string($response) ? json_decode($response, true) : null;
        return array($status, is_array($data) ? $data : array());
    }

    private static function describe(int $status, array $data): string
    {
        $detail = $data['error']['message'] ?? ($data['message'] ?? '');
        $reason = match (true) {
            $status === 0 => '无法连接接口，请检查地址和服务器网络。',
            $status === 401, $status === 403 => 'API Key 无效或没有权限。',
            $status === 404 => '接口地址或模型不存在。',
            $status === 429 => '请求过于频繁或额度不足。',
            default => '接口返回错误（HTTP ' . $status . '）。',
        };
        return $reason . (is_string($detail) && $detail !== '' ? ' ' . mb_substr($detail, 0, 120) : '');
    }
}
