<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Geo;

/** Baidu 普通收录 / 快速收录 link submission. */
final class BaiduPusher
{
    /** @return array<string, mixed>|null Baidu's decoded answer, null when it could not be reached. */
    public static function send(string $origin, string $token, array $urls, bool $daily = false): ?array
    {
        $api = (getenv('FANGDAYS_BAIDU_PUSH_API') ?: 'http://data.zz.baidu.com/urls') . '?site=' . rawurlencode($origin) . '&token=' . rawurlencode($token) . ($daily ? '&type=daily' : '');
        $response = @file_get_contents($api, false, stream_context_create(array('http' => array('method' => 'POST', 'header' => "Content-Type: text/plain\r\n", 'content' => implode("\n", $urls), 'timeout' => 10, 'ignore_errors' => true))));
        $result = is_string($response) ? json_decode($response, true) : null;
        return is_array($result) ? $result : null;
    }
}
