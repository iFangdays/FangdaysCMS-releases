<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Geo;

use RuntimeException;

final class GeoBudgetExceeded extends RuntimeException
{
}
