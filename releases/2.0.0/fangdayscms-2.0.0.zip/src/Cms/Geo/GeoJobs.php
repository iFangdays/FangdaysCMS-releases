<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Geo;

use FangdaysCMS\Cms\Pboot\PbootConfig;
use PDO;

/** Background work: publishing queues a job, bin/geo.php (or an admin visit) runs it. */
final class GeoJobs
{
    private const BACKOFF = array(300, 1800, 7200);
    private const STALE_AFTER = 600;

    public function __construct(private readonly PDO $pdo)
    {
    }

    public function queuePush(int $postId, string $origin, int $publishAt): void
    {
        $this->queueUrl('post', $postId, $origin, $publishAt);
    }

    /** A published post also changes its category and the home page. */
    public function queueContent(int $postId, ?int $categoryId, string $origin, int $publishAt): void
    {
        $this->queueUrl('post', $postId, $origin, $publishAt);
        if ($categoryId !== null) {
            $this->queueUrl('category', $categoryId, $origin, $publishAt);
        }
        $this->queueUrl('home', 0, $origin, $publishAt);
    }

    /** One push per page, engine and day, so repeated saves spend no extra quota. */
    public function queueUrl(string $kind, int $id, string $origin, int $publishAt = 0): int
    {
        if (! (new PbootConfig($this->pdo))->on('geo_auto_push')) {
            return 0;
        }
        return $this->enqueue($kind, $id, $origin, $publishAt);
    }

    /** Every public page, for a first sync or after a migration. The manual button ignores the auto switch. */
    public function queueAll(string $origin): int
    {
        $count = 0;
        foreach ((new GeoUrl($this->pdo))->publicTargets() as [$kind, $id]) {
            $count += $this->enqueue($kind, $id, $origin, 0);
        }
        return $count;
    }

    private function enqueue(string $kind, int $id, string $origin, int $publishAt): int
    {
        $pusher = new GeoPusher($this->pdo);
        $count = 0;
        $runAfter = max(time(), $publishAt);
        foreach ($pusher->urlEngines() as $engine) {
            $count += $this->insert($engine, $kind, $id, $origin, $runAfter);
        }
        // The sitemap covers the whole site, so one submission a day is enough.
        return $count + ($pusher->googleReady() ? $this->insert('google', 'sitemap', 0, $origin, $runAfter) : 0);
    }

    private function insert(string $engine, string $kind, int $id, string $origin, int $runAfter): int
    {
        $mysql = $this->pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql';
        $now = time();
        $stmt = $this->pdo->prepare(($mysql ? 'INSERT IGNORE' : 'INSERT OR IGNORE') . " INTO geo_jobs (type, payload, dedupe_key, status, attempts, run_after, last_error, created_at, updated_at) VALUES ('push', ?, ?, 'pending', 0, ?, '', ?, ?)");
        $stmt->execute(array(json_encode(array('engine' => $engine, 'kind' => $kind, 'id' => $id, 'origin' => $origin)), 'push:' . $engine . ':' . $kind . ':' . $id . ':' . date('Ymd', $runAfter), $runAfter, $now, $now));
        return $stmt->rowCount();
    }

    /** @return array{done: int, failed: int, retry: int} */
    public function run(int $limit = 20, ?string $type = null): array
    {
        $now = time();
        $this->pdo->prepare("UPDATE geo_jobs SET status = 'pending', updated_at = ? WHERE status = 'running' AND updated_at < ?")->execute(array($now, $now - self::STALE_AFTER));
        $stmt = $this->pdo->prepare("SELECT * FROM geo_jobs WHERE status = 'pending' AND run_after <= ?" . ($type === null ? '' : ' AND type = ?') . ' ORDER BY run_after, id LIMIT ' . max(1, $limit));
        $stmt->execute($type === null ? array($now) : array($now, $type));
        $counts = array('done' => 0, 'failed' => 0, 'retry' => 0);
        $claim = $this->pdo->prepare("UPDATE geo_jobs SET status = 'running', updated_at = ? WHERE id = ? AND status = 'pending'");
        foreach ($stmt->fetchAll() as $job) {
            $claim->execute(array($now, $job['id']));
            if ($claim->rowCount() !== 1) {
                continue;
            }
            $counts[$job['type'] === 'sample' ? $this->sampleJob($job) : $this->pushJob($job)]++;
        }
        return $counts;
    }

    public function stats(): array
    {
        $counts = array('pending' => 0, 'running' => 0, 'done' => 0, 'failed' => 0);
        foreach ($this->pdo->query('SELECT status, COUNT(*) AS total FROM geo_jobs GROUP BY status') as $row) {
            $counts[(string) $row['status']] = (int) $row['total'];
        }
        return $counts;
    }

    public function recentPushes(int $limit = 20): array
    {
        return $this->pdo->query("SELECT payload, status, attempts, last_error, updated_at FROM geo_jobs WHERE type = 'push' ORDER BY id DESC LIMIT " . max(1, $limit))->fetchAll();
    }

    public function failures(int $limit = 10): array
    {
        return $this->pdo->query("SELECT id, type, payload, attempts, last_error, updated_at FROM geo_jobs WHERE status = 'failed' ORDER BY id DESC LIMIT " . max(1, $limit))->fetchAll();
    }

    private function pushJob(array $job): string
    {
        $payload = json_decode((string) $job['payload'], true);
        $payload = is_array($payload) ? $payload : array();
        // Jobs queued before multi-engine push carried only post_id.
        $kind = (string) ($payload['kind'] ?? 'post');
        $engine = (string) ($payload['engine'] ?? 'baidu');
        $origin = (string) ($payload['origin'] ?? '');
        $pusher = new GeoPusher($this->pdo);
        if ($kind === 'sitemap') {
            $result = $pusher->submitSitemap($origin);
        } else {
            $path = (new GeoUrl($this->pdo))->publicPath($kind, (int) ($payload['id'] ?? $payload['post_id'] ?? 0));
            // Hidden, deleted or unpublished since it was queued: nothing to announce.
            if ($path === null) {
                $this->finish((int) $job['id'], 'done', (int) $job['attempts'], '内容已不公开，跳过推送');
                return 'done';
            }
            $result = $pusher->send($engine, $origin, $origin . $path);
        }
        if ($result['ok']) {
            $this->finish((int) $job['id'], 'done', (int) $job['attempts'] + 1, '');
            return 'done';
        }
        if ($result['quota']) {
            $this->reschedule((int) $job['id'], (int) $job['attempts'], strtotime('tomorrow'), '配额已用完，明日继续');
            return 'retry';
        }
        return $this->failed($job, $result['message']);
    }

    private function sampleJob(array $job): string
    {
        $payload = json_decode((string) $job['payload'], true);
        $monitor = new GeoMonitor($this->pdo);
        $question = is_array($payload) ? $monitor->question((int) ($payload['question_id'] ?? 0)) : null;
        if ($question === null || $question['status'] !== 'active') {
            $this->finish((int) $job['id'], 'done', (int) $job['attempts'], '问题已归档，跳过抽样');
            return 'done';
        }
        try {
            $result = (new GeoAi($this->pdo))->chat((string) $payload['provider'], (string) $question['question']);
            $monitor->record($question, (string) $payload['provider'], 'api', $result['answer'], $result['citations'], 0);
        } catch (GeoBudgetExceeded $error) {
            $this->reschedule((int) $job['id'], (int) $job['attempts'], strtotime('tomorrow'), $error->getMessage());
            return 'retry';
        } catch (\RuntimeException | \InvalidArgumentException $error) {
            return $this->failed($job, $error->getMessage());
        }
        $this->finish((int) $job['id'], 'done', (int) $job['attempts'] + 1, '');
        return 'done';
    }

    private function failed(array $job, string $message): string
    {
        $attempts = (int) $job['attempts'] + 1;
        if (! isset(self::BACKOFF[$attempts - 1])) {
            $this->finish((int) $job['id'], 'failed', $attempts, $message);
            return 'failed';
        }
        $this->reschedule((int) $job['id'], $attempts, time() + self::BACKOFF[$attempts - 1], $message);
        return 'retry';
    }

    private function finish(int $id, string $status, int $attempts, string $error): void
    {
        $this->pdo->prepare('UPDATE geo_jobs SET status = ?, attempts = ?, last_error = ?, updated_at = ? WHERE id = ?')->execute(array($status, $attempts, mb_substr($error, 0, 255), time(), $id));
    }

    private function reschedule(int $id, int $attempts, int $runAfter, string $error): void
    {
        $this->pdo->prepare("UPDATE geo_jobs SET status = 'pending', attempts = ?, run_after = ?, last_error = ?, updated_at = ? WHERE id = ?")->execute(array($attempts, $runAfter, mb_substr($error, 0, 255), time(), $id));
    }
}
