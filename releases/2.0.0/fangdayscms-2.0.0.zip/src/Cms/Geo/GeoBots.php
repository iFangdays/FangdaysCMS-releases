<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Geo;

use FangdaysCMS\Cms\Pboot\PbootConfig;
use PDO;

/** Daily counts of AI crawlers; "User-Agent 片段=名称" lines in 配置参数 extend the list. */
final class GeoBots
{
    private const AGENTS = array('gptbot' => 'GPTBot', 'oai-searchbot' => 'OAI-SearchBot', 'chatgpt-user' => 'ChatGPT-User', 'claudebot' => 'ClaudeBot', 'claude-user' => 'Claude-User', 'claude-searchbot' => 'Claude-SearchBot', 'perplexitybot' => 'PerplexityBot', 'perplexity-user' => 'Perplexity-User', 'bytespider' => 'Bytespider', 'amazonbot' => 'Amazonbot', 'meta-externalagent' => 'Meta-ExternalAgent');

    public static function record(PDO $pdo, string $agent, string $uri): bool
    {
        $name = self::match($agent, (new PbootConfig($pdo))->get('geo_bot_agents'));
        if ($name === null) {
            return false;
        }
        $path = (string) parse_url($uri, PHP_URL_PATH);
        $group = preg_match('#^/([A-Za-z0-9_-]+)#', $path, $found) === 1 ? '/' . substr($found[1], 0, 40) : '/';
        $mysql = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql';
        $pdo->prepare('INSERT INTO geo_bot_daily (day, bot, path_group, hits) VALUES (?, ?, ?, 1) ' . ($mysql ? 'ON DUPLICATE KEY UPDATE hits = hits + 1' : 'ON CONFLICT(day, bot, path_group) DO UPDATE SET hits = hits + 1'))
            ->execute(array(date('Y-m-d'), $name, $group));
        return true;
    }

    public static function match(string $agent, string $extra = ''): ?string
    {
        $agent = strtolower($agent);
        $agents = self::AGENTS;
        foreach (preg_split('/\R/u', $extra) ?: array() as $line) {
            $parts = array_map('trim', explode('=', $line, 2));
            if (count($parts) === 2 && $parts[0] !== '' && $parts[1] !== '') {
                $agents[strtolower($parts[0])] = mb_substr($parts[1], 0, 60);
            }
        }
        foreach ($agents as $fragment => $name) {
            if (str_contains($agent, (string) $fragment)) {
                return $name;
            }
        }
        return null;
    }

    public static function summary(PDO $pdo, int $days = 30): array
    {
        $stmt = $pdo->prepare('SELECT bot, SUM(hits) AS hits, MAX(day) AS last_day FROM geo_bot_daily WHERE day >= ? GROUP BY bot ORDER BY hits DESC');
        $stmt->execute(array(date('Y-m-d', time() - $days * 86400)));
        return $stmt->fetchAll();
    }
}
