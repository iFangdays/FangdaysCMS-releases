<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Geo;

use FangdaysCMS\Cms\Pboot\PbootConfig;
use PDO;

/**
 * Link submission to search engines that offer a general-purpose API. Google's Indexing API only
 * accepts job and livestream pages, so Google gets the sitemap through Search Console instead.
 */
final class GeoPusher
{
    public const URL_ENGINES = array('baidu' => '百度普通收录', 'baidu_daily' => '百度快速收录', 'indexnow' => 'IndexNow（Bing 等）');

    private readonly PbootConfig $config;

    public function __construct(private readonly PDO $pdo)
    {
        $this->config = new PbootConfig($pdo);
    }

    /** @return list<string> engines that take single addresses and are set up on this site */
    public function urlEngines(): array
    {
        $engines = array();
        if ($this->config->get('baidu_zz_token') !== '') {
            $engines[] = 'baidu';
        }
        if ($this->config->get('baidu_ks_token') !== '' && $this->config->on('geo_baidu_daily')) {
            $engines[] = 'baidu_daily';
        }
        if ($this->config->on('geo_indexnow')) {
            $engines[] = 'indexnow';
        }
        return $engines;
    }

    public function googleReady(): bool
    {
        return $this->config->get('geo_google_site') !== '' && $this->config->get('geo_google_account') !== '';
    }

    /** The key is public by design: search engines read it back from /{key}.txt. */
    public function indexNowKey(): string
    {
        $key = $this->config->get('geo_indexnow_key');
        if ($key === '') {
            $key = bin2hex(random_bytes(16));
            $this->config->store(array('geo_indexnow_key' => $key));
        }
        return $key;
    }

    /** @return array{ok: bool, quota: bool, message: string} */
    public function send(string $engine, string $origin, string $url): array
    {
        return match ($engine) {
            'baidu', 'baidu_daily' => $this->baidu($engine === 'baidu_daily', $origin, $url),
            'indexnow' => $this->indexNow($origin, $url),
            default => self::result(false, false, '未知推送渠道'),
        };
    }

    /** @return array{ok: bool, quota: bool, message: string} */
    public function submitSitemap(string $origin): array
    {
        $account = json_decode($this->config->get('geo_google_account'), true);
        if (! is_array($account) || ! is_string($account['client_email'] ?? null) || ! is_string($account['private_key'] ?? null)) {
            return self::result(false, false, 'Google 服务账号 JSON 无效');
        }
        if (! extension_loaded('openssl')) {
            return self::result(false, false, '服务器缺少 openssl 扩展');
        }
        $base = rtrim((string) (getenv('FANGDAYS_GOOGLE_API') ?: ''), '/');
        $tokenUrl = $base !== '' ? $base . '/token' : 'https://oauth2.googleapis.com/token';
        $now = time();
        $segment = static fn (array $data): string => rtrim(strtr(base64_encode((string) json_encode($data)), '+/', '-_'), '=');
        $unsigned = $segment(array('alg' => 'RS256', 'typ' => 'JWT')) . '.' . $segment(array('iss' => $account['client_email'], 'scope' => 'https://www.googleapis.com/auth/webmasters', 'aud' => $tokenUrl, 'iat' => $now, 'exp' => $now + 3000));
        $signature = '';
        if (! @openssl_sign($unsigned, $signature, $account['private_key'], 'sha256WithRSAEncryption')) {
            return self::result(false, false, 'Google 服务账号私钥无效');
        }
        [$status, $body] = self::request('POST', $tokenUrl, "Content-Type: application/x-www-form-urlencoded\r\n", http_build_query(array('grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer', 'assertion' => $unsigned . '.' . rtrim(strtr(base64_encode($signature), '+/', '-_'), '='))));
        $token = json_decode($body, true)['access_token'] ?? null;
        if (! is_string($token)) {
            return self::result(false, false, 'Google 授权失败（HTTP ' . $status . '）');
        }
        $feed = $origin . '/sitemap.xml';
        $submit = ($base !== '' ? $base : 'https://www.googleapis.com/webmasters/v3') . '/sites/' . rawurlencode($this->config->get('geo_google_site')) . '/sitemaps/' . rawurlencode($feed);
        [$status] = self::request('PUT', $submit, "Authorization: Bearer " . $token . "\r\nContent-Length: 0\r\n", '');
        return $status >= 200 && $status < 300 ? self::result(true, false, '') : self::result(false, $status === 429, 'Google 提交失败（HTTP ' . $status . '），请确认服务账号已加入 Search Console 站点');
    }

    private function baidu(bool $daily, string $origin, string $url): array
    {
        $token = $this->config->get($daily ? 'baidu_ks_token' : 'baidu_zz_token');
        if ($token === '') {
            return self::result(false, false, '未配置百度 token');
        }
        $result = BaiduPusher::send($origin, $token, array($url), $daily);
        if ($result === null) {
            return self::result(false, false, '百度接口无法访问');
        }
        if (! isset($result['error'])) {
            return self::result(true, false, '');
        }
        $message = (string) ($result['message'] ?? $result['error']);
        return self::result(false, stripos($message, 'over quota') !== false, $message);
    }

    private function indexNow(string $origin, string $url): array
    {
        $host = (string) parse_url($origin, PHP_URL_HOST);
        $key = $this->indexNowKey();
        [$status] = self::request('POST', (getenv('FANGDAYS_INDEXNOW_API') ?: 'https://api.indexnow.org/indexnow'), "Content-Type: application/json; charset=utf-8\r\n", (string) json_encode(array('host' => $host, 'key' => $key, 'keyLocation' => $origin . '/' . $key . '.txt', 'urlList' => array($url))));
        if ($status === 200 || $status === 202) {
            return self::result(true, false, '');
        }
        return self::result(false, $status === 429, 'IndexNow 返回 HTTP ' . $status);
    }

    /** @return array{0: int, 1: string} */
    private static function request(string $method, string $url, string $headers, string $content): array
    {
        $body = @file_get_contents($url, false, stream_context_create(array('http' => array('method' => $method, 'header' => $headers, 'content' => $content, 'timeout' => 10, 'ignore_errors' => true))));
        $status = isset($http_response_header[0]) && preg_match('#\s(\d{3})\s?#', $http_response_header[0], $found) === 1 ? (int) $found[1] : 0;
        return array($status, is_string($body) ? $body : '');
    }

    private static function result(bool $ok, bool $quota, string $message): array
    {
        return array('ok' => $ok, 'quota' => $quota, 'message' => $message);
    }
}
