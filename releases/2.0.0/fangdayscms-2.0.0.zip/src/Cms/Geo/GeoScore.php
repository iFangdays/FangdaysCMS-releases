<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Geo;

use FangdaysCMS\Cms\OperationsRepository;
use PDO;

/** Local editing advice, no external AI. The score never blocks publishing. */
final class GeoScore
{
    private const SAMPLE = 500;
    private const MIN_LENGTH = 300;
    private const STALE_DAYS = 365;
    public const MAX_SCORE = 100;
    public const GOOD_SCORE = 80;
    public const PASS_SCORE = 60;

    /** check => [label, points, advice when it fails]; the points add up to MAX_SCORE. */
    public const RULES = array(
        'summary' => array('一句话结论', 20, '在正文前写一句话结论，直接回答读者的问题。'),
        'headings' => array('小标题结构', 15, '用至少两个小标题拆分内容。'),
        'faq' => array('常见问题', 15, '补充至少两条真实的常见问题。'),
        'lists' => array('列表或表格', 10, '用列表或表格呈现可比较的信息。'),
        'numbers' => array('具体数字', 10, '加入具体数字、规格或日期。'),
        'source' => array('作者或来源', 10, '注明作者、来源或引用链接。'),
        'fresh' => array('一年内更新过', 10, '内容超过一年未更新，请复核。'),
        'length' => array('正文长度', 10, '正文偏短，至少写到 ' . self::MIN_LENGTH . ' 字。'),
    );

    public function __construct(private readonly PDO $pdo)
    {
    }

    /** @return array{key: string, label: string} */
    public static function grade(int $score): array
    {
        return match (true) {
            $score >= self::GOOD_SCORE => array('key' => 'good', 'label' => '优秀'),
            $score >= self::PASS_SCORE => array('key' => 'pass', 'label' => '及格'),
            default => array('key' => 'low', 'label' => '待优化'),
        };
    }

    /** @return array{score: int, issues: list<string>, checks: array<string, bool>} */
    public static function evaluate(string $title, string $body, array $meta, int $lastmod, string $author, string $source, string $keywords, array $knownContacts): array
    {
        $text = trim((string) preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags($body), ENT_QUOTES | ENT_HTML5, 'UTF-8')));
        $length = mb_strlen($text);
        $score = 0;
        $issues = array();
        $checks = array(
            'summary' => $meta['summary'] !== '',
            'headings' => preg_match_all('/<h[2-4]\b/i', $body) >= 2,
            'lists' => preg_match('/<(?:ul|ol|table)\b/i', $body) === 1,
            'faq' => count($meta['faq']) >= 2,
            'numbers' => preg_match('/\d/u', $text) === 1,
            'source' => $author !== '' || $source !== '' || preg_match('/<a\b[^>]*href=/i', $body) === 1,
            'fresh' => $lastmod >= time() - self::STALE_DAYS * 86400,
            'length' => $length >= self::MIN_LENGTH,
        );
        foreach ($checks as $key => $passed) {
            if ($passed) {
                $score += self::RULES[$key][1];
            } else {
                $issues[] = self::RULES[$key][2];
            }
        }
        foreach (array_filter(array_map('trim', preg_split('/[,，]/u', $keywords) ?: array())) as $keyword) {
            if ($length > 0 && mb_substr_count($text, $keyword) * mb_strlen($keyword) > $length * 0.08) {
                $score -= 15;
                $issues[] = '关键词“' . $keyword . '”出现过多，疑似堆砌。';
            }
        }
        if ($knownContacts) {
            preg_match_all('/\b1[3-9]\d{9}\b|[\w.+-]+@[\w-]+\.[\w.-]+/u', $text, $found);
            foreach (array_unique($found[0]) as $contact) {
                if (! in_array($contact, $knownContacts, true)) {
                    $issues[] = '联系方式 ' . $contact . ' 与事实库不一致，请核对。';
                }
            }
        }
        return array('score' => max(0, $score), 'issues' => $issues, 'checks' => $checks);
    }

    public function post(int $id): ?array
    {
        $stmt = $this->pdo->prepare("SELECT p.title, p.body, p.updated_at, COALESCE(pm.author, '') AS author, COALESCE(pm.source, '') AS source, COALESCE(pm.seo_keywords, '') AS seo_keywords, COALESCE(pm.published_at, 0) AS published_at FROM posts p LEFT JOIN post_meta pm ON pm.post_id = p.id WHERE p.id = ?");
        $stmt->execute(array($id));
        $row = $stmt->fetch();
        if ($row === false) {
            return null;
        }
        $meta = (new GeoRepository($this->pdo))->meta('post', $id);
        return self::evaluate((string) $row['title'], (string) $row['body'], $meta, max((int) $row['updated_at'], (int) $row['published_at']), (string) $row['author'], (string) $row['source'], (string) $row['seo_keywords'], $this->contacts());
    }

    /** Rescore public posts whose content changed; returns how many were scored. */
    public function refresh(): int
    {
        $count = 0;
        $mysql = $this->pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql';
        $known = $this->pdo->prepare("SELECT content_hash FROM geo_scores WHERE entity_type = 'post' AND entity_id = ?");
        $save = $this->pdo->prepare(($mysql ? 'REPLACE' : 'INSERT OR REPLACE') . " INTO geo_scores (entity_type, entity_id, score, issues_json, content_hash, created_at) VALUES ('post', ?, ?, ?, ?, ?)");
        foreach (array_slice((new GeoUrl($this->pdo))->publicPosts(), 0, self::SAMPLE) as $post) {
            $result = $this->post((int) $post['id']);
            $hash = hash('sha256', (string) json_encode(array($post['lastmod'], $result)));
            $known->execute(array($post['id']));
            if ($known->fetchColumn() === $hash) {
                continue;
            }
            $save->execute(array($post['id'], $result['score'], json_encode($result['issues'], JSON_UNESCAPED_UNICODE), $hash, time()));
            $count++;
        }
        return $count;
    }

    /** Public posts, weakest first; unscored posts come last with a null score. */
    public function ranking(int $limit = 100): array
    {
        $scores = array();
        foreach ($this->pdo->query("SELECT entity_id, score, issues_json FROM geo_scores WHERE entity_type = 'post'") as $row) {
            $scores[(int) $row['entity_id']] = $row;
        }
        $points = array_column(self::RULES, 1, 2);
        $rows = array();
        foreach ((new GeoUrl($this->pdo))->publicPosts() as $post) {
            $score = $scores[(int) $post['id']] ?? null;
            $issues = $score === null ? array() : json_decode((string) $score['issues_json'], true);
            $issues = is_array($issues) ? $issues : array();
            $rows[] = array('id' => (int) $post['id'], 'title' => (string) $post['title'], 'path' => (string) $post['path'], 'score' => $score === null ? null : (int) $score['score'], 'issues' => $issues, 'gain' => (int) ($points[$issues[0] ?? ''] ?? 0));
        }
        usort($rows, static fn (array $a, array $b): int => ($a['score'] ?? PHP_INT_MAX) <=> ($b['score'] ?? PHP_INT_MAX));
        return array_slice($rows, 0, $limit);
    }

    /** Where the site stands, for comparing one page with the rest. @return array{average: ?int, scored: int, good: int, pass: int, low: int} */
    public function summary(): array
    {
        $public = array_flip(array_map('intval', array_column((new GeoUrl($this->pdo))->publicPosts(), 'id')));
        $stmt = $this->pdo->query("SELECT entity_id, score FROM geo_scores WHERE entity_type = 'post'");
        $scores = array();
        foreach ($stmt as $row) {
            if (isset($public[(int) $row['entity_id']])) {
                $scores[] = (int) $row['score'];
            }
        }
        $count = static fn (string $key): int => count(array_filter($scores, static fn (int $score): bool => self::grade($score)['key'] === $key));
        return array('average' => $scores ? (int) round(array_sum($scores) / count($scores)) : null, 'scored' => count($scores), 'good' => $count('good'), 'pass' => $count('pass'), 'low' => $count('low'));
    }

    private function contacts(): array
    {
        $company = (new OperationsRepository($this->pdo))->company();
        $contacts = array_filter(array((string) ($company['phone'] ?? ''), (string) ($company['mobile'] ?? ''), (string) ($company['email'] ?? '')));
        foreach ((new GeoRepository($this->pdo))->facts(null, 'confirmed') as $fact) {
            if ($fact['category'] === 'contact') {
                $contacts[] = (string) $fact['value'];
            }
        }
        return array_values($contacts);
    }
}
