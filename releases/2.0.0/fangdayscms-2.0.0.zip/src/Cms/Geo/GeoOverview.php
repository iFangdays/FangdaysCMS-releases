<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Geo;

use FangdaysCMS\Cms\Pboot\PbootConfig;
use PDO;

/** The GEO work as one path: what is done, what comes next, and the last audit. */
final class GeoOverview
{
    private const MIN_FACTS = 3;

    public function __construct(private readonly PDO $pdo, private readonly string $siteHost)
    {
    }

    /** @return list<array{title: string, why: string, done: bool, status: string, href: string, action: string, optional: bool}> */
    public function steps(): array
    {
        $facts = (new GeoRepository($this->pdo))->facts(null, 'confirmed');
        $pusher = new GeoPusher($this->pdo);
        $scores = (new GeoScore($this->pdo))->summary();
        $monitor = new GeoMonitor($this->pdo);
        $questions = count($monitor->questions());
        $samples = (int) $this->pdo->query('SELECT COUNT(*) FROM geo_samples')->fetchColumn();
        $models = (new GeoAi($this->pdo))->configured();
        $channels = count($pusher->urlEngines()) + ($pusher->googleReady() ? 1 : 0);
        return array(
            array('title' => '完善品牌事实库', 'why' => '公司、产品、服务和联系方式经确认后写入结构化数据，AI 和搜索引擎读到的信息才准确。', 'done' => count($facts) >= self::MIN_FACTS, 'status' => '已确认 ' . count($facts) . ' 条，建议至少 ' . self::MIN_FACTS . ' 条', 'href' => '/admin/geo/facts', 'action' => '去确认事实', 'optional' => false),
            array('title' => '打开收录推送', 'why' => '发布后自动通知搜索引擎。国内 AI 主要从搜索索引取材，先被收录才有机会被引用。', 'done' => $channels > 0, 'status' => $channels > 0 ? '已启用 ' . $channels . ' 个渠道' : '还没有启用渠道', 'href' => '/admin/geo/push', 'action' => '去配置推送', 'optional' => false),
            array('title' => '把内容改到及格', 'why' => '按评分建议补结论、小标题和 FAQ，让内容更容易被整段引用。', 'done' => $scores['average'] !== null && $scores['average'] >= GeoScore::PASS_SCORE, 'status' => $scores['average'] === null ? '还没有评分' : '站点平均 ' . $scores['average'] . ' / ' . GeoScore::MAX_SCORE . ' 分，及格线 ' . GeoScore::PASS_SCORE . ' 分', 'href' => '/admin/geo/content', 'action' => '去优化内容', 'optional' => false),
            array('title' => '接入 AI 接口', 'why' => '用来改写内容、生成 FAQ，并自动向 AI 提问抽样。不接入也能用其他功能。', 'done' => $models !== array(), 'status' => $models ? '已接入：' . implode('、', $models) : '未接入', 'href' => '/admin/geo/ai', 'action' => '去接入', 'optional' => true),
            array('title' => '用真实问题看效果', 'why' => '记录 AI 回答里有没有提到你、排第几、引用了哪里，按周看变化。', 'done' => $samples > 0, 'status' => $samples > 0 ? $questions . ' 个问题，' . $samples . ' 条样本' : ($questions > 0 ? $questions . ' 个问题，还没有样本' : '还没有问题'), 'href' => '/admin/geo/monitor', 'action' => '去记录', 'optional' => false),
        );
    }

    /** @return array{at: int, items: list<array{group: string, level: string, title: string, detail: string}>}|null */
    public function lastAudit(): ?array
    {
        $saved = json_decode((new PbootConfig($this->pdo))->get('geo_audit_last'), true);
        return is_array($saved) && isset($saved['at'], $saved['items']) ? $saved : null;
    }

    public function saveAudit(array $items): void
    {
        (new PbootConfig($this->pdo))->store(array('geo_audit_last' => (string) json_encode(array('at' => time(), 'items' => $items), JSON_UNESCAPED_UNICODE)));
    }

    /** @return array{ok: int, warn: int, fail: int} */
    public static function auditCounts(array $items): array
    {
        $counts = array('ok' => 0, 'warn' => 0, 'fail' => 0);
        foreach ($items as $item) {
            $counts[$item['level']]++;
        }
        return $counts;
    }

    /** @return array{samples: int, rate: int, position: ?float, cited: int, channel: string}|null */
    public function headline(): ?array
    {
        return GeoMonitor::headline((new GeoMonitor($this->pdo))->report($this->siteHost));
    }
}
