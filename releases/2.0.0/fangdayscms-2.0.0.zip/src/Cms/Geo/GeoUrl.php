<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Geo;

use FangdaysCMS\Cms\ContentRepository;
use FangdaysCMS\Cms\PageLevel;
use FangdaysCMS\Cms\Pboot\PbootData;
use FangdaysCMS\Cms\Pboot\PbootSite;
use FangdaysCMS\Cms\Pboot\PbootUrl;
use FangdaysCMS\Cms\View;
use PDO;

/** The one public address of each page, and which content anonymous visitors may reach. */
final class GeoUrl
{
    private readonly ?PbootUrl $url;
    private readonly PbootData $data;
    private readonly PageLevel $levels;

    public function __construct(private readonly PDO $pdo, string $locale = 'zh-CN')
    {
        $this->url = PbootUrl::fromSettings(PbootSite::settings($pdo));
        $this->data = new PbootData($pdo, $locale, null, $this->url);
        $this->levels = new PageLevel($pdo);
    }

    /** Publicly readable posts, newest first, each with its address and last change. */
    public function publicPosts(?int $postId = null): array
    {
        $sql = "SELECT p.id, p.title, p.slug, p.category_id, p.created_at, p.updated_at, COALESCE(pm.published_at, 0) AS published_at, COALESCE(pm.gcode, '') AS gcode, COALESCE(pm.gtype, 4) AS gtype, COALESCE(s.gcode, '') AS sort_gcode, COALESCE(s.gtype, 4) AS sort_gtype
            FROM posts p LEFT JOIN post_meta pm ON pm.post_id = p.id LEFT JOIN post_visibility v ON v.post_id = p.id LEFT JOIN category_settings s ON s.category_id = p.category_id
            WHERE p.status = 'published' AND COALESCE(NULLIF(pm.published_at, 0), p.created_at) <= (? + 0) AND COALESCE(v.visibility, 'public') = 'public' AND COALESCE(pm.outlink, '') = '' AND COALESCE(s.type, 'list') <> 'single'";
        $params = array(time());
        if ($postId !== null) {
            $sql .= ' AND p.id = ?';
            $params[] = $postId;
        }
        $stmt = $this->pdo->prepare($sql . ' ORDER BY p.id DESC');
        $stmt->execute($params);
        $posts = array();
        foreach ($stmt->fetchAll() as $row) {
            if ($this->levels->denied(array('gcode' => $row['gcode'], 'gtype' => $row['gtype']), null) || $this->levels->denied(array('gcode' => $row['sort_gcode'], 'gtype' => $row['sort_gtype']), null)) {
                continue;
            }
            $row['path'] = $this->postPath($row);
            $row['lastmod'] = max((int) $row['published_at'], (int) $row['updated_at'], (int) $row['created_at']);
            $posts[] = $row;
        }
        return $posts;
    }

    /** Address of a pushable page, or null when it is not public right now. */
    public function publicPath(string $kind, int $id): ?string
    {
        if ($kind === 'home') {
            return View::localizedPath('/');
        }
        if ($kind === 'post') {
            return $this->publicPosts($id)[0]['path'] ?? null;
        }
        if ($kind === 'page') {
            $stmt = $this->pdo->prepare("SELECT slug FROM pages WHERE id = ? AND status = 'published'");
            $stmt->execute(array($id));
            $slug = $stmt->fetchColumn();
            return $slug === false ? null : View::localizedPath('/page/' . rawurlencode((string) $slug));
        }
        if ($kind === 'category') {
            foreach ($this->publicCategories() as $category) {
                if ((int) $category['id'] === $id) {
                    return $this->categoryPath($category);
                }
            }
        }
        return null;
    }

    /** @return list<array{0: string, 1: int}> every public page as [kind, id] */
    public function publicTargets(): array
    {
        $targets = array(array('home', 0));
        foreach ($this->publicCategories() as $category) {
            $targets[] = array('category', (int) $category['id']);
        }
        foreach ($this->pdo->query("SELECT id FROM pages WHERE status = 'published' ORDER BY id") as $page) {
            $targets[] = array('page', (int) $page['id']);
        }
        foreach ($this->publicPosts() as $post) {
            $targets[] = array('post', (int) $post['id']);
        }
        return $targets;
    }

    /** Categories a visitor can open: the sitemap and every push use this one rule. */
    public function publicCategories(): array
    {
        return array_values(array_filter((new ContentRepository($this->pdo))->categories(), fn (array $category): bool => (int) $category['is_visible'] === 1 && ($category['type'] ?? 'list') !== 'link' && (($category['type'] ?? '') !== 'single' || ($category['single_status'] ?? '') === 'published') && $this->categoryIsPublic((int) $category['id'])));
    }

    public function postPath(array $post): string
    {
        $sort = $post['category_id'] === null ? array() : ($this->data->sort((string) $post['category_id']) ?? array());
        return $this->data->contentLink(array(
            'id' => (string) $post['id'], 'type' => '2', 'filename' => (string) $post['slug'], 'scode' => (string) ($post['category_id'] ?? ''),
            'urlname' => (string) ($sort['urlname'] ?? ''), 'sortfilename' => (string) ($sort['filename'] ?? '')
        ));
    }

    public function categoryPath(array $category): string
    {
        $sort = $this->data->sort((string) ($category['id'] ?? ''));
        return $sort !== null && ($sort['outlink'] ?? '') === '' ? $this->data->sortLink($sort) : View::localizedPath('/category/' . rawurlencode((string) $category['slug']));
    }

    /** @return list<array{name: string, path: string, description: string}> the category and its parents, top first */
    public function trail(int $categoryId): array
    {
        return array_map(fn (array $sort): array => array('name' => (string) $sort['name'], 'path' => $this->categoryPath(array('id' => $sort['scode'], 'slug' => $sort['filename'])), 'description' => (string) ($sort['description'] ?? '')), $this->data->position((string) $categoryId));
    }

    /** Site identity of this region; areas can differ from the canonical settings. */
    public function site(): array
    {
        return $this->data->site();
    }

    public function company(): array
    {
        return $this->data->company();
    }

    public function plainRoutes(): bool
    {
        return $this->url === null;
    }

    public function categoryIsPublic(int $categoryId): bool
    {
        $stmt = $this->pdo->prepare('SELECT gcode, gtype FROM category_settings WHERE category_id = ?');
        $stmt->execute(array($categoryId));
        $rule = $stmt->fetch();
        return $rule === false || ! $this->levels->denied($rule, null);
    }
}
