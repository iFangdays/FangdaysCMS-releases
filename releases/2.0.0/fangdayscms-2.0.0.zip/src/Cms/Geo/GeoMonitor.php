<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Geo;

use FangdaysCMS\Cms\Pboot\PbootConfig;
use InvalidArgumentException;
use PDO;

/** Question sets answered by AI platforms: sampled by API or recorded by hand from the apps. */
final class GeoMonitor
{
    /** Apps with no API of their own still get manual rows. */
    public const PLATFORMS = array('doubao' => '豆包', 'qwen' => '千问', 'deepseek' => 'DeepSeek', 'ernie' => '文心', 'yuanbao' => '元宝（混元）', 'other' => '其他');
    private const MANUAL_EVERY_DAYS = 14;

    public function __construct(private readonly PDO $pdo)
    {
    }

    public function questions(bool $activeOnly = true): array
    {
        return $this->pdo->query('SELECT * FROM geo_questions' . ($activeOnly ? " WHERE status = 'active'" : '') . ' ORDER BY id')->fetchAll();
    }

    public function question(int $id): ?array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM geo_questions WHERE id = ?');
        $stmt->execute(array($id));
        return $stmt->fetch() ?: null;
    }

    public function saveQuestion(string $question, string $brands, string $competitors): void
    {
        [$question, $brands, $competitors] = array(trim($question), trim($brands), trim($competitors));
        if ($question === '' || mb_strlen($question) > 300 || $brands === '' || mb_strlen($brands) > 500 || mb_strlen($competitors) > 500) {
            throw new InvalidArgumentException('问题或品牌词长度无效。');
        }
        $this->pdo->prepare("INSERT INTO geo_questions (question, brand_terms, competitor_terms, status, created_at) VALUES (?, ?, ?, 'active', ?)")->execute(array($question, $brands, $competitors, time()));
    }

    public function archiveQuestion(int $id): void
    {
        $this->pdo->prepare("UPDATE geo_questions SET status = 'archived' WHERE id = ?")->execute(array($id));
    }

    /** @return array{mentioned: bool, position: int, competitors: list<string>, cited: list<string>} position 1 = named first */
    public static function analyze(string $answer, string $brandTerms, string $competitorTerms, array $citations = array()): array
    {
        $terms = static fn (string $list): array => array_values(array_filter(array_map('trim', preg_split('/[,，\n]/u', $list) ?: array())));
        $first = static function (array $names) use ($answer): ?int {
            $positions = array_filter(array_map(static fn (string $name) => mb_stripos($answer, $name), $names), static fn ($position): bool => $position !== false);
            return $positions ? min($positions) : null;
        };
        $brand = $first($terms($brandTerms));
        $seen = array();
        foreach ($terms($competitorTerms) as $name) {
            $position = $first(array($name));
            if ($position !== null) {
                $seen[$name] = $position;
            }
        }
        $rank = 0;
        if ($brand !== null) {
            $rank = 1 + count(array_filter($seen, static fn (int $position): bool => $position < $brand));
        }
        preg_match_all('#https?://[^\s<>"\')\]，。）]+#u', $answer, $found);
        return array('mentioned' => $brand !== null, 'position' => $rank, 'competitors' => array_keys($seen), 'cited' => array_values(array_unique(array_merge($found[0], $citations))));
    }

    public function record(array $question, string $platform, string $channel, string $answer, array $citations, int $recordedBy, int $sampledAt = 0): void
    {
        $answer = trim($answer);
        if (! isset(self::PLATFORMS[$platform]) || $answer === '' || mb_strlen($answer) > 20000) {
            throw new InvalidArgumentException('平台或回答内容无效。');
        }
        $result = self::analyze($answer, (string) $question['brand_terms'], (string) $question['competitor_terms'], $citations);
        $this->pdo->prepare('INSERT INTO geo_samples (question_id, platform, channel, answer, mentioned, position, competitors_json, cited_urls_json, sampled_at, recorded_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute(array($question['id'], $platform, $channel, $answer, $result['mentioned'] ? 1 : 0, $result['position'], json_encode($result['competitors'], JSON_UNESCAPED_UNICODE), json_encode($result['cited'], JSON_UNESCAPED_UNICODE), $sampledAt ?: time(), $recordedBy));
    }

    /** One job per question, platform and repeat, per day; answers vary, so one call proves little. */
    public function queueSamples(): int
    {
        $config = new PbootConfig($this->pdo);
        $repeat = max(1, min(10, (int) $config->get('geo_sample_repeat')));
        $providers = array_keys((new GeoAi($this->pdo))->configured());
        $mysql = $this->pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql';
        $insert = $this->pdo->prepare(($mysql ? 'INSERT IGNORE' : 'INSERT OR IGNORE') . " INTO geo_jobs (type, payload, dedupe_key, status, attempts, run_after, last_error, created_at, updated_at) VALUES ('sample', ?, ?, 'pending', 0, ?, '', ?, ?)");
        $now = time();
        $count = 0;
        foreach ($this->questions() as $question) {
            foreach ($providers as $provider) {
                for ($n = 1; $n <= $repeat; $n++) {
                    $insert->execute(array(json_encode(array('question_id' => (int) $question['id'], 'provider' => $provider)), 'sample:' . $question['id'] . ':' . $provider . ':' . date('Ymd', $now) . ':' . $n, $now, $now, $now));
                    $count += $insert->rowCount();
                }
            }
        }
        return $count;
    }

    /** bin/geo.php queues a round when geo_sample_days have passed; 0 leaves sampling manual. */
    public function queueIfDue(): int
    {
        $days = (int) (new PbootConfig($this->pdo))->get('geo_sample_days');
        if ($days < 1) {
            return 0;
        }
        $last = (int) $this->pdo->query("SELECT COALESCE(MAX(created_at), 0) FROM geo_jobs WHERE type = 'sample'")->fetchColumn();
        return $last > time() - $days * 86400 ? 0 : $this->queueSamples();
    }

    /** Questions with no app reading recently, since API answers can differ from what users see. */
    public function manualDue(): array
    {
        $stmt = $this->pdo->prepare("SELECT q.* FROM geo_questions q WHERE q.status = 'active' AND NOT EXISTS (SELECT 1 FROM geo_samples s WHERE s.question_id = q.id AND s.channel = 'manual' AND s.sampled_at > ?) ORDER BY q.id");
        $stmt->execute(array(time() - self::MANUAL_EVERY_DAYS * 86400));
        return $stmt->fetchAll();
    }

    /** Latest recorded answers, so a reading can be checked against what the platform actually said. */
    public function recentSamples(int $limit = 20): array
    {
        $stmt = $this->pdo->prepare('SELECT s.platform, s.channel, s.answer, s.mentioned, s.position, s.sampled_at, q.question FROM geo_samples s JOIN geo_questions q ON q.id = s.question_id ORDER BY s.sampled_at DESC, s.id DESC LIMIT ' . max(1, $limit));
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /** The headline figures of the richer channel; API and app answers stay apart, as in report(). @return array{samples: int, rate: int, position: ?float, cited: int, channel: string}|null */
    public static function headline(array $report): ?array
    {
        $groups = array('api' => array_filter($report['groups'], static fn (array $group): bool => $group['channel'] === 'api'), 'manual' => array_filter($report['groups'], static fn (array $group): bool => $group['channel'] !== 'api'));
        $samples = static fn (array $rows): int => (int) array_sum(array_column($rows, 'samples'));
        $channel = $samples($groups['api']) >= $samples($groups['manual']) ? 'api' : 'manual';
        $rows = $groups[$channel];
        if ($samples($rows) === 0) {
            return null;
        }
        $positions = array_merge(...array_values(array_column($rows, 'positions')));
        return array('samples' => $samples($rows), 'rate' => (int) round(array_sum(array_column($rows, 'mentioned')) / $samples($rows) * 100), 'position' => $positions ? round(array_sum($positions) / count($positions), 1) : null, 'cited' => (int) array_sum(array_column($rows, 'site_cited')), 'channel' => $channel);
    }

    /** Made-up figures in the shape of report(), shown only inside a labelled example. */
    public static function exampleReport(): array
    {
        $weeks = array('第 1 周' => array(9, 3), '第 2 周' => array(9, 4), '第 3 周' => array(9, 5), '第 4 周' => array(9, 7));
        $series = array_map(static fn (array $week): array => array('samples' => $week[0], 'mentioned' => $week[1]), $weeks);
        return array(
            'groups' => array(
                array('platform' => 'deepseek', 'channel' => 'api', 'samples' => 36, 'mentioned' => 19, 'positions' => array_merge(array_fill(0, 11, 1), array_fill(0, 8, 2)), 'site_cited' => 6, 'weeks' => $series),
                array('platform' => 'doubao', 'channel' => 'manual', 'samples' => 8, 'mentioned' => 3, 'positions' => array(1, 2, 3), 'site_cited' => 1, 'weeks' => array('第 3 周' => array('samples' => 4, 'mentioned' => 1), '第 4 周' => array('samples' => 4, 'mentioned' => 2))),
            ),
            'competitors' => array('竞品 A' => 14, '竞品 B' => 6),
            'domains' => array('brand.example' => 7, 'zhihu.example' => 5, 'baike.example' => 3),
        );
    }

    /** Totals per platform and channel: the two channels are never added together. */
    public function report(string $siteHost, int $days = 90): array
    {
        $stmt = $this->pdo->prepare('SELECT platform, channel, mentioned, position, competitors_json, cited_urls_json, sampled_at FROM geo_samples WHERE sampled_at >= ?');
        $stmt->execute(array(time() - $days * 86400));
        $groups = array();
        $domains = array();
        $competitors = array();
        foreach ($stmt->fetchAll() as $row) {
            $key = $row['platform'] . '|' . $row['channel'];
            $groups[$key] ??= array('platform' => (string) $row['platform'], 'channel' => (string) $row['channel'], 'samples' => 0, 'mentioned' => 0, 'positions' => array(), 'site_cited' => 0, 'weeks' => array());
            $group = &$groups[$key];
            $group['samples']++;
            $group['mentioned'] += (int) $row['mentioned'];
            if ((int) $row['position'] > 0) {
                $group['positions'][] = (int) $row['position'];
            }
            $week = date('o-\WW', (int) $row['sampled_at']);
            $group['weeks'][$week] ??= array('samples' => 0, 'mentioned' => 0);
            $group['weeks'][$week]['samples']++;
            $group['weeks'][$week]['mentioned'] += (int) $row['mentioned'];
            $cited = false;
            foreach ((array) json_decode((string) $row['cited_urls_json'], true) as $url) {
                $host = strtolower((string) parse_url((string) $url, PHP_URL_HOST));
                if ($host === '') {
                    continue;
                }
                $domains[$host] = ($domains[$host] ?? 0) + 1;
                $cited = $cited || $host === strtolower($siteHost);
            }
            $group['site_cited'] += $cited ? 1 : 0;
            unset($group);
            foreach ((array) json_decode((string) $row['competitors_json'], true) as $name) {
                $competitors[(string) $name] = ($competitors[(string) $name] ?? 0) + 1;
            }
        }
        arsort($domains);
        arsort($competitors);
        ksort($groups);
        return array('groups' => array_values($groups), 'domains' => array_slice($domains, 0, 15, true), 'competitors' => array_slice($competitors, 0, 15, true));
    }
}
