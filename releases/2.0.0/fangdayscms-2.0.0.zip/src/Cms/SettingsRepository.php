<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;
use PDO;

final class SettingsRepository
{
    public function __construct(private readonly PDO $pdo)
    {
    }

    public function all(string $defaultName): array
    {
        $values = array('site_name' => $defaultName, 'description' => '', 'footer_text' => 'Powered by FangdaysCMS', 'footer_text_en' => '', 'desktop_template' => '', 'mobile_template' => '', 'search_template' => '', 'desktop_template_en' => '', 'mobile_template_en' => '', 'search_template_en' => '', 'locale' => 'zh-CN', 'site_name_en' => '', 'description_en' => '', 'seo_title' => '', 'seo_keywords' => '', 'seo_description' => '', 'seo_title_en' => '', 'seo_keywords_en' => '', 'seo_description_en' => '', 'pboot_theme' => '');
        foreach ($this->pdo->query('SELECT name, value FROM site_settings') as $row) {
            if (array_key_exists($row['name'], $values)) {
                $values[$row['name']] = $row['value'];
            }
        }
        return $values;
    }

    public function save(string $name, string $description, string $footer, string $desktopTemplate = '', string $mobileTemplate = '', string $locale = 'zh-CN', string $nameEn = '', string $descriptionEn = '', string $seoTitleEn = '', string $seoKeywordsEn = '', string $seoDescriptionEn = '', string $searchTemplate = '', string $desktopTemplateEn = '', string $mobileTemplateEn = '', string $searchTemplateEn = '', string $footerEn = ''): void
    {
        $name = trim($name);
        $description = trim($description);
        $footer = trim($footer);
        $desktopTemplate = trim($desktopTemplate);
        $mobileTemplate = trim($mobileTemplate);
        $locale = trim($locale);
        $nameEn = trim($nameEn);
        $descriptionEn = trim($descriptionEn);
        $seoTitleEn = trim($seoTitleEn);
        $seoKeywordsEn = trim($seoKeywordsEn);
        $seoDescriptionEn = trim($seoDescriptionEn);
        $searchTemplate = trim($searchTemplate);
        $desktopTemplateEn = trim($desktopTemplateEn);
        $mobileTemplateEn = trim($mobileTemplateEn);
        $searchTemplateEn = trim($searchTemplateEn);
        $footerEn = trim($footerEn);
        SiteTemplate::check($desktopTemplate);
        SiteTemplate::check($mobileTemplate);
        SiteTemplate::check($searchTemplate);
        SiteTemplate::check($desktopTemplateEn);
        SiteTemplate::check($mobileTemplateEn);
        SiteTemplate::check($searchTemplateEn);
        if (! preg_match('/^[A-Za-z][A-Za-z0-9]*(?:-[A-Za-z0-9]+)*$/D', $locale)) {
            throw new InvalidArgumentException('站点语言无效。');
        }
        $region = (new RegionRepository($this->pdo))->find($locale);
        if ($region === null || (int) $region['is_enabled'] !== 1) {
            throw new InvalidArgumentException('站点语言无效或区域未启用。');
        }
        if ($name === '' || mb_strlen($name) > 100 || mb_strlen($description) > 300 || mb_strlen($footer) > 150 || mb_strlen($footerEn) > 150 || mb_strlen($nameEn) > 100 || mb_strlen($descriptionEn) > 300 || mb_strlen($seoTitleEn) > 160 || mb_strlen($seoKeywordsEn) > 300 || mb_strlen($seoDescriptionEn) > 300) {
            throw new InvalidArgumentException('站点名称、简介或页脚长度无效。');
        }
        $this->pdo->beginTransaction();
        try {
            $stmt = $this->pdo->prepare('DELETE FROM site_settings WHERE name = ?');
            $insert = $this->pdo->prepare('INSERT INTO site_settings (name, value) VALUES (?, ?)');
            foreach (array('site_name' => $name, 'description' => $description, 'footer_text' => $footer, 'footer_text_en' => $footerEn, 'desktop_template' => $desktopTemplate, 'mobile_template' => $mobileTemplate, 'search_template' => $searchTemplate, 'desktop_template_en' => $desktopTemplateEn, 'mobile_template_en' => $mobileTemplateEn, 'search_template_en' => $searchTemplateEn, 'locale' => $locale, 'site_name_en' => $nameEn, 'description_en' => $descriptionEn, 'seo_title_en' => $seoTitleEn, 'seo_keywords_en' => $seoKeywordsEn, 'seo_description_en' => $seoDescriptionEn) as $key => $value) {
                $stmt->execute(array($key));
                $insert->execute(array($key, $value));
            }
            $this->pdo->commit();
        } catch (\Throwable $error) {
            $this->pdo->rollBack();
            throw $error;
        }
    }

    /** Activate a PbootCMS theme from templates/themes, or '' for the built-in views. */
    public function saveTheme(string $theme, string $root): void
    {
        $theme = trim($theme);
        if ($theme !== '' && ! in_array($theme, \FangdaysCMS\Cms\Pboot\Theme::names($root), true)) {
            throw new InvalidArgumentException('前台主题不存在。');
        }
        $this->pdo->prepare('DELETE FROM site_settings WHERE name = ?')->execute(array('pboot_theme'));
        $this->pdo->prepare('INSERT INTO site_settings (name, value) VALUES (?, ?)')->execute(array('pboot_theme', $theme));
    }
}
