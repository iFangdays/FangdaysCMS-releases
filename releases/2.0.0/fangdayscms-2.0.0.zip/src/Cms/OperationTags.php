<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

/** Resolve Pboot-style text tags before the view escapes the output. */
final class OperationTags
{
    public static function plain(string $source, array $labels, array $company): string
    {
        $source = TemplateTags::normalize($source);
        $source = preg_replace_callback('/\{fd:company([A-Za-z]+)\}/', static fn (array $match): string => (string) ($company[strtolower($match[1])] ?? ''), $source) ?? $source;
        return preg_replace_callback('/\{label:([A-Za-z][A-Za-z0-9_]*)\}/', static fn (array $match): string => (string) ($labels[$match[1]] ?? ''), $source) ?? $source;
    }

    /** Render the supported Pboot operation tags in a trusted HTML fragment. */
    public static function html(string $source, OperationsRepository $operations, array $labels = array(), array $company = array()): string
    {
        $source = TemplateTags::normalize($source);
        $tokens = array();
        $prefix = 'FD_TAG_' . bin2hex(random_bytes(12)) . '_';
        $token = static function (string $value) use (&$tokens, $prefix): string {
            $key = $prefix . count($tokens) . '_';
            $tokens[$key] = View::e($value);
            return $key;
        };
        $source = preg_replace_callback('/\{fd:company([A-Za-z]+)\}/', static fn (array $match): string => $token((string) ($company[strtolower($match[1])] ?? '')), $source) ?? $source;
        $source = preg_replace_callback('/\{label:([A-Za-z][A-Za-z0-9_]*)\}/', static function (array $match) use ($labels, $token): string {
            $label = $labels[$match[1]] ?? '';
            if (is_array($label)) {
                $value = (string) ($label['value'] ?? '');
                return ($label['type'] ?? 'text') === 'editor' ? RichText::clean($value, 'html') : (($label['type'] ?? 'text') === 'image' ? '<img src="' . View::e($value) . '" alt="">' : $token($value));
            }
            return $token((string) $label);
        }, $source) ?? $source;
        $source = preg_replace_callback('~\{fd:(slide|link)\s+([^}]*)\}(.*?)\{/fd:\1\}~s', static function (array $match) use ($operations): string {
            $kind = $match[1];
            $params = array();
            preg_match_all('/\b(gid|num|start)\s*=\s*(?:"([0-9]+)"|\x27([0-9]+)\x27|([0-9]+))/', $match[2], $found, PREG_SET_ORDER);
            foreach ($found as $param) {
                $params[$param[1]] = (int) ($param[2] ?: $param[3] ?: $param[4]);
            }
            if (($params['gid'] ?? 0) < 1 || $params['gid'] > 1000000) {
                return '';
            }
            $num = max(1, min($params['num'] ?? ($kind === 'slide' ? 20 : 10), 200));
            $start = max(1, min($params['start'] ?? 1, 1000000));
            $rows = $kind === 'slide' ? $operations->slides($params['gid'], $num, $start) : $operations->links($params['gid'], $num, $start);
            $output = '';
            foreach ($rows as $index => $row) {
                $fields = $kind === 'slide'
                    ? array('id' => $row['id'], 'src' => $row['image_path'], 'link' => $row['link'], 'title' => $row['title'], 'subtitle' => $row['subtitle'])
                    : array('id' => $row['id'], 'logo' => $row['logo_path'], 'link' => $row['link'], 'name' => $row['name']);
                $fields['n'] = $index;
                $fields['i'] = $index + 1;
                $body = preg_replace_callback('~\{fd:if\s*\((.*?)\)\}(.*?)\{/fd:if\}~si', static function (array $if) use ($fields, $kind): string {
                    if (! str_contains(strtolower($if[1]), '[' . strtolower($kind) . ':')) {
                        return $if[0];
                    }
                    $branches = explode('{else}', $if[2], 2);
                    return self::evaluateCondition($if[1], $kind, $fields) ? $branches[0] : ($branches[1] ?? '');
                }, $match[3]) ?? $match[3];
                $output .= preg_replace_callback('/\[' . $kind . ':([a-z]+)\]/', static fn (array $field): string => View::e($fields[$field[1]] ?? ''), $body) ?? $body;
            }
            return $output;
        }, $source) ?? $source;
        return strtr($source, $tokens);
    }

    private static function evaluateCondition(string $condition, string $kind, array $fields): bool
    {
        $resolve = static function (string $value) use ($kind, $fields): string {
            $value = trim($value);
            if (preg_match('/^\[' . preg_quote($kind, '/') . ':([a-z]+)\]$/i', $value, $match)) {
                return (string) ($fields[strtolower($match[1])] ?? '');
            }
            return trim($value, " \t\n\r\x27\"");
        };
        $evaluate = static function (string $expression) use ($resolve): bool {
            if (preg_match('/^\s*(.*?)\s*(>=|<=|!=|==|=|>|<)\s*(.*?)\s*$/s', $expression, $comparison)) {
                $left = $resolve($comparison[1]);
                $right = $resolve($comparison[3]);
                if (is_numeric($left) && is_numeric($right)) {
                    $left = (float) $left;
                    $right = (float) $right;
                }
                return match ($comparison[2]) {
                    '!=' => $left != $right,
                    '>' => $left > $right,
                    '<' => $left < $right,
                    '>=' => $left >= $right,
                    '<=' => $left <= $right,
                    default => $left == $right,
                };
            }
            return $resolve($expression) !== '';
        };
        foreach (preg_split('/\s*(?:\|\||\bor\b)\s*/i', trim($condition)) ?: array() as $orPart) {
            $andResult = true;
            foreach (preg_split('/\s*(?:&&|\band\b)\s*/i', $orPart) ?: array() as $andPart) {
                $andResult = $andResult && $evaluate($andPart);
            }
            if ($andResult) {
                return true;
            }
        }
        return false;
    }
}
