<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;
use PDO;

final class ContentRepository
{
    private const POST_META_SELECT = "COALESCE(pm.subtitle, '') AS subtitle, COALESCE(pm.subtitle_en, '') AS subtitle_en, COALESCE(pm.author, '') AS author, COALESCE(pm.source, '') AS source, COALESCE(pm.title_color, '') AS title_color, COALESCE(pm.outlink, '') AS outlink, COALESCE(pm.seo_keywords, '') AS seo_keywords, COALESCE(pm.seo_keywords_en, '') AS seo_keywords_en, COALESCE(pm.seo_description, '') AS seo_description, COALESCE(pm.seo_description_en, '') AS seo_description_en, COALESCE(pm.is_top, 0) AS is_top, COALESCE(pm.is_recommended, 0) AS is_recommended, COALESCE(pm.is_headline, 0) AS is_headline, COALESCE(pm.body_format, 'plain') AS body_format, COALESCE(NULLIF(pm.published_at, 0), p.created_at) AS published_at, COALESCE(pm.sort_order, 255) AS sort_order, COALESCE(pm.visits, 0) AS visits, COALESCE(pm.sub_category_id, 0) AS sub_category_id, COALESCE(pm.gcode, '') AS gcode, COALESCE(pm.gtype, 4) AS gtype, COALESCE(pm.gnote, '') AS gnote";
    private const SEARCH_COLUMNS = array('title' => 'p.title', 'content' => 'p.body', 'subtitle' => 'pm.subtitle', 'author' => 'pm.author', 'source' => 'pm.source', 'keywords' => 'pm.seo_keywords', 'description' => 'pm.seo_description');

    public function __construct(private readonly PDO $pdo)
    {
    }

    public function categories(): array
    {
        $rows = $this->pdo->query("SELECT c.id, c.parent_id, c.name, c.name_en, c.slug, c.sort_order, cm.model_id, COALESCE(s.type, 'list') AS type, COALESCE(s.is_visible, 1) AS is_visible, COALESCE(s.list_template, '') AS list_template, COALESCE(s.content_template, '') AS content_template, COALESCE(s.outlink, '') AS outlink, COALESCE(s.single_status, 'draft') AS single_status FROM categories c LEFT JOIN category_models cm ON cm.category_id = c.id LEFT JOIN category_settings s ON s.category_id = c.id ORDER BY c.sort_order ASC, c.id ASC")->fetchAll();
        return self::treeRows($rows);
    }

    public function categoriesWithPostCounts(): array
    {
        $rows = $this->pdo->query("SELECT c.id, c.parent_id, c.name, c.name_en, c.slug, c.sort_order, c.area, cm.model_id, m.name AS model_name, COALESCE(s.type, 'list') AS type, COALESCE(s.is_visible, 1) AS is_visible, COALESCE(s.outlink, '') AS outlink, COALESCE(s.single_status, 'draft') AS single_status, COALESCE(s.list_template, '') AS list_template, COALESCE(s.content_template, '') AS content_template, COUNT(p.id) AS post_count FROM categories c LEFT JOIN category_models cm ON cm.category_id = c.id LEFT JOIN category_settings s ON s.category_id = c.id LEFT JOIN content_models m ON m.id = cm.model_id LEFT JOIN posts p ON p.category_id = c.id GROUP BY c.id, c.parent_id, c.name, c.name_en, c.slug, c.sort_order, c.area, cm.model_id, m.name, s.type, s.is_visible, s.outlink, s.single_status, s.list_template, s.content_template ORDER BY c.sort_order ASC, c.id ASC")->fetchAll();
        $rows = self::treeRows($rows);
        $counts = array();
        foreach ($rows as $row) {
            $counts[(int) $row['id']] = (int) $row['post_count'];
        }
        foreach (array_reverse($rows) as $row) {
            if ($row['parent_id'] !== null) {
                $counts[(int) $row['parent_id']] = ($counts[(int) $row['parent_id']] ?? 0) + $counts[(int) $row['id']];
            }
        }
        foreach ($rows as &$row) {
            $row['post_count'] = $counts[(int) $row['id']];
        }
        return $rows;
    }

    public function rootCategories(): array
    {
        return array_values(array_filter($this->categories(), static fn (array $category): bool => $category['parent_id'] === null && self::isPublicCategory($category)));
    }

    public function childCategories(int $parentId): array
    {
        return array_values(array_filter($this->categories(), static fn (array $category): bool => (int) $category['parent_id'] === $parentId && self::isPublicCategory($category)));
    }

    /**
     * 批量新增: one menu per line, an indented line goes under the line above it and "名称 | 模型" picks
     * its content model. Commas still separate menus on one line.
     * @return list<array{name: string, depth: int, model: string}>
     */
    public static function parseMenuOutline(string $text): array
    {
        $nodes = array();
        $open = array();
        foreach (preg_split('/\R/u', $text) ?: array() as $line) {
            preg_match('/^([ \t　]*)(?:[-*•└├]\s*)?(.*)$/u', $line, $parts);
            if (trim($parts[2] ?? '') === '') {
                continue;
            }
            $indent = strlen(str_replace(array("\t", '　'), '  ', $parts[1]));
            while ($open !== array() && end($open) >= $indent) {
                array_pop($open);
            }
            $depth = count($open);
            $open[] = $indent;
            foreach (preg_split('/[,，]/u', $parts[2]) ?: array() as $item) {
                [$name, $model] = array_pad(array_map('trim', preg_split('/[|｜]/u', $item, 2) ?: array()), 2, '');
                if ($name !== '') {
                    $nodes[] = array('name' => $name, 'depth' => $depth, 'model' => $model);
                }
            }
        }
        return $nodes;
    }

    public function parentChoices(?int $categoryId): array
    {
        $excluded = $categoryId === null ? array() : array_flip($this->categoryDescendantIds($categoryId));
        return array_values(array_filter($this->categories(), static fn (array $category): bool => ! isset($excluded[(int) $category['id']])));
    }

    public function categoryAncestors(int $categoryId): array
    {
        $lookup = array_column($this->categories(), null, 'id');
        $ancestors = array();
        $seen = array();
        $current = $categoryId;
        while (isset($lookup[$current]) && ! isset($seen[$current])) {
            $seen[$current] = true;
            array_unshift($ancestors, $lookup[$current]);
            $current = (int) ($lookup[$current]['parent_id'] ?? 0);
        }
        foreach ($ancestors as $index => $ancestor) {
            $parts = array();
            foreach (array_slice($ancestors, 0, $index + 1) as $pathCategory) {
                $parts[] = rawurlencode((string) $pathCategory['slug']);
            }
            $ancestors[$index]['url_path'] = implode('/', $parts);
        }
        return $ancestors;
    }

    public function categoryDescendantIds(int $categoryId): array
    {
        $children = array();
        foreach ($this->categories() as $category) {
            $children[(int) ($category['parent_id'] ?? 0)][] = (int) $category['id'];
        }
        $ids = array();
        $queue = array($categoryId);
        while ($queue) {
            $current = array_shift($queue);
            if (isset($ids[$current])) {
                continue;
            }
            $ids[$current] = true;
            foreach ($children[$current] ?? array() as $childId) {
                $queue[] = $childId;
            }
        }
        return array_keys($ids);
    }

    public function category(int $id): ?array
    {
        $stmt = $this->pdo->prepare("SELECT c.id, c.parent_id, c.name, c.name_en, c.slug, c.sort_order, cm.model_id, COALESCE(s.type, 'list') AS type, COALESCE(s.is_visible, 1) AS is_visible, COALESCE(s.list_template, '') AS list_template, COALESCE(s.content_template, '') AS content_template, COALESCE(s.outlink, '') AS outlink, COALESCE(s.seo_title, '') AS seo_title, COALESCE(s.seo_title_en, '') AS seo_title_en, COALESCE(s.seo_keywords, '') AS seo_keywords, COALESCE(s.seo_keywords_en, '') AS seo_keywords_en, COALESCE(s.seo_description, '') AS seo_description, COALESCE(s.seo_description_en, '') AS seo_description_en, COALESCE(s.single_title, '') AS single_title, COALESCE(s.single_title_en, '') AS single_title_en, COALESCE(s.single_body, '') AS single_body, COALESCE(s.single_body_en, '') AS single_body_en, COALESCE(s.single_body_format, 'plain') AS single_body_format, COALESCE(s.single_status, 'draft') AS single_status, COALESCE(s.subname, '') AS subname FROM categories c LEFT JOIN category_models cm ON cm.category_id = c.id LEFT JOIN category_settings s ON s.category_id = c.id WHERE c.id = ?");
        $stmt->execute(array($id));
        return $stmt->fetch() ?: null;
    }

    public function categoryBySlug(string $slug): ?array
    {
        $stmt = $this->pdo->prepare("SELECT c.id, c.parent_id, c.name, c.name_en, c.slug, c.sort_order, cm.model_id, COALESCE(s.type, 'list') AS type, COALESCE(s.is_visible, 1) AS is_visible, COALESCE(s.list_template, '') AS list_template, COALESCE(s.content_template, '') AS content_template, COALESCE(s.outlink, '') AS outlink, COALESCE(s.seo_title, '') AS seo_title, COALESCE(s.seo_title_en, '') AS seo_title_en, COALESCE(s.seo_keywords, '') AS seo_keywords, COALESCE(s.seo_keywords_en, '') AS seo_keywords_en, COALESCE(s.seo_description, '') AS seo_description, COALESCE(s.seo_description_en, '') AS seo_description_en, COALESCE(s.single_title, '') AS single_title, COALESCE(s.single_title_en, '') AS single_title_en, COALESCE(s.single_body, '') AS single_body, COALESCE(s.single_body_en, '') AS single_body_en, COALESCE(s.single_body_format, 'plain') AS single_body_format, COALESCE(s.single_status, 'draft') AS single_status FROM categories c LEFT JOIN category_models cm ON cm.category_id = c.id LEFT JOIN category_settings s ON s.category_id = c.id WHERE c.slug = ?");
        $stmt->execute(array($slug));
        $category = $stmt->fetch() ?: null;
        if ($category !== null) {
            $category['url_path'] = $this->categoryPath((int) $category['id']);
        }
        return $category;
    }

    public function categoryByPath(string $path): ?array
    {
        $segments = array_values(array_filter(explode('/', trim($path, '/')), static fn (string $segment): bool => $segment !== ''));
        if ($segments === array()) {
            return null;
        }
        if (count($segments) === 1) {
            return $this->categoryBySlug($segments[0]);
        }
        $parentId = null;
        $category = null;
        foreach ($segments as $segment) {
            $category = $this->categoryBySlugAndParent($segment, $parentId);
            if ($category === null) {
                return null;
            }
            $parentId = (int) $category['id'];
        }
        if ($category !== null) {
            $category['url_path'] = $this->categoryPath((int) $category['id']);
        }
        return $category;
    }

    public function categoryPath(int $categoryId): string
    {
        $parts = array();
        foreach ($this->categoryAncestors($categoryId) as $category) {
            $parts[] = rawurlencode((string) $category['slug']);
        }
        return implode('/', $parts);
    }

    private function categoryBySlugAndParent(string $slug, ?int $parentId): ?array
    {
        $parentClause = $parentId === null ? 'c.parent_id IS NULL' : 'c.parent_id = ?';
        $sql = "SELECT c.id, c.parent_id, c.name, c.name_en, c.slug, c.sort_order, cm.model_id, COALESCE(s.type, 'list') AS type, COALESCE(s.is_visible, 1) AS is_visible, COALESCE(s.list_template, '') AS list_template, COALESCE(s.content_template, '') AS content_template, COALESCE(s.outlink, '') AS outlink, COALESCE(s.seo_title, '') AS seo_title, COALESCE(s.seo_title_en, '') AS seo_title_en, COALESCE(s.seo_keywords, '') AS seo_keywords, COALESCE(s.seo_keywords_en, '') AS seo_keywords_en, COALESCE(s.seo_description, '') AS seo_description, COALESCE(s.seo_description_en, '') AS seo_description_en, COALESCE(s.single_title, '') AS single_title, COALESCE(s.single_title_en, '') AS single_title_en, COALESCE(s.single_body, '') AS single_body, COALESCE(s.single_body_en, '') AS single_body_en, COALESCE(s.single_body_format, 'plain') AS single_body_format, COALESCE(s.single_status, 'draft') AS single_status FROM categories c LEFT JOIN category_models cm ON cm.category_id = c.id LEFT JOIN category_settings s ON s.category_id = c.id WHERE c.slug = ? AND {$parentClause}";
        $stmt = $this->pdo->prepare($sql);
        $params = array($slug);
        if ($parentId !== null) {
            $params[] = $parentId;
        }
        $stmt->execute($params);
        return $stmt->fetch() ?: null;
    }

    public function categoryUrl(array $category): string
    {
        return $this->categoryPath((int) $category['id']);
    }

    public function saveCategorySettings(int $categoryId, string $type, string $outlink, string $seoTitle, string $seoKeywords, string $seoDescription, ?bool $isVisible = null, ?string $listTemplate = null, ?string $contentTemplate = null, string $seoTitleEn = '', string $seoKeywordsEn = '', string $seoDescriptionEn = ''): void
    {
        $outlink = trim($outlink);
        $seoTitle = trim($seoTitle);
        $seoKeywords = trim($seoKeywords);
        $seoDescription = trim($seoDescription);
        $seoTitleEn = trim($seoTitleEn);
        $seoKeywordsEn = trim($seoKeywordsEn);
        $seoDescriptionEn = trim($seoDescriptionEn);
        if ($listTemplate !== null) {
            SiteTemplate::check($listTemplate);
        }
        if ($contentTemplate !== null) {
            SiteTemplate::check($contentTemplate);
        }
        if (! in_array($type, array('list', 'single', 'link'), true)
            || mb_strlen($seoTitle) > 255 || mb_strlen($seoKeywords) > 255 || mb_strlen($seoDescription) > 500 || mb_strlen($seoTitleEn) > 255 || mb_strlen($seoKeywordsEn) > 255 || mb_strlen($seoDescriptionEn) > 500) {
            throw new InvalidArgumentException('栏目类型或 SEO 信息无效。');
        }
        if ($type !== 'list') {
            $count = $this->pdo->prepare('SELECT COUNT(*) FROM posts WHERE category_id = ?');
            $count->execute(array($categoryId));
            if ((int) $count->fetchColumn() > 0) {
                throw new InvalidArgumentException('该栏目下已有文章，请先将直属文章移到列表栏目。');
            }
        }
        if ($type === 'link') {
            if (! self::validRedirectTarget($outlink)) {
                throw new InvalidArgumentException('跳转链接须为 http(s) 地址或站内绝对路径。');
            }
            $category = $this->category($categoryId);
            if ($category !== null && $outlink === '/category/' . $category['slug']) {
                throw new InvalidArgumentException('跳转链接不能指向栏目自身。');
            }
        } else {
            $outlink = '';
        }
        $exists = $this->pdo->prepare('SELECT category_id FROM category_settings WHERE category_id = ?');
        $exists->execute(array($categoryId));
        if ($exists->fetchColumn() === false) {
            $stmt = $this->pdo->prepare('INSERT INTO category_settings (category_id, type, is_visible, list_template, content_template, outlink, seo_title, seo_title_en, seo_keywords, seo_keywords_en, seo_description, seo_description_en, single_title, single_title_en, single_body, single_body_en, single_body_format, single_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
            $stmt->execute(array($categoryId, $type, (int) ($isVisible ?? true), $listTemplate ?? '', $contentTemplate ?? '', $outlink, $seoTitle, $seoTitleEn, $seoKeywords, $seoKeywordsEn, $seoDescription, $seoDescriptionEn, '', '', '', '', 'plain', 'draft'));
        } else {
            $stmt = $this->pdo->prepare('UPDATE category_settings SET type = ?, outlink = ?, seo_title = ?, seo_title_en = ?, seo_keywords = ?, seo_keywords_en = ?, seo_description = ?, seo_description_en = ?, is_visible = COALESCE(?, is_visible), list_template = COALESCE(?, list_template), content_template = COALESCE(?, content_template) WHERE category_id = ?');
            $stmt->execute(array($type, $outlink, $seoTitle, $seoTitleEn, $seoKeywords, $seoKeywordsEn, $seoDescription, $seoDescriptionEn, $isVisible === null ? null : (int) $isVisible, $listTemplate, $contentTemplate, $categoryId));
        }
    }

    /** Pboot sort subname; stored beside the other category settings, which must already exist. */
    public function saveCategorySubname(int $categoryId, string $subname): void
    {
        $subname = trim($subname);
        if (mb_strlen($subname) > 200) {
            throw new InvalidArgumentException('栏目副名称不能超过 200 字。');
        }
        $stmt = $this->pdo->prepare('UPDATE category_settings SET subname = ? WHERE category_id = ?');
        $stmt->execute(array($subname, $categoryId));
    }

    public function saveSingle(int $categoryId, string $title, string $body, string $status, string $bodyFormat = 'plain', string $titleEn = '', string $bodyEn = ''): void
    {
        $category = $this->category($categoryId);
        if ($category === null || $category['type'] !== 'single') {
            throw new InvalidArgumentException('请选择单页类型栏目。');
        }
        $title = trim($title);
        $titleEn = trim($titleEn);
        $bodyEn = RichText::clean($bodyEn, $bodyFormat);
        if ($title === '' || mb_strlen($title) > 100 || mb_strlen($titleEn) > 100 || strlen($body) > 2000000 || strlen($bodyEn) > 2000000 || ! in_array($status, array('draft', 'published'), true)) {
            throw new InvalidArgumentException('单页标题、正文或状态无效。');
        }
        $body = RichText::clean($body, $bodyFormat);
        $stmt = $this->pdo->prepare('UPDATE category_settings SET single_title = ?, single_title_en = ?, single_body = ?, single_body_en = ?, single_body_format = ?, single_status = ?, single_updated_at = ? WHERE category_id = ?');
        $stmt->execute(array($title, $titleEn, $body, $bodyEn, $bodyFormat, $status, time(), $categoryId));
    }

    private static function isPublicCategory(array $category): bool
    {
        return (int) $category['is_visible'] === 1 && ($category['type'] !== 'single' || $category['single_status'] === 'published');
    }

    public function saveCategory(?int $id, string $name, string $slug, int $sortOrder, ?int $parentId = null, string $nameEn = ''): int
    {
        $name = trim($name);
        $nameEn = trim($nameEn);
        self::checkSlug($slug);
        if ($name === '' || strlen($name) > 300 || strlen($nameEn) > 300 || $sortOrder < 0 || $sortOrder > 1000000) {
            throw new InvalidArgumentException('Category name or order is invalid.');
        }
        if ($id !== null && $this->category($id) === null) {
            throw new InvalidArgumentException('栏目不存在。');
        }
        if ($parentId !== null && ($this->category($parentId) === null || ($id !== null && in_array($parentId, $this->categoryDescendantIds($id), true)))) {
            throw new InvalidArgumentException('上级栏目不存在，或会形成循环层级。');
        }
        if ($id === null) {
            $stmt = $this->pdo->prepare('INSERT INTO categories (parent_id, name, name_en, slug, sort_order) VALUES (?, ?, ?, ?, ?)');
            $stmt->execute(array($parentId, $name, $nameEn, $slug, $sortOrder));
            return (int) $this->pdo->lastInsertId();
        }
        $stmt = $this->pdo->prepare('UPDATE categories SET parent_id = ?, name = ?, name_en = ?, slug = ?, sort_order = ? WHERE id = ?');
        $stmt->execute(array($parentId, $name, $nameEn, $slug, $sortOrder, $id));
        return $id;
    }

    /** Validates a Pboot access rule: group code, comparison type and the note shown when denied. */
    private static function levelRule(string $gcode, string $gtype, string $gnote): array
    {
        $gcode = trim($gcode);
        $gnote = trim($gnote);
        if (preg_match('/^[A-Za-z0-9_-]{0,64}$/D', $gcode) !== 1 || ! isset(PageLevel::TYPES[(int) $gtype]) || mb_strlen($gnote) > 100) {
            throw new InvalidArgumentException('浏览权限设置无效。');
        }
        return array($gcode, (int) $gtype, $gnote);
    }

    /** Category access rule and descriptions (Pboot gcode, gtype, gnote, def1-3). */
    public function categoryAccess(int $id): array
    {
        $stmt = $this->pdo->prepare('SELECT gcode, gtype, gnote, def1, def2, def3 FROM category_settings WHERE category_id = ?');
        $stmt->execute(array($id));
        return $stmt->fetch() ?: array('gcode' => '', 'gtype' => 4, 'gnote' => '', 'def1' => '', 'def2' => '', 'def3' => '');
    }

    public function saveCategoryAccess(int $id, string $gcode, string $gtype, string $gnote, string $def1 = '', string $def2 = '', string $def3 = ''): void
    {
        [$gcode, $type, $gnote] = self::levelRule($gcode, $gtype, $gnote);
        if (max(mb_strlen($def1), mb_strlen($def2), mb_strlen($def3)) > 1000) {
            throw new InvalidArgumentException('栏目描述最多 1000 个字符。');
        }
        $this->pdo->prepare('UPDATE category_settings SET gcode = ?, gtype = ?, gnote = ?, def1 = ?, def2 = ?, def3 = ? WHERE category_id = ?')->execute(array($gcode, $type, $gnote, $def1, $def2, $def3, $id));
    }

    /** Pboot 专题内容 list rows: the single-page categories with their title, time and visits. */
    public function singles(): array
    {
        $extra = array_column($this->pdo->query("SELECT category_id, single_title, single_updated_at, single_visits FROM category_settings WHERE type = 'single'")->fetchAll(), null, 'category_id');
        $rows = array();
        foreach ($this->categories() as $category) {
            if ($category['type'] === 'single') {
                $rows[] = $category + ($extra[$category['id']] ?? array()) + array('single_title' => '', 'single_updated_at' => 0, 'single_visits' => 0);
            }
        }
        return $rows;
    }

    /** Pboot 栏目列表 状态 switch. */
    public function setCategoryVisible(int $id, bool $visible): void
    {
        $category = $this->category($id) ?? throw new InvalidArgumentException('栏目不存在。');
        $stmt = $this->pdo->prepare('UPDATE category_settings SET is_visible = ? WHERE category_id = ?');
        $stmt->execute(array((int) $visible, $id));
        if ($stmt->rowCount() === 0 && ! $this->pdo->query('SELECT 1 FROM category_settings WHERE category_id = ' . $id)->fetchColumn()) {
            $this->saveCategorySettings($id, (string) $category['type'], '', '', '', '', $visible);
        }
    }

    /** Pboot 栏目列表 保存排序: sort_order[id] => value. @return int rows changed */
    public function saveCategorySortOrders(array $orders): int
    {
        $validated = array();
        foreach ($orders as $id => $value) {
            if (! ctype_digit((string) $id) || (int) $id < 1 || ! is_string($value) || ! ctype_digit($value) || (int) $value > 1000000) {
                throw new InvalidArgumentException('排序值须为 0 到 1000000 的整数。');
            }
            $validated[(int) $id] = (int) $value;
        }
        if ($validated === array() || count($validated) > 2000) {
            throw new InvalidArgumentException('没有可保存的排序。');
        }
        $stmt = $this->pdo->prepare('UPDATE categories SET sort_order = ? WHERE id = ?');
        $changed = 0;
        $this->pdo->beginTransaction();
        try {
            foreach ($validated as $id => $value) {
                $stmt->execute(array($value, $id));
                $changed += $stmt->rowCount();
            }
            $this->pdo->commit();
        } catch (\Throwable $error) {
            $this->pdo->rollBack();
            throw $error;
        }
        return $changed;
    }

    public function deleteCategory(int $id): void
    {
        if (count($this->categoryDescendantIds($id)) > 1) {
            throw new InvalidArgumentException('该栏目还有子栏目，请先调整子栏目归属。');
        }
        $stmt = $this->pdo->prepare('DELETE FROM categories WHERE id = ?');
        $stmt->execute(array($id));
    }

    private static function treeRows(array $rows): array
    {
        $children = array();
        foreach ($rows as $row) {
            $children[(int) ($row['parent_id'] ?? 0)][] = $row;
        }
        $result = array();
        $seen = array();
        $walk = static function (int $parentId, int $depth) use (&$walk, &$result, &$seen, $children): void {
            foreach ($children[$parentId] ?? array() as $row) {
                $id = (int) $row['id'];
                if (isset($seen[$id])) {
                    continue;
                }
                $seen[$id] = true;
                $row['depth'] = $depth;
                $result[] = $row;
                $walk($id, $depth + 1);
            }
        };
        $walk(0, 0);
        foreach ($rows as $row) {
            if (! isset($seen[(int) $row['id']])) {
                $walk((int) ($row['parent_id'] ?? 0), 0);
            }
        }
        $byId = array_column($result, null, 'id');
        foreach ($result as &$row) {
            $path = array();
            $current = $row;
            while ($current !== null) {
                array_unshift($path, rawurlencode((string) $current['slug']));
                $parentId = $current['parent_id'] ?? null;
                $current = $parentId === null ? null : ($byId[(int) $parentId] ?? null);
            }
            $row['url_path'] = implode('/', $path);
        }
        unset($row);
        return $result;
    }

    public function posts(?string $status = null, ?int $categoryId = null, bool $includeMembers = false, ?int $tagId = null, ?string $query = null, int $page = 1, ?string $feature = null, bool $includeFuture = false, array $fieldFilters = array(), array $search = array(), int $num = 20): array
    {
        [$where, $params] = $this->postFilters($status, $categoryId, $includeMembers, $tagId, $query, $feature, $includeFuture, $fieldFilters, $search);
        $sql = "SELECT p.id, p.category_id, p.title, p.title_en, p.slug, p.body, p.body_en, p.status, p.created_at, p.updated_at, c.name AS category_name, c.name_en AS category_name_en, c.slug AS category_slug, COALESCE(v.visibility, 'public') AS visibility, m.path AS cover_path, EXISTS (SELECT 1 FROM post_gallery g WHERE g.post_id = p.id) AS has_gallery, " . self::POST_META_SELECT . " FROM posts p LEFT JOIN categories c ON c.id = p.category_id LEFT JOIN post_visibility v ON v.post_id = p.id LEFT JOIN post_cover pc ON pc.post_id = p.id LEFT JOIN media m ON m.id = pc.media_id LEFT JOIN post_meta pm ON pm.post_id = p.id";
        if ($where) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY COALESCE(pm.is_top, 0) DESC, COALESCE(pm.is_recommended, 0) DESC, COALESCE(pm.is_headline, 0) DESC, COALESCE(pm.sort_order, 255) ASC, COALESCE(NULLIF(pm.published_at, 0), p.created_at) DESC, p.id DESC LIMIT ? OFFSET ?';
        $stmt = $this->pdo->prepare($sql);
        foreach ($params as $index => $param) {
            $stmt->bindValue($index + 1, $param, is_int($param) ? PDO::PARAM_INT : PDO::PARAM_STR);
        }
        $num = max(1, min(200, $num));
        $stmt->bindValue(count($params) + 1, $num, PDO::PARAM_INT);
        $stmt->bindValue(count($params) + 2, (max(1, $page) - 1) * $num, PDO::PARAM_INT);
        $stmt->execute();
        $rows = $stmt->fetchAll();
        foreach ($rows as &$row) {
            $row['category_path'] = $row['category_id'] === null ? '' : $this->categoryPath((int) $row['category_id']);
        }
        unset($row);
        return $rows;
    }

    public function countPosts(?string $status = null, ?int $categoryId = null, bool $includeMembers = false, ?int $tagId = null, ?string $query = null, ?string $feature = null, bool $includeFuture = false, array $fieldFilters = array(), array $search = array()): int
    {
        [$where, $params] = $this->postFilters($status, $categoryId, $includeMembers, $tagId, $query, $feature, $includeFuture, $fieldFilters, $search);
        $sql = 'SELECT COUNT(*) FROM posts p LEFT JOIN post_visibility v ON v.post_id = p.id LEFT JOIN post_meta pm ON pm.post_id = p.id';
        if ($where) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $stmt = $this->pdo->prepare($sql);
        foreach ($params as $index => $param) {
            $stmt->bindValue($index + 1, $param, is_int($param) ? PDO::PARAM_INT : PDO::PARAM_STR);
        }
        $stmt->execute();
        return (int) $stmt->fetchColumn();
    }

    public function post(int $id): ?array
    {
        $stmt = $this->pdo->prepare("SELECT p.id, p.category_id, p.title, p.title_en, p.slug, p.body, p.body_en, p.status, p.created_at, p.updated_at, COALESCE(v.visibility, 'public') AS visibility, pc.media_id AS cover_media_id, " . self::POST_META_SELECT . " FROM posts p LEFT JOIN post_visibility v ON v.post_id = p.id LEFT JOIN post_cover pc ON pc.post_id = p.id LEFT JOIN post_meta pm ON pm.post_id = p.id WHERE p.id = ?");
        $stmt->execute(array($id));
        return $stmt->fetch() ?: null;
    }

    public function publishedPostBySlug(string $slug): ?array
    {
        $stmt = $this->pdo->prepare("SELECT p.id, p.category_id, p.title, p.title_en, p.slug, p.body, p.body_en, p.status, p.created_at, p.updated_at, c.name AS category_name, c.name_en AS category_name_en, c.slug AS category_slug, COALESCE(v.visibility, 'public') AS visibility, m.path AS cover_path, EXISTS (SELECT 1 FROM post_gallery g WHERE g.post_id = p.id) AS has_gallery, " . self::POST_META_SELECT . " FROM posts p LEFT JOIN categories c ON c.id = p.category_id LEFT JOIN post_visibility v ON v.post_id = p.id LEFT JOIN post_cover pc ON pc.post_id = p.id LEFT JOIN media m ON m.id = pc.media_id LEFT JOIN post_meta pm ON pm.post_id = p.id WHERE p.slug = ? AND p.status = 'published' AND COALESCE(NULLIF(pm.published_at, 0), p.created_at) <= (? + 0)");
        $stmt->bindValue(1, $slug);
        $stmt->bindValue(2, time(), PDO::PARAM_INT);
        $stmt->execute();
        $post = $stmt->fetch() ?: null;
        if ($post !== null) {
            $post['category_path'] = $post['category_id'] === null ? '' : $this->categoryPath((int) $post['category_id']);
        }
        return $post;
    }

    public function savePost(?int $id, ?int $categoryId, string $title, string $slug, string $body, string $status, string $titleEn = '', string $bodyEn = ''): int
    {
        $title = trim($title);
        $titleEn = trim($titleEn);
        $bodyEn = RichText::clean($bodyEn, 'html');
        self::checkSlug($slug);
        if ($title === '' || strlen($title) > 300 || strlen($titleEn) > 300 || strlen($body) > 2000000 || strlen($bodyEn) > 2000000 || ! in_array($status, array('draft', 'published'), true)) {
            throw new InvalidArgumentException('Post title, body, or status is invalid.');
        }
        if ($categoryId !== null) {
            $category = $this->category($categoryId);
            if ($category === null || $category['type'] !== 'list') {
                throw new InvalidArgumentException('请选择列表类型栏目。');
            }
        }
        $now = time();
        if ($id === null) {
            $stmt = $this->pdo->prepare('INSERT INTO posts (category_id, title, title_en, slug, body, body_en, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
            $stmt->execute(array($categoryId, $title, $titleEn, $slug, $body, $bodyEn, $status, $now, $now));
            return (int) $this->pdo->lastInsertId();
        }
        $stmt = $this->pdo->prepare('UPDATE posts SET category_id = ?, title = ?, title_en = ?, slug = ?, body = ?, body_en = ?, status = ?, updated_at = ? WHERE id = ?');
        $stmt->execute(array($categoryId, $title, $titleEn, $slug, $body, $bodyEn, $status, $now, $id));
        return $id;
    }

    public function savePostMeta(int $postId, array $attributes): void
    {
        $post = $this->post($postId);
        if ($post === null) {
            throw new InvalidArgumentException('文章不存在。');
        }
        $values = array();
        foreach (array('subtitle' => 255, 'subtitle_en' => 255, 'author' => 100, 'source' => 100, 'seo_keywords' => 255, 'seo_keywords_en' => 255, 'seo_description' => 500, 'seo_description_en' => 500) as $name => $limit) {
            $value = $attributes[$name] ?? '';
            if (! is_string($value) || mb_strlen(trim($value)) > $limit) {
                throw new InvalidArgumentException('文章附加信息长度无效。');
            }
            $values[$name] = trim($value);
        }
        $color = $attributes['title_color'] ?? '';
        if (! is_string($color) || ($color !== '' && ! preg_match('/^#[0-9a-fA-F]{6}$/D', $color))) {
            throw new InvalidArgumentException('标题颜色须为六位十六进制色值。');
        }
        $values['title_color'] = strtolower($color);
        $outlink = $attributes['outlink'] ?? '';
        if (! is_string($outlink)) {
            throw new InvalidArgumentException('文章跳转链接无效。');
        }
        $outlink = trim($outlink);
        if ($outlink !== '' && (! self::validRedirectTarget($outlink) || $outlink === '/post/' . $post['slug'])) {
            throw new InvalidArgumentException('文章跳转链接须为 http(s) 地址或站内绝对路径，且不能指向自身。');
        }
        $values['outlink'] = $outlink;
        $format = $attributes['body_format'] ?? $post['body_format'];
        if (! in_array($format, array('plain', 'html'), true)) {
            throw new InvalidArgumentException('正文格式无效。');
        }
        $values['body_format'] = $format;
        $publishedAt = $attributes['published_at'] ?? $post['published_at'];
        if ((! is_int($publishedAt) && (! is_string($publishedAt) || ! ctype_digit($publishedAt))) || (int) $publishedAt < 1 || (int) $publishedAt > 253402300799) {
            throw new InvalidArgumentException('发布时间无效。');
        }
        $values['published_at'] = (int) $publishedAt;
        $sortOrder = $attributes['sort_order'] ?? $post['sort_order'];
        if ((! is_int($sortOrder) && (! is_string($sortOrder) || ! ctype_digit($sortOrder))) || (int) $sortOrder < 0 || (int) $sortOrder > 1000000) {
            throw new InvalidArgumentException('排序值须为 0 到 1000000 的整数。');
        }
        $values['sort_order'] = (int) $sortOrder;
        foreach (array('is_top', 'is_recommended', 'is_headline') as $name) {
            $flag = $attributes[$name] ?? '0';
            if (! in_array($flag, array('0', '1'), true)) {
                throw new InvalidArgumentException('文章推荐属性无效。');
            }
            $values[$name] = (int) $flag;
        }
        $subCategory = (string) ($attributes['sub_category_id'] ?? $post['sub_category_id']);
        if ($subCategory !== '' && $subCategory !== '0' && (! ctype_digit($subCategory) || ($this->category((int) $subCategory)['type'] ?? '') !== 'list')) {
            throw new InvalidArgumentException('请选择列表类型的内容副栏目。');
        }
        $values['sub_category_id'] = (int) $subCategory;
        [$values['gcode'], $values['gtype'], $values['gnote']] = self::levelRule((string) ($attributes['gcode'] ?? $post['gcode']), (string) ($attributes['gtype'] ?? $post['gtype']), (string) ($attributes['gnote'] ?? $post['gnote']));
        $exists = $this->pdo->prepare('SELECT post_id FROM post_meta WHERE post_id = ?');
        $exists->execute(array($postId));
        $columns = array('subtitle', 'subtitle_en', 'author', 'source', 'title_color', 'outlink', 'seo_keywords', 'seo_keywords_en', 'seo_description', 'seo_description_en', 'is_top', 'is_recommended', 'is_headline', 'body_format', 'published_at', 'sort_order', 'sub_category_id', 'gcode', 'gtype', 'gnote');
        if ($exists->fetchColumn() === false) {
            $stmt = $this->pdo->prepare('INSERT INTO post_meta (post_id, ' . implode(', ', $columns) . ') VALUES (' . implode(', ', array_fill(0, count($columns) + 1, '?')) . ')');
            $stmt->execute(array_merge(array($postId), array_map(static fn (string $name) => $values[$name], $columns)));
        } else {
            $assignments = implode(', ', array_map(static fn (string $name): string => $name . ' = ?', $columns));
            $stmt = $this->pdo->prepare('UPDATE post_meta SET ' . $assignments . ' WHERE post_id = ?');
            $stmt->execute(array_merge(array_map(static fn (string $name) => $values[$name], $columns), array($postId)));
        }
    }

    public function deletePost(int $id): void
    {
        $stmt = $this->pdo->prepare('DELETE FROM posts WHERE id = ?');
        $stmt->execute(array($id));
    }

    public function bulkPosts(array $ids, string $action): int
    {
        if (! in_array($action, array('publish', 'draft', 'delete'), true)) {
            throw new InvalidArgumentException('请选择本页文章，并指定有效操作。');
        }
        $validated = self::validatedPostIds($ids);
        $placeholders = implode(', ', array_fill(0, count($validated), '?'));
        if ($action === 'delete') {
            $stmt = $this->pdo->prepare('DELETE FROM posts WHERE id IN (' . $placeholders . ')');
            $stmt->execute($validated);
            return $stmt->rowCount();
        }
        $status = $action === 'publish' ? 'published' : 'draft';
        $stmt = $this->pdo->prepare('UPDATE posts SET status = ?, updated_at = ? WHERE id IN (' . $placeholders . ')');
        $stmt->execute(array_merge(array($status, time()), $validated));
        return $stmt->rowCount();
    }

    /** The list switches of Pboot's content table: 状态, 置顶, 推荐. */
    public function setPostSwitch(int $id, string $field, bool $on): void
    {
        if ($this->post($id) === null) {
            throw new InvalidArgumentException('文章不存在。');
        }
        if ($field === 'status') {
            $this->pdo->prepare('UPDATE posts SET status = ?, updated_at = ? WHERE id = ?')->execute(array($on ? 'published' : 'draft', time(), $id));
            return;
        }
        $column = array('istop' => 'is_top', 'isrecommend' => 'is_recommended', 'isheadline' => 'is_headline')[$field] ?? throw new InvalidArgumentException('开关字段无效。');
        $exists = $this->pdo->prepare('SELECT post_id FROM post_meta WHERE post_id = ?');
        $exists->execute(array($id));
        if ($exists->fetchColumn() === false) {
            $this->pdo->prepare("INSERT INTO post_meta (post_id, seo_description, seo_description_en, $column) VALUES (?, '', '', ?)")->execute(array($id, (int) $on));
        } else {
            $this->pdo->prepare("UPDATE post_meta SET $column = ? WHERE post_id = ?")->execute(array((int) $on, $id));
        }
    }

    public function transferPosts(array $ids, string $action, int $categoryId): int
    {
        if (! in_array($action, array('copy', 'move'), true)) {
            throw new InvalidArgumentException('请选择复制或移动操作。');
        }
        $validated = self::validatedPostIds($ids);
        $category = $this->category($categoryId);
        if ($category === null || $category['type'] !== 'list') {
            throw new InvalidArgumentException('目标栏目须为列表类型。');
        }
        $this->pdo->beginTransaction();
        try {
            $sources = array();
            foreach ($validated as $id) {
                $sources[] = $this->post($id) ?? throw new InvalidArgumentException('所选文章已不存在，请刷新列表。');
            }
            if ($action === 'move') {
                $stmt = $this->pdo->prepare('UPDATE posts SET category_id = ?, updated_at = ? WHERE id = ?');
                foreach ($sources as $source) {
                    $stmt->execute(array($categoryId, time(), $source['id']));
                }
            } else {
                $insert = $this->pdo->prepare('INSERT INTO posts (category_id, title, title_en, slug, body, body_en, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
                $relations = array(
                    'post_meta' => array('subtitle', 'subtitle_en', 'author', 'source', 'title_color', 'outlink', 'seo_keywords', 'seo_keywords_en', 'seo_description', 'seo_description_en', 'is_top', 'is_recommended', 'is_headline', 'body_format', 'published_at', 'sort_order', 'sub_category_id', 'gcode', 'gtype', 'gnote'),
                    'post_visibility' => array('visibility'),
                    'post_cover' => array('media_id'),
                    'post_gallery' => array('position', 'media_id', 'title'),
                    'post_attachment' => array('path', 'original_name', 'bytes'),
                    'post_tags' => array('tag_id'),
                    'post_field_values' => array('field_id', 'value'),
                    'post_field_attachments' => array('field_id', 'path', 'original_name', 'bytes')
                );
                foreach ($sources as $source) {
                    $now = time();
                    $insert->execute(array($categoryId, $source['title'], $source['title_en'] ?? '', $this->copySlug($source['slug']), $source['body'], $source['body_en'] ?? '', $source['status'], $now, $now));
                    $copyId = (int) $this->pdo->lastInsertId();
                    foreach ($relations as $table => $columns) {
                        $fields = implode(', ', $columns);
                        $stmt = $this->pdo->prepare('INSERT INTO ' . $table . ' (post_id, ' . $fields . ') SELECT ?, ' . $fields . ' FROM ' . $table . ' WHERE post_id = ?');
                        $stmt->execute(array($copyId, $source['id']));
                    }
                }
            }
            $this->pdo->commit();
        } catch (\Throwable $error) {
            $this->pdo->rollBack();
            throw $error;
        }
        return count($validated);
    }

    public function savePostSortOrders(array $orders): int
    {
        if (count($orders) < 1 || count($orders) > 200) {
            throw new InvalidArgumentException('请选择本页文章设置排序。');
        }
        $validated = array();
        foreach ($orders as $id => $value) {
            if (! ctype_digit((string) $id) || (int) $id < 1 || ! is_string($value) || ! ctype_digit($value) || (int) $value > 1000000) {
                throw new InvalidArgumentException('排序值须为 0 到 1000000 的整数。');
            }
            $validated[(int) $id] = (int) $value;
        }
        $this->pdo->beginTransaction();
        try {
            $exists = $this->pdo->prepare('SELECT 1 FROM post_meta WHERE post_id = ?');
            $insert = $this->pdo->prepare("INSERT INTO post_meta (post_id, seo_description, seo_description_en, published_at, sort_order) VALUES (?, '', '', ?, ?)");
            $update = $this->pdo->prepare('UPDATE post_meta SET sort_order = ? WHERE post_id = ?');
            foreach ($validated as $id => $value) {
                $post = $this->post($id) ?? throw new InvalidArgumentException('所选文章已不存在，请刷新列表。');
                $exists->execute(array($id));
                if ($exists->fetchColumn() === false) {
                    $insert->execute(array($id, $post['published_at'], $value));
                } else {
                    $update->execute(array($value, $id));
                }
            }
            $this->pdo->commit();
        } catch (\Throwable $error) {
            $this->pdo->rollBack();
            throw $error;
        }
        return count($validated);
    }

    private static function validatedPostIds(array $ids): array
    {
        if (count($ids) < 1 || count($ids) > 20) {
            throw new InvalidArgumentException('请选择本页文章，并指定有效操作。');
        }
        $validated = array();
        foreach ($ids as $id) {
            if (! is_string($id) || ! ctype_digit($id) || (int) $id < 1) {
                throw new InvalidArgumentException('所选文章无效。');
            }
            $validated[] = (int) $id;
        }
        return array_values(array_unique($validated));
    }

    private function copySlug(string $slug): string
    {
        $exists = $this->pdo->prepare('SELECT 1 FROM posts WHERE slug = ?');
        for ($number = 1; $number <= 1000; $number++) {
            $suffix = $number === 1 ? '-copy' : '-copy-' . $number;
            $candidate = rtrim(substr($slug, 0, 160 - strlen($suffix)), '-') . $suffix;
            $exists->execute(array($candidate));
            if ($exists->fetchColumn() === false) {
                return $candidate;
            }
        }
        throw new InvalidArgumentException('无法为副本生成唯一 URL 别名。');
    }

    public function memberCanAccess(int $postId, int $groupId): bool
    {
        $stmt = $this->pdo->prepare("SELECT CASE WHEN COALESCE(v.visibility, 'public') = 'public' THEN 1 WHEN EXISTS (SELECT 1 FROM post_group_visibility gv JOIN member_groups active_group ON active_group.id = gv.group_id AND active_group.status = 'active' WHERE gv.post_id = p.id AND gv.group_id = ?) OR NOT EXISTS (SELECT 1 FROM post_group_visibility gv2 WHERE gv2.post_id = p.id) THEN 1 ELSE 0 END FROM posts p LEFT JOIN post_visibility v ON v.post_id = p.id WHERE p.id = ?");
        $stmt->execute(array($groupId, $postId));
        return (bool) $stmt->fetchColumn();
    }
    public function setVisibility(int $postId, string $visibility): void
    {
        if (! in_array($visibility, array('public', 'members'), true)) {
            throw new InvalidArgumentException('文章可见范围无效。');
        }
        $stmt = $this->pdo->prepare('DELETE FROM post_visibility WHERE post_id = ?');
        $stmt->execute(array($postId));
        if ($visibility === 'members') {
            $stmt = $this->pdo->prepare('INSERT INTO post_visibility (post_id, visibility) VALUES (?, ?)');
            $stmt->execute(array($postId, $visibility));
        }
    }

    private static function checkSlug(string $slug): void
    {
        if (strlen($slug) > 160 || ! preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/D', $slug)) {
            throw new InvalidArgumentException('Slug must use lowercase letters, digits, and single hyphens.');
        }
    }

    private static function validRedirectTarget(string $url): bool
    {
        if ($url === '' || strlen($url) > 2048) {
            return false;
        }
        $parts = parse_url($url);
        $absolute = $parts !== false && in_array(strtolower($parts['scheme'] ?? ''), array('http', 'https'), true)
            && ! empty($parts['host']) && ! isset($parts['user']) && ! isset($parts['pass'])
            && filter_var($url, FILTER_VALIDATE_URL) !== false;
        $relative = (bool) preg_match('~^/(?!/)[^\x00-\x20\x7f\\\\]*$~D', $url);
        return $absolute || $relative;
    }

    private function postFilters(?string $status, ?int $categoryId, bool $includeMembers, ?int $tagId, ?string $query, ?string $feature, bool $includeFuture, array $fieldFilters, array $search): array
    {
        $where = array();
        $params = array();
        if ($status !== null) {
            $where[] = 'p.status = ?';
            $params[] = $status;
        }
        if ($categoryId !== null) {
            $categoryIds = $this->categoryDescendantIds($categoryId);
            $where[] = 'p.category_id IN (' . implode(', ', array_fill(0, count($categoryIds), '?')) . ')';
            array_push($params, ...$categoryIds);
        }
        if ($status === 'published' && ! $includeMembers) {
            $where[] = "COALESCE(v.visibility, 'public') = 'public'";
        }
        if ($status === 'published' && ! $includeFuture) {
            $where[] = 'COALESCE(NULLIF(pm.published_at, 0), p.created_at) <= (? + 0)';
            $params[] = time();
        }
        if ($tagId !== null) {
            $where[] = 'EXISTS (SELECT 1 FROM post_tags pt WHERE pt.post_id = p.id AND pt.tag_id = ?)';
            $params[] = $tagId;
        }
        if ($feature !== null) {
            $column = array('top' => 'is_top', 'recommended' => 'is_recommended', 'headline' => 'is_headline')[$feature] ?? null;
            if ($column === null) {
                throw new InvalidArgumentException('文章属性筛选无效。');
            }
            $where[] = 'COALESCE(pm.' . $column . ', 0) = 1';
        }
        if ($query !== null && trim($query) !== '') {
            $where[] = "(p.title LIKE ? OR p.body LIKE ? OR pm.subtitle LIKE ? OR pm.author LIKE ? OR pm.source LIKE ? OR pm.seo_keywords LIKE ? OR EXISTS (SELECT 1 FROM post_field_values pf JOIN posts active_post ON active_post.id = pf.post_id JOIN model_fields mf ON mf.id = pf.field_id LEFT JOIN category_models cm ON cm.category_id = active_post.category_id WHERE pf.post_id = p.id AND mf.model_id = COALESCE(cm.model_id, (SELECT id FROM content_models WHERE slug = 'article')) AND pf.value LIKE ?))";
            for ($i = 0; $i < 7; $i++) {
                $params[] = '%' . trim($query) . '%';
            }
        }
        foreach ($fieldFilters as $filter) {
            if (! is_array($filter) || ! is_int($filter['id'] ?? null) || $filter['id'] < 1 || ! is_string($filter['value'] ?? null) || ! in_array($filter['type'] ?? null, array('select', 'radio', 'multi'), true)) {
                throw new InvalidArgumentException('扩展字段筛选条件无效。');
            }
            $activeField = "EXISTS (SELECT 1 FROM post_field_values pf JOIN posts active_post ON active_post.id = pf.post_id JOIN model_fields mf ON mf.id = pf.field_id LEFT JOIN category_models cm ON cm.category_id = active_post.category_id WHERE pf.post_id = p.id AND pf.field_id = ? AND mf.model_id = COALESCE(cm.model_id, (SELECT id FROM content_models WHERE slug = 'article')) AND ";
            if ($filter['type'] === 'multi') {
                if ($this->pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql') {
                    $where[] = $activeField . "LOCATE(CONCAT(',', ?, ','), CONCAT(',', pf.value, ',')) > 0)";
                } else {
                    $where[] = $activeField . "instr(',' || pf.value || ',', ',' || ? || ',') > 0)";
                }
                $params[] = $filter['id'];
                $params[] = $filter['value'];
            } else {
                $where[] = $activeField . 'pf.value = ?)';
                $params[] = $filter['id'];
                $params[] = $filter['value'];
            }
        }
        if ($search !== array()) {
            $ids = $search['category_ids'] ?? array();
            if ($ids !== array()) {
                if (! is_array($ids) || array_filter($ids, static fn ($id): bool => ! is_int($id) || $id < 1)) {
                    throw new InvalidArgumentException('搜索栏目无效。');
                }
                $where[] = 'p.category_id IN (' . implode(', ', array_fill(0, count($ids), '?')) . ')';
                array_push($params, ...$ids);
            }
            $keyword = $search['keyword'] ?? '';
            if ($keyword !== '') {
                if (! is_string($keyword) || ! is_array($search['fields'] ?? null) || $search['fields'] === array()) {
                    throw new InvalidArgumentException('搜索字段无效。');
                }
                $parts = array();
                foreach ($search['fields'] as $field) {
                    $parts[] = $this->searchFieldClause($field, $keyword, false, $params);
                }
                $where[] = '(' . implode(' OR ', $parts) . ')';
            }
            foreach ($search['conditions'] ?? array() as $field => $value) {
                $where[] = $this->searchFieldClause($field, $value, true, $params);
            }
        }
        return array($where, $params);
    }

    private function searchFieldClause(string $field, string $value, bool $direct, array &$params): string
    {
        $contains = '%' . str_replace(array('!', '%', '_'), array('!!', '!%', '!_'), $value) . '%';
        if (isset(self::SEARCH_COLUMNS[$field])) {
            $params[] = $contains;
            return self::SEARCH_COLUMNS[$field] . " LIKE ? ESCAPE '!'";
        }
        if (! preg_match('/^ext_[A-Za-z][A-Za-z0-9_]{0,58}$/D', $field)) {
            throw new InvalidArgumentException('搜索字段无效。');
        }
        $clause = "EXISTS (SELECT 1 FROM post_field_values pf JOIN model_fields mf ON mf.id = pf.field_id JOIN posts active_post ON active_post.id = pf.post_id LEFT JOIN category_models cm ON cm.category_id = active_post.category_id WHERE pf.post_id = p.id AND mf.model_id = COALESCE(cm.model_id, (SELECT id FROM content_models WHERE slug = 'article')) AND mf.name = ? AND ";
        $params[] = $field;
        if (! $direct) {
            $params[] = $contains;
            return $clause . "pf.value LIKE ? ESCAPE '!')";
        }
        $multi = $this->pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql'
            ? "LOCATE(CONCAT(',', ?, ','), CONCAT(',', pf.value, ',')) > 0"
            : "instr(',' || pf.value || ',', ',' || ? || ',') > 0";
        array_push($params, $value, $value, $contains);
        return $clause . "((mf.field_type = 'multi' AND " . $multi . ") OR (mf.field_type IN ('select', 'radio', 'date', 'image') AND pf.value = ?) OR (mf.field_type IN ('text', 'textarea', 'editor') AND pf.value LIKE ? ESCAPE '!')))";
    }
}
