<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

final class PageCache
{
    private const TTL = 60;

    public static function key(string $root, string $locale, string $path, array $query): string
    {
        ksort($query);
        $token = self::version($root) . '|' . $locale . '|' . $path . '|' . http_build_query($query);
        return rtrim($root, '/') . '/storage/cache/pages/' . hash('sha256', $token) . '.html';
    }

    public static function invalidate(string $root, string $locale, string $path, array $query = array()): void
    {
        $file = self::key($root, $locale, $path, $query);
        $directory = dirname($file);
        if (is_link($directory) || is_link($file)) {
            return;
        }
        if (is_file($file)) {
            @unlink($file);
        }
    }

    public static function read(string $file, int $ttl = self::TTL): ?string
    {
        $updatedAt = is_file($file) && ! is_link($file) ? @filemtime($file) : false;
        if ($updatedAt === false || (time() - (int) $updatedAt) > $ttl) {
            return null;
        }
        $html = file_get_contents($file);
        return is_string($html) ? $html : null;
    }

    public static function write(string $file, string $html): void
    {
        $directory = dirname($file);
        if (is_link($directory) || is_link($file)) {
            return;
        }
        if (! is_dir($directory) && ! @mkdir($directory, 0750, true) && ! is_dir($directory)) {
            return;
        }
        $temporary = $file . '.' . bin2hex(random_bytes(6)) . '.tmp';
        if (@file_put_contents($temporary, $html, LOCK_EX) !== false) {
            if (! @rename($temporary, $file) && is_file($temporary)) {
                @unlink($temporary);
            }
        }
    }

    public static function etag(string $html): string
    {
        return '"' . hash('sha256', $html) . '"';
    }

    public static function matches(string $header, string $etag): bool
    {
        foreach (explode(',', $header) as $candidate) {
            $candidate = trim($candidate);
            if ($candidate === '*' || $candidate === $etag || $candidate === 'W/' . $etag) {
                return true;
            }
        }
        return false;
    }

    public static function stats(string $root): array
    {
        $directory = rtrim($root, '/') . '/storage/cache/pages';
        if (is_link($directory)) {
            return array('count' => 0, 'bytes' => 0);
        }
        $files = is_dir($directory) ? (glob($directory . '/*.html') ?: array()) : array();
        $now = time();
        $freshFiles = array();
        $bytes = 0;
        foreach ($files as $file) {
            $updatedAt = is_file($file) && ! is_link($file) ? @filemtime($file) : false;
            if ($updatedAt === false || ($now - (int) $updatedAt) > self::TTL) {
                if (is_file($file)) {
                    @unlink($file);
                }
                continue;
            }
            $freshFiles[] = $file;
            $bytes += (int) (@filesize($file) ?: 0);
        }
        foreach (glob($directory . '/*.tmp') ?: array() as $temporary) {
            if (is_file($temporary)) {
                @unlink($temporary);
            }
        }
        return array('count' => count($freshFiles), 'bytes' => $bytes);
    }

    public static function clear(string $root): void
    {
        $directory = rtrim($root, '/') . '/storage/cache/pages';
        if (is_dir($directory) && ! is_link($directory)) {
            foreach (glob($directory . '/*.html') ?: array() as $file) {
                if (is_file($file)) {
                    @unlink($file);
                }
            }
        }
        if (! is_link($directory)) {
            foreach (glob($directory . '/*.tmp') ?: array() as $temporary) {
                if (is_file($temporary)) {
                    @unlink($temporary);
                }
            }
        }
    }

    public static function bump(string $root): void
    {
        $file = rtrim($root, '/') . '/storage/cache/pages/.version';
        $directory = dirname($file);
        if (is_link($directory) || is_link($file)) {
            return;
        }
        if (! is_dir($directory) && ! @mkdir($directory, 0750, true) && ! is_dir($directory)) {
            return;
        }
        @file_put_contents($file, (string) microtime(true), LOCK_EX);
        foreach (glob($directory . '/*.html') ?: array() as $cachedFile) {
            if (is_file($cachedFile)) {
                @unlink($cachedFile);
            }
        }
    }

    private static function version(string $root): string
    {
        $file = rtrim($root, '/') . '/storage/cache/pages/.version';
        return is_file($file) && ! is_link($file) ? (string) file_get_contents($file) : '0';
    }
}
