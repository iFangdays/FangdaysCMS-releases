<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

/**
 * Drag-to-verify check for the admin login, switched by Pboot's 后台验证码 (admin_check_code).
 * The login page starts a clock in the session; a finished drag posts to /login/slider, which hands
 * out a single-use pass only after a human-possible delay. /login then spends that pass. It slows
 * scripted logins but is no barrier to a determined bot: the login lock remains the real limit.
 */
final class SliderCaptcha
{
    private const MIN_SECONDS = 0.5;
    public const PASS_SECONDS = 300;

    /** Start timing a new attempt; call whenever the login form is shown. */
    public static function begin(): void
    {
        $_SESSION['slider_shown_at'] = microtime(true);
        unset($_SESSION['slider_pass']);
    }

    /** A pass for the finished drag, or null when no form was shown or it finished too quickly. */
    public static function issue(): ?string
    {
        $shownAt = $_SESSION['slider_shown_at'] ?? null;
        if (! is_float($shownAt) || microtime(true) - $shownAt < self::MIN_SECONDS) {
            return null;
        }
        $pass = bin2hex(random_bytes(16));
        $_SESSION['slider_pass'] = array('token' => $pass, 'expires_at' => time() + self::PASS_SECONDS);
        return $pass;
    }

    /** Error message when the login needs a slider pass and $input is not a valid one, else null. */
    public static function error(string $input): ?string
    {
        if (! Captcha::required('admin')) {
            return null;
        }
        if (trim($input) === '') {
            return '请先完成滑块验证。';
        }
        $stored = $_SESSION['slider_pass'] ?? null;
        unset($_SESSION['slider_pass']);
        if (! is_array($stored) || ! hash_equals((string) ($stored['token'] ?? ''), $input) || (int) ($stored['expires_at'] ?? 0) < time()) {
            return '滑块验证已失效，请重新拖动。';
        }
        return null;
    }
}
