<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use RuntimeException;
use ZipArchive;

/** Installs a verified upgrade archive with a file-level rollback backup. */
final class UpgradeInstaller
{
    private const PROTECTED_FILES = array(
        'config/app.php',
        'var/content.sqlite',
        'var/license.code',
        'var/license.code.bak',
        'var/upgrade.lock',
        'var/installed-version.json',
        'var/upgrade-check.json',
    );
    private const PROTECTED_PREFIXES = array(
        'var/upgrades/',
        'public/uploads/',
        'public/static/upload/',
        'storage/',
    );

    /** @return array{version:string,backup:string,files:int} */
    public static function install(string $package, array $manifest, string $root, string $backupRoot): array
    {
        if (! is_file($package) || ! is_readable($package) || ! is_dir($root)) {
            throw new RuntimeException('升级包或站点目录不可用。');
        }
        if (! is_string($manifest['version'] ?? null) || ! preg_match('/^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/D', $manifest['version'])) {
            throw new RuntimeException('升级清单版本号无效。');
        }
        if (! is_int($manifest['size'] ?? null) || $manifest['size'] < 1 || ! is_string($manifest['sha256'] ?? null) || ! preg_match('/^[a-f0-9]{64}$/D', $manifest['sha256'])) {
            throw new RuntimeException('升级清单校验字段无效。');
        }
        $actualSize = filesize($package);
        $actualSha256 = hash_file('sha256', $package);
        if ($actualSize !== $manifest['size'] || $actualSha256 !== $manifest['sha256']) {
            throw new RuntimeException('升级包大小或 SHA-256 校验失败。');
        }
        $lock = null;
        $lockPath = rtrim($root, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'var/upgrade.lock';
        if (! is_dir(dirname($lockPath)) && ! mkdir(dirname($lockPath), 0700, true) && ! is_dir(dirname($lockPath))) {
            throw new RuntimeException('无法创建升级锁目录。');
        }
        $lock = @fopen($lockPath, 'c');
        if ($lock === false || ! flock($lock, LOCK_EX | LOCK_NB)) {
            if (is_resource($lock)) {
                fclose($lock);
            }
            throw new RuntimeException('已有升级任务正在执行。');
        }
        $zip = new ZipArchive();
        if ($zip->open($package) !== true) {
            flock($lock, LOCK_UN);
            fclose($lock);
            throw new RuntimeException('升级包不是有效 ZIP。');
        }
        $temp = rtrim($root, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . '.upgrade-' . bin2hex(random_bytes(8));
        $backup = rtrim($backupRoot, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . (string) $manifest['version'] . '-' . gmdate('YmdHis');
        $written = array();
        try {
            if (! mkdir($temp, 0700, true) && ! is_dir($temp)) {
                throw new RuntimeException('无法创建升级临时目录。');
            }
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $name = (string) $zip->getNameIndex($i);
                if ($name === '' || str_ends_with($name, '/') || $name[0] === '/' || str_contains($name, '\\') || preg_match('#(^|/)\.\.?(/|$)#', $name) || self::isProtectedPath($name)) {
                    throw new RuntimeException('升级包包含非法路径。');
                }
            }
            if (! $zip->extractTo($temp)) {
                throw new RuntimeException('升级包解压失败。');
            }
            $zip->close();
            $zip = null;
            $files = array();
            $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($temp, \FilesystemIterator::SKIP_DOTS));
            foreach ($iterator as $file) {
                if ($file->isFile()) {
                    $relative = substr($file->getPathname(), strlen($temp) + 1);
                    $files[] = str_replace(DIRECTORY_SEPARATOR, '/', $relative);
                }
            }
            if (!$files || count($files) > 10000) {
                throw new RuntimeException('升级包文件数量无效。');
            }
            foreach ($files as $relative) {
                $source = $temp . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relative);
                $target = rtrim($root, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relative);
                $targetDir = dirname($target);
                if (! is_dir($targetDir) && ! mkdir($targetDir, 0750, true) && ! is_dir($targetDir)) {
                    throw new RuntimeException('无法创建升级目录。');
                }
                if (is_file($target)) {
                    $saved = $backup . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relative);
                    if (! is_dir(dirname($saved)) && ! mkdir(dirname($saved), 0700, true) && ! is_dir(dirname($saved))) {
                        throw new RuntimeException('无法创建回滚备份。');
                    }
                    if (! copy($target, $saved)) {
                        throw new RuntimeException('无法备份旧文件。');
                    }
                }
                if (! copy($source, $target)) {
                    throw new RuntimeException('无法写入升级文件。');
                }
                $written[] = $relative;
            }
            if (! is_dir($backup) && ! mkdir($backup, 0700, true) && ! is_dir($backup)) {
                throw new RuntimeException('无法记录回滚目录。');
            }
            file_put_contents($backup . DIRECTORY_SEPARATOR . '.manifest.json', json_encode($manifest, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), LOCK_EX);
            $versionMarker = 'var/installed-version.json';
            $versionTarget = rtrim($root, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $versionMarker);
            $versionBackup = $backup . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $versionMarker);
            if (is_file($versionTarget)) {
                if (! is_dir(dirname($versionBackup)) && ! mkdir(dirname($versionBackup), 0700, true) && ! is_dir(dirname($versionBackup))) {
                    throw new RuntimeException('无法备份版本标记。');
                }
                if (! copy($versionTarget, $versionBackup)) {
                    throw new RuntimeException('无法备份版本标记。');
                }
            }
            $marker = json_encode(array('version' => (string) $manifest['version'], 'installed_at' => gmdate('c')), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            $markerTemp = $versionTarget . '.part-' . bin2hex(random_bytes(6));
            if (file_put_contents($markerTemp, $marker . PHP_EOL, LOCK_EX) === false || ! rename($markerTemp, $versionTarget)) {
                @unlink($markerTemp);
                throw new RuntimeException('无法写入版本标记。');
            }
            $installed = json_decode((string) file_get_contents($versionTarget), true);
            if (! is_array($installed) || ($installed['version'] ?? '') !== (string) $manifest['version']) {
                throw new RuntimeException('升级后版本校验失败。');
            }
            $written[] = $versionMarker;
            if (class_exists(PageCache::class)) {
                PageCache::bump($root);
            }
            if (function_exists('opcache_reset')) {
                @opcache_reset();
            }
            return array('version' => (string) $manifest['version'], 'backup' => $backup, 'files' => count($files));
        } catch (\Throwable $error) {
            foreach ($written as $relative) {
                $target = rtrim($root, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relative);
                $saved = $backup . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relative);
                if (is_file($saved)) {
                    @copy($saved, $target);
                } else {
                    @unlink($target);
                }
            }
            throw $error;
        } finally {
            if (is_object($zip)) {
                @$zip->close();
            }
            self::removeTree($temp);
            if (is_resource($lock)) {
                flock($lock, LOCK_UN);
                fclose($lock);
            }
        }
    }

    private static function isProtectedPath(string $relative): bool
    {
        if (in_array($relative, self::PROTECTED_FILES, true)) {
            return true;
        }
        foreach (self::PROTECTED_PREFIXES as $prefix) {
            if (str_starts_with($relative, $prefix)) {
                return true;
            }
        }
        return false;
    }

    private static function removeTree(string $path): void
    {
        if (! is_dir($path)) {
            return;
        }
        foreach (new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($path, \FilesystemIterator::SKIP_DOTS), \RecursiveIteratorIterator::CHILD_FIRST) as $file) {
            $file->isDir() ? @rmdir($file->getPathname()) : @unlink($file->getPathname());
        }
        @rmdir($path);
    }
}
