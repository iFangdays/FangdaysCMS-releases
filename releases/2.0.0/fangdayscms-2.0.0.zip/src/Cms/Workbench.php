<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use PDO;

/** Figures for the admin workbench; each block appears only for the permissions behind its pages. */
final class Workbench
{
    private const TREND_DAYS = 14;
    private const RECENT_POSTS = 6;
    private const RECENT_EVENTS = 6;

    public function __construct(private readonly PDO $pdo)
    {
    }

    public function overview(array $can): array
    {
        $reviews = $this->reviews($can);
        $stats = array();
        if ($can['content.view']) {
            $published = $this->count("SELECT COUNT(*) FROM posts WHERE status = 'published'");
            $drafts = $this->count("SELECT COUNT(*) FROM posts WHERE status = 'draft'");
            $stats[] = array('全部内容', $this->count('SELECT COUNT(*) FROM posts'), '已发布 ' . $published . ' · 草稿 ' . $drafts, '/admin/posts', 'fa-file-text-o');
            $stats[] = array('本周新增', $this->count('SELECT COUNT(*) FROM posts WHERE created_at >= ?', array(strtotime('monday this week'))), '从本周一起计', '/admin/posts', 'fa-line-chart');
        }
        if ($reviews !== array()) {
            $stats[] = array('待审核', array_sum(array_column($reviews, 1)), '留言、评论与投稿', $reviews[0][2], 'fa-bell-o');
        }
        if ($can['members.manage']) {
            $stats[] = array('会员', $this->count('SELECT COUNT(*) FROM members'), '近 30 天新增 ' . $this->count('SELECT COUNT(*) FROM members WHERE created_at >= ?', array(time() - 2592000)), '/admin/members', 'fa-users');
        }
        if ($can['media.manage'] && count($stats) < 4) {
            $stats[] = array('媒体图片', $this->count('SELECT COUNT(*) FROM media'), '媒体库中的图片', '/admin/media', 'fa-picture-o');
        }
        return array(
            'stats' => $stats,
            'pending' => $can['content.view'] ? array_merge($reviews, array(array('未发布草稿', $this->count("SELECT COUNT(*) FROM posts WHERE status = 'draft'"), '/admin/posts?status=draft', 'fa-file-o'))) : $reviews,
            'trend' => $can['content.view'] ? $this->trend() : array(),
            'recent' => $can['content.view'] ? $this->recentPosts() : array(),
            'events' => $can['settings.manage'] ? $this->recentEvents() : array(),
        );
    }

    /** @return list<array{0: string, 1: int, 2: string, 3: string}> label, count, link, icon */
    private function reviews(array $can): array
    {
        $rows = array();
        if ($can['operations.manage']) {
            $rows[] = array('待审留言', $this->count("SELECT COUNT(*) FROM guestbook_messages WHERE status = 'pending'"), '/admin/messages?status=pending', 'fa-comments-o');
            $rows[] = array('待审评论', $this->count("SELECT COUNT(*) FROM post_comments WHERE status = 'pending'"), '/admin/comments?status=pending', 'fa-commenting-o');
        }
        if ($can['members.manage']) {
            $rows[] = array('待审投稿', $this->count("SELECT COUNT(*) FROM member_submissions WHERE status = 'pending'"), '/admin/submissions', 'fa-pencil-square-o');
        }
        return $rows;
    }

    /** New posts per day, oldest first, counted in the site's time zone. */
    private function trend(): array
    {
        $start = strtotime('-' . (self::TREND_DAYS - 1) . ' days 00:00:00');
        $days = array();
        for ($i = 0; $i < self::TREND_DAYS; $i++) {
            $days[date('Y-m-d', strtotime('+' . $i . ' days', $start))] = 0;
        }
        $stmt = $this->pdo->prepare('SELECT created_at FROM posts WHERE created_at >= ?');
        $stmt->execute(array($start));
        foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $createdAt) {
            $day = date('Y-m-d', (int) $createdAt);
            if (isset($days[$day])) {
                $days[$day]++;
            }
        }
        return $days;
    }

    private function recentPosts(): array
    {
        return $this->pdo->query('SELECT p.id, p.title, p.status, p.created_at, c.name AS category_name FROM posts p LEFT JOIN categories c ON c.id = p.category_id ORDER BY p.created_at DESC, p.id DESC LIMIT ' . self::RECENT_POSTS)->fetchAll();
    }

    /** Latest sign-ins and changes, named after the menu page they touched; page views stay in 系统日志. */
    private function recentEvents(): array
    {
        $pages = array();
        foreach ((new MenuRepository($this->pdo))->all() as $item) {
            if ($item['path'] !== '/admin' && $item['parent_id'] !== null) {
                $pages[(string) $item['path']] = (string) $item['label'];
            }
        }
        $events = $this->pdo->query("SELECT username, method, path, created_at FROM audit_logs WHERE method <> 'GET' ORDER BY id DESC LIMIT " . self::RECENT_EVENTS)->fetchAll();
        foreach ($events as &$event) {
            $path = (string) $event['path'];
            $page = $path;
            foreach ($pages as $prefix => $label) {
                if ($path === $prefix || str_starts_with($path, $prefix . '/')) {
                    $page = $label;
                }
            }
            $event['summary'] = match ((string) $event['method']) {
                'LOGIN_OK' => '登录后台',
                'LOGIN_FAIL' => '登录失败',
                default => '修改了 ' . $page,
            };
        }
        return $events;
    }

    private function count(string $sql, array $params = array()): int
    {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return (int) $stmt->fetchColumn();
    }
}
