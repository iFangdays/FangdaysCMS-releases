<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;
use PDO;

final class MemberRepository
{
    private const PLACEHOLDER = '@member.invalid';
    /** Imported Pboot accounts: password_hash() of the old md5(md5()) value, replaced at the next login. */
    public const LEGACY_PREFIX = 'pboot$';

    public static function verifyPassword(string $password, string $stored): bool
    {
        return str_starts_with($stored, self::LEGACY_PREFIX)
            ? password_verify(md5(md5($password)), substr($stored, strlen(self::LEGACY_PREFIX)))
            : password_verify($password, $stored);
    }

    /** Moves an imported account to a modern hash once its password has been verified. */
    public function upgradePassword(int $id, string $password, string $stored): void
    {
        if (str_starts_with($stored, self::LEGACY_PREFIX)) {
            $this->pdo->prepare('UPDATE members SET password_hash = ? WHERE id = ?')->execute(array(password_hash($password, PASSWORD_DEFAULT), $id));
        }
    }

    public function __construct(private readonly PDO $pdo)
    {
    }

    public function register(string $email, string $displayName, string $password, array $fieldValues = array()): int
    {
        $email = strtolower(trim($email));
        $displayName = trim($displayName);
        if (strlen($email) > 191 || filter_var($email, FILTER_VALIDATE_EMAIL) === false || $displayName === '' || mb_strlen($displayName) > 100 || strlen($password) < 12) {
            throw new InvalidArgumentException('邮箱、昵称或密码无效；密码至少 12 位。');
        }
        $this->pdo->beginTransaction();
        try {
            $stmt = $this->pdo->prepare('INSERT INTO members (email, display_name, password_hash, status, created_at) VALUES (?, ?, ?, ?, ?)');
            $stmt->execute(array($email, $displayName, password_hash($password, PASSWORD_DEFAULT), 'active', time()));
            $id = (int) $this->pdo->lastInsertId();
            $group = $this->pdo->query("SELECT id FROM member_groups WHERE code = 'default' AND status = 'active' LIMIT 1")->fetchColumn();
            if ($group !== false) {
                $insert = $this->pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql'
                    ? 'INSERT IGNORE INTO member_group_members (group_id, member_id) VALUES (?, ?)'
                    : 'INSERT OR IGNORE INTO member_group_members (group_id, member_id) VALUES (?, ?)';
                $stmt = $this->pdo->prepare($insert);
                $stmt->execute(array((int) $group, $id));
            }
            $this->saveFields($id, $fieldValues);
            $this->pdo->commit();
            return $id;
        } catch (\Throwable $error) {
            $this->pdo->rollBack();
            throw $error;
        }
    }

    public function authenticate(string $email, string $password): ?array
    {
        $stmt = $this->pdo->prepare('SELECT m.id, m.email, m.display_name, m.password_hash, m.status, COALESCE(MIN(g.id), 0) AS group_id FROM members m LEFT JOIN member_group_members gm ON gm.member_id = m.id LEFT JOIN member_groups g ON g.id = gm.group_id AND g.status = \'active\' WHERE m.email = ? GROUP BY m.id, m.email, m.display_name, m.password_hash, m.status');
        $stmt->execute(array(strtolower(trim($email))));
        $member = $stmt->fetch();
        if (! $member || $member['status'] !== 'active' || ! self::verifyPassword($password, (string) $member['password_hash'])) {
            return null;
        }
        $this->upgradePassword((int) $member['id'], $password, (string) $member['password_hash']);
        unset($member['password_hash']);
        return $member;
    }

    public function byId(int $id): ?array
    {
        $stmt = $this->pdo->prepare('SELECT m.id, m.email, m.display_name, m.status, m.created_at, COALESCE(MIN(g.id), 0) AS group_id FROM members m LEFT JOIN member_group_members gm ON gm.member_id = m.id LEFT JOIN member_groups g ON g.id = gm.group_id AND g.status = \'active\' WHERE m.id = ? GROUP BY m.id, m.email, m.display_name, m.status, m.created_at');
        $stmt->execute(array($id));
        $member = $stmt->fetch() ?: null;
        if ($member !== null) $member['fields'] = (new MemberFieldRepository($this->pdo))->values($id);
        return $member;
    }

    public function all(): array
    {
        return $this->pdo->query('SELECT m.id, m.email, m.display_name, m.status, m.created_at, COALESCE(MIN(g.id), 0) AS group_id FROM members m LEFT JOIN member_group_members gm ON gm.member_id = m.id LEFT JOIN member_groups g ON g.id = gm.group_id AND g.status = \'active\' GROUP BY m.id, m.email, m.display_name, m.status, m.created_at ORDER BY m.id DESC')->fetchAll();
    }

    /** One member as the admin form edits it (any status, any group). */
    public function adminRow(int $id): ?array
    {
        $stmt = $this->pdo->prepare("SELECT m.*, COALESCE((SELECT MIN(gm.group_id) FROM member_group_members gm WHERE gm.member_id = m.id), 0) AS group_id FROM members m WHERE m.id = ?");
        $stmt->execute(array($id));
        $row = $stmt->fetch();
        if (! $row) {
            return null;
        }
        unset($row['password_hash']);
        $row['email'] = str_ends_with((string) $row['email'], self::PLACEHOLDER) ? '' : (string) $row['email'];
        return $row;
    }

    /** PbootCMS 会员新增 / 会员修改: at least one of username, e-mail and mobile identifies the account. */
    public function adminSave(?int $id, array $input): int
    {
        $text = static fn (string $key): string => is_string($input[$key] ?? null) ? trim($input[$key]) : '';
        [$username, $email, $mobile, $name, $headpic] = array($text('username'), strtolower($text('email')), $text('mobile'), $text('display_name'), $text('headpic'));
        $password = is_string($input['password'] ?? null) ? $input['password'] : '';
        $score = $text('score') === '' ? '0' : $text('score');
        $status = $text('status');
        $group = (int) $text('group_id');
        if ($username === '' && $email === '' && $mobile === '') {
            throw new InvalidArgumentException('用户名、邮箱、手机至少填写一项。');
        }
        if (mb_strlen($username) > 100 || ($email !== '' && (strlen($email) > 191 || filter_var($email, FILTER_VALIDATE_EMAIL) === false)) || ($mobile !== '' && preg_match('/^1[0-9]{10}$/D', $mobile) !== 1)) {
            throw new InvalidArgumentException('用户名、邮箱或手机格式不正确。');
        }
        if (mb_strlen($name) > 100 || ! ctype_digit($score) || ! in_array($status, array('active', 'pending', 'disabled'), true)) {
            throw new InvalidArgumentException('昵称、积分或状态无效。');
        }
        if ($headpic !== '' && preg_match('#^/uploads/[A-Za-z0-9/_.-]+\.(?:jpe?g|png|gif|webp)$#D', $headpic) !== 1) {
            throw new InvalidArgumentException('头像地址无效。');
        }
        if ($password === '' ? $id === null : strlen($password) < 12) {
            throw new InvalidArgumentException('登录密码至少 12 位。');
        }
        foreach (array('username' => $username, 'email' => $email, 'mobile' => $mobile) as $column => $value) {
            $taken = $this->pdo->prepare("SELECT 1 FROM members WHERE $column = ? AND id <> ?");
            $taken->execute(array($value, $id ?? 0));
            if ($value !== '' && $taken->fetchColumn() !== false) {
                throw new InvalidArgumentException(array('username' => '用户名', 'email' => '邮箱', 'mobile' => '手机')[$column] . '已被使用。');
            }
        }
        if ($group > 0) {
            $exists = $this->pdo->prepare('SELECT 1 FROM member_groups WHERE id = ?');
            $exists->execute(array($group));
            if ($exists->fetchColumn() === false) {
                throw new InvalidArgumentException('会员等级不存在。');
            }
        }
        $this->pdo->beginTransaction();
        try {
            $stored = $email !== '' ? $email : 'u-' . bin2hex(random_bytes(8)) . self::PLACEHOLDER;
            if ($id === null) {
                $this->pdo->prepare('INSERT INTO members (email, display_name, password_hash, status, created_at, username, mobile, headpic, score) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
                    ->execute(array($stored, $name !== '' ? $name : ($username !== '' ? $username : ($email !== '' ? $email : $mobile)), password_hash($password, PASSWORD_DEFAULT), $status, time(), $username, $mobile, $headpic, (int) $score));
                $id = (int) $this->pdo->lastInsertId();
            } else {
                $this->pdo->prepare('UPDATE members SET email = CASE WHEN ? = \'\' AND email LIKE ? THEN email ELSE ? END, display_name = ?, status = ?, username = ?, mobile = ?, headpic = ?, score = ? WHERE id = ?')
                    ->execute(array($email, '%' . self::PLACEHOLDER, $stored, $name, $status, $username, $mobile, $headpic, (int) $score, $id));
                if ($password !== '') {
                    $this->pdo->prepare('UPDATE members SET password_hash = ? WHERE id = ?')->execute(array(password_hash($password, PASSWORD_DEFAULT), $id));
                }
            }
            $this->pdo->prepare('DELETE FROM member_group_members WHERE member_id = ?')->execute(array($id));
            if ($group > 0) {
                $this->pdo->prepare('INSERT INTO member_group_members (group_id, member_id) VALUES (?, ?)')->execute(array($group, $id));
            }
            (new MemberFieldRepository($this->pdo))->saveValues($id, is_array($input['fields'] ?? null) ? $input['fields'] : array());
            $this->pdo->commit();
            return $id;
        } catch (\Throwable $error) {
            $this->pdo->rollBack();
            throw $error;
        }
    }

    public function delete(int $id): void
    {
        $this->pdo->prepare('DELETE FROM members WHERE id = ?')->execute(array($id));
    }

    /** PbootCMS 会员列表 rows: account names, score, level and login time, optionally filtered by a keyword. */
    public function adminList(string $keyword = ''): array
    {
        $sql = "SELECT m.id, m.email, COALESCE(m.username, '') AS username, COALESCE(m.mobile, '') AS mobile, m.display_name, m.status, m.created_at, COALESCE(m.score, 0) AS score, COALESCE(m.last_login_time, 0) AS last_login_time, (SELECT g.name FROM member_group_members gm JOIN member_groups g ON g.id = gm.group_id WHERE gm.member_id = m.id ORDER BY g.id LIMIT 1) AS group_name FROM members m";
        $params = array();
        if ($keyword !== '') {
            $sql .= ' WHERE m.username LIKE ? OR m.display_name LIKE ? OR m.email LIKE ? OR m.mobile LIKE ?';
            $params = array_fill(0, 4, '%' . $keyword . '%');
        }
        $stmt = $this->pdo->prepare($sql . ' ORDER BY m.id DESC');
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function updateName(int $id, string $displayName): void
    {
        $displayName = trim($displayName);
        if ($displayName === '' || mb_strlen($displayName) > 100) {
            throw new InvalidArgumentException('昵称不能为空且不超过 100 个字。');
        }
        $stmt = $this->pdo->prepare('UPDATE members SET display_name = ? WHERE id = ?');
        $stmt->execute(array($displayName, $id));
    }

    public function updateProfile(int $id, string $displayName, array $fieldValues): void
    {
        $this->updateName($id, $displayName);
        $this->saveFields($id, $fieldValues);
    }

    private function saveFields(int $memberId, array $values): void
    {
        (new MemberFieldRepository($this->pdo))->saveValues($memberId, $values);
    }
    public function changePassword(int $id, string $currentPassword, string $newPassword): void
    {
        if (strlen($newPassword) < 12) {
            throw new InvalidArgumentException('新密码至少 12 位。');
        }
        $stmt = $this->pdo->prepare('SELECT password_hash FROM members WHERE id = ? AND status = ?');
        $stmt->execute(array($id, 'active'));
        $hash = $stmt->fetchColumn();
        if (! is_string($hash) || ! self::verifyPassword($currentPassword, $hash)) {
            throw new InvalidArgumentException('当前密码不正确。');
        }
        $stmt = $this->pdo->prepare('UPDATE members SET password_hash = ? WHERE id = ?');
        $stmt->execute(array(password_hash($newPassword, PASSWORD_DEFAULT), $id));
    }

    public function issueToken(string $email, string $type, int $ttl): ?string
    {
        if (! in_array($type, array('verify', 'reset'), true)) {
            throw new InvalidArgumentException('会员令牌类型无效。');
        }
        $stmt = $this->pdo->prepare('SELECT id FROM members WHERE email = ? LIMIT 1');
        $stmt->execute(array(strtolower(trim($email))));
        $memberId = $stmt->fetchColumn();
        if ($memberId === false) {
            return null;
        }
        $token = bin2hex(random_bytes(32));
        $hash = hash('sha256', $token);
        $this->pdo->prepare('UPDATE member_tokens SET used_at = ? WHERE member_id = ? AND token_type = ? AND used_at IS NULL')->execute(array(time(), (int) $memberId, $type));
        $this->pdo->prepare('INSERT INTO member_tokens (member_id, token_hash, token_type, expires_at, used_at, created_at) VALUES (?, ?, ?, ?, NULL, ?)')->execute(array((int) $memberId, $hash, $type, time() + $ttl, time()));
        return $token;
    }

    public function revokeToken(string $token, string $type): void
    {
        if ($token === '' || ! in_array($type, array('verify', 'reset'), true)) {
            return;
        }
        $this->pdo->prepare('DELETE FROM member_tokens WHERE token_hash = ? AND token_type = ? AND used_at IS NULL')->execute(array(hash('sha256', $token), $type));
    }

    public function consumeToken(string $token, string $type): ?int
    {
        if (! preg_match('/^[a-f0-9]{64}$/', $token) || ! in_array($type, array('verify', 'reset'), true)) {
            return null;
        }
        $stmt = $this->pdo->prepare('SELECT id, member_id FROM member_tokens WHERE token_hash = ? AND token_type = ? AND used_at IS NULL AND expires_at >= ? LIMIT 1');
        $stmt->execute(array(hash('sha256', $token), $type, time()));
        $row = $stmt->fetch();
        if (! $row) {
            return null;
        }
        $used = $this->pdo->prepare('UPDATE member_tokens SET used_at = ? WHERE id = ? AND used_at IS NULL');
        $used->execute(array(time(), (int) $row['id']));
        return $used->rowCount() === 1 ? (int) $row['member_id'] : null;
    }

    public function resetPassword(int $id, string $newPassword): void
    {
        if (strlen($newPassword) < 12) {
            throw new InvalidArgumentException('新密码至少 12 位。');
        }
        $stmt = $this->pdo->prepare('UPDATE members SET password_hash = ?, status = ? WHERE id = ?');
        $stmt->execute(array(password_hash($newPassword, PASSWORD_DEFAULT), 'active', $id));
    }

    public function markVerified(int $id): void
    {
        $stmt = $this->pdo->prepare('UPDATE members SET status = ? WHERE id = ? AND status = ?');
        $stmt->execute(array('active', $id, 'pending'));
    }

    public function setStatus(int $id, string $status): void
    {
        if (! in_array($status, array('active', 'disabled'), true)) {
            throw new InvalidArgumentException('会员状态无效。');
        }
        $stmt = $this->pdo->prepare('UPDATE members SET status = ? WHERE id = ?');
        $stmt->execute(array($status, $id));
    }
}
