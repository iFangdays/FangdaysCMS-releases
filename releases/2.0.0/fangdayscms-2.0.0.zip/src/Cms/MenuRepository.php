<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;
use PDO;

final class MenuRepository
{
    public const LOCALES = array('zh-CN', 'en-US');

    public function __construct(private readonly PDO $pdo)
    {
    }

    public function all(bool $includeHidden = true): array
    {
        $sql = 'SELECT id, parent_id, slug, label, icon, path, permission, sort_order, is_visible, is_quick FROM admin_menus';
        if (! $includeHidden) {
            $sql .= ' WHERE is_visible = 1';
        }
        $sql .= ' ORDER BY sort_order ASC, id ASC';
        return $this->pdo->query($sql)->fetchAll();
    }

    /** Visible items the role may open; a group (top-level grp_ row) is kept when any of its items is. */
    public function visibleFor(array $can): array
    {
        $all = $this->all(false);
        $isGroup = static fn (array $item): bool => $item['parent_id'] === null && str_starts_with((string) $item['slug'], 'grp_');
        $items = array_filter($all, static fn (array $item): bool => ! $isGroup($item) && ($can[(string) $item['permission']] ?? false) === true);
        $usedGroups = array();
        foreach ($items as $item) {
            if ($item['parent_id'] !== null) {
                $usedGroups[(int) $item['parent_id']] = true;
            }
        }
        return array_values(array_filter($all, static fn (array $item): bool => $isGroup($item) ? isset($usedGroups[(int) $item['id']]) : in_array($item, $items, true)));
    }

    public function save(?int $id, array $input): int
    {
        $label = trim((string) ($input['label'] ?? ''));
        $slug = trim((string) ($input['slug'] ?? ''));
        $path = trim((string) ($input['path'] ?? ''));
        $permission = trim((string) ($input['permission'] ?? ''));
        $parentId = $input['parent_id'] === '' ? null : filter_var($input['parent_id'], FILTER_VALIDATE_INT, array('options' => array('min_range' => 1)));
        $sortOrder = filter_var($input['sort_order'] ?? 0, FILTER_VALIDATE_INT);
        if ($label === '' || mb_strlen($label) > 100 || ! preg_match('/^[a-z][a-z0-9_-]{1,63}$/D', $slug) || ! preg_match('#^/admin(?:/[a-z0-9_/-]+)?$#D', $path) || ! array_key_exists($permission, Permissions::CATALOG) || $sortOrder === false || $parentId === false) {
            throw new InvalidArgumentException('菜单字段无效。');
        }
        if ($parentId !== null && $id !== null && $parentId === $id) {
            throw new InvalidArgumentException('菜单不能将自身作为父级。');
        }
        $values = array($parentId, $slug, $label, trim((string) ($input['icon'] ?? 'fa-circle-o')), $path, $permission, $sortOrder, ! empty($input['is_visible']) ? 1 : 0, ! empty($input['is_quick']) ? 1 : 0);
        if ($id === null) {
            $stmt = $this->pdo->prepare('INSERT INTO admin_menus (parent_id, slug, label, icon, path, permission, sort_order, is_visible, is_quick) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
            $stmt->execute($values);
            return (int) $this->pdo->lastInsertId();
        }
        $stmt = $this->pdo->prepare('UPDATE admin_menus SET parent_id = ?, slug = ?, label = ?, icon = ?, path = ?, permission = ?, sort_order = ?, is_visible = ?, is_quick = ? WHERE id = ?');
        $stmt->execute(array_merge($values, array($id)));
        return $id;
    }

    public function setVisible(int $id, bool $visible): void
    {
        $this->pdo->prepare('UPDATE admin_menus SET is_visible = ? WHERE id = ?')->execute(array((int) $visible, $id));
    }

    public function delete(int $id): void
    {
        $stmt = $this->pdo->prepare('DELETE FROM admin_menus WHERE id = ?');
        $stmt->execute(array($id));
    }

    public function quickLinks(array $can): array
    {
        return array_values(array_filter($this->visibleFor($can), static fn (array $item): bool => (int) $item['is_quick'] === 1));
    }
}
