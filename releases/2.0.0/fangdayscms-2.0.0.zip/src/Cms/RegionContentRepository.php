<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;
use PDO;

/** Isolated regional records; canonical tables are never mutated by this class. */
final class RegionContentRepository
{
    private const TYPES = array('post', 'page', 'category');
    private const FIELDS = array('title', 'body', 'slug', 'status', 'visibility', 'category_id', 'parent_id', 'seo_title', 'seo_keywords', 'seo_description', 'custom_fields', 'media');

    public function __construct(private readonly PDO $pdo)
    {
    }

    public function save(string $locale, string $type, ?int $id, ?int $sourceId, string $slug, array $payload, string $status, int $userId): int
    {
        if ($locale === 'zh-CN' || !in_array($type, self::TYPES, true) || !preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/D', $slug) || !in_array($status, array('draft', 'published'), true)) {
            throw new InvalidArgumentException('区域记录或状态无效。');
        }
        $this->assertRegion($locale);
        if ($sourceId !== null) {
            $this->assertSource($type, $sourceId);
        }
        $clean = array();
        foreach ($payload as $field => $value) {
            if (!is_string($field) || !in_array($field, self::FIELDS, true) || (!is_scalar($value) && $value !== null && !is_array($value))) {
                throw new InvalidArgumentException('区域记录包含未知字段。');
            }
            $clean[$field] = $value;
        }
        $clean['slug'] = $slug;
        $clean['status'] = $status;
        if (($clean['title'] ?? '') === '' || !isset($clean['body'])) {
            throw new InvalidArgumentException('区域记录必须包含标题和正文。');
        }
        if (isset($clean['category_id']) && $clean['category_id'] !== null) {
            $categoryId = filter_var($clean['category_id'], FILTER_VALIDATE_INT, array('options' => array('min_range' => 1)));
            if ($categoryId === false) throw new InvalidArgumentException('区域栏目 ID 无效。');
            $this->assertSource('category', (int) $categoryId);
        }
        $json = json_encode($clean, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        $now = time();
        if ($id !== null) {
            $stmt = $this->pdo->prepare('SELECT locale, entity_type FROM region_content_records WHERE id = ?');
            $stmt->execute(array($id));
            $existing = $stmt->fetch();
            if ($existing === false || (string) $existing['locale'] !== $locale || (string) $existing['entity_type'] !== $type) throw new InvalidArgumentException('区域记录不属于当前区域或实体类型。');
            $stmt = $this->pdo->prepare('UPDATE region_content_records SET source_id = ?, slug = ?, status = ?, payload_json = ?, updated_at = ?, updated_by = ?, deleted_at = NULL WHERE id = ? AND locale = ?');
            $stmt->execute(array($sourceId, $slug, $status, $json, $now, $userId, $id, $locale));
            return $id;
        }
        $stmt = $this->pdo->prepare('INSERT INTO region_content_records (locale, entity_type, source_id, slug, status, payload_json, created_at, updated_at, created_by, updated_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute(array($locale, $type, $sourceId, $slug, $status, $json, $now, $now, $userId, $userId));
        return (int) $this->pdo->lastInsertId();
    }

    public function all(string $locale, ?string $type = null, bool $includeDeleted = false): array
    {
        $where = 'locale = ?';
        $params = array($locale);
        if ($type !== null) {
            if (!in_array($type, self::TYPES, true)) return array();
            $where .= ' AND entity_type = ?';
            $params[] = $type;
        }
        if (!$includeDeleted) $where .= ' AND deleted_at IS NULL';
        $stmt = $this->pdo->prepare('SELECT * FROM region_content_records WHERE ' . $where . ' ORDER BY updated_at DESC, id DESC');
        $stmt->execute($params);
        return array_values(array_filter(array_map(fn ($row) => $this->decode($row), $stmt->fetchAll()), static fn ($row) => $row !== null));
    }

    public function published(string $locale, ?string $type = null): array
    {
        return array_values(array_filter($this->all($locale, $type), static fn (array $row): bool => $row['status'] === 'published'));
    }

    public function publishedForCategory(string $locale, int $categoryId): array
    {
        return array_values(array_filter($this->published($locale, 'post'), static fn (array $row): bool => (int) ($row['category_id'] ?? 0) === $categoryId));
    }

    public function mergePosts(string $locale, array $canonical): array
    {
        if ($locale === 'zh-CN') return $canonical;
        $bySource = array();
        foreach ($this->published($locale, 'post') as $record) {
            $row = $this->asPost($record);
            if ($record['source_id'] !== null) $bySource[(int) $record['source_id']] = $row;
            else $canonical[] = $row;
        }
        foreach ($canonical as &$row) {
            if (isset($bySource[(int) ($row['id'] ?? 0)])) $row = array_merge($row, $bySource[(int) $row['id']]);
        }
        unset($row);
        return $canonical;
    }

    public function mergePages(string $locale, array $canonical): array
    {
        if ($locale === 'zh-CN') return $canonical;
        $bySource = array();
        foreach ($this->published($locale, 'page') as $record) {
            $row = array_merge(array('id' => -((int) $record['id']), 'slug' => $record['slug'], 'title' => '', 'body' => '', 'body_format' => 'plain', 'menu_order' => 255, 'seo_title' => '', 'seo_keywords' => '', 'seo_description' => ''), $record);
            if ($record['source_id'] !== null) $bySource[(int) $record['source_id']] = $row; else $canonical[] = $row;
        }
        foreach ($canonical as &$row) if (isset($bySource[(int) ($row['id'] ?? 0)])) $row = array_merge($row, $bySource[(int) $row['id']]);
        unset($row);
        return $canonical;
    }

    public function mergeCategories(string $locale, array $canonical): array
    {
        if ($locale === 'zh-CN') return $canonical;
        $bySource = array();
        foreach ($this->published($locale, 'category') as $record) {
            $row = array_merge(array('id' => -((int) $record['id']), 'parent_id' => null, 'name' => '', 'slug' => $record['slug'], 'type' => 'list', 'is_visible' => 1, 'sort_order' => 255, 'seo_title' => '', 'seo_keywords' => '', 'seo_description' => '', 'single_status' => 'published'), $record);
            if ($record['source_id'] !== null) $bySource[(int) $record['source_id']] = $row; else $canonical[] = $row;
        }
        foreach ($canonical as &$row) if (isset($bySource[(int) ($row['id'] ?? 0)])) $row = array_merge($row, $bySource[(int) $row['id']]);
        unset($row);
        return $canonical;
    }

    public function byId(string $locale, int $id): ?array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM region_content_records WHERE locale = ? AND id = ? AND deleted_at IS NULL');
        $stmt->execute(array($locale, $id));
        return $this->decode($stmt->fetch() ?: null);
    }

    public function asPost(array $record): array
    {
        return array_merge(array('id' => -((int) $record['id']), 'slug' => $record['slug'], 'title' => $record['title'] ?? '', 'body' => $record['body'] ?? '', 'subtitle' => '', 'author' => '', 'source' => '', 'category_name' => '', 'category_slug' => '', 'category_path' => '', 'visibility' => $record['visibility'] ?? 'public', 'published_at' => (int) $record['updated_at'], 'created_at' => (int) $record['created_at'], 'updated_at' => (int) $record['updated_at'], 'sort_order' => 255, 'outlink' => '', 'body_format' => 'plain', 'seo_keywords' => $record['seo_keywords'] ?? '', 'seo_description' => $record['seo_description'] ?? ''), $record);
    }

    public function publishedBySlug(string $locale, string $type, string $slug): ?array
    {
        if (!in_array($type, self::TYPES, true)) return null;
        $stmt = $this->pdo->prepare("SELECT * FROM region_content_records WHERE locale = ? AND entity_type = ? AND slug = ? AND status = 'published' AND deleted_at IS NULL");
        $stmt->execute(array($locale, $type, $slug));
        return $this->decode($stmt->fetch() ?: null);
    }

    public function tombstone(string $locale, int $id, int $userId): void
    {
        $stmt = $this->pdo->prepare('UPDATE region_content_records SET status = \'draft\', deleted_at = ?, updated_at = ?, updated_by = ? WHERE locale = ? AND id = ? AND deleted_at IS NULL');
        $stmt->execute(array(time(), time(), $userId, $locale, $id));
        if ($stmt->rowCount() !== 1) throw new InvalidArgumentException('区域记录不存在或不属于当前区域。');
    }

    private function assertRegion(string $locale): void
    {
        $stmt = $this->pdo->prepare('SELECT 1 FROM regions WHERE locale = ? AND is_enabled = 1 AND locale <> \'zh-CN\'');
        $stmt->execute(array($locale));
        if (!$stmt->fetchColumn()) throw new InvalidArgumentException('未知或不可写区域。');
    }

    private function assertSource(string $type, int $id): void
    {
        $tables = array('post' => 'posts', 'page' => 'pages', 'category' => 'categories');
        $stmt = $this->pdo->prepare('SELECT 1 FROM ' . $tables[$type] . ' WHERE id = ?');
        $stmt->execute(array($id));
        if (!$stmt->fetchColumn()) throw new InvalidArgumentException('未知 canonical ID。');
    }

    private function decode(?array $row): ?array
    {
        if ($row === null) return null;
        $payload = json_decode((string) $row['payload_json'], true);
        if (!is_array($payload)) throw new InvalidArgumentException('区域记录数据损坏。');
        return array_merge($row, $payload);
    }
}
