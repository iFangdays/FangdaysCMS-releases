<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use FangdaysCMS\Licensing\LicenseCode;
use FangdaysCMS\Licensing\LicenseStore;
use FangdaysCMS\Licensing\TrustedKeys;
use RuntimeException;

/** Local provisioning helper. Licensed automatically only on a machine holding a trusted vendor signing key. */
final class Quickstart
{
    public static function install(string $root, string $keyFile, string $domain = '127.0.0.1', string $siteName = 'FangdaysCMS'): array
    {
        if (is_file($root . '/config/app.php')) {
            throw new RuntimeException('站点已经安装，快速安装不会覆盖现有数据。');
        }
        $domain = LicenseCode::normalizeDomain($domain) ?? throw new RuntimeException('站点域名无效。');
        // Only the vendor's own trusted signing key can license a quickstart site; nothing is generated here.
        $secret = null;
        if (is_file($keyFile)) {
            $encoded = file_get_contents($keyFile);
            $decoded = $encoded === false ? false : base64_decode(trim($encoded), true);
            if ($decoded !== false && LicenseCode::keyIdFor($decoded, TrustedKeys::KEYS) !== null) {
                $secret = $decoded;
            }
        }
        $password = rtrim(strtr(base64_encode(random_bytes(24)), '+/', '-_'), '=');
        Installer::install(array(
            'site_name' => $siteName,
            'site_domain' => $domain,
            'admin_username' => 'admin',
            'admin_password' => $password,
            'database_driver' => 'sqlite'
        ), $root);
        $config = require $root . '/config/app.php';
        $pdo = Database::connect($config['database']);
        $content = new ContentRepository($pdo);
        $newsId = $content->saveCategory(null, '网站动态', 'news', 10);
        $content->savePost(null, $newsId, '欢迎使用 FangdaysCMS', 'welcome', '站点已经安装完成。登录后台后，可以修改栏目、发布文章、管理标签与会员，并维护角色权限。', 'published');
        (new PageRepository($pdo))->save(null, '关于我们', 'about', '请在后台「单页」中编辑这里的介绍、联系方式与服务内容。', 'published', 10);
        (new SettingsRepository($pdo))->save($siteName, $siteName . ' 的最新动态与专题内容。', 'Powered by FangdaysCMS');
        $licensed = false;
        if ($secret !== null) {
            $code = LicenseCode::issue(LicenseCode::claims($domain, 'never', (string) LicenseCode::keyIdFor($secret, TrustedKeys::KEYS)), $secret);
            if (! (new LicenseStore($config['license_file'], $domain))->activate($code)['valid']) {
                throw new RuntimeException('站点已安装，但本地授权激活失败。');
            }
            $licensed = true;
        }
        return array('domain' => $domain, 'username' => 'admin', 'password' => $password, 'licensed' => $licensed);
    }
}
