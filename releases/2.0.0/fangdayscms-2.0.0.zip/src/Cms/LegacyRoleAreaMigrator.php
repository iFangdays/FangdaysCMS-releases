<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;
use PDO;

/**
 * Migrates Pboot ay_role_area rows into canonical role_locales grants.
 * The source is read-only; all target validation happens before any write.
 */
final class LegacyRoleAreaMigrator
{
    /** @param array<string,string> $roleMap */
    public static function migrate(PDO $source, PDO $target, array $roleMap = array()): array
    {
        $driver = $source->getAttribute(PDO::ATTR_DRIVER_NAME);
        foreach (array('ay_role', 'ay_role_area', 'ay_area') as $table) {
            if (! self::tableExists($source, $driver, $table)) {
                throw new InvalidArgumentException('旧库缺少 ' . $table . '，未执行角色区域迁移。');
            }
        }
        foreach (array('rcode' => 'ay_role', 'acode' => 'ay_role_area') as $column => $table) {
            if (! self::columnExists($source, $driver, $table, $column)) {
                throw new InvalidArgumentException($table . ' 缺少必需列：' . $column);
            }
        }
        foreach (array('acode' => 'ay_area') as $column => $table) {
            if (! self::columnExists($source, $driver, $table, $column)) {
                throw new InvalidArgumentException($table . ' 缺少必需列：' . $column);
            }
        }

        $rows = $source->query('SELECT rcode, acode FROM ay_role_area ORDER BY rcode, acode')->fetchAll(PDO::FETCH_ASSOC);
        $roles = array();
        foreach ($rows as $row) {
            $rcode = trim((string) $row['rcode']);
            $acode = trim((string) $row['acode']);
            if ($rcode === '' || $acode === '') {
                throw new InvalidArgumentException('角色区域关联含空 role/acode，已原子拒绝。');
            }
            $roles[$rcode] = true;
        }
        $roleRows = $source->query('SELECT rcode FROM ay_role')->fetchAll(PDO::FETCH_COLUMN);
        $knownLegacyRoles = array_fill_keys(array_map('strval', $roleRows), true);
        foreach (array_keys($roles) as $rcode) {
            if (! isset($knownLegacyRoles[$rcode])) {
                throw new InvalidArgumentException('未知旧角色：' . $rcode . '，已原子拒绝。');
            }
        }

        $roleIds = array();
        $roleStmt = $target->prepare('SELECT id FROM roles WHERE slug = ?');
        foreach (array_keys($roles) as $rcode) {
            $slug = array_key_exists($rcode, $roleMap) ? trim((string) $roleMap[$rcode]) : $rcode;
            if ($slug === '' || ! preg_match('/^[a-z][a-z0-9_-]{1,63}$/D', $slug)) {
                throw new InvalidArgumentException('旧角色映射无效：' . $rcode . '，已原子拒绝。');
            }
            $roleStmt->execute(array($slug));
            $id = $roleStmt->fetchColumn();
            if ($id === false) {
                throw new InvalidArgumentException('旧角色未映射到 canonical role：' . $rcode . '，已原子拒绝。');
            }
            $roleIds[$rcode] = (int) $id;
        }

        $areaStmt = $target->prepare('SELECT locale FROM regions WHERE legacy_acode = ? OR prefix = ? OR locale = ?');
        $grants = array();
        foreach ($rows as $row) {
            $acode = trim((string) $row['acode']);
            $areaStmt->execute(array($acode, $acode, $acode));
            $locale = $areaStmt->fetchColumn();
            if ($locale === false) {
                throw new InvalidArgumentException('未知旧区域：' . $acode . '，已原子拒绝。');
            }
            $grants[] = array($roleIds[(string) $row['rcode']], (string) $locale);
        }

        $target->beginTransaction();
        try {
            $delete = $target->prepare('DELETE FROM role_locales WHERE role_id = ?');
            $insert = $target->prepare('INSERT INTO role_locales (role_id, locale) VALUES (?, ?)');
            $seen = array();
            foreach ($roleIds as $roleId) {
                $delete->execute(array($roleId));
            }
            foreach ($grants as [$roleId, $locale]) {
                $key = $roleId . ':' . $locale;
                if (isset($seen[$key])) {
                    continue;
                }
                $insert->execute(array($roleId, $locale));
                $seen[$key] = true;
            }
            $target->commit();
        } catch (\Throwable $error) {
            if ($target->inTransaction()) {
                $target->rollBack();
            }
            throw $error;
        }
        return array('source_rows' => count($rows), 'roles' => count($roleIds), 'grants' => count($grants));
    }

    private static function tableExists(PDO $pdo, string $driver, string $table): bool
    {
        if ($driver === 'sqlite') {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM sqlite_master WHERE type = 'table' AND name = ?");
            $stmt->execute(array($table));
            return (bool) $stmt->fetchColumn();
        }
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?');
        $stmt->execute(array($table));
        return (bool) $stmt->fetchColumn();
    }

    private static function columnExists(PDO $pdo, string $driver, string $table, string $column): bool
    {
        if ($driver === 'sqlite') {
            $stmt = $pdo->query('PRAGMA table_info(' . $table . ')');
            foreach ($stmt as $item) {
                if ((string) $item['name'] === $column) return true;
            }
            return false;
        }
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?');
        $stmt->execute(array($table, $column));
        return (bool) $stmt->fetchColumn();
    }
}
