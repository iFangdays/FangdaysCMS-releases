<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;
use PDO;

/** Locale-specific overlays; legacy columns remain the canonical fallback. */
final class TranslationRepository
{
    public function __construct(private readonly PDO $pdo)
    {
    }

    public function all(?string $locale = null): array
    {
        if ($locale === null) {
            return $this->pdo->query('SELECT entity_type, entity_key, locale, field, value FROM content_translations ORDER BY entity_type, entity_key, locale, field')->fetchAll();
        }
        $stmt = $this->pdo->prepare('SELECT entity_type, entity_key, locale, field, value FROM content_translations WHERE locale = ? ORDER BY entity_type, entity_key, field');
        $stmt->execute(array($locale));
        return $stmt->fetchAll();
    }

    public function forEntity(string $type, string $key, string $locale): array
    {
        $stmt = $this->pdo->prepare('SELECT field, value FROM content_translations WHERE entity_type = ? AND entity_key = ? AND locale = ?');
        $stmt->execute(array($type, $key, $locale));
        return array_column($stmt->fetchAll(), 'value', 'field');
    }

    public function apply(string $type, array $row, string $locale): array
    {
        if ($locale === 'zh-CN' || ! isset($row['id'])) {
            return $row;
        }
        $values = $this->forEntity($type, (string) $row['id'], $locale);
        $structuralFields = array('id', 'entity_type', 'entity_key', 'locale', 'status', 'visibility', 'is_visible', 'category_id', 'parent_id', 'model_id', 'slug', 'sort_order', 'type', 'body_format', 'single_status', 'created_at', 'updated_at', 'published_at');
        foreach ($values as $field => $value) {
            if (! in_array($field, $structuralFields, true) && array_key_exists($field, $row) && (string) $value !== '') {
                $row[$field] = $value;
            }
        }
        return $row;
    }

    public function save(string $type, string $key, string $locale, string $field, string $value): void
    {
        foreach (array($type, $key, $locale, $field) as $part) {
            if (trim($part) === '' || strlen($part) > 100) {
                throw new InvalidArgumentException('译文标识无效。');
            }
        }
        if (! preg_match('/^[A-Za-z][A-Za-z0-9]*(?:-[A-Za-z0-9]+)*$/D', $locale) || strlen($value) > 2000000) {
            throw new InvalidArgumentException('译文区域或内容无效。');
        }
        if (trim($value) === '') {
            $this->delete($type, $key, $locale, $field);
            return;
        }
        $exists = $this->pdo->prepare('SELECT 1 FROM content_translations WHERE entity_type = ? AND entity_key = ? AND locale = ? AND field = ?');
        $exists->execute(array($type, $key, $locale, $field));
        if ($exists->fetchColumn() !== false) {
            $stmt = $this->pdo->prepare('UPDATE content_translations SET value = ? WHERE entity_type = ? AND entity_key = ? AND locale = ? AND field = ?');
            $stmt->execute(array($value, $type, $key, $locale, $field));
            return;
        }
        $stmt = $this->pdo->prepare('INSERT INTO content_translations (entity_type, entity_key, locale, field, value) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute(array($type, $key, $locale, $field, $value));
    }

    /** Save an overlay for a regional admin without accepting a caller-supplied locale. */
    public function saveForLocale(string $type, string $key, string $locale, string $field, string $value): void
    {
        $this->assertOverlayTarget($type, $key, $locale, $field);
        $this->save($type, $key, $locale, $field, $value);
    }

    public function deleteForLocale(string $type, string $key, string $locale, string $field): void
    {
        $this->assertOverlayTarget($type, $key, $locale, $field);
        $this->delete($type, $key, $locale, $field);
    }

    private function assertOverlayTarget(string $type, string $key, string $locale, string $field): void
    {
        if ($locale === '' || $locale === 'zh-CN') {
            throw new InvalidArgumentException('区域译文必须写入当前非 canonical 区域。');
        }
        $fields = array(
            'post' => array('title', 'body', 'subtitle', 'author', 'source', 'seo_keywords', 'seo_description'),
            'page' => array('title', 'body', 'seo_title', 'seo_keywords', 'seo_description'),
            'category' => array('name', 'seo_title', 'seo_keywords', 'seo_description', 'single_title', 'single_body'),
            'company' => array('name', 'address', 'telephone', 'email', 'description'),
            'site' => array('site_name', 'description', 'seo_title', 'seo_keywords', 'seo_description', 'footer_text'),
        );
        if (! isset($fields[$type]) || ! in_array($field, $fields[$type], true)) {
            throw new InvalidArgumentException('该字段不是区域 overlay。');
        }
        if (! preg_match('/^[1-9][0-9]*$/D', $key) || ($type === 'site' || $type === 'company') && $key !== '1') {
            throw new InvalidArgumentException('区域译文对象无效。');
        }
        $tables = array('post' => 'posts', 'page' => 'pages', 'category' => 'categories', 'company' => 'company_profile', 'site' => 'site_settings');
        $stmt = $this->pdo->prepare('SELECT 1 FROM ' . $tables[$type] . ' WHERE ' . ($type === 'site' ? 'name' : 'id') . ' = ? LIMIT 1');
        $stmt->execute(array($type === 'site' ? 'site_name' : ($type === 'company' ? 1 : (int) $key)));
        if (! $stmt->fetchColumn()) {
            throw new InvalidArgumentException('区域译文对象不存在。');
        }
    }

    public function delete(string $type, string $key, string $locale, string $field): void
    {
        $stmt = $this->pdo->prepare('DELETE FROM content_translations WHERE entity_type = ? AND entity_key = ? AND locale = ? AND field = ?');
        $stmt->execute(array($type, $key, $locale, $field));
    }

    public function deleteEntity(string $type, string $key, string $locale): void
    {
        $stmt = $this->pdo->prepare('DELETE FROM content_translations WHERE entity_type = ? AND entity_key = ? AND locale = ?');
        $stmt->execute(array($type, $key, $locale));
    }
}
