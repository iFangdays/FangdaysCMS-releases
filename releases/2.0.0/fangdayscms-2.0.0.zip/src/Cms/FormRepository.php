<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;
use PDO;

final class FormRepository
{
    private const FIELD_TYPES = array('text', 'email', 'textarea', 'select');

    public function __construct(private readonly PDO $pdo)
    {
    }

    public function all(): array
    {
        return $this->pdo->query('SELECT * FROM custom_forms ORDER BY id DESC')->fetchAll();
    }

    public function byId(int $id): ?array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM custom_forms WHERE id = ?');
        $stmt->execute(array($id));
        return $stmt->fetch() ?: null;
    }

    public function publishedBySlug(string $slug): ?array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM custom_forms WHERE slug = ? AND status = ?');
        $stmt->execute(array($slug, 'published'));
        return $stmt->fetch() ?: null;
    }

    public function fields(array $form): array
    {
        $fields = json_decode((string) ($form['fields_json'] ?? '[]'), true);
        return is_array($fields) ? array_values(array_filter($fields, 'is_array')) : array();
    }

    /** $fieldText null keeps the current fields (managed one by one on the 字段 page). */
    public function save(?int $id, string $name, string $slug, string $intro, string $status, ?string $fieldText = null): int
    {
        $name = trim($name);
        $slug = trim($slug);
        $intro = trim($intro);
        if ($name === '' || mb_strlen($name) > 100 || ! preg_match('/^[a-z][a-z0-9-]{0,63}$/', $slug)) {
            throw new InvalidArgumentException('表单名称或标识无效。');
        }
        if (! in_array($status, array('draft', 'published'), true)) {
            throw new InvalidArgumentException('表单状态无效。');
        }
        if (mb_strlen($intro) > 500) {
            throw new InvalidArgumentException('表单说明不能超过 500 个字。');
        }
        $fields = $fieldText === null ? ($id === null ? array() : $this->fields($this->byId($id) ?? array())) : $this->parseFields($fieldText);
        $json = json_encode($fields, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
        $now = time();
        try {
            if ($id === null) {
                $stmt = $this->pdo->prepare('INSERT INTO custom_forms (name, slug, intro, status, fields_json, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)');
                $stmt->execute(array($name, $slug, $intro, $status, $json, $now, $now));
                return (int) $this->pdo->lastInsertId();
            }
            $stmt = $this->pdo->prepare('UPDATE custom_forms SET name = ?, slug = ?, intro = ?, status = ?, fields_json = ?, updated_at = ? WHERE id = ?');
            $stmt->execute(array($name, $slug, $intro, $status, $json, $now, $id));
            if ($stmt->rowCount() === 0 && $this->byId($id) === null) {
                throw new InvalidArgumentException('表单不存在。');
            }
            return $id;
        } catch (\PDOException $error) {
            if ((int) $error->errorInfo[1] === 19 || str_contains($error->getMessage(), 'Duplicate')) {
                throw new InvalidArgumentException('表单标识已经存在。');
            }
            throw $error;
        }
    }

    /** Pboot 表单字段: add or change one field; $original names the field being changed. */
    public function saveField(int $formId, ?string $original, array $input): void
    {
        $form = $this->byId($formId) ?? throw new InvalidArgumentException('表单不存在。');
        $line = implode('|', array_map(static fn (string $key): string => str_replace(array('|', "\n", "\r"), ' ', is_string($input[$key] ?? null) ? $input[$key] : ''), array('name', 'label', 'type', 'required', 'options')));
        $field = $this->parseFields($line)[0] ?? throw new InvalidArgumentException('字段格式无效。');
        if (mb_strlen((string) $field['label']) > 100) {
            throw new InvalidArgumentException('字段描述最多 100 个字符。');
        }
        $sort = is_string($input['sort'] ?? null) && ctype_digit($input['sort']) ? (int) $input['sort'] : 255;
        $rows = array();
        $replaced = false;
        foreach ($this->fields($form) as $row) {
            if ($row['name'] === $field['name'] && $row['name'] !== $original) {
                throw new InvalidArgumentException('字段标识不能重复。');
            }
            if ($row['name'] === $original) {
                $rows[] = array('sort' => $sort) + $field;
                $replaced = true;
            } else {
                $rows[] = $row;
            }
        }
        if (! $replaced) {
            if ($original !== null) {
                throw new InvalidArgumentException('字段不存在。');
            }
            $rows[] = array('sort' => $sort) + $field;
        }
        usort($rows, static fn (array $a, array $b): int => ($a['sort'] ?? 255) <=> ($b['sort'] ?? 255));
        $this->storeFields($formId, $rows);
    }

    public function deleteField(int $formId, string $name): void
    {
        $form = $this->byId($formId) ?? throw new InvalidArgumentException('表单不存在。');
        $this->storeFields($formId, array_values(array_filter($this->fields($form), static fn (array $row): bool => $row['name'] !== $name)));
    }

    private function storeFields(int $formId, array $rows): void
    {
        $this->pdo->prepare('UPDATE custom_forms SET fields_json = ?, updated_at = ? WHERE id = ?')->execute(array(json_encode($rows, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), time(), $formId));
    }

    public function setStatus(int $id, bool $published): void
    {
        $this->pdo->prepare('UPDATE custom_forms SET status = ?, updated_at = ? WHERE id = ?')->execute(array($published ? 'published' : 'draft', time(), $id));
    }

    public function delete(int $id): void
    {
        $stmt = $this->pdo->prepare('DELETE FROM custom_forms WHERE id = ?');
        $stmt->execute(array($id));
        if ($stmt->rowCount() === 0) {
            throw new InvalidArgumentException('表单不存在。');
        }
    }

    public function submit(int $formId, array $values, ?int $memberId = null): int
    {
        $form = $this->byId($formId);
        if ($form === null || $form['status'] !== 'published') {
            throw new InvalidArgumentException('表单不存在或未发布。');
        }
        $normalized = array();
        foreach ($this->fields($form) as $field) {
            $name = (string) ($field['name'] ?? '');
            $value = is_string($values[$name] ?? null) ? trim($values[$name]) : '';
            if (! empty($field['required']) && $value === '') {
                throw new InvalidArgumentException((string) ($field['label'] ?? $name) . '不能为空。');
            }
            if (($field['type'] ?? '') === 'email' && $value !== '' && ! filter_var($value, FILTER_VALIDATE_EMAIL)) {
                throw new InvalidArgumentException((string) ($field['label'] ?? $name) . '格式无效。');
            }
            if (mb_strlen($value) > 2000) {
                throw new InvalidArgumentException('表单内容过长。');
            }
            $normalized[$name] = $value;
        }
        $stmt = $this->pdo->prepare('INSERT INTO form_submissions (form_id, member_id, values_json, created_at) VALUES (?, ?, ?, ?)');
        $stmt->execute(array($formId, $memberId, json_encode($normalized, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), time()));
        return (int) $this->pdo->lastInsertId();
    }

    public function submissions(int $formId): array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM form_submissions WHERE form_id = ? ORDER BY created_at DESC, id DESC');
        $stmt->execute(array($formId));
        return $stmt->fetchAll();
    }

    private function parseFields(string $text): array
    {
        $result = array();
        foreach (preg_split('/\R/', trim($text)) ?: array() as $line) {
            $line = trim($line);
            if ($line === '') {
                continue;
            }
            $parts = array_map('trim', explode('|', $line, 5));
            [$name, $label, $type, $required, $options] = array_pad($parts, 5, '');
            // Pboot form fields use plain names such as tel; names used by the submission itself are reserved.
            if (! preg_match('/^[a-z][a-z0-9_]{0,58}$/', $name) || in_array($name, array('website', 'checkcode', 'submit'), true) || $label === '' || ! in_array($type, self::FIELD_TYPES, true)) {
                throw new InvalidArgumentException('字段格式无效，请使用：字段标识|字段名|类型|必填|选项（标识为小写字母开头的字母、数字或下划线）。');
            }
            if (isset($result[$name])) {
                throw new InvalidArgumentException('字段标识不能重复。');
            }
            if ($type === 'select' && $options === '') {
                throw new InvalidArgumentException('下拉字段必须填写选项。');
            }
            $result[$name] = array('name' => $name, 'label' => $label, 'type' => $type, 'required' => in_array(strtolower($required), array('1', 'yes', 'y', '是'), true), 'options' => $type === 'select' ? array_values(array_filter(array_map('trim', explode(',', $options)))) : array());
        }
        return array_values($result);
    }
}
