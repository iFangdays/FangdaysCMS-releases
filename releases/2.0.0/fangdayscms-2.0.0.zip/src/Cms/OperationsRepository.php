<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;
use PDO;

final class OperationsRepository
{
    private const COMPANY_FIELDS = array('name', 'address', 'postcode', 'contact', 'mobile', 'phone', 'fax', 'email', 'qq', 'weixin', 'blicense', 'other');

    public function __construct(private readonly PDO $pdo)
    {
    }

    public function slides(?int $groupId = null, int $limit = 200, int $start = 1): array
    {
        $stmt = $this->pdo->prepare('SELECT s.id, s.group_id, s.media_id, s.title, s.subtitle, s.link, s.sort_order, m.path AS image_path, m.original_name AS image_name FROM slides s JOIN media m ON m.id = s.media_id WHERE (? IS NULL OR s.group_id = ?) ORDER BY s.sort_order, s.id LIMIT ? OFFSET ?');
        $stmt->bindValue(1, $groupId, $groupId === null ? PDO::PARAM_NULL : PDO::PARAM_INT);
        $stmt->bindValue(2, $groupId, $groupId === null ? PDO::PARAM_NULL : PDO::PARAM_INT);
        $stmt->bindValue(3, max(1, min($limit, 200)), PDO::PARAM_INT);
        $stmt->bindValue(4, max(0, $start - 1), PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function slide(int $id): ?array
    {
        $stmt = $this->pdo->prepare('SELECT s.id, s.group_id, s.media_id, s.title, s.subtitle, s.link, s.sort_order, m.path AS image_path FROM slides s JOIN media m ON m.id = s.media_id WHERE s.id = ?');
        $stmt->execute(array($id));
        return $stmt->fetch() ?: null;
    }

    public function saveSlide(?int $id, array $input): int
    {
        $group = self::number($input['group_id'] ?? '', '分组', 1, 1000000);
        $media = self::number($input['media_id'] ?? '', '轮播图片', 1, PHP_INT_MAX);
        $this->requireMedia($media);
        $title = self::shortText($input['title'] ?? '', '标题', 150);
        $subtitle = self::shortText($input['subtitle'] ?? '', '副标题', 255);
        $link = self::link($input['link'] ?? '', false);
        $order = self::number($input['sort_order'] ?? '', '排序', 0, 1000000);
        if ($id === null) {
            $stmt = $this->pdo->prepare('INSERT INTO slides (group_id, media_id, title, subtitle, link, sort_order) VALUES (?, ?, ?, ?, ?, ?)');
            $stmt->execute(array($group, $media, $title, $subtitle, $link, $order));
            return (int) $this->pdo->lastInsertId();
        }
        if ($this->slide($id) === null) {
            throw new InvalidArgumentException('轮播图不存在。');
        }
        $stmt = $this->pdo->prepare('UPDATE slides SET group_id = ?, media_id = ?, title = ?, subtitle = ?, link = ?, sort_order = ? WHERE id = ?');
        $stmt->execute(array($group, $media, $title, $subtitle, $link, $order, $id));
        return $id;
    }

    public function deleteSlide(int $id): void
    {
        $stmt = $this->pdo->prepare('DELETE FROM slides WHERE id = ?');
        $stmt->execute(array($id));
    }

    public function links(?int $groupId = null, int $limit = 200, int $start = 1): array
    {
        $stmt = $this->pdo->prepare('SELECT l.id, l.group_id, l.name, l.link, l.media_id, l.sort_order, m.path AS logo_path FROM friend_links l LEFT JOIN media m ON m.id = l.media_id WHERE (? IS NULL OR l.group_id = ?) ORDER BY l.sort_order, l.id LIMIT ? OFFSET ?');
        $stmt->bindValue(1, $groupId, $groupId === null ? PDO::PARAM_NULL : PDO::PARAM_INT);
        $stmt->bindValue(2, $groupId, $groupId === null ? PDO::PARAM_NULL : PDO::PARAM_INT);
        $stmt->bindValue(3, max(1, min($limit, 200)), PDO::PARAM_INT);
        $stmt->bindValue(4, max(0, $start - 1), PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function friendLink(int $id): ?array
    {
        $stmt = $this->pdo->prepare('SELECT l.id, l.group_id, l.name, l.link, l.media_id, l.sort_order, m.path AS logo_path FROM friend_links l LEFT JOIN media m ON m.id = l.media_id WHERE l.id = ?');
        $stmt->execute(array($id));
        return $stmt->fetch() ?: null;
    }

    public function saveLink(?int $id, array $input): int
    {
        $group = self::number($input['group_id'] ?? '', '分组', 1, 1000000);
        $name = self::shortText($input['name'] ?? '', '友链名称', 150, true);
        $link = self::link($input['link'] ?? '', true);
        if (! is_string($input['media_id'] ?? '')) {
            throw new InvalidArgumentException('Logo 图片无效。');
        }
        $media = trim($input['media_id'] ?? '');
        $mediaId = $media === '' ? null : self::number($media, 'Logo 图片', 1, PHP_INT_MAX);
        if ($mediaId !== null) {
            $this->requireMedia($mediaId);
        }
        $order = self::number($input['sort_order'] ?? '', '排序', 0, 1000000);
        if ($id === null) {
            $stmt = $this->pdo->prepare('INSERT INTO friend_links (group_id, name, link, media_id, sort_order) VALUES (?, ?, ?, ?, ?)');
            $stmt->execute(array($group, $name, $link, $mediaId, $order));
            return (int) $this->pdo->lastInsertId();
        }
        if ($this->friendLink($id) === null) {
            throw new InvalidArgumentException('友情链接不存在。');
        }
        $stmt = $this->pdo->prepare('UPDATE friend_links SET group_id = ?, name = ?, link = ?, media_id = ?, sort_order = ? WHERE id = ?');
        $stmt->execute(array($group, $name, $link, $mediaId, $order, $id));
        return $id;
    }

    /** Pboot 保存排序 on the 轮播图片 / 友情链接 lists: sort_order[id] => value. */
    public function saveSortOrders(bool $slides, array $orders): int
    {
        $stmt = $this->pdo->prepare('UPDATE ' . ($slides ? 'slides' : 'friend_links') . ' SET sort_order = ? WHERE id = ?');
        $changed = 0;
        foreach ($orders as $id => $value) {
            if (! ctype_digit((string) $id) || ! is_string($value) || ! ctype_digit($value) || (int) $value > 1000000) {
                throw new InvalidArgumentException('排序值须为 0 到 1000000 的整数。');
            }
        }
        foreach ($orders as $id => $value) {
            $stmt->execute(array((int) $value, (int) $id));
            $changed += $stmt->rowCount();
        }
        return $changed;
    }

    public function deleteLink(int $id): void
    {
        $stmt = $this->pdo->prepare('DELETE FROM friend_links WHERE id = ?');
        $stmt->execute(array($id));
    }

    public function labels(): array
    {
        return $this->pdo->query('SELECT id, name, description, type, value, value_en FROM custom_labels ORDER BY id DESC LIMIT 200')->fetchAll();
    }

    public function label(int $id): ?array
    {
        $stmt = $this->pdo->prepare('SELECT id, name, description, type, value, value_en FROM custom_labels WHERE id = ?');
        $stmt->execute(array($id));
        return $stmt->fetch() ?: null;
    }

    public function labelValues(string $locale = 'zh-CN'): array
    {
        $values = array();
        $column = $locale === 'en-US' ? 'COALESCE(NULLIF(value_en, \'\'), value)' : 'value';
        foreach ($this->pdo->query("SELECT name, $column AS label_value FROM custom_labels") as $row) {
            $values[$row['name']] = $row['label_value'];
        }
        return $values;
    }

    public function labelDefinitions(string $locale = 'zh-CN'): array
    {
        $definitions = array();
        $column = $locale === 'en-US' ? 'COALESCE(NULLIF(value_en, \'\'), value)' : 'value';
        foreach ($this->pdo->query("SELECT name, type, $column AS label_value FROM custom_labels") as $row) {
            $definitions[$row['name']] = array('value' => $row['label_value'], 'type' => $row['type']);
        }
        return $definitions;
    }

    public function labelApiItems(string $locale = 'zh-CN'): array
    {
        $column = $locale === 'en-US' ? 'COALESCE(NULLIF(value_en, \'\'), value)' : 'value';
        $stmt = $this->pdo->query("SELECT name, type, $column AS value FROM custom_labels ORDER BY id DESC");
        return $stmt->fetchAll();
    }

    public function saveLabel(?int $id, array $input): int
    {
        if (! is_string($input['name'] ?? '')) {
            throw new InvalidArgumentException('标签标识无效。');
        }
        $name = trim($input['name'] ?? '');
        if (! preg_match('/^[a-zA-Z][a-zA-Z0-9_]*$/D', $name) || strlen($name) > 64) {
            throw new InvalidArgumentException('标签标识须以字母开头，只能包含字母、数字和下划线，最多 64 个字符。');
        }
        $description = self::shortText($input['description'] ?? '', '说明', 150);
        $type = (string) ($input['type'] ?? 'text');
        if (! in_array($type, array('text', 'editor', 'image'), true)) {
            throw new InvalidArgumentException('标签类型无效。');
        }
        foreach (array('value', 'value_en') as $valueKey) {
            if (! is_string($input[$valueKey] ?? '')) {
                throw new InvalidArgumentException('标签内容无效。');
            }
        }
        $value = trim((string) $input['value']);
        $valueEn = trim((string) ($input['value_en'] ?? ''));
        if ($type === 'editor') {
            $value = RichText::clean($value, 'html');
            $valueEn = RichText::clean($valueEn, 'html');
            if (strlen($value) > 200000 || strlen($valueEn) > 200000) {
                throw new InvalidArgumentException('富文本标签内容过长。');
            }
        } elseif ($type === 'image') {
            foreach (array($value, $valueEn) as $path) {
                if ($path === '') {
                    continue;
                }
                if (! preg_match('#^/uploads/[0-9]{4}/[0-9]{2}/[a-f0-9]{32}\\.(jpg|png|webp|gif)$#D', $path)) {
                    throw new InvalidArgumentException('图片标签必须引用媒体库图片。');
                }
                $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM media WHERE path = ?');
                $stmt->execute(array($path));
                if (! (int) $stmt->fetchColumn()) {
                    throw new InvalidArgumentException('图片标签引用的媒体不存在。');
                }
            }
        } elseif (mb_strlen($value) > 2000 || mb_strlen($valueEn) > 2000) {
            throw new InvalidArgumentException('标签内容最多 2000 个字符。');
        }
        if ($id === null) {
            $stmt = $this->pdo->prepare('INSERT INTO custom_labels (name, description, type, value, value_en) VALUES (?, ?, ?, ?, ?)');
            $stmt->execute(array($name, $description, $type, $value, $valueEn));
            return (int) $this->pdo->lastInsertId();
        }
        if ($this->label($id) === null) {
            throw new InvalidArgumentException('自定义标签不存在。');
        }
        $stmt = $this->pdo->prepare('UPDATE custom_labels SET name = ?, description = ?, type = ?, value = ?, value_en = ? WHERE id = ?');
        $stmt->execute(array($name, $description, $type, $value, $valueEn, $id));
        return $id;
    }

    /** Pboot 标签内容: save every label's value from one form. Each value passes the rules of its type. */
    public function saveLabelValues(array $values, array $valuesEn): int
    {
        $changed = 0;
        $this->pdo->beginTransaction();
        try {
            foreach ($values as $id => $value) {
                $label = ctype_digit((string) $id) ? $this->label((int) $id) : null;
                if ($label === null || ! is_string($value)) {
                    throw new InvalidArgumentException('自定义标签不存在。');
                }
                $valueEn = $valuesEn[$id] ?? $label['value_en'];
                if ($value !== $label['value'] || $valueEn !== $label['value_en']) {
                    $this->saveLabel((int) $id, array('value' => $value, 'value_en' => $valueEn) + $label);
                    $changed++;
                }
            }
            $this->pdo->commit();
            return $changed;
        } catch (\Throwable $error) {
            $this->pdo->rollBack();
            throw $error;
        }
    }

    public function deleteLabel(int $id): void
    {
        $stmt = $this->pdo->prepare('DELETE FROM custom_labels WHERE id = ?');
        $stmt->execute(array($id));
    }

    public function company(string $locale = 'zh-CN'): array
    {
        $row = $this->pdo->query('SELECT * FROM company_profile WHERE id = 1')->fetch() ?: array();
        $values = array_fill_keys(self::COMPANY_FIELDS, '');
        foreach (self::COMPANY_FIELDS as $field) {
            $values[$field] = (string) ($row[$field] ?? '');
        }
        if ($locale === 'en-US') {
            foreach (array('name', 'address', 'contact') as $field) {
                $localized = (string) ($row[$field . '_en'] ?? '');
                if ($localized !== '') {
                    $values[$field] = $localized;
                }
            }
        }
        return $values;
    }

    public function saveCompany(array $input): void
    {
        $values = array();
        $maxLengths = array('name' => 150, 'address' => 255, 'postcode' => 30, 'contact' => 100, 'mobile' => 50, 'phone' => 50, 'fax' => 50, 'email' => 191, 'qq' => 50, 'weixin' => 255, 'blicense' => 255, 'other' => 2000);
        foreach (self::COMPANY_FIELDS as $field) {
            $values[$field] = self::shortText($input[$field] ?? '', $field, $maxLengths[$field]);
        }
        foreach (array('name_en' => 150, 'address_en' => 255, 'contact_en' => 100) as $field => $maxLength) {
            $values[$field] = self::shortText($input[$field] ?? '', $field, $maxLength);
        }
        if ($values['email'] !== '' && filter_var($values['email'], FILTER_VALIDATE_EMAIL) === false) {
            throw new InvalidArgumentException('公司邮箱格式无效。');
        }
        $columns = implode(', ', array_merge(self::COMPANY_FIELDS, array('name_en', 'address_en', 'contact_en')));
        $params = array_values($values);
        $this->pdo->beginTransaction();
        try {
            $this->pdo->exec('DELETE FROM company_profile WHERE id = 1');
            $stmt = $this->pdo->prepare('INSERT INTO company_profile (id, ' . $columns . ') VALUES (' . implode(', ', array_fill(0, count($params) + 1, '?')) . ')');
            $stmt->execute(array_merge(array(1), $params));
            $this->pdo->commit();
        } catch (\Throwable $error) {
            $this->pdo->rollBack();
            throw $error;
        }
    }

    private function requireMedia(int $id): void
    {
        $stmt = $this->pdo->prepare('SELECT 1 FROM media WHERE id = ?');
        $stmt->execute(array($id));
        if (! $stmt->fetchColumn()) {
            throw new InvalidArgumentException('所选图片不存在，请先到媒体图片上传。');
        }
    }

    private static function number(mixed $value, string $label, int $min, int $max): int
    {
        $number = filter_var($value, FILTER_VALIDATE_INT, array('options' => array('min_range' => $min, 'max_range' => $max)));
        if ($number === false) {
            throw new InvalidArgumentException($label . '须为 ' . $min . ' 到 ' . $max . ' 的整数。');
        }
        return $number;
    }

    private static function shortText(mixed $value, string $label, int $max, bool $required = false): string
    {
        if (! is_string($value)) {
            throw new InvalidArgumentException($label . '无效。');
        }
        $value = trim($value);
        if (($required && $value === '') || mb_strlen($value) > $max) {
            throw new InvalidArgumentException($label . '不能为空或超过 ' . $max . ' 个字符。');
        }
        return $value;
    }

    private static function link(mixed $value, bool $required): string
    {
        if (! is_string($value)) {
            throw new InvalidArgumentException('链接格式无效。');
        }
        $value = trim($value);
        if ($value === '' && ! $required) {
            return '';
        }
        $parts = parse_url($value);
        $absolute = $parts !== false && in_array(strtolower($parts['scheme'] ?? ''), array('http', 'https'), true)
            && ! empty($parts['host']) && ! isset($parts['user']) && ! isset($parts['pass'])
            && filter_var($value, FILTER_VALIDATE_URL) !== false;
        $relative = (bool) preg_match('~^/(?!/)[^\x00-\x20\x7f\\\\]*$~D', $value);
        if (strlen($value) > 2048 || (! $absolute && ! $relative)) {
            throw new InvalidArgumentException('链接只支持 http(s) 地址或站内绝对路径。');
        }
        return $value;
    }
}
