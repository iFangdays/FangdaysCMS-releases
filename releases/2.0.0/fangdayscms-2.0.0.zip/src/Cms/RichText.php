<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;

final class RichText
{
    private static ?\HTMLPurifier $purifier = null;

    public static function clean(string $body, string $format): string
    {
        if (! in_array($format, array('plain', 'html'), true) || strlen($body) > 2000000) {
            throw new InvalidArgumentException('正文格式或长度无效。');
        }
        return $format === 'html' ? self::purifier()->purify($body) : $body;
    }

    public static function render(string $body, string $format): string
    {
        return $format === 'html'
            ? self::clean($body, 'html')
            : nl2br(View::e($body));
    }

    public static function editorHtml(string $body, string $format): string
    {
        if ($format === 'html') {
            return self::clean($body, 'html');
        }
        return '<p>' . str_replace("\n", '<br>', View::e(str_replace("\r\n", "\n", $body))) . '</p>';
    }

    public static function summary(string $body, string $format, int $limit): string
    {
        $text = $format === 'html'
            ? html_entity_decode(strip_tags(preg_replace('~</(?:p|div|li|h[2-4]|blockquote|br)>~i', ' ', $body) ?? $body), ENT_QUOTES | ENT_HTML5, 'UTF-8')
            : $body;
        $text = preg_replace('/\s+/u', ' ', $text) ?? $text;
        return mb_substr(trim($text), 0, $limit);
    }

    private static function purifier(): \HTMLPurifier
    {
        if (self::$purifier !== null) {
            return self::$purifier;
        }
        require_once dirname(__DIR__, 2) . '/third_party/htmlpurifier/library/HTMLPurifier.auto.php';
        $config = \HTMLPurifier_Config::createDefault();
        $config->set('Core.Encoding', 'UTF-8');
        $config->set('Cache.DefinitionImpl', null);
        // Covers the formatting UEditor writes (and PbootCMS content uses); Purifier still validates every value.
        $config->set('HTML.Allowed', 'p[style],br,b,i,strong,em,u,s,sub,sup,h1[style],h2[style],h3[style],h4[style],h5[style],h6[style],hr,blockquote[style],ul[style],ol[style],li[style],a[href|title|target],img[src|alt|title|width|height|style],table[style|border|cellpadding|cellspacing|width],caption,thead,tbody,tfoot,tr[style],th[style|colspan|rowspan|width],td[style|colspan|rowspan|width|valign|align],pre[class],code,span[style],div[style]');
        $config->set('CSS.AllowedProperties', array('color', 'background-color', 'text-align', 'font-size', 'font-family', 'font-weight', 'font-style', 'text-indent', 'text-decoration', 'line-height', 'letter-spacing', 'white-space', 'vertical-align', 'width', 'height', 'margin', 'margin-top', 'margin-right', 'margin-bottom', 'margin-left', 'padding', 'padding-top', 'padding-right', 'padding-bottom', 'padding-left', 'border', 'border-collapse'));
        $config->set('Attr.AllowedFrameTargets', array('_blank'));
        $config->set('URI.AllowedSchemes', array('http' => true, 'https' => true, 'mailto' => true));
        $config->set('HTML.SafeIframe', false);
        $config->set('HTML.SafeObject', false);
        return self::$purifier = new \HTMLPurifier($config);
    }
}
