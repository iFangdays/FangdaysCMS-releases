<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

/** Small file-backed fixed-window limiter for authentication and public interactions. */
final class RateLimiter
{
    public function __construct(private readonly string $directory)
    {
    }

    public function cleanup(int $maxAgeSeconds = 86400): int
    {
        if (! is_dir($this->directory)) {
            return 0;
        }
        $removed = 0;
        $threshold = time() - max(60, $maxAgeSeconds);
        foreach (glob($this->directory . '/*.json') ?: array() as $path) {
            if (is_link($path) || ! is_file($path)) {
                continue;
            }
            $updated = @filemtime($path);
            if ($updated !== false && $updated < $threshold && @unlink($path)) {
                $removed++;
            }
        }
        return $removed;
    }

    public function configuredAllow(string $scope, string $identity, int $defaultLimit, int $defaultWindowSeconds = 300): bool
    {
        $key = strtoupper((string) preg_replace('/[^A-Za-z0-9]+/', '_', $scope));
        $limit = self::positiveEnvironmentInt('FANGDAYS_RATE_' . $key . '_LIMIT', $defaultLimit);
        $window = self::positiveEnvironmentInt('FANGDAYS_RATE_' . $key . '_WINDOW', $defaultWindowSeconds);
        return $this->allow($scope, $identity, $limit, $window);
    }

    private static function positiveEnvironmentInt(string $name, int $fallback): int
    {
        $value = getenv($name);
        if ($value === false || ! preg_match('/^[1-9][0-9]{0,5}$/', $value)) {
            return $fallback;
        }
        return max(1, min(86400, (int) $value));
    }

    public function allow(string $scope, string $identity, int $limit, int $windowSeconds = 300): bool
    {
        $windowSeconds = max(1, $windowSeconds);
        if (! is_dir($this->directory) && ! mkdir($this->directory, 0700, true) && ! is_dir($this->directory)) {
            return false;
        }
        $path = $this->directory . '/' . hash('sha256', $scope . "\0" . $identity) . '.json';
        $handle = @fopen($path, 'c+');
        if ($handle === false || ! flock($handle, LOCK_EX)) {
            if (is_resource($handle)) {
                fclose($handle);
            }
            return false;
        }
        $raw = stream_get_contents($handle);
        $state = is_string($raw) ? json_decode($raw, true) : null;
        $now = time();
        if (! is_array($state) || ! is_int($state['started'] ?? null) || $now - $state['started'] >= $windowSeconds) {
            $state = array('started' => $now, 'hits' => 0);
        }
        $state['hits']++;
        $allowed = $state['hits'] <= $limit;
        ftruncate($handle, 0);
        rewind($handle);
        fwrite($handle, json_encode($state, JSON_THROW_ON_ERROR));
        fflush($handle);
        flock($handle, LOCK_UN);
        fclose($handle);
        return $allowed;
    }
}
