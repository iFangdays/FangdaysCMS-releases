<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

/** Render Pboot-style select tags inside a trusted HTML template fragment. */
final class ContentFilterTags
{
    public static function html(string $source, array $fields, string $path, array $query = array()): string
    {
        $source = TemplateTags::normalize($source);
        $byName = array();
        foreach ($fields as $field) {
            if (in_array($field['field_type'] ?? null, array('select', 'radio', 'multi'), true) && is_string($field['name'] ?? null)) {
                $byName[$field['name']] = $field;
            }
        }
        $source = preg_replace_callback('~\{fd:select\s+([^}]*)\}(.*?)\{/fd:select\}~s', static function (array $match) use ($byName, $path, $query): string {
            $name = self::attributes($match[1])['field'] ?? '';
            if (! isset($byName[$name])) {
                return '';
            }
            $field = $byName[$name];
            $current = (string) ($field['current'] ?? '');
            $output = '';
            foreach ($field['options'] as $index => $value) {
                $value = (string) $value;
                $body = preg_replace_callback('~\{fd:if\s*\((.*?)\)\}(.*?)\{/fd:if\}~si', static function (array $condition) use ($value, $current): string {
                    $branches = explode('{else}', $condition[2], 2);
                    return self::evaluateCondition($condition[1], $value, $current) ? $branches[0] : ($branches[1] ?? '');
                }, $match[2]) ?? $match[2];
                $output .= strtr($body, array(
                    '[select:n]' => (string) $index,
                    '[select:i]' => (string) ($index + 1),
                    '[select:value]' => View::e($value),
                    '[select:name]' => View::e($value),
                    '[select:text]' => View::e($value),
                    '[select:current]' => View::e($current),
                    '[select:link]' => View::e(self::link($path, $query, $name, $value)),
                ));
            }
            return $output;
        }, $source) ?? $source;

        return preg_replace_callback('~\{fd:selectall\s+([^}]*)\}~', static function (array $match) use ($byName, $path, $query): string {
            $attributes = self::attributes($match[1]);
            $name = $attributes['field'] ?? '';
            if (! isset($byName[$name])) {
                return '';
            }
            $active = (string) ($byName[$name]['current'] ?? '') === '';
            $class = $active ? ($attributes['active'] ?? '') : ($attributes['class'] ?? '');
            $text = $attributes['text'] ?? '全部';
            return '<a href="' . View::e(self::link($path, $query, $name, null)) . '" class="' . View::e($class) . '"' . ($active ? ' aria-current="true"' : '') . '>' . View::e($text) . '</a>';
        }, $source) ?? $source;
    }

    private static function evaluateCondition(string $condition, string $value, string $current): bool
    {
        $resolve = static function (string $operand) use ($value, $current): string {
            $operand = trim($operand);
            $unquoted = trim($operand, " \t\n\r\x27\"");
            if (preg_match('/^\[select:(value|current)\]$/i', $unquoted, $match)) {
                return $match[1] === 'value' ? $value : $current;
            }
            return $unquoted;
        };
        $evaluate = static function (string $expression) use ($resolve): bool {
            if (preg_match('/^\s*(.*?)\s*(>=|<=|!=|==|=|>|<)\s*(.*?)\s*$/s', $expression, $comparison)) {
                $left = $resolve($comparison[1]);
                $right = $resolve($comparison[3]);
                if (is_numeric($left) && is_numeric($right)) {
                    $left = (float) $left;
                    $right = (float) $right;
                }
                return match ($comparison[2]) {
                    '!=' => $left != $right,
                    '>' => $left > $right,
                    '<' => $left < $right,
                    '>=' => $left >= $right,
                    '<=' => $left <= $right,
                    default => $left == $right,
                };
            }
            return $resolve($expression) !== '';
        };
        foreach (preg_split('/\s*(?:\|\||\bor\b)\s*/i', trim($condition)) ?: array() as $orPart) {
            $andResult = true;
            foreach (preg_split('/\s*(?:&&|\band\b)\s*/i', $orPart) ?: array() as $andPart) {
                $andResult = $andResult && $evaluate($andPart);
            }
            if ($andResult) {
                return true;
            }
        }
        return false;
    }

    private static function attributes(string $source): array
    {
        preg_match_all('~\b([a-z]+)\s*=\s*(?:"([^"]*)"|\x27([^\x27]*)\x27|([^\s}]+))~', $source, $matches, PREG_SET_ORDER);
        foreach ($matches as $match) {
            $result[$match[1]] = $match[2] !== '' ? $match[2] : ($match[3] !== '' ? $match[3] : ($match[4] ?? ''));
        }
        return $result;
    }

    private static function link(string $path, array $query, string $field, ?string $value): string
    {
        unset($query['page'], $query[$field]);
        if ($value !== null) {
            $query[$field] = $value;
        }
        return $path . ($query ? (str_contains($path, '?') ? '&' : '?') . http_build_query($query) : '');
    }
}
