<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use RuntimeException;

/** Minimal SMTP transport for the isolated local sink and configured mail relay. */
final class SmtpMailer
{
    public static function configured(): bool
    {
        return (getenv('FANGDAYS_SMTP_HOST') ?: '') !== '';
    }

    public static function send(string $to, string $type, string $token): void
    {
        $host = (string) getenv('FANGDAYS_SMTP_HOST');
        $port = (int) (getenv('FANGDAYS_SMTP_PORT') ?: 2525);
        $from = (string) (getenv('FANGDAYS_SMTP_FROM') ?: 'noreply@localhost.test');
        if ($host === '' || $port < 1 || $port > 65535 || filter_var($to, FILTER_VALIDATE_EMAIL) === false || filter_var($from, FILTER_VALIDATE_EMAIL) === false) {
            throw new RuntimeException('mail transport unavailable');
        }
        if (! function_exists('stream_socket_client')) {
            throw new RuntimeException('mail transport unavailable');
        }
        $socket = @stream_socket_client('tcp://' . $host . ':' . $port, $errno, $error, 3);
        if (! is_resource($socket)) {
            throw new RuntimeException('mail transport unavailable');
        }
        stream_set_timeout($socket, 3);
        try {
            self::expect($socket, 220);
            self::command($socket, 'EHLO localhost', 250);
            self::command($socket, 'MAIL FROM:<' . $from . '>', 250);
            self::command($socket, 'RCPT TO:<' . $to . '>', 250);
            self::command($socket, 'DATA', 354);
            $url = '/member/' . ($type === 'reset' ? 'reset' : 'verify') . '?token=' . rawurlencode($token);
            $body = "Your FangdaysCMS link: " . $url;
            $message = "From: FangdaysCMS <" . $from . ">\r\nTo: <" . $to . ">\r\nSubject: FangdaysCMS account action\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n" . $body;
            $message = preg_replace('/\r?\n/', "\r\n", $message);
            $message = preg_replace('/^\./m', '..', (string) $message);
            fwrite($socket, $message . "\r\n.\r\n");
            self::expect($socket, 250);
            self::command($socket, 'QUIT', 221);
        } finally {
            fclose($socket);
        }
    }

    /**
     * Pboot sendmail(): HTML mail through the SMTP server of 配置参数 → 邮件通知
     * (ssl:// when smtp_ssl, AUTH LOGIN when an account is set). $to may list several addresses.
     */
    public static function sendMail(array $server, string $to, string $subject, string $html): void
    {
        $host = (string) ($server['smtp_server'] ?? '');
        $port = (int) ($server['smtp_port'] ?? 0) ?: (($server['smtp_ssl'] ?? '') === '1' ? 465 : 25);
        $user = (string) ($server['smtp_username'] ?? '');
        $recipients = array_values(array_filter(preg_split('/[,，;\s]+/u', $to) ?: array(), static fn (string $mail): bool => filter_var($mail, FILTER_VALIDATE_EMAIL) !== false));
        $from = filter_var($user, FILTER_VALIDATE_EMAIL) !== false ? $user : 'noreply@' . ($host !== '' ? $host : 'localhost');
        if ($host === '' || $port > 65535 || ! $recipients) {
            throw new RuntimeException('邮件服务器或收件人未配置。');
        }
        if (! function_exists('stream_socket_client')) {
            throw new RuntimeException('主机禁用了 stream_socket_client，无法发送邮件。');
        }
        $socket = @stream_socket_client((($server['smtp_ssl'] ?? '') === '1' ? 'ssl://' : 'tcp://') . $host . ':' . $port, $errno, $error, 5);
        if (! is_resource($socket)) {
            throw new RuntimeException('无法连接邮件服务器：' . $error);
        }
        stream_set_timeout($socket, 5);
        try {
            self::expect($socket, 220);
            self::command($socket, 'EHLO localhost', 250);
            if ($user !== '') {
                self::command($socket, 'AUTH LOGIN', 334);
                self::command($socket, base64_encode($user), 334);
                self::command($socket, base64_encode((string) ($server['smtp_password'] ?? '')), 235);
            }
            self::command($socket, 'MAIL FROM:<' . $from . '>', 250);
            foreach ($recipients as $recipient) {
                self::command($socket, 'RCPT TO:<' . $recipient . '>', 250);
            }
            self::command($socket, 'DATA', 354);
            $message = 'From: =?UTF-8?B?' . base64_encode('网站通知') . '?= <' . $from . ">\r\nTo: " . implode(', ', array_map(static fn (string $mail): string => '<' . $mail . '>', $recipients))
                . "\r\nSubject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\nMIME-Version: 1.0\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n"
                . chunk_split(base64_encode($html));
            fwrite($socket, $message . "\r\n.\r\n");
            self::expect($socket, 250);
            self::command($socket, 'QUIT', 221);
        } catch (RuntimeException $exception) {
            throw new RuntimeException('邮件发送失败：服务器拒绝了请求。', 0, $exception);
        } finally {
            fclose($socket);
        }
    }

    private static function command($socket, string $command, int $expected): void
    {
        fwrite($socket, $command . "\r\n");
        self::expect($socket, $expected);
    }

    private static function expect($socket, int $expected): void
    {
        $line = fgets($socket);
        if (! is_string($line) || (int) substr($line, 0, 3) !== $expected) {
            throw new RuntimeException('mail transport unavailable');
        }
        while (isset($line[3]) && $line[3] === '-') {
            $line = fgets($socket);
            if (! is_string($line)) {
                throw new RuntimeException('mail transport unavailable');
            }
        }
    }
}
