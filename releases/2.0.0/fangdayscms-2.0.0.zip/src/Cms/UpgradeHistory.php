<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;
use PDO;

final class UpgradeHistory
{
    public function __construct(private PDO $pdo)
    {
    }

    public function record(string $version, string $status, string $backupPath, string $manifestHash): void
    {
        if (! preg_match('/^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/D', $version)) {
            throw new InvalidArgumentException('升级版本号无效。');
        }
        if (! in_array($status, array('success', 'failed', 'rolled_back'), true)) {
            throw new InvalidArgumentException('升级状态无效。');
        }
        if ($backupPath === '' || strlen($backupPath) > 255 || str_contains($backupPath, "\0")) {
            throw new InvalidArgumentException('升级备份路径无效。');
        }
        if (! preg_match('/^[a-f0-9]{64}$/D', $manifestHash)) {
            throw new InvalidArgumentException('升级清单哈希无效。');
        }
        $stmt = $this->pdo->prepare('INSERT INTO upgrade_history (version, status, backup_path, manifest_hash, created_at) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute(array($version, $status, $backupPath, $manifestHash, time()));
    }

    /** @return list<array<string,mixed>> */
    public function recent(int $limit = 20): array
    {
        $limit = max(1, min(100, $limit));
        $stmt = $this->pdo->query('SELECT id, version, status, backup_path, manifest_hash, created_at FROM upgrade_history ORDER BY id DESC LIMIT ' . $limit);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
