<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Pboot;

/**
 * PbootCMS 3.2.10 front-end addresses: core\basic\Url::home(), ParserController::parserLink()
 * and the CMS branch of core\view\Paging::buildPath(). Modes: 1 普通 (/index.php/x/),
 * 2 伪静态 (/x/), 3 兼容 (/?x/).
 */
final class PbootUrl
{
    public function __construct(
        private readonly int $type,
        private readonly string $suffix = '.html',
        private readonly string $breakChar = '_',
        private readonly bool $contentPath = false,
    ) {
    }

    /** @param array<string, string> $settings site_settings values with the pboot_ prefix */
    public static function fromSettings(array $settings): ?self
    {
        $type = (int) ($settings['pboot_url_rule_type'] ?? 0);
        if (! in_array($type, array(1, 2, 3), true)) {
            return null;
        }
        $suffix = (string) ($settings['pboot_url_rule_suffix'] ?? '');
        $break = (string) ($settings['pboot_url_break_char'] ?? '');
        return new self($type, preg_match('/^\.[a-z0-9]{1,8}$/D', $suffix) === 1 ? $suffix : '.html', in_array($break, array('_', '-'), true) ? $break : '_', ($settings['pboot_url_rule_content_path'] ?? '') === '1');
    }

    public function type(): int
    {
        return $this->type;
    }

    public function suffix(): string
    {
        return $this->suffix;
    }

    public function breakChar(): string
    {
        return $this->breakChar;
    }

    public function contentPath(): bool
    {
        return $this->contentPath;
    }

    /** Url::home(): $suffix null appends "/", true the page suffix, false nothing. */
    public function home(string $path, ?bool $suffix = null, string $qs = ''): string
    {
        $end = $suffix === true ? $this->suffix : ($suffix === false ? '' : '/');
        $path = trim(str_replace('home/Index', '', trim($path, '/')), '/');
        if ($path === '') {
            return match ($this->type) {
                1 => '/index.php/',
                2 => '/',
                default => '/?',
            };
        }
        return match ($this->type) {
            1 => '/index.php/' . $path . $end . ($qs !== '' ? '?' . $qs : ''),
            2 => '/' . $path . $end . ($qs !== '' ? '?' . $qs : ''),
            default => '/?' . $path . $end . ($qs !== '' ? '&' . $qs : ''),
        };
    }

    /** parserLink() for a category (list or single page). */
    public function sortLink(string $type, string $urlname, string $scode, string $filename): string
    {
        if ($filename !== '') {
            return $this->home($filename);
        }
        return $this->home(($urlname !== '' ? $urlname : ($type === '1' ? 'about' : 'list')) . $this->breakChar . $scode);
    }

    /** parserLink() for a content page. */
    public function contentLink(string $urlname, string $scode, string $sortFilename, string $id, string $filename): string
    {
        if ($this->contentPath || $scode === '') {
            return $this->home($filename !== '' ? $filename : $id, true);
        }
        $parent = $sortFilename !== '' ? $sortFilename : ($urlname !== '' ? $urlname : 'list') . $this->breakChar . $scode;
        return $this->home($parent . '/' . ($filename !== '' ? $filename : $id), true);
    }

    /** Separator before extra query parameters on a home() address. */
    public function querySeparator(string $link): string
    {
        return $this->type === 3 || str_contains($link, '?') ? '&' : '?';
    }

    /**
     * Paging::buildPath() for category lists: page N of a category address,
     * keeping other query parameters. $link is the page-1 address from sortLink().
     */
    public function pageLink(string $link, int $page, array $query): string
    {
        unset($query['page'], $query['p'], $query['s']);
        $base = rtrim($link, '/');
        $path = $page <= 1 ? $base . '/' : $base . $this->breakChar . $page . '/';
        $qs = http_build_query($query);
        if ($qs === '') {
            return $path;
        }
        return $this->type === 3 ? rtrim($path, '/') . '&' . $qs : $path . '?' . $qs;
    }
}
