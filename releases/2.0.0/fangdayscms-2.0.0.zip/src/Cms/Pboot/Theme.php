<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Pboot;

use FangdaysCMS\Cms\TemplateTags;
use InvalidArgumentException;

/**
 * A PbootCMS theme: HTML in templates/themes/{name}/html (never served),
 * assets in public/template/{name} (served as {fd:sitetplpath}).
 * The mobile variant lives in the theme's wap/ folder, as in Pboot (get_theme() . '/wap').
 */
final class Theme
{
    private const MAX_BYTES = 1000000;

    public function __construct(private readonly string $root, private readonly string $name, private readonly bool $wap = false)
    {
        if (! self::validName($name) || ! is_dir($this->htmlDir())) {
            throw new InvalidArgumentException('前台主题不存在。');
        }
    }

    /** @return list<string> installed theme names */
    public static function names(string $root): array
    {
        $names = array();
        foreach (scandir($root . '/templates/themes') ?: array() as $name) {
            if (self::validName($name) && is_dir($root . '/templates/themes/' . $name . '/html')) {
                $names[] = $name;
            }
        }
        sort($names, SORT_STRING);
        return $names;
    }

    public static function validName(string $name): bool
    {
        return preg_match('/^[a-z0-9][a-z0-9_-]{0,31}$/D', $name) === 1;
    }

    public function name(): string
    {
        return $this->name;
    }

    public static function hasWap(string $root, string $name): bool
    {
        return self::validName($name) && is_dir($root . '/templates/themes/' . $name . '/wap/html');
    }

    public function wap(): bool
    {
        return $this->wap;
    }

    public function assetPath(): string
    {
        return '/template/' . $this->name . ($this->wap ? '/wap' : '');
    }

    public function has(string $file): bool
    {
        return self::validFile($file) && is_file($this->htmlDir() . '/' . $file) && ! is_link($this->htmlDir() . '/' . $file);
    }

    /** @return list<string> top-level page templates, e.g. newslist.html */
    public function pages(): array
    {
        $pages = array();
        foreach (scandir($this->htmlDir()) ?: array() as $file) {
            if ($this->has($file)) {
                $pages[] = $file;
            }
        }
        sort($pages, SORT_STRING);
        return $pages;
    }

    /** @return list<string> every template below the html folder, partials included, e.g. comm/head.html */
    public function files(): array
    {
        $base = $this->htmlDir() . '/';
        $files = array();
        foreach (new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($base, \FilesystemIterator::SKIP_DOTS)) as $file) {
            $relative = substr(str_replace('\\', '/', $file->getPathname()), strlen($base));
            if ($this->has($relative)) {
                $files[] = $relative;
            }
        }
        sort($files, SORT_STRING);
        return $files;
    }

    /** One template as stored, without expanding includes. */
    public function source(string $file): string
    {
        if (! $this->has($file)) {
            throw new InvalidArgumentException('模板文件不存在：' . $file);
        }
        return $this->read($file);
    }

    public function save(string $file, string $source): void
    {
        if (! $this->has($file)) {
            throw new InvalidArgumentException('模板文件不存在：' . $file);
        }
        if ($source === '' || strlen($source) > self::MAX_BYTES || str_contains(strtolower($source), '<?php')) {
            throw new InvalidArgumentException('模板内容不能为空、不能超过 1 MB，且不得包含 PHP 代码。');
        }
        if (file_put_contents($this->htmlDir() . '/' . $file, $source, LOCK_EX) === false) {
            throw new InvalidArgumentException('模板文件保存失败。');
        }
    }

    /** Read a template and expand Pboot {include file=...} directives. */
    public function load(string $file): string
    {
        return $this->expand($this->read($file), 0);
    }

    private function expand(string $source, int $depth): string
    {
        if ($depth > 10) {
            throw new InvalidArgumentException('模板 include 嵌套过深。');
        }
        return preg_replace_callback('/\{include\s+file\s?=\s?([\"\']?)([\w\.\-\/@]+)([\"\']?)\s*\}/', fn (array $match): string => $this->expand($this->read($match[2]), $depth + 1), $source) ?? $source;
    }

    private function read(string $file): string
    {
        if (! self::validFile($file)) {
            throw new InvalidArgumentException('模板文件名无效：' . $file);
        }
        $path = $this->htmlDir() . '/' . $file;
        $real = realpath($path);
        if ($real === false || ! str_starts_with($real, (string) realpath($this->htmlDir()) . '/') || ! is_file($real)) {
            throw new InvalidArgumentException('模板文件不存在：' . $file);
        }
        $source = file_get_contents($real, false, null, 0, self::MAX_BYTES + 1);
        if ($source === false || strlen($source) > self::MAX_BYTES) {
            throw new InvalidArgumentException('模板文件无法读取或过大：' . $file);
        }
        // Some Pboot theme files carry a UTF-8 BOM; it would end up in the middle of the page.
        return TemplateTags::normalize(str_starts_with($source, "\xEF\xBB\xBF") ? substr($source, 3) : $source);
    }

    private function htmlDir(): string
    {
        return $this->root . '/templates/themes/' . $this->name . ($this->wap ? '/wap' : '') . '/html';
    }

    private static function validFile(string $file): bool
    {
        return preg_match('#^(?:[A-Za-z0-9_-]+/)*[A-Za-z0-9_-]+(?:\.[A-Za-z0-9_-]+)*\.html$#D', $file) === 1 && ! str_contains($file, '..');
    }
}
