<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Pboot;

use InvalidArgumentException;
use PDO;

/**
 * PbootCMS 3.2.10 system configuration (apps/admin/view/default/system/config.html), stored as
 * site_settings rows named pboot_{key}. Defaults keep FangdaysCMS's existing behaviour where Pboot's
 * would change it (captchas off, guest comments allowed, FangdaysCMS URLs); tools/pboot_import.php
 * writes Pboot's own values.
 */
final class PbootConfig
{
    private const ON_OFF = array('1' => '启用', '0' => '禁用');

    /** @var array<string, array{0: string, 1: string}> tab id => [title, submit value] */
    public const TABS = array(
        't1' => array('基本配置', 'basic'), 't2' => array('邮件通知', 'email'), 't3' => array('百度接口', 'baidu'),
        't4' => array('WebAPI', 'api'), 't5' => array('图片水印', 'watermark'), 't6' => array('安全配置', 'security'),
        't7' => array('URL规则', 'urlrule'), 't8' => array('标题样式', 'pagetitle'), 't9' => array('会员配置', 'member'),
        't10' => array('GEO优化', 'geo'),
    );

    /** Tabs edited on the GEO 收录推送 page; their old addresses still open here. */
    public const GEO_TABS = array('t3', 't10');

    /**
     * Fields that mean nothing until another field is set, as data-show-when conditions
     * (admin-shell.js): `,` lists values, `!=` negates, `&` means and, `|` means or. Hidden fields keep their values.
     */
    public const DEPENDS = array(
        'close_site_note' => 'close_site=1',
        'wap_domain' => 'open_wap=1',
        'tpl_html_cache_time' => 'tpl_html_cache=1',
        'main_domain' => 'to_main_domain=1',
        'message_send_to' => 'message_send_mail=1|form_send_mail=1|comment_send_mail=1',
        'baidu_ks_token' => 'geo_baidu_daily=1',
        'api_auth' => 'api_open=1',
        'api_appid' => 'api_open=1&api_auth=1',
        'api_secret' => 'api_open=1&api_auth=1',
        'watermark_text' => 'watermark_open=1&watermark_pic=',
        'watermark_text_font' => 'watermark_open=1&watermark_pic=',
        'watermark_text_size' => 'watermark_open=1&watermark_pic=',
        'watermark_text_color' => 'watermark_open=1&watermark_pic=',
        'watermark_pic' => 'watermark_open=1',
        'watermark_position' => 'watermark_open=1',
        'message_check_code' => 'message_status=1',
        'message_verify' => 'message_status=1',
        'message_rqlogin' => 'message_status=1',
        'form_check_code' => 'form_status=1',
        'url_rule_content_path' => 'url_rule_type=1,2,3',
        'url_rule_suffix' => 'url_rule_type=1,2,3',
        'url_break_char' => 'url_rule_type=1,2,3',
        'geo_google_account' => 'geo_google_site!=',
        'register_type' => 'register_status=1',
        'register_check_code' => 'register_status=1',
        'register_verify' => 'register_status=1',
        'register_score' => 'register_status=1',
        'register_gcode' => 'register_status=1',
        'login_check_code' => 'login_status=1',
        'login_no_wait' => 'login_status=1',
        'login_score' => 'login_status=1',
        'comment_anonymous' => 'comment_status=1',
        'comment_check_code' => 'comment_status=1',
        'comment_verify' => 'comment_status=1',
    );

    /**
     * key => [tab, label, type, default, options|placeholder]; type is radio, text, number, textarea, password or select.
     * Tab t11 has no entry in TABS: it is edited on the /admin/geo/ai page. 'generated' values are never edited.
     */
    public const FIELDS = array(
        'close_site' => array('t1', '网站状态', 'radio', '0', array('1' => '关闭', '0' => '开启')),
        'close_site_note' => array('t1', '关站提示', 'textarea', '', '本站维护中，请稍后再访问，带来不便，敬请谅解！'),
        'open_wap' => array('t1', '手机版', 'radio', '0', array('1' => '独立手机版', '0' => 'H5自适应手机版')),
        'wap_domain' => array('t1', '手机版域名绑定', 'text', '', '如：m.xxx.com 非技术员不要改'),
        'tpl_html_cache' => array('t1', '静态缓存', 'radio', '1', self::ON_OFF),
        'tpl_html_cache_time' => array('t1', '缓存有效期(秒)', 'number', '60', '请输入缓存有效期（秒）'),
        'gzip' => array('t1', 'Gzip页面压缩', 'radio', '0', self::ON_OFF),
        'lgautosw' => array('t1', '跨语言自动切换', 'radio', '1', self::ON_OFF),
        'spiderlog' => array('t1', '记录蜘蛛访问', 'radio', '1', self::ON_OFF),
        'to_https' => array('t1', '自动转HTTPS', 'radio', '0', self::ON_OFF),
        'to_main_domain' => array('t1', '自动转主域名', 'radio', '0', self::ON_OFF),
        'main_domain' => array('t1', '网站主域名', 'text', '', '如：www.xxx.com'),
        'pagenum' => array('t1', '分页数字条数量', 'number', '5', '请输入前端分页数字条显示数量'),
        'content_tags_replace_num' => array('t1', '内链替换次数', 'number', '3', '请输入文章内链替换次数，默认3次'),
        'content_keyword_replace' => array('t1', '敏感词过滤', 'textarea', '', '请输入需要过滤的关键词，多个之间逗号隔开'),

        'smtp_server' => array('t2', 'SMTP服务器', 'text', '', '请输入SMTP服务器'),
        'smtp_port' => array('t2', 'SMTP端口', 'number', '', '请输入SMTP端口,一般SSL为465，普通为25'),
        'smtp_ssl' => array('t2', '是否为SSL', 'radio', '0', array('1' => '是', '0' => '否')),
        'smtp_username' => array('t2', '邮箱账号', 'text', '', '请输入邮箱账号'),
        'smtp_password' => array('t2', '邮箱密码', 'password', '', '请输入邮箱密码或邮箱授权码'),
        'smtp_username_test' => array('t2', '测试账号', 'text', '', '请输入用于接受测试邮件的账号'),
        'message_send_mail' => array('t2', '留言发送邮件', 'radio', '0', self::ON_OFF),
        'form_send_mail' => array('t2', '表单发送邮件', 'radio', '0', self::ON_OFF),
        'comment_send_mail' => array('t2', '评论发送邮件', 'radio', '0', self::ON_OFF),
        'message_send_to' => array('t2', '信息接收邮箱', 'text', '', '请输入信息接收邮箱'),

        'baidu_zz_token' => array('t3', '普通收录token', 'text', '', '请输入普通收录token'),
        'baidu_ks_token' => array('t3', '快速收录token', 'text', '', '请输入快速收录token'),

        'api_open' => array('t4', 'API状态', 'radio', '0', self::ON_OFF),
        'api_auth' => array('t4', 'API强制认证', 'radio', '1', self::ON_OFF),
        'api_appid' => array('t4', 'API认证用户', 'text', '', '请输入API认证用户名'),
        'api_secret' => array('t4', 'API认证密钥', 'password', '', '请输入API认证密钥'),

        'watermark_open' => array('t5', '状态', 'radio', '0', self::ON_OFF),
        'watermark_text' => array('t5', '水印文字', 'text', '', '请输入水印文字，如：XXXCMS'),
        'watermark_text_font' => array('t5', '文字字体', 'text', '', '字体文件路径，如：/uploads/fonts/font.ttf'),
        'watermark_text_size' => array('t5', '文字大小', 'number', '16', '请输入水印文字大小，如：20'),
        'watermark_text_color' => array('t5', '文字颜色', 'text', '100,100,100', '请输入水印文字颜色，如：100,100,100'),
        'watermark_pic' => array('t5', '水印图片', 'text', '', '水印图片路径（媒体库图片地址），优先文字水印'),
        'watermark_position' => array('t5', '水印位置', 'radio', '4', array('1' => '左上', '2' => '右上', '3' => '左下', '4' => '右下', '5' => '中间')),

        'message_status' => array('t6', '留言功能', 'radio', '1', self::ON_OFF),
        'message_check_code' => array('t6', '留言验证码', 'radio', '0', self::ON_OFF),
        'message_verify' => array('t6', '留言审核', 'radio', '1', self::ON_OFF),
        'message_rqlogin' => array('t6', '留言需登录', 'radio', '0', self::ON_OFF),
        'form_status' => array('t6', '表单功能', 'radio', '1', self::ON_OFF),
        'form_check_code' => array('t6', '表单验证码', 'radio', '0', self::ON_OFF),
        'ip_deny' => array('t6', 'IP黑名单', 'textarea', '', '请输入需要禁止访问的IP，多个之间逗号隔开，IP地址支持使用/掩码位数模式，如：192.168.1.0/24, 192.168.2.100'),
        'ip_allow' => array('t6', 'IP白名单', 'textarea', '', '请输入需要允许访问的IP，多个之间逗号隔开，IP地址支持使用/掩码位数模式，如：192.168.1.0/24, 192.168.2.100'),
        'admin_check_code' => array('t6', '后台滑块验证', 'radio', '0', self::ON_OFF),
        'lock_count' => array('t6', '后台登录阀值', 'number', '10', '请输入后台登录失败几次后锁定IP，默认5次'),
        'lock_time' => array('t6', '失败锁定时间', 'number', '300', '请输入后台登录异常锁定时间，默认为900秒'),

        'url_rule_type' => array('t7', '地址模式', 'radio', '', array('' => 'FangdaysCMS地址，类似：/post/1', '1' => '普通模式，类似：/index.php/product/1.html', '2' => '伪静态模式，类似：/product/1.html', '3' => '兼容模式，类似：/?product/1.html')),
        'url_rule_content_path' => array('t7', '文章路径', 'radio', '0', array('0' => '带栏目路径，类似：/product/1.html', '1' => '不带栏目路径，类似：/1.html')),
        'url_rule_suffix' => array('t7', '内容页后缀', 'text', '.html', '如：.html'),
        'url_break_char' => array('t7', '分隔符', 'radio', '_', array('_' => '下划线 _', '-' => '中划线 -')),

        'geo_auto_push' => array('t10', '发布后自动推送', 'radio', '1', self::ON_OFF),
        'geo_baidu_daily' => array('t10', '百度快速收录', 'radio', '0', self::ON_OFF),
        'geo_indexnow' => array('t10', 'IndexNow（Bing 等）', 'radio', '0', self::ON_OFF),
        'geo_google_site' => array('t10', 'Google 站点标识', 'text', '', 'Search Console 中的资源，如 sc-domain:example.com 或 https://example.com/'),
        'geo_google_account' => array('t10', 'Google 服务账号 JSON', 'password', '', '留空则保持现有内容；服务账号需先加入 Search Console 站点'),
        'geo_360_js' => array('t10', '360 自动收录 JS', 'text', '', '从 360 站长平台复制 script 的 src 地址，须为 https'),
        'geo_robots_extra' => array('t10', 'robots 追加规则', 'textarea', '', '追加到 robots.txt 的规则，例如 User-agent: GPTBot 换行 Disallow: /'),
        'geo_llms_enabled' => array('t10', 'llms.txt', 'radio', '0', self::ON_OFF),
        'geo_bot_agents' => array('t10', '补充 AI 爬虫', 'textarea', '', '每行一个：User-Agent片段=显示名称'),

        'geo_indexnow_key' => array('generated', 'IndexNow Key', 'text', '', ''),
        'geo_audit_last' => array('generated', '最近一次站点体检', 'text', '', ''),
        'geo_ai_provider' => array('t11', 'AI 辅助使用', 'radio', '', array('' => '关闭', 'doubao' => '豆包', 'qwen' => '千问', 'deepseek' => 'DeepSeek', 'ernie' => '文心', 'yuanbao' => '元宝（混元）')),
        'geo_ai_daily_limit' => array('t11', '每日调用上限', 'number', '50', '辅助改写和抽样共用，达到上限后当天停止调用'),
        'geo_sample_days' => array('t11', '抽样周期（天）', 'number', '0', '0 表示只手动抽样'),
        'geo_sample_repeat' => array('t11', '每题抽样次数', 'number', '3', '1 到 10；AI 回答有波动，建议至少 3 次'),
        'geo_api_doubao_key' => array('t11', '豆包 API Key', 'password', '', '留空则保持现有密钥'),
        'geo_api_doubao_model' => array('t11', '豆包 模型', 'text', '', '填写模型名或接入点'),
        'geo_api_doubao_url' => array('t11', '豆包 接口地址', 'text', '', '留空使用默认地址，自定义地址须为 https'),
        'geo_api_qwen_key' => array('t11', '千问 API Key', 'password', '', '留空则保持现有密钥'),
        'geo_api_qwen_model' => array('t11', '千问 模型', 'text', '', '填写模型名或接入点'),
        'geo_api_qwen_url' => array('t11', '千问 接口地址', 'text', '', '留空使用默认地址，自定义地址须为 https'),
        'geo_api_deepseek_key' => array('t11', 'DeepSeek API Key', 'password', '', '留空则保持现有密钥'),
        'geo_api_deepseek_model' => array('t11', 'DeepSeek 模型', 'text', '', '填写模型名或接入点'),
        'geo_api_deepseek_url' => array('t11', 'DeepSeek 接口地址', 'text', '', '留空使用默认地址，自定义地址须为 https'),
        'geo_api_ernie_key' => array('t11', '文心 API Key', 'password', '', '留空则保持现有密钥'),
        'geo_api_ernie_model' => array('t11', '文心 模型', 'text', '', '填写模型名或接入点'),
        'geo_api_ernie_url' => array('t11', '文心 接口地址', 'text', '', '留空使用默认地址，自定义地址须为 https'),
        'geo_api_yuanbao_key' => array('t11', '元宝（混元） API Key', 'password', '', '留空则保持现有密钥'),
        'geo_api_yuanbao_model' => array('t11', '元宝（混元） 模型', 'text', '', '填写模型名或接入点'),
        'geo_api_yuanbao_url' => array('t11', '元宝（混元） 接口地址', 'text', '', '留空使用默认地址，自定义地址须为 https'),

        'index_title' => array('t8', '首页', 'text', '', ''),
        'about_title' => array('t8', '专题页', 'text', '', ''),
        'list_title' => array('t8', '列表页', 'text', '', ''),
        'content_title' => array('t8', '内容页', 'text', '', ''),
        'search_title' => array('t8', '搜索结果页', 'text', '', ''),
        'register_title' => array('t8', '会员注册页', 'text', '', ''),
        'login_title' => array('t8', '会员登录页', 'text', '', ''),
        'ucenter_title' => array('t8', '个人中心页', 'text', '', ''),
        'umodify_title' => array('t8', '资料修改页', 'text', '', ''),
        'other_title' => array('t8', '其它页', 'text', '', ''),

        'register_status' => array('t9', '会员注册', 'radio', '1', self::ON_OFF),
        'register_type' => array('t9', '会员注册类型', 'radio', '2', array('1' => '用户名', '2' => '邮箱账号', '3' => '手机号码')),
        'register_check_code' => array('t9', '会员注册验证码', 'radio', '0', array('0' => '禁用', '1' => '普通验证码', '2' => '邮箱验证码')),
        'register_verify' => array('t9', '会员注册审核', 'radio', '0', self::ON_OFF),
        'login_status' => array('t9', '会员登录', 'radio', '1', self::ON_OFF),
        'login_check_code' => array('t9', '会员登录验证码', 'radio', '0', self::ON_OFF),
        'login_no_wait' => array('t9', '不等待跳登录', 'radio', '0', self::ON_OFF),
        'comment_status' => array('t9', '评论功能', 'radio', '1', self::ON_OFF),
        'comment_anonymous' => array('t9', '匿名评论', 'radio', '1', self::ON_OFF),
        'comment_check_code' => array('t9', '评论验证码', 'radio', '0', self::ON_OFF),
        'comment_verify' => array('t9', '评论审核', 'radio', '1', self::ON_OFF),
        'register_score' => array('t9', '会员注册积分', 'number', '0', '请输入会员注册初始积分'),
        'login_score' => array('t9', '会员登录积分', 'number', '0', '请输入会员每次登录积分'),
        'register_gcode' => array('t9', '会员默认等级', 'select', '', array()),
        'home_upload_ext' => array('t9', '允许上传格式', 'text', 'jpg,jpeg,png,gif,webp', '以英文逗号隔开！'),
    );

    /** Pboot's own values for keys missing from an imported ay_config (its "unset means on" rules). */
    public const PBOOT_DEFAULTS = array(
        'message_check_code' => '1', 'form_check_code' => '1', 'admin_check_code' => '1', 'comment_check_code' => '1', 'login_check_code' => '1',
        'register_check_code' => '1', 'comment_anonymous' => '0', 'register_type' => '1', 'tpl_html_cache' => '0', 'url_rule_type' => '3', 'lock_count' => '5', 'lock_time' => '900',
    );

    private array $values;

    public function __construct(private readonly PDO $pdo)
    {
        $this->values = array();
        foreach ($pdo->query("SELECT name, value FROM site_settings WHERE name LIKE 'pboot!_%' ESCAPE '!'") as $row) {
            $this->values[substr((string) $row['name'], 6)] = (string) $row['value'];
        }
    }

    public function get(string $key): string
    {
        $default = (string) (self::FIELDS[$key][3] ?? '');
        $value = $this->values[$key] ?? '';
        return $value !== '' ? $value : $default;
    }

    public function on(string $key): bool
    {
        return $this->get($key) === '1';
    }

    /** @return array<string, string> every configured key with its effective value */
    public function all(): array
    {
        $values = array();
        foreach (array_keys(self::FIELDS) as $key) {
            $values[$key] = $this->get($key);
        }
        return $values;
    }

    /** Validate and store the fields of one tab (Pboot saves per tab via its submit value). */
    public function saveTab(string $tab, array $input): void
    {
        $values = array();
        foreach (self::FIELDS as $key => [$fieldTab, $label, $type, $default, $options]) {
            if ($fieldTab !== $tab) {
                continue;
            }
            $value = is_string($input[$key] ?? null) ? trim($input[$key]) : '';
            if ($type === 'password' && $value === '') {
                continue; // keep the stored secret when the field is left empty
            }
            $values[$key] = self::validate($key, $label, $type, $value, $options);
        }
        if (! $values) {
            throw new InvalidArgumentException('配置分类无效。');
        }
        $this->store($values);
    }

    /** @param array<string, string> $values already validated values */
    public function store(array $values): void
    {
        $delete = $this->pdo->prepare('DELETE FROM site_settings WHERE name = ?');
        $insert = $this->pdo->prepare('INSERT INTO site_settings (name, value) VALUES (?, ?)');
        foreach ($values as $key => $value) {
            $delete->execute(array('pboot_' . $key));
            $insert->execute(array('pboot_' . $key, $value));
            $this->values[$key] = $value;
        }
    }

    private static function validate(string $key, string $label, string $type, string $value, array|string $options): string
    {
        $fail = static fn (string $why = '格式无效') => throw new InvalidArgumentException($label . $why . '。');
        if ($type === 'radio') {
            return array_key_exists($value, $options) ? $value : $fail('选项无效');
        }
        if ($type === 'number') {
            return $value === '' || (ctype_digit($value) && strlen($value) <= 9) ? $value : $fail('须为非负整数');
        }
        if (mb_strlen($value) > (in_array($type, array('textarea', 'password'), true) ? 5000 : 500)) {
            $fail('过长');
        }
        $host = '/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?::[0-9]{1,5})?$/iD';
        switch ($key) {
            case 'wap_domain':
            case 'main_domain':
            case 'smtp_server':
                return $value === '' || preg_match($host, $value) === 1 ? strtolower($value) : $fail();
            case 'message_send_to':
            case 'smtp_username_test':
                foreach ($value === '' ? array() : (preg_split('/[,，;\s]+/u', $value) ?: array()) as $mail) {
                    if (filter_var($mail, FILTER_VALIDATE_EMAIL) === false) {
                        $fail('须为邮箱地址，多个用逗号隔开');
                    }
                }
                return $value;
            case 'ip_deny':
            case 'ip_allow':
                $items = array_values(array_filter(array_map('trim', preg_split('/[\s,，]+/u', $value) ?: array())));
                foreach ($items as $item) {
                    [$address, $bits] = array_pad(explode('/', $item, 2), 2, null);
                    if (filter_var($address, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) === false || ($bits !== null && (! ctype_digit($bits) || (int) $bits > 32))) {
                        $fail('只能填写 IPv4 地址或 CIDR 网段，例如 192.168.1.0/24');
                    }
                }
                return implode(',', $items);
            case 'url_rule_suffix':
                return preg_match('/^\.[a-z0-9]{1,8}$/D', $value) === 1 ? $value : $fail('须以点开头，如 .html');
            case 'watermark_text_color':
                return $value === '' || preg_match('/^(?:25[0-5]|2[0-4][0-9]|1?[0-9]{1,2})(?:,(?:25[0-5]|2[0-4][0-9]|1?[0-9]{1,2})){2}$/D', $value) === 1 ? $value : $fail('须为 R,G,B，如 100,100,100');
            case 'watermark_pic':
            case 'watermark_text_font':
                return $value === '' || (preg_match('#^/[A-Za-z0-9/_.-]+\.(?:png|jpe?g|gif|ttf|otf)$#Di', $value) === 1 && ! str_contains($value, '..')) ? $value : $fail('须为站内文件路径');
            case 'home_upload_ext':
                return preg_match('/^[a-z0-9]{1,8}(?:,[a-z0-9]{1,8})*$/D', strtolower(str_replace(array('，', ' '), array(',', ''), $value))) === 1 ? strtolower(str_replace(array('，', ' '), array(',', ''), $value)) : $fail('须为英文逗号分隔的扩展名');
            case 'register_gcode':
                return $value === '' || ctype_digit($value) ? $value : $fail();
        }
        return $value;
    }
}
