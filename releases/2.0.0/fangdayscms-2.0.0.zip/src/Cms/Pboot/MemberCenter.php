<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Pboot;

use FangdaysCMS\Cms\MemberRepository;
use FangdaysCMS\Cms\Captcha;
use FangdaysCMS\Cms\MemberFieldRepository;
use FangdaysCMS\Cms\RateLimiter;
use FangdaysCMS\Cms\SmtpMailer;
use FangdaysCMS\Cms\View;
use InvalidArgumentException;
use PDO;

/**
 * PbootCMS member actions (apps/home/controller/MemberController, MemberModel) on FangdaysCMS members.
 * Accounts can be a username, an e-mail or a mobile number (配置参数 → 会员注册类型); members without an
 * e-mail get an unusable placeholder address, because FangdaysCMS keys members by e-mail.
 * Differences on purpose: passwords use password_hash and FangdaysCMS's 12-character minimum, backurl
 * must stay on this site, and 找回密码 needs the account's own e-mail and a code sent to it.
 * Action methods return [ok, message, redirect address] like Interaction.
 */
final class MemberCenter
{
    public const PLACEHOLDER = '@member.invalid';
    /** E-mailed codes: lifetime in seconds and wrong answers allowed. */
    private const MAIL_CODE_TTL = 600;
    private const MAIL_CODE_TRIES = 5;

    public function __construct(
        private readonly PDO $pdo,
        private readonly PbootConfig $config,
        private readonly ?PbootUrl $url,
        private readonly string $root,
        private readonly string $siteName,
    ) {
    }

    /** Address of a Pboot member action (member/login, comment/my, ...) for the configured URL mode. */
    public function address(string $action, string $query = ''): string
    {
        if ($this->url !== null) {
            return $this->url->home($action, null, $query);
        }
        return View::localizedPath('/' . $action) . ($query !== '' ? '?' . $query : '');
    }

    /** Everything {user:*} can show, keyed like Pboot's getUser() row. */
    public function user(int $id): ?array
    {
        $stmt = $this->pdo->prepare("SELECT m.*, g.id AS gid, COALESCE(g.code, '') AS gcode, COALESCE(g.name, '') AS gname FROM members m LEFT JOIN member_group_members gm ON gm.member_id = m.id LEFT JOIN member_groups g ON g.id = gm.group_id AND g.status = 'active' WHERE m.id = ? ORDER BY g.id LIMIT 1");
        $stmt->execute(array($id));
        $row = $stmt->fetch();
        if (! $row) {
            return null;
        }
        $email = str_ends_with((string) $row['email'], self::PLACEHOLDER) ? '' : (string) $row['email'];
        $user = array(
            'id' => (string) $row['id'], 'ucode' => (string) $row['id'],
            'username' => (string) ($row['username'] !== '' ? $row['username'] : ($email !== '' ? $email : $row['mobile'])),
            'useremail' => $email, 'usermobile' => (string) $row['mobile'], 'nickname' => (string) $row['display_name'],
            'headpic' => (string) $row['headpic'], 'status' => $row['status'] === 'active' ? '1' : '0',
            'gid' => (string) ($row['gid'] ?? ''), 'gcode' => (string) $row['gcode'], 'gname' => (string) $row['gname'],
            'score' => (string) $row['score'], 'registertime' => date('Y-m-d H:i:s', (int) $row['created_at']),
            'logincount' => (string) $row['login_count'], 'lastloginip' => (string) $row['last_login_ip'],
            'lastlogintime' => (int) $row['last_login_time'] > 0 ? date('Y-m-d H:i:s', (int) $row['last_login_time']) : '',
            // FangdaysCMS member fields used by the rest of the site.
            'email' => $email, 'display_name' => (string) $row['display_name'], 'group_id' => (int) ($row['gid'] ?? 0),
        );
        foreach ((new MemberFieldRepository($this->pdo))->values($id) as $field) {
            $user[(string) $field['name']] ??= (string) $field['value'];
        }
        return $user;
    }

    public function login(array $post, array $query): array
    {
        if (! $this->config->on('login_status')) {
            return array(false, '系统已经关闭登录功能，请到后台开启再试！', '');
        }
        if (($error = Captcha::error('login', self::field($post, 'checkcode'))) !== null) {
            return array(false, $error, '');
        }
        $account = self::field($post, 'username');
        if ($account === '') {
            return array(false, '用户账号不能为空！', '');
        }
        $identity = (string) ($_SERVER['REMOTE_ADDR'] ?? '') . '|' . strtolower($account);
        if (! (new RateLimiter($this->root . '/var/rate-limits'))->configuredAllow('member-login', $identity, 10, 300)) {
            return array(false, '登录尝试次数过多，请稍后再试！', '');
        }
        $member = $this->find($account);
        if ($member === null) {
            return array(false, '用户账号不存在！', '');
        }
        $password = (string) ($post['password'] ?? '');
        if ($password === '') {
            return array(false, '用户密码不能为空！', '');
        }
        if (! MemberRepository::verifyPassword($password, (string) $member['password_hash'])) {
            return array(false, '账号密码错误，请核对后重试！', '');
        }
        if ($member['status'] !== 'active') {
            return array(false, '您的账号待审核，请联系管理员！', '');
        }
        (new MemberRepository($this->pdo))->upgradePassword((int) $member['id'], $password, (string) $member['password_hash']);
        $score = (int) $this->config->get('login_score');
        $this->pdo->prepare('UPDATE members SET login_count = login_count + 1, last_login_ip = ?, last_login_time = ?, score = score + ? WHERE id = ?')
            ->execute(array((string) ($_SERVER['REMOTE_ADDR'] ?? ''), time(), max(0, $score), (int) $member['id']));
        $this->upgradeGroup((int) $member['id']);
        session_regenerate_id(true);
        $_SESSION['member_id'] = (int) $member['id'];
        $back = is_string($query['backurl'] ?? null) ? $query['backurl'] : '';
        return array(true, '登录成功！', self::local($back) ? $back : $this->address('member/ucenter'));
    }

    public function register(array $post): array
    {
        if (! $this->config->on('register_status')) {
            return array(false, '系统已经关闭注册功能，请到后台开启再试！', '');
        }
        if (time() - (int) ($_SESSION['pboot_lastreg'] ?? 0) < 10) {
            return array(false, '您注册太频繁了，请稍后再试！', '');
        }
        $mailCode = $this->config->get('register_check_code') === '2';
        if (! $mailCode && ($error = Captcha::error('register', self::field($post, 'checkcode'))) !== null) {
            return array(false, $error, '');
        }
        $account = self::field($post, 'username');
        $type = $this->config->get('register_type');
        $email = $mobile = $username = '';
        if ($type === '2') {
            if ($account === '') {
                return array(false, '账号不能为空，请输入注册的邮箱账号！', '');
            }
            if (filter_var($account, FILTER_VALIDATE_EMAIL) === false) {
                return array(false, '账号格式不正确，请输入正确的邮箱账号！', '');
            }
            if ($this->find($account) !== null) {
                return array(false, '您输入的邮箱已被注册！', '');
            }
            $email = strtolower($account);
        } elseif ($type === '3') {
            if ($account === '') {
                return array(false, '账号不能为空，请输入注册的手机号码！', '');
            }
            if (preg_match('/^1[0-9]{10}$/D', $account) !== 1) {
                return array(false, '账号格式不正确，请输入正确的手机号码！', '');
            }
            if ($this->find($account) !== null) {
                return array(false, '您输入的手机号码已被注册！', '');
            }
            $mobile = $account;
        } else {
            if ($account === '') {
                return array(false, '用户名不能为空！', '');
            }
            if (preg_match('/^[\w\@\.]{1,100}$/D', $account) !== 1) {
                return array(false, '用户账号含有不允许的特殊字符！', '');
            }
            if ($this->find($account) !== null) {
                return array(false, '您输入的账号已被注册！', '');
            }
            $username = $account;
        }
        if ($mailCode && ($error = self::mailCodeError('register', $email, self::field($post, 'checkcode'))) !== null) {
            return array(false, $error, '');
        }
        $password = (string) ($post['password'] ?? '');
        if ($password !== (string) ($post['rpassword'] ?? '')) {
            return array(false, '确认密码不正确！', '');
        }
        if ($password === '') {
            return array(false, '密码不能为空！', '');
        }
        if (strlen($password) < 12) {
            return array(false, '密码至少 12 位！', '');
        }
        $nickname = self::field($post, 'nickname');
        $nickname = mb_substr($nickname !== '' ? $nickname : $account, 0, 100);
        $verify = $this->config->on('register_verify');
        $this->pdo->beginTransaction();
        try {
            $this->pdo->prepare('INSERT INTO members (email, display_name, password_hash, status, created_at, username, mobile, score) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
                ->execute(array($email !== '' ? $email : 'u-' . bin2hex(random_bytes(8)) . self::PLACEHOLDER, $nickname, password_hash($password, PASSWORD_DEFAULT), $verify ? 'pending' : 'active', time(), $username, $mobile, max(0, (int) $this->config->get('register_score'))));
            $id = (int) $this->pdo->lastInsertId();
            $group = $this->config->get('register_gcode');
            $groupId = $group !== '' ? $group : $this->pdo->query("SELECT id FROM member_groups WHERE status = 'active' ORDER BY CASE WHEN code = 'default' THEN 0 ELSE 1 END, id LIMIT 1")->fetchColumn();
            if ($groupId !== false && $groupId !== '') {
                $this->pdo->prepare('INSERT INTO member_group_members (group_id, member_id) VALUES (?, ?)')->execute(array((int) $groupId, $id));
            }
            (new MemberFieldRepository($this->pdo))->saveValues($id, array_map(static fn ($value) => is_array($value) ? $value : str_ireplace(array('fd:if', 'pboot:if'), '', (string) $value), $post));
            $this->pdo->commit();
        } catch (InvalidArgumentException $exception) {
            $this->pdo->rollBack();
            return array(false, rtrim($exception->getMessage(), '。') . '！', '');
        } catch (\Throwable $exception) {
            $this->pdo->rollBack();
            throw $exception;
        }
        $_SESSION['pboot_lastreg'] = time();
        unset($_SESSION['pboot_mailcode']);
        return array(true, $verify ? '注册成功，请等待管理员审核！' : '注册成功！', $this->address('member/login'));
    }

    /** 找回密码: the account's own e-mail plus the code mailed to it by sendEmail(retrieve). */
    public function retrieve(array $post): array
    {
        $email = strtolower(self::field($post, 'email'));
        if (($error = self::mailCodeError('retrieve', $email, self::field($post, 'checkcode'))) !== null) {
            return array(false, $error, '');
        }
        $member = $this->find(self::field($post, 'username'));
        if ($member === null) {
            return array(false, '该用户不存在！', '');
        }
        if (str_ends_with((string) $member['email'], self::PLACEHOLDER) || $email !== strtolower((string) $member['email'])) {
            return array(false, '与注册邮箱不匹配，请联系管理员！', '');
        }
        $password = (string) ($post['password'] ?? '');
        if (strlen($password) < 12) {
            return array(false, '密码至少 12 位！', '');
        }
        $this->pdo->prepare('UPDATE members SET password_hash = ? WHERE id = ?')->execute(array(password_hash($password, PASSWORD_DEFAULT), (int) $member['id']));
        unset($_SESSION['pboot_mailcode']);
        return array(true, '修改成功！', $this->address('member/login'));
    }

    public function modify(int $id, array $post): array
    {
        $stmt = $this->pdo->prepare('SELECT password_hash FROM members WHERE id = ?');
        $stmt->execute(array($id));
        $old = (string) ($post['opassword'] ?? '');
        if ($old === '') {
            return array(false, '请输入当前密码！', '');
        }
        if (! MemberRepository::verifyPassword($old, (string) $stmt->fetchColumn())) {
            return array(false, '您输入的当前密码不正确！', '');
        }
        $email = strtolower(self::field($post, 'useremail'));
        $mobile = self::field($post, 'usermobile');
        if ($email !== '') {
            if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
                return array(false, '邮箱格式不正确，请输入正确的邮箱账号！', '');
            }
            if (($other = $this->find($email)) !== null && (int) $other['id'] !== $id) {
                return array(false, '您输入的邮箱已被注册！', '');
            }
        }
        if ($mobile !== '') {
            if (preg_match('/^1[0-9]{10}$/D', $mobile) !== 1) {
                return array(false, '手机格式不正确，请输入正确的手机号码！', '');
            }
            if (($other = $this->find($mobile)) !== null && (int) $other['id'] !== $id) {
                return array(false, '您输入的手机号码已被注册！', '');
            }
        }
        $headpic = self::field($post, 'headpic');
        if ($headpic !== '' && preg_match('#^/uploads/member/[0-9]{6}/[a-f0-9]{32}\.(?:jpg|png|gif|webp)$#D', $headpic) !== 1) {
            return array(false, '头像地址无效，请重新上传！', '');
        }
        $password = (string) ($post['password'] ?? '');
        if ($password !== '' && $password !== (string) ($post['rpassword'] ?? '')) {
            return array(false, '确认密码不正确！', '');
        }
        if ($password !== '' && strlen($password) < 12) {
            return array(false, '密码至少 12 位！', '');
        }
        $nickname = mb_substr(self::field($post, 'nickname'), 0, 100);
        $current = $this->pdo->prepare('SELECT email, display_name FROM members WHERE id = ?');
        $current->execute(array($id));
        $row = $current->fetch();
        $this->pdo->beginTransaction();
        try {
            $this->pdo->prepare('UPDATE members SET display_name = ?, email = ?, mobile = ?, headpic = ? WHERE id = ?')
                ->execute(array($nickname !== '' ? $nickname : (string) $row['display_name'], $email !== '' ? $email : (str_ends_with((string) $row['email'], self::PLACEHOLDER) ? (string) $row['email'] : 'u-' . bin2hex(random_bytes(8)) . self::PLACEHOLDER), $mobile, $headpic, $id));
            if ($password !== '') {
                $this->pdo->prepare('UPDATE members SET password_hash = ? WHERE id = ?')->execute(array(password_hash($password, PASSWORD_DEFAULT), $id));
            }
            (new MemberFieldRepository($this->pdo))->saveValues($id, array_map(static fn ($value) => is_array($value) ? $value : str_ireplace(array('fd:if', 'pboot:if'), '', (string) $value), $post));
            $this->pdo->commit();
        } catch (InvalidArgumentException $exception) {
            $this->pdo->rollBack();
            return array(false, rtrim($exception->getMessage(), '。') . '！', '');
        }
        return array(true, '修改成功！', $this->address('member/umodify'));
    }

    /** member/upload: one image for the avatar (home_upload_ext limited to image types). */
    public function upload(array $file): array
    {
        if (! isset($file['error'], $file['tmp_name'], $file['size']) || $file['error'] !== UPLOAD_ERR_OK || ! is_uploaded_file((string) $file['tmp_name']) || (int) $file['size'] < 1 || (int) $file['size'] > 2 * 1024 * 1024) {
            return array(false, '请选择小于 2 MB 的图片！', '');
        }
        $types = array('image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp');
        $mime = (new \finfo(FILEINFO_MIME_TYPE))->file((string) $file['tmp_name']);
        $allowed = array_map('trim', explode(',', strtolower($this->config->get('home_upload_ext'))));
        $size = @getimagesize((string) $file['tmp_name']);
        if (! isset($types[$mime]) || $size === false || ! array_intersect($allowed, $types[$mime] === 'jpg' ? array('jpg', 'jpeg') : array($types[$mime]))) {
            return array(false, '上传的文件格式不允许！', '');
        }
        $path = '/uploads/member/' . date('Ym') . '/' . bin2hex(random_bytes(16)) . '.' . $types[$mime];
        $target = $this->root . '/public' . $path;
        if (! is_dir(dirname($target)) && ! mkdir(dirname($target), 0755, true) && ! is_dir(dirname($target))) {
            return array(false, '上传失败！', '');
        }
        if (! move_uploaded_file((string) $file['tmp_name'], $target)) {
            return array(false, '上传失败！', '');
        }
        if (function_exists('chmod')) {
            chmod($target, 0644);
        }
        return array(true, $path, '');
    }

    /** member/sendEmail: a 4-character code for 邮箱验证码 registration or 找回密码. */
    public function sendEmail(array $post): array
    {
        $retrieve = self::field($post, 'retrieve') !== '';
        if (! $retrieve && $this->config->get('register_check_code') !== '2') {
            return array(false, '发送失败，后台配置非邮箱验证码模式！', '');
        }
        if (time() - (int) ($_SESSION['pboot_lastsend'] ?? 0) < 10) {
            return array(false, '您提交太频繁了，请稍后再试！', '');
        }
        if (empty($_SESSION['pboot_sendemail'])) {
            return array(false, '非法提交发送邮件！', '');
        }
        $to = strtolower(self::field($post, 'to'));
        if ($to === '') {
            return array(false, '发送失败，缺少发送对象参数to！', '');
        }
        if (filter_var($to, FILTER_VALIDATE_EMAIL) === false) {
            return array(false, '邮箱格式不正确，请输入正确的邮箱账号！', '');
        }
        $member = $this->find($to);
        if (! $retrieve && $member !== null) {
            return array(false, '您输入的邮箱已被注册！', '');
        }
        $_SESSION['pboot_lastsend'] = time();
        if ($retrieve && ($member === null || strtolower((string) $member['email']) !== $to)) {
            // Do not reveal whether an address belongs to an account.
            return array(true, '发送成功！', '');
        }
        $code = '';
        for ($i = 0; $i < 4; $i++) {
            $code .= 'abcdefghkmnprtuvwxy23456789'[random_int(0, 26)];
        }
        $scheme = ! empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http';
        try {
            SmtpMailer::sendMail($this->config->all(), $to, '【' . $this->siteName . '】您有新的验证码信息，请注意查收！', '您的验证码为：' . $code . '<br>来自网站 ' . View::e($scheme . '://' . (string) ($_SERVER['HTTP_HOST'] ?? '')) . ' （' . date('Y-m-d H:i:s') . '）');
        } catch (\RuntimeException $exception) {
            return array(false, '发送失败，' . $exception->getMessage(), '');
        }
        // Kept apart from the image captcha ($_SESSION['checkcode']), which any visitor can read,
        // and bound to the address and purpose it was sent for.
        $_SESSION['pboot_mailcode'] = array('code' => $code, 'to' => $to, 'purpose' => $retrieve ? 'retrieve' : 'register', 'expires' => time() + self::MAIL_CODE_TTL, 'tries' => 0);
        return array(true, '发送成功！', '');
    }

    /** member/isRegister. Pboot answers code 1 for "taken or invalid" and 0 for "available". */
    public function isRegister(array $post): array
    {
        $account = self::field($post, 'username');
        $type = $this->config->get('register_type');
        [$valid, $kind] = match ($type) {
            '2' => array(filter_var($account, FILTER_VALIDATE_EMAIL) !== false, '邮箱'),
            '3' => array(preg_match('/^1[0-9]{10}$/D', $account) === 1, '手机号码'),
            default => array(preg_match('/^[\w\@\.]+$/D', $account) === 1, '账号'),
        };
        if ($account === '') {
            return array(true, '账号不能为空！', '');
        }
        if (! $valid) {
            return array(true, $type === '1' ? '用户账号含有不允许的特殊字符！' : '账号格式不正确，请输入正确的' . ($type === '2' ? '邮箱账号' : '手机号码') . '！', '');
        }
        return $this->find($account) !== null ? array(true, '您输入的' . $kind . '已被注册！', '') : array(false, '您输入的' . $kind . '可以使用！', '');
    }

    /** getMyComment(): the member's comments with the commented title, newest first. */
    public function myComments(int $memberId, int $num, int $page, int $start, bool $count): array
    {
        $total = 0;
        if ($count) {
            $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM post_comments WHERE member_id = ?');
            $stmt->execute(array($memberId));
            $total = max(0, (int) $stmt->fetchColumn() - ($start - 1));
        }
        $stmt = $this->pdo->prepare("SELECT c.id, c.post_id AS contentid, c.parent_id AS pid, c.content AS comment, c.status, c.created_at, c.user_ip, c.user_os, c.user_bs, c.likes, c.oppose, p.title, p.slug FROM post_comments c LEFT JOIN posts p ON p.id = c.post_id WHERE c.member_id = ? ORDER BY c.id DESC LIMIT " . max(1, min(200, $num)) . ' OFFSET ' . max(0, ($start - 1) + (max(1, $page) - 1) * $num));
        $stmt->execute(array($memberId));
        return array('rows' => array_map(static fn (array $row): array => $row + array('date' => date('Y-m-d H:i:s', (int) $row['created_at']), 'status' => $row['status'] === 'approved' ? '1' : '0'), $stmt->fetchAll()), 'total' => $total);
    }

    public function deleteComment(int $memberId, int $id): array
    {
        $stmt = $this->pdo->prepare('DELETE FROM post_comments WHERE id = ? AND member_id = ?');
        $stmt->execute(array($id, $memberId));
        return $stmt->rowCount() > 0 ? array(true, '删除成功！', '') : array(false, '删除失败！', '');
    }

    /** DoController likes/oppose: once per browser (cookie), then back to the page. */
    public function vote(int $postId, string $kind): void
    {
        $cookie = $kind . '_' . $postId;
        if ($postId > 0 && empty($_COOKIE[$cookie])) {
            $this->pdo->prepare('UPDATE post_meta SET ' . ($kind === 'likes' ? 'likes = likes + 1' : 'oppose = oppose + 1') . ' WHERE post_id = ?')->execute(array($postId));
            setcookie($cookie, '1', array('expires' => time() + 31536000, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax'));
        }
    }

    /** Pboot 会员组 score ranges: move the member to the group whose lscore..uscore covers the score. */
    private function upgradeGroup(int $id): void
    {
        $stmt = $this->pdo->prepare("SELECT g.id FROM members m JOIN member_groups g ON g.status = 'active' AND g.uscore > 0 AND m.score BETWEEN g.lscore AND g.uscore WHERE m.id = ? ORDER BY g.lscore DESC LIMIT 1");
        $stmt->execute(array($id));
        $group = $stmt->fetchColumn();
        if ($group !== false) {
            $this->pdo->prepare('DELETE FROM member_group_members WHERE member_id = ?')->execute(array($id));
            $this->pdo->prepare('INSERT INTO member_group_members (group_id, member_id) VALUES (?, ?)')->execute(array((int) $group, $id));
        }
    }

    /**
     * Error for an e-mailed code, or null when $input is the code last sent to $email for $purpose.
     * $email is '' when the account has no address (register_type 1 or 3). Codes expire and allow a few tries.
     */
    private static function mailCodeError(string $purpose, string $email, string $input): ?string
    {
        $input = strtolower(trim($input));
        if ($input === '') {
            return '验证码不能为空！';
        }
        $sent = $_SESSION['pboot_mailcode'] ?? null;
        if (! is_array($sent) || ($sent['purpose'] ?? '') !== $purpose || (int) ($sent['expires'] ?? 0) < time() || ($email !== '' && ($sent['to'] ?? '') !== strtolower($email))) {
            return '验证码错误！';
        }
        if (! hash_equals((string) $sent['code'], $input)) {
            $sent['tries'] = (int) ($sent['tries'] ?? 0) + 1;
            if ($sent['tries'] >= self::MAIL_CODE_TRIES) {
                unset($_SESSION['pboot_mailcode']);
            } else {
                $_SESSION['pboot_mailcode'] = $sent;
            }
            return '验证码错误！';
        }
        return null;
    }

    /** checkUsername(): a member by user name, e-mail or mobile. */
    private function find(string $account): ?array
    {
        if ($account === '') {
            return null;
        }
        $stmt = $this->pdo->prepare('SELECT id, email, password_hash, status FROM members WHERE username = ? OR email = ? OR mobile = ? ORDER BY id LIMIT 1');
        $stmt->execute(array($account, strtolower($account), $account));
        return $stmt->fetch() ?: null;
    }

    /** A relative address, or an absolute one on this host (no open redirects). */
    private static function local(string $url): bool
    {
        if ($url === '' || preg_match('/[\x00-\x20\\\\]/', $url) === 1) {
            return false;
        }
        if (preg_match('~^/(?!/)~', $url) === 1) {
            return true;
        }
        $host = parse_url($url, PHP_URL_HOST);
        $port = parse_url($url, PHP_URL_PORT);
        return in_array(parse_url($url, PHP_URL_SCHEME), array('http', 'https'), true) && is_string($host) && strcasecmp($host . ($port !== null ? ':' . $port : ''), (string) ($_SERVER['HTTP_HOST'] ?? '')) === 0;
    }

    private static function field(array $post, string $name): string
    {
        return is_string($post[$name] ?? null) ? trim($post[$name]) : '';
    }
}
