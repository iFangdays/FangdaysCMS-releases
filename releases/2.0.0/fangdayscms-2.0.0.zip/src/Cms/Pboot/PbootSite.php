<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Pboot;

use FangdaysCMS\Cms\Geo\GeoBots;
use FangdaysCMS\Cms\Geo\GeoHead;
use Closure;
use FangdaysCMS\Cms\AuditLogRepository;
use FangdaysCMS\Cms\PageLevel;
use FangdaysCMS\Cms\TemplateTags;
use FangdaysCMS\Cms\View;
use InvalidArgumentException;
use PDO;

/**
 * Front-end pages rendered from a PbootCMS theme, following apps/home/controller/IndexController
 * (routing in _empty(), pages in getIndexPage/getListPage/getContentPage/getAboutPage) and the
 * Search/Tag controllers. With a Pboot URL mode set, Pboot addresses are generated and accepted;
 * FangdaysCMS addresses (/category/..., /post/...) keep working either way.
 * handle() returns false for routes it leaves to the built-in views.
 */
final class PbootSite
{
    /** Pboot default model templates, keyed by FangdaysCMS model slug. */
    private const MODEL_TEMPLATES = array(
        'product' => array('productlist.html', 'product.html'),
        'case' => array('caselist.html', 'case.html'),
        'job' => array('joblist.html', 'job.html'),
    );

    /** Pboot member actions served by FangdaysCMS member pages when the theme has no member pages. */
    private const MEMBER_PAGES = array('login' => '/member/login', 'register' => '/member/register', 'ucenter' => '/member/profile', 'umodify' => '/member/profile', 'retrieve' => '/member/forgot', 'logout' => '/member/logout');

    /** Theme member pages: template, title setting, default title, special sort code. */
    private const MEMBER_TEMPLATES = array(
        'login' => array('member/login.html', 'login_title', '会员登录', '-2'),
        'register' => array('member/register.html', 'register_title', '会员注册', '-3'),
        'retrieve' => array('member/retrieve.html', 'register_title', '找回密码', '-3'),
        'ucenter' => array('member/ucenter.html', 'ucenter_title', '个人中心', '-4'),
        'umodify' => array('member/umodify.html', 'umodify_title', '资料修改', '-5'),
    );

    private PbootData $data;
    private ?array $member;
    private MemberCenter $members;
    private ?array $config = null;
    /** Query parameters without the Pboot path key of 兼容 mode. */
    private array $query;
    private ?int $page = null;

    public function __construct(private readonly PDO $pdo, private readonly Theme $theme, private readonly array $base, private readonly ?PbootUrl $url = null)
    {
        $this->members = new MemberCenter($pdo, new PbootConfig($pdo), $url, dirname(__DIR__, 3), (string) ($base['site_name'] ?? ''));
        $this->member = isset($base['member']['id']) ? ($this->members->user((int) $base['member']['id']) ?? $base['member']) : null;
        $this->data = new PbootData($pdo, (string) ($base['locale'] ?? 'zh-CN'), $this->member, $url);
        $this->query = $_GET;
    }

    public static function forSite(PDO $pdo, string $root, array $base): ?self
    {
        $settings = self::settings($pdo);
        $name = self::themeName($settings, $root);
        if ($name === null) {
            return null;
        }
        $wap = self::wantsWap($settings) && Theme::hasWap($root, $name);
        return new self($pdo, new Theme($root, $name, $wap), $base, PbootUrl::fromSettings($settings));
    }

    /** The selected Pboot theme, or null when the built-in views render the site. */
    public static function themeName(array $settings, string $root): ?string
    {
        $name = (string) ($settings['pboot_theme'] ?? '');
        return $name !== '' && in_array($name, Theme::names($root), true) ? $name : null;
    }

    /** SpiderController::getSpider(): crawler names by user-agent fragment, in Pboot's order. */
    private const SPIDERS = array('googlebot' => 'Google', 'baiduspider' => 'Baidu', 'webscan' => '360WebScan', '360spider' => '360So', 'adsbot' => 'Adwords', 'bingbot' => 'Bing', 'slurp' => 'Yahoo', 'sosospider' => 'Soso', 'sogou' => 'Sogou', 'yodaobot' => 'Yodao', 'speedy' => 'Speedy', 'yandexbot' => 'Yandex', 'easouspider' => 'Easou', 'symantecspider' => 'Symantec', 'qiniu' => 'Qiniu', 'jiankongbao' => 'JianKongBao', 'dnspod' => 'DNSPod', 'linkpadbot' => 'Linkpad', 'mj12bot' => 'MJ12', 'dingtalkbot' => 'DingTalk', 'bytespider' => 'Byte', 'zoominfobot' => 'Zoominfo', 'yisouspider' => 'Yisou', 'spider' => 'other-spider', 'bot' => 'other-bot');

    /** FangdaysCMS page for a Pboot member action, or null. */
    public static function memberPage(string $action): ?string
    {
        return self::MEMBER_PAGES[$action] ?? null;
    }

    /** @return array<string, string> */
    public static function settings(PDO $pdo): array
    {
        $settings = array();
        foreach ($pdo->query("SELECT name, value FROM site_settings WHERE name LIKE 'pboot!_%' ESCAPE '!'") as $row) {
            $settings[(string) $row['name']] = (string) $row['value'];
        }
        return $settings;
    }

    /** HomeController: 手机自适应主题 (open_wap, wap_domain, mobile user agent). */
    public static function wantsWap(array $settings): bool
    {
        if (($settings['pboot_open_wap'] ?? '') !== '1') {
            return false;
        }
        $domain = (string) ($settings['pboot_wap_domain'] ?? '');
        return ($domain !== '' && strcasecmp($domain, self::host()) === 0) || self::isMobile();
    }

    /**
     * HomeController constructor checks for every front-end request: closed site, HTTPS and
     * main-domain redirects, IP black/white lists and the wap-domain redirect. Returns true
     * when it has already answered the request.
     */
    public static function gate(PDO $pdo): bool
    {
        $settings = self::settings($pdo);
        // AI crawlers go to daily totals; a line per visit would swamp the system log.
        if (! GeoBots::record($pdo, (string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), (string) ($_SERVER['REQUEST_URI'] ?? '/')) && ($settings['pboot_spiderlog'] ?? '') !== '0') {
            self::logSpider($pdo);
        }
        if (($settings['pboot_close_site'] ?? '') === '1') {
            self::message(503, ($settings['pboot_close_site_note'] ?? '') !== '' ? $settings['pboot_close_site_note'] : '本站维护中，请稍后再访问，带来不便，敬请谅解！');
            return true;
        }
        $https = ! empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
        $uri = (string) ($_SERVER['REQUEST_URI'] ?? '/');
        if (! $https && ($settings['pboot_to_https'] ?? '') === '1') {
            header('Location: https://' . self::host(true) . $uri, true, 301);
            return true;
        }
        $wapDomain = (string) ($settings['pboot_wap_domain'] ?? '');
        $main = (string) ($settings['pboot_main_domain'] ?? '');
        if (! ($wapDomain !== '' && self::isMobile()) && $main !== '' && ($settings['pboot_to_main_domain'] ?? '') === '1' && strcasecmp($main, self::host(true)) !== 0 && strcasecmp($main, self::host()) !== 0) {
            header('Location: ' . ($https ? 'https://' : 'http://') . $main . $uri, true, 301);
            return true;
        }
        $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false) {
            foreach (self::networks($settings['pboot_ip_deny'] ?? '') as $network) {
                if (self::networkMatch($ip, $network)) {
                    self::message(403, '本站启用了黑名单功能，您的IP(' . $ip . ')不允许访问！');
                    return true;
                }
            }
            $allow = self::networks($settings['pboot_ip_allow'] ?? '');
            if ($allow && ! array_filter($allow, static fn (string $network): bool => self::networkMatch($ip, $network))) {
                self::message(403, '本站启用了白名单功能，您的IP(' . $ip . ')不在允许范围！');
                return true;
            }
        }
        if (($settings['pboot_open_wap'] ?? '') === '1' && $wapDomain !== '' && self::isMobile() && strcasecmp($wapDomain, self::host()) !== 0) {
            header('Location: ' . ($https ? 'https://' : 'http://') . $wapDomain . $uri, true, 302);
            return true;
        }
        return false;
    }

    public function handle(string $path): bool
    {
        try {
            return $this->route($path);
        } catch (InvalidArgumentException $error) {
            error_log('FangdaysCMS Pboot theme: ' . $error->getMessage());
            return false;
        }
    }

    private function route(string $path): bool
    {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            return $this->submit($path);
        }
        if ($this->url !== null && ($pbootPath = $this->pbootPath($path)) !== null && $this->dispatch($pbootPath)) {
            return true;
        }
        if ($path === '/' && $this->url?->type() === 3) {
            // 兼容 mode: /?tag=x opens the tag page and /?keyword=x the search page.
            if (is_string($this->query['tag'] ?? null) && $this->query['tag'] !== '') {
                return $this->tagPage($this->query['tag']);
            }
            if (is_string($this->query['keyword'] ?? null) && $this->query['keyword'] !== '') {
                return $this->searchPage();
            }
        }
        if ($path === '/') {
            return $this->indexPage();
        }
        if (preg_match('#^/category/([a-z0-9-]+(?:/[a-z0-9-]+)*)$#D', $path, $match)) {
            $sort = $this->data->sort($match[1]);
            if ($sort === null || $sort['url_path'] !== $match[1] || $sort['kind'] === 'link') {
                return false;
            }
            return $sort['kind'] === 'single' ? $this->aboutPage($sort) : $this->listPage($sort);
        }
        if (preg_match('#^/post/([a-z0-9-]+)$#D', $path, $match)) {
            $content = $this->data->content($match[1]);
            return $content !== null && $content['filename'] === $match[1] && $this->contentPage($content);
        }
        if ($path === '/search' || $path === '/search/') {
            return $this->searchPage();
        }
        if (preg_match('#^/tag/([^/]+)$#D', $path, $match)) {
            return $this->tagPage(rawurldecode($match[1]));
        }
        if ($path === '/qrcode' || $path === '/core/qrcode.php') {
            return $this->qrcode();
        }
        if (preg_match('#^/member/([A-Za-z]+)/?$#D', $path, $match)) {
            return $this->memberAction($match[1]);
        }
        if (preg_match('#^/comment/(my|del)/?$#D', $path, $match)) {
            return $this->commentAction($match[1]);
        }
        if (preg_match('#^/do/(likes|oppose)$#D', $path, $match)) {
            return $this->vote($match[1], (string) ($_GET['id'] ?? ''));
        }
        // Pboot Url::get() addresses: /?p=/home/Do/likes/id/4
        if ($path === '/' && is_string($_GET['p'] ?? null) && preg_match('#^/?home/Do/(likes|oppose)/id/([0-9]+)/?$#D', $_GET['p'], $match)) {
            return $this->vote($match[1], $match[2]);
        }
        return false;
    }

    /** MemberController actions on the theme's member pages. */
    private function memberAction(string $action): bool
    {
        $post = ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
        $memberId = (int) ($this->base['member']['id'] ?? 0);
        if ($action === 'logout') {
            \FangdaysCMS\Cms\Auth::memberLogout();
            return $this->redirect($this->members->address('member/login'));
        }
        if (in_array($action, array('upload', 'sendEmail', 'isRegister'), true)) {
            if (! $post) {
                return false;
            }
            if (! self::sameOrigin()) {
                return $this->json(false, '非法提交，请从本站页面提交！');
            }
            if ($action === 'upload') {
                if ($memberId === 0) {
                    return $this->json(false, '请先登录！');
                }
                [$ok, $data] = $this->members->upload(is_array($_FILES['upload'] ?? null) ? $_FILES['upload'] : array());
                return $this->json($ok, $ok ? array($data) : $data);
            }
            [$ok, $message] = $action === 'sendEmail' ? $this->members->sendEmail($_POST) : $this->members->isRegister($_POST);
            return $this->json($ok, $message);
        }
        if (! isset(self::MEMBER_TEMPLATES[$action]) || ! $this->theme->has(self::MEMBER_TEMPLATES[$action][0])) {
            return false;
        }
        $needsLogin = in_array($action, array('ucenter', 'umodify'), true);
        if ($needsLogin && $memberId === 0) {
            return $this->redirect($this->members->address('member/login'));
        }
        if (! $needsLogin && $action !== 'retrieve' && $memberId !== 0) {
            return $this->redirect($this->members->address('member/ucenter'));
        }
        if ($post) {
            if (! self::sameOrigin()) {
                return $this->respond(array(false, '非法提交，请从本站页面提交！', ''));
            }
            return $this->respond(match ($action) {
                'login' => $this->members->login($_POST, $this->query),
                'register' => $this->members->register($_POST),
                'retrieve' => $this->members->retrieve($_POST),
                default => $this->members->modify($memberId, $_POST),
            });
        }
        [$template, $titleKey, $title, $code] = self::MEMBER_TEMPLATES[$action];
        $link = $this->members->address('member/' . $action);
        $parser = $this->parser();
        $html = $parser->parserBefore($this->load($template));
        $html = str_replace('{fd:pagetitle}', $this->config($titleKey) ?: $title . '-{fd:sitetitle}-{fd:sitesubtitle}', $html);
        $html = $parser->parserPositionLabel($html, '0', $title, $link);
        $html = $parser->parserSpecialPageSortLabel($html, $code, $title, $link);
        return $this->output($parser, $parser->parserAfter($html));
    }

    /** CommentController my/del. */
    private function commentAction(string $action): bool
    {
        $memberId = (int) ($this->base['member']['id'] ?? 0);
        if ($memberId === 0) {
            return $this->redirect($this->members->address('member/login'));
        }
        if ($action === 'del') {
            $id = $this->query['id'] ?? '';
            if (! self::sameOrigin() || (($_SERVER['HTTP_ORIGIN'] ?? '') === '' && ($_SERVER['HTTP_REFERER'] ?? '') === '')) {
                return $this->respond(array(false, '非法提交，请从本站页面提交！', ''));
            }
            return $this->respond(is_string($id) && ctype_digit($id) ? $this->members->deleteComment($memberId, (int) $id) : array(false, '传递参数有误！', ''));
        }
        if (! $this->theme->has('member/mycomment.html')) {
            return false;
        }
        $link = $this->members->address('comment/my');
        $parser = $this->parser();
        $html = $parser->parserBefore($this->load('member/mycomment.html'));
        $html = str_replace('{fd:pagetitle}', '我的评论-{fd:sitetitle}-{fd:sitesubtitle}', $html);
        $html = $parser->parserPositionLabel($html, '0', '我的评论', $link);
        $html = $parser->parserSpecialPageSortLabel($html, '-3', '我的评论', $link);
        $html = $parser->parserMyCommentLabel($html, $this->members, $memberId);
        return $this->output($parser, $parser->parserAfter($html));
    }

    private function vote(string $kind, string $id): bool
    {
        $this->members->vote(ctype_digit($id) ? (int) $id : 0, $kind);
        $referer = (string) ($_SERVER['HTTP_REFERER'] ?? '');
        header('Cache-Control: no-store');
        header('Location: ' . ($referer !== '' && self::sameHost($referer) ? $referer : '/'), true, 302);
        return true;
    }

    private function json(bool $ok, mixed $data): bool
    {
        header('Cache-Control: no-store');
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('code' => $ok ? 1 : 0, 'data' => $data, 'tourl' => '', 'rowtotal' => is_array($data) ? count($data) : 1), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG);
        return true;
    }

    /**
     * Theme forms post to the Pboot addresses message, form/{fcode} and comment/add (or the same paths
     * on FangdaysCMS URLs). Requests carrying a FangdaysCMS CSRF token belong to the built-in pages.
     */
    private function submit(string $path): bool
    {
        if (isset($_POST['_csrf'])) {
            return false;
        }
        $target = trim(($this->url !== null ? $this->pbootPath($path) : null) ?? $path, '/');
        $target = preg_replace('/(?:_|\.)' . preg_quote(substr($this->url?->suffix() ?? '.html', 1), '/') . '$/', '', $target) ?? $target;
        if (preg_match('#^member/([A-Za-z]+)$#D', $target, $member) === 1) {
            return $this->memberAction($member[1]);
        }
        if ($target !== 'message' && $target !== 'comment/add' && preg_match('#^form/([A-Za-z0-9-]+)$#D', $target, $form) !== 1) {
            return false;
        }
        if (! self::sameOrigin()) {
            return $this->respond(array(false, '非法提交，请从本站页面提交！', ''));
        }
        $interaction = new Interaction($this->pdo, new PbootConfig($this->pdo), $this->base['member'] ?? null, (string) ($this->base['site_name'] ?? ''), dirname(__DIR__, 3), $this->url);
        return $this->respond(match (true) {
            $target === 'message' => $interaction->message($_POST),
            $target === 'comment/add' => $interaction->comment($_POST + $this->query, $_POST),
            default => $interaction->form($form[1], $_POST),
        });
    }

    /** Pboot alert_back()/alert_location() for forms, Response::json() for AJAX. */
    private function respond(array $result): bool
    {
        [$ok, $message, $to] = $result;
        header('Cache-Control: no-store');
        if ($to === '-1') {
            $referer = (string) ($_SERVER['HTTP_REFERER'] ?? '');
            $to = $referer !== '' && self::sameHost($referer) ? $referer : '/';
        }
        if (strtolower((string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')) === 'xmlhttprequest') {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('code' => $ok ? 1 : 0, 'data' => $message, 'tourl' => $to, 'rowtotal' => 1), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG);
            return true;
        }
        $flags = JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
        header('Content-Type: text/html; charset=utf-8');
        echo '<script type="text/javascript">alert(' . json_encode($message, $flags) . ');' . ($to !== '' ? 'location.href=' . json_encode($to, $flags | JSON_UNESCAPED_SLASHES) . ';' : 'window.history.go(-1);') . '</script>';
        return true;
    }

    /** Stand-in for a CSRF token on theme forms: a browser's Origin/Referer must name this host. */
    private static function sameOrigin(): bool
    {
        foreach (array('HTTP_ORIGIN', 'HTTP_REFERER') as $header) {
            $value = (string) ($_SERVER[$header] ?? '');
            if ($value !== '' && $value !== 'null') {
                return self::sameHost($value);
            }
        }
        return true;
    }

    private static function sameHost(string $url): bool
    {
        $host = parse_url($url, PHP_URL_HOST);
        $port = parse_url($url, PHP_URL_PORT);
        return is_string($host) && strcasecmp($host . ($port !== null ? ':' . $port : ''), (string) ($_SERVER['HTTP_HOST'] ?? '')) === 0;
    }

    /** The Pboot path of this request for the configured URL mode, or null. */
    private function pbootPath(string $path): ?string
    {
        $resolved = $this->url === null ? null : (new PbootRoute($this->data, $this->url))->requestPath($path, (string) ($_SERVER['QUERY_STRING'] ?? ''));
        if ($resolved !== null && $this->url->type() === 3) {
            // PHP has already turned this key into a $_GET entry with an empty value.
            foreach ($this->query as $key => $value) {
                if ($value === '') {
                    unset($this->query[$key]);
                    break;
                }
            }
        }
        return $resolved;
    }

    /** IndexController::_empty(): resolve a Pboot path to a page. */
    private function dispatch(string $path): bool
    {
        $route = new PbootRoute($this->data, $this->url);
        [$path, $suffix] = $route->normalize($path);
        if ($path === '') {
            return $this->indexPage();
        }
        $parts = explode('/', $path);
        switch (strtolower($parts[0])) {
            case 'search':
            case 'keyword':
                return $this->searchPage();
            case 'tag':
                $tag = $parts[1] ?? ($this->query['tag'] ?? '');
                return is_string($tag) && $this->tagPage($tag);
            case 'message':
                return $this->redirect('/message');
            case 'form':
                return isset($parts[1]) && preg_match('/^[a-z0-9-]+$/D', $parts[1]) === 1 && $this->redirect('/form/' . $parts[1]);
            case 'sitemap':
            case 'sitemap_xml':
                return $this->redirect('/sitemap.xml');
            case 'member':
                return isset($parts[1]) && $this->memberAction($parts[1]);
            case 'comment':
                return isset($parts[1]) && in_array($parts[1], array('my', 'del'), true) && $this->commentAction($parts[1]);
            case 'spider':
                return false;
        }
        $target = $route->resolve($path, $suffix);
        if ($target === null) {
            return false;
        }
        if (isset($target['content'])) {
            return $this->contentPage($target['content']);
        }
        $this->page = $target['page'];
        return $this->sortPage($target['sort']);
    }

    /** IndexController::checkPageLevel(): signed-in members get the note, guests go to the login page. */
    private function levelDenied(array ...$rules): bool
    {
        $note = (new PageLevel($this->pdo))->firstDenied($rules, $this->member);
        if ($note === null) {
            return false;
        }
        if ($this->member !== null) {
            self::message(403, $note);
            return true;
        }
        $back = urlencode((string) ($_SERVER['REQUEST_URI'] ?? '/'));
        $login = $this->url?->home('member/login', null, 'backurl=' . $back) ?? View::localizedPath('/member/login?backurl=' . $back);
        if ($this->config('login_no_wait') === '1') {
            return $this->redirect($login);
        }
        self::message(403, $note, $login);
        return true;
    }

    private function sortPage(array $sort): bool
    {
        return $sort['kind'] === 'single' ? $this->aboutPage($sort) : $this->listPage($sort);
    }

    private function indexPage(): bool
    {
        GeoHead::mark('home');
        $parser = $this->parser();
        $html = $parser->parserBefore($this->load('index.html'));
        $html = str_replace('{fd:pagetitle}', $this->config('index_title') ?: '{fd:sitetitle}-{fd:sitesubtitle}', $html);
        $html = $parser->parserPositionLabel($html, '-1', '首页', View::localizedPath('/'));
        $html = $parser->parserSpecialPageSortLabel($html, '0', '', View::localizedPath('/'));
        return $this->output($parser, $parser->parserAfter($html));
    }

    private function listPage(array $sort): bool
    {
        GeoHead::mark('category', (int) $sort['scode'], (string) $sort['filename']);
        if ($this->levelDenied($sort)) {
            return true;
        }
        $link = $this->data->sortLink($sort);
        $paging = $this->url === null ? null : fn (int $page): string => $this->url->pageLink($link, $page, $this->query);
        $parser = $this->parser(array(), $paging, $link);
        $html = $parser->parserBefore($this->load($this->template($sort, true)));
        $title = $sort['title'] !== '' ? '{sort:title}' : '{sort:name}';
        $html = str_replace('{fd:pagetitle}', $this->config('list_title') ?: $title . '-{fd:sitetitle}-{fd:sitesubtitle}', $html);
        $html = str_replace(array('{fd:pagekeywords}', '{fd:pagedescription}'), array('{sort:keywords}', '{sort:description}'), $html);
        $html = $parser->parserPositionLabel($html, $sort['scode']);
        $html = $parser->parserSortLabel($html, $sort);
        $html = $parser->parserListLabel($html, $sort['scode']);
        return $this->output($parser, $parser->parserAfter($html));
    }

    private function contentPage(array $content): bool
    {
        $sort = $this->data->sort((string) $content['scode']);
        if ($sort === null) {
            return false;
        }
        if ($this->levelDenied($sort, $content)) {
            return true;
        }
        GeoHead::mark('post', (int) $content['id'], (string) ($content['filename'] ?? ''));
        $parser = $this->parser();
        $html = $parser->parserBefore($this->load($this->template($sort, false)));
        $html = str_replace('{fd:pagetitle}', $this->config('content_title') ?: '{content:title}-{sort:name}-{fd:sitetitle}-{fd:sitesubtitle}', $html);
        $html = str_replace(array('{fd:pagekeywords}', '{fd:pagedescription}'), array('{content:keywords}', '{content:description}'), $html);
        $html = $parser->parserPositionLabel($html, $sort['scode']);
        $html = $parser->parserSortLabel($html, $sort);
        $html = $parser->parserCurrentContentLabel($html, $sort, $content);
        $html = $parser->parserCommentLabel($html);
        $this->data->addVisit((int) $content['id']);
        return $this->output($parser, $parser->parserAfter($html));
    }

    private function aboutPage(array $sort): bool
    {
        GeoHead::mark('category', (int) $sort['scode'], (string) $sort['filename']);
        $content = $this->data->about($sort['scode']);
        if ($content === null) {
            return false;
        }
        if ($this->levelDenied($sort)) {
            return true;
        }
        $link = $this->data->sortLink($sort);
        $parser = $this->parser(array(), $this->url === null ? null : fn (int $page): string => $this->url->pageLink($link, $page, $this->query), $link);
        $html = $parser->parserBefore($this->load($this->template($sort, false)));
        $title = $sort['title'] !== '' ? '{sort:title}' : '{content:title}';
        $html = str_replace('{fd:pagetitle}', $this->config('about_title') ?: $title . '-{fd:sitetitle}-{fd:sitesubtitle}', $html);
        $html = str_replace(array('{fd:pagekeywords}', '{fd:pagedescription}'), array('{content:keywords}', '{content:description}'), $html);
        $html = $parser->parserPositionLabel($html, $sort['scode']);
        $html = $parser->parserSortLabel($html, $sort);
        $html = $parser->parserCurrentContentLabel($html, $sort, $content);
        $html = $parser->parserCommentLabel($html);
        $this->data->addSingleVisit((int) $sort['scode']);
        return $this->output($parser, $parser->parserAfter($html));
    }

    private function searchPage(): bool
    {
        $link = $this->url?->home('search') ?? View::localizedPath('/search');
        $parser = $this->parser();
        $html = $parser->parserBefore($this->load($this->requestedTemplate('searchtpl', 'search.html')));
        $keyword = is_string($this->query['keyword'] ?? null) ? trim($this->query['keyword']) : '';
        // Pboot reads the title keyword through its "var" filter, which only accepts [\w\-.] characters.
        $prefix = preg_match('/^[\w\-\.]+$/D', $keyword) === 1 ? $keyword . '-' : '';
        $html = str_replace('{fd:pagetitle}', $this->config('search_title') ?: $prefix . '搜索结果-{fd:sitetitle}-{fd:sitesubtitle}', $html);
        $html = $parser->parserPositionLabel($html, '0', '搜索', $link);
        $html = $parser->parserSpecialPageSortLabel($html, '-1', '搜索结果', $link);
        $html = $parser->parserSearchLabel($html);
        return $this->output($parser, $parser->parserAfter($html));
    }

    private function tagPage(string $tag): bool
    {
        if ($tag === '' || mb_strlen($tag) > 100) {
            return false;
        }
        $link = $this->url?->home('tag/' . $tag) ?? View::localizedPath('/tag/') . rawurlencode($tag);
        $parser = $this->parser(array('tag' => $tag));
        $html = $parser->parserBefore($this->load($this->requestedTemplate('tagstpl', 'tags.html')));
        $html = $parser->parserPositionLabel($html, '0', '相关内容', $link);
        $html = $parser->parserSpecialPageSortLabel($html, '-2', '相关内容', $link);
        return $this->output($parser, $parser->parserAfter($html));
    }

    /** Pboot core/qrcode.php: PNG for {fd:qrcode}. */
    private function qrcode(): bool
    {
        $string = $_GET['string'] ?? '';
        if (! is_string($string) || $string === '' || strlen($string) > 1000) {
            return false;
        }
        require_once dirname(__DIR__, 3) . '/third_party/phpqrcode/phpqrcode.php';
        header('Cache-Control: public, max-age=86400');
        \QRcode::png($string, false, 'M', 6, 1);
        return true;
    }

    /** Pboot searchtpl/tagstpl request parameter: another page template of the theme. */
    private function requestedTemplate(string $parameter, string $default): string
    {
        $name = $_GET[$parameter] ?? '';
        return is_string($name) && preg_match('/^[\w]+\.html$/D', $name) === 1 && $this->theme->has($name) ? $name : $default;
    }

    /** Pboot core\view\Parser constants such as {URL}, resolved in template source before labels. */
    private function load(string $file): string
    {
        $constants = array(
            'URL' => (string) ($_SERVER['REQUEST_URI'] ?? '/'),
            'SITE_DIR' => '', 'SITE_INDEX_DIR' => '', 'STATIC_DIR' => '/static',
            'APP_THEME_DIR' => $this->theme->assetPath(),
        );
        return preg_replace_callback('/\{([A-Z_]+)\}/', static fn (array $match): string => array_key_exists($match[1], $constants) ? htmlspecialchars($constants[$match[1]], ENT_QUOTES, 'UTF-8') : $match[0], $this->theme->load($file)) ?? '';
    }

    /** Category or model template when the theme has it, otherwise Pboot's default for the model. */
    private function template(array $sort, bool $list): string
    {
        $configured = $list ? $sort['listtpl'] : $sort['contenttpl'];
        if ($configured !== '' && $this->theme->has($configured)) {
            return $configured;
        }
        if ($sort['kind'] === 'single') {
            return 'about.html';
        }
        $defaults = self::MODEL_TEMPLATES[$sort['urlname']] ?? array('newslist.html', 'news.html');
        return $list ? $defaults[0] : $defaults[1];
    }

    /** @param ?Closure(int): string $paging Paging::buildPath() of category lists; others use the basic form. */
    private function parser(array $query = array(), ?Closure $paging = null, ?string $pageBase = null): LabelParser
    {
        $scheme = ! empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http';
        $host = (string) ($_SERVER['HTTP_HOST'] ?? 'localhost');
        $requestPath = (string) (parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH) ?: '/');
        $query += $this->query;
        if ($this->page !== null) {
            $query['page'] = (string) $this->page;
        }
        return new LabelParser($this->data, array(
            'tpl_path' => $this->theme->assetPath(),
            'public_root' => dirname(__DIR__, 3) . '/public',
            'path' => $requestPath,
            'query' => $query,
            'page_link' => $paging ?? Paging::basic($requestPath, (string) ($_SERVER['QUERY_STRING'] ?? '')),
            'page_base' => $pageBase,
            'url' => $this->url,
            'member_center' => $this->members,
            'config' => $this->configValues(),
            'http_url' => $scheme . '://' . $host,
            'page_url' => $scheme . '://' . $host . (string) ($_SERVER['REQUEST_URI'] ?? '/'),
        ));
    }

    private function output(LabelParser $parser, string $html): bool
    {
        if (($redirect = $parser->redirect()) !== null) {
            return $this->redirect($redirect);
        }
        View::renderSiteHtml($html, $this->base);
        return true;
    }

    private function redirect(string $location): bool
    {
        header('Location: ' . (str_starts_with($location, '/') && ! str_starts_with($location, '//') ? View::localizedPath($location) : $location), true, 302);
        return true;
    }

    private function config(string $name): string
    {
        return (string) ($this->configValues()[$name] ?? '');
    }

    private function configValues(): array
    {
        if ($this->config !== null) {
            return $this->config;
        }
        $values = array('pagesize' => '20');
        foreach (self::settings($this->pdo) as $name => $value) {
            if ($value !== '') {
                $values[substr($name, 6)] = $value;
            }
        }
        // Effective 配置参数 values, defaults included.
        return $this->config = array_map(static fn ($value) => is_string($value) ? TemplateTags::normalize($value) : $value, (new PbootConfig($this->pdo))->all() + $values);
    }

    /** Pboot 蜘蛛爬行记录, written to the system log like "Baidu爬行 /path". */
    private static function logSpider(PDO $pdo): void
    {
        $agent = strtolower((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''));
        foreach (self::SPIDERS as $fragment => $name) {
            if (str_contains($agent, $fragment)) {
                (new AuditLogRepository($pdo))->record(null, $name . '爬行', 'GET', substr((string) ($_SERVER['REQUEST_URI'] ?? '/'), 0, 255), (string) ($_SERVER['REMOTE_ADDR'] ?? ''));
                return;
            }
        }
    }

    private static function message(int $status, string $text, string $link = ''): void
    {
        http_response_code($status);
        header('Content-Type: text/html; charset=utf-8');
        header('Cache-Control: no-store');
        echo '<!doctype html><html lang="zh"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>提示信息</title></head>'
            . '<body style="font-family:sans-serif;color:#333;text-align:center;padding:12% 16px"><p style="font-size:18px">' . htmlspecialchars($text, ENT_QUOTES, 'UTF-8') . '</p>'
            . ($link !== '' ? '<p><a href="' . htmlspecialchars($link, ENT_QUOTES, 'UTF-8') . '">前往登录</a></p>' : '') . '</body></html>';
    }

    private static function host(bool $withPort = false): string
    {
        $host = strtolower((string) ($_SERVER['HTTP_HOST'] ?? ''));
        return $withPort ? $host : (string) preg_replace('/:[0-9]+$/D', '', $host);
    }

    /** get_user_os() based is_mobile(), plus FangdaysCMS's ?device= override for previews. */
    private static function isMobile(): bool
    {
        $device = is_string($_GET['device'] ?? null) ? strtolower($_GET['device']) : '';
        if (in_array($device, array('mobile', 'desktop'), true)) {
            return $device === 'mobile';
        }
        return preg_match('/Android|iPhone|iPad|Windows Phone/i', (string) ($_SERVER['HTTP_USER_AGENT'] ?? '')) === 1;
    }

    /** @return list<string> IPv4 addresses or CIDR ranges, one per line or comma separated. */
    private static function networks(string $value): array
    {
        return array_values(array_filter(array_map('trim', preg_split('/[\s,，]+/u', $value) ?: array()), static fn (string $item): bool => $item !== ''));
    }

    private static function networkMatch(string $ip, string $network): bool
    {
        if (! str_contains($network, '/')) {
            return $network === $ip;
        }
        [$base, $bits] = explode('/', $network, 2);
        if (! ctype_digit($bits) || (int) $bits > 32 || ip2long($base) === false) {
            return false;
        }
        if ((int) $bits === 0) {
            return true;
        }
        $shift = 32 - (int) $bits;
        return (ip2long($ip) >> $shift) === (ip2long($base) >> $shift);
    }
}
