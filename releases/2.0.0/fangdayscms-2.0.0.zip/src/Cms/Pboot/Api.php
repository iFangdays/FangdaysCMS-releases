<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Pboot;

use FangdaysCMS\Cms\FormRepository;
use FangdaysCMS\Cms\GuestbookRepository;
use FangdaysCMS\Cms\PageLevel;
use FangdaysCMS\Cms\RateLimiter;
use FangdaysCMS\Cms\SmtpMailer;
use FangdaysCMS\Cms\View;
use InvalidArgumentException;
use PDO;
use RuntimeException;

/**
 * PbootCMS 3.2.10 api.php: the cms, list, content, about and do controllers, with the same routes
 * (/api.php/cms/site/acode/cn or /api.php?p=/cms/site), JSON envelope and appid/timestamp/signature check.
 *
 * Differences on purpose: signatures compare in constant time and far-future timestamps are refused; the
 * same-site exemption from the 15-second window compares hosts, not a substring of Referer; `cms/msg` and
 * `cms/form` (visitors' phone numbers and form data) need API authentication; content the anonymous API
 * caller may not view by level has an empty body, and `content/index` answers with the note.
 */
final class Api
{
    /** Parameters that are not field filters in cms/search. */
    private const SEARCH_RESERVED = array('appid', 'timestamp', 'signature', 'keyword', 'field', 'scode', 'page', 'from', 'isappinstalled', 'tdsourcetag', 'x', 'y', 'searchtpl', 'p', 's', 'num', 'order', 'tags', 'fuzzy', 'acode');

    private readonly PbootConfig $config;
    private readonly ?PbootUrl $url;
    private ?PbootData $data = null;
    private string $acode = '';
    private array $params = array();
    private ?int $rowTotal = null;

    public function __construct(private readonly PDO $pdo, private readonly string $root, private readonly string $defaultLocale)
    {
        $this->config = new PbootConfig($pdo);
        $this->url = PbootUrl::fromSettings(PbootSite::settings($pdo));
    }

    public function handle(string $path): void
    {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        $route = is_string($_GET['p'] ?? null) && $_GET['p'] !== '' ? $_GET['p'] : substr($path, strlen('/api.php'));
        $segments = array_values(array_filter(explode('/', $route), static fn (string $part): bool => $part !== ''));
        if (isset($segments[0]) && strtolower($segments[0]) === 'home') {
            array_shift($segments); // Pboot's likeslink and opposelink address /home/Do/likes.
        }
        $controller = strtolower($segments[0] ?? '');
        $action = $segments[1] ?? 'index';
        // Pboot's routes: /list/2, /content/8 and /about/1 put the value where the action would be.
        $value = array('list' => 'scode', 'content' => 'id', 'about' => 'scode')[$controller] ?? null;
        if ($value !== null && $action !== 'index') {
            $this->params[$value] = rawurldecode($action);
        }
        for ($i = 2; $i + 1 < count($segments); $i += 2) {
            $this->params[$segments[$i]] = rawurldecode($segments[$i + 1]);
        }
        $this->params = array_filter($_POST, 'is_string') + array_filter($_GET, 'is_string') + $this->params;
        $handler = match ($controller) {
            'cms' => 'cms',
            'list', 'content', 'about', 'do' => $controller,
            default => null,
        };
        if ($handler === null) {
            $this->json(0, '对不起，您访问的页面类文件不存在，请核对后再试！');
            return;
        }
        if (($denied = $this->denied()) !== null) {
            $this->json(0, $denied);
            return;
        }
        $this->selectArea();
        match ($handler) {
            'cms' => $this->cms($action),
            'list' => $this->listAction(),
            'content' => $this->contentAction(),
            'about' => $this->aboutAction(),
            'do' => $this->vote($action),
        };
    }

    /** ApiController::checkAccess(). */
    private function denied(): ?string
    {
        if (! $this->config->on('api_open')) {
            return '系统尚未开启API功能，请到后台配置';
        }
        if (! $this->config->on('api_auth')) {
            return null;
        }
        $appid = $this->config->get('api_appid');
        $secret = $this->config->get('api_secret');
        if ($appid === '') {
            return '请求失败：管理后台接口认证用户配置有误';
        }
        if ($secret === '') {
            return '请求失败：管理后台接口认证密钥配置有误';
        }
        foreach (array('appid', 'timestamp', 'signature') as $name) {
            if ($this->param($name) === '') {
                return '请求失败：未检查到' . $name . '参数';
            }
        }
        // Pages of this site may embed {fd:signature} and be served from the page cache, so their
        // requests get the cache lifetime as well. Referer is forgeable: the window stays bounded.
        $window = self::sameSite() ? min(86400, max(15, (int) $this->config->get('tpl_html_cache_time')) + 300) : 15;
        if (! $this->freshTimestamp($window)) {
            return '请求失败：接口时间戳验证失败！';
        }
        if (! hash_equals(md5(md5($appid . $secret . $this->param('timestamp'))), $this->param('signature'))) {
            return '请求失败：接口签名信息错误！';
        }
        return null;
    }

    private function freshTimestamp(int $window): bool
    {
        $timestamp = $this->param('timestamp');
        $age = time() - (ctype_digit($timestamp) ? (int) $timestamp : 0);
        return $age <= $window && $age >= -60;
    }

    /** Request made from one of this site's pages, by its (forgeable) Referer. */
    private static function sameSite(): bool
    {
        $referer = parse_url((string) ($_SERVER['HTTP_REFERER'] ?? ''));
        $host = (string) ($referer['host'] ?? '');
        if (isset($referer['port'])) {
            $host .= ':' . $referer['port'];
        }
        return $host !== '' && $host === (string) ($_SERVER['HTTP_HOST'] ?? '');
    }

    /** The acode parameter names an area; without it the default area answers. An unknown one has no data. */
    private function selectArea(): void
    {
        $regions = $this->pdo->query('SELECT locale, prefix, is_default, legacy_acode FROM regions WHERE is_enabled = 1 ORDER BY sort_order, locale')->fetchAll();
        $wanted = $this->param('acode');
        foreach ($regions as $region) {
            $codes = array((string) ($region['legacy_acode'] ?? ''), (string) $region['prefix'], (string) $region['locale']);
            if ($wanted === '' ? (int) $region['is_default'] === 1 : in_array($wanted, $codes, true)) {
                $this->acode = (string) ($region['legacy_acode'] ?? '') ?: (string) $region['prefix'];
                $this->data = new PbootData($this->pdo, (string) $region['locale'], null, $this->url);
                return;
            }
        }
        if ($wanted === '') {
            $this->acode = $this->defaultLocale;
            $this->data = new PbootData($this->pdo, $this->defaultLocale, null, $this->url);
        }
    }

    private function cms(string $action): void
    {
        match ($action) {
            'site' => $this->single('site'),
            'company' => $this->single('company'),
            'label' => $this->label(),
            'nav' => $this->nav(),
            'position' => $this->position(),
            'sort' => $this->sort(),
            'pics' => $this->pics(),
            'slide' => $this->slide(),
            'link' => $this->link(),
            'search' => $this->search(),
            'msg' => $this->messages(),
            'addmsg' => $this->addMessage(),
            'form' => $this->formRows(),
            'addform' => $this->addForm(),
            default => $this->json(0, '您调用的接口不存在，请核对后重试！'),
        };
    }

    private function single(string $table): void
    {
        $row = $this->data === null ? array() : array('id' => '1', 'acode' => $this->acode) + ($table === 'site' ? $this->data->site() : $this->data->company());
        $name = $this->param('name');
        $this->json(1, $name === '' ? $row : ($row[$name] ?? ''));
    }

    private function label(): void
    {
        $labels = array_map(static fn (array $label): string => $label['value'], $this->data?->labels() ?? array());
        $name = $this->param('name');
        $this->json(1, $name === '' ? $labels : ($labels[$name] ?? ''));
    }

    private function sortRow(array $sort): array
    {
        $access = $this->groupId((string) $sort['gcode']);
        $filename = (string) $sort['filename'];
        return array(
            'id' => $sort['id'], 'acode' => $this->acode, 'mcode' => self::modelCode((string) $sort['mcode']), 'pcode' => $sort['pcode'], 'scode' => $sort['scode'], 'name' => $sort['name'],
            'listtpl' => $sort['listtpl'], 'contenttpl' => $sort['contenttpl'], 'status' => $sort['status'], 'outlink' => $sort['outlink'], 'subname' => $sort['subname'],
            'ico' => $sort['ico'], 'pic' => $sort['pic'], 'title' => $sort['title'], 'keywords' => $sort['keywords'], 'description' => $sort['description'],
            'filename' => $filename === 'sort-' . $sort['scode'] ? '' : $filename, 'sorting' => $sort['sorting'], 'create_user' => '', 'update_user' => '', 'create_time' => '', 'update_time' => '',
            'gtype' => (string) $sort['gtype'], 'gid' => $access, 'gnote' => $sort['gnote'], 'def1' => $sort['def1'], 'def2' => $sort['def2'], 'def3' => $sort['def3'], 'type' => $sort['type'],
        );
    }

    /** Imported models are named pboot-<mcode>. */
    private static function modelCode(string $slug): string
    {
        return str_starts_with($slug, 'pboot-') ? substr($slug, 6) : $slug;
    }

    private function groupId(string $gcode): string
    {
        if ($gcode === '') {
            return '';
        }
        $stmt = $this->pdo->prepare('SELECT id FROM member_groups WHERE code = ?');
        $stmt->execute(array($gcode));
        return (string) $stmt->fetchColumn();
    }

    private function nav(): void
    {
        $sorts = array_filter($this->data?->sorts() ?? array(), static fn (array $sort): bool => $sort['status'] === '1');
        $scode = $this->param('scode');
        if ($scode !== '') {
            $this->json(1, array_values(array_map(fn (array $sort): array => $this->sortRow($sort), array_filter($sorts, static fn (array $sort): bool => $sort['pcode'] === $scode))));
            return;
        }
        $tree = function (string $parent) use (&$tree, $sorts): array {
            $rows = array();
            foreach ($sorts as $sort) {
                if ($sort['pcode'] === $parent) {
                    $rows[] = $this->sortRow($sort) + array('son' => $tree((string) $sort['scode']));
                }
            }
            return $rows;
        };
        $this->json(1, $tree('0'));
    }

    private function position(): void
    {
        $scode = $this->param('scode');
        if ($scode === '') {
            $this->json(0, '必须传递当前分类scode参数');
            return;
        }
        $sorts = $this->data?->sorts() ?? array();
        $rows = array();
        for ($guard = 0; isset($sorts[$scode]) && $guard < 64; $guard++) {
            $sort = $sorts[$scode];
            array_unshift($rows, array('scode' => $sort['scode'], 'id' => $sort['id'], 'pcode' => $sort['pcode'], 'name' => $sort['name'], 'outlink' => $sort['outlink'], 'type' => $sort['type']));
            $scode = (string) $sort['pcode'];
        }
        $this->json(1, $rows);
    }

    private function sort(): void
    {
        $scode = $this->param('scode');
        if ($scode === '') {
            $this->json(0, '必须传递分类scode参数');
            return;
        }
        $sort = $this->data?->sort($scode);
        $this->json(1, $sort === null ? array() : $this->sortRow($sort));
    }

    private function pics(): void
    {
        $id = $this->param('id');
        if (! ctype_digit($id) || (int) $id === 0) {
            $this->json(0, '必须传递内容id参数');
            return;
        }
        $content = $this->data?->content($id);
        $this->json(1, ($content['pics'] ?? '') === '' ? array() : explode(',', (string) $content['pics']));
    }

    private function slide(): void
    {
        $gid = $this->param('gid');
        if ($gid === '') {
            $this->json(0, '必须传递幻灯片分组gid参数');
            return;
        }
        $rows = $this->data?->slides((int) $gid, $this->integer('num', 10), 1) ?? array();
        $this->json(1, array_map(fn (array $row): array => array('id' => (string) $row['id'], 'acode' => $this->acode, 'gid' => (string) $row['gid'], 'pic' => (string) $row['pic'], 'link' => (string) $row['link'], 'title' => (string) $row['title'], 'subtitle' => (string) $row['subtitle'], 'sorting' => (string) $row['sorting'], 'create_user' => '', 'update_user' => '', 'create_time' => '', 'update_time' => ''), $rows));
    }

    private function link(): void
    {
        $gid = $this->param('gid');
        if ($gid === '') {
            $this->json(0, '必须传递友情链接分组gid参数');
            return;
        }
        $rows = $this->data?->links((int) $gid, $this->integer('num', 20), 1) ?? array();
        $this->json(1, array_map(fn (array $row): array => array('id' => (string) $row['id'], 'acode' => $this->acode, 'gid' => (string) $row['gid'], 'name' => (string) $row['name'], 'link' => (string) $row['link'], 'logo' => (string) $row['logo'], 'sorting' => (string) $row['sorting'], 'create_user' => '', 'update_user' => '', 'create_time' => '', 'update_time' => ''), $rows));
    }

    private function listAction(): void
    {
        $this->contents(array('scode' => $this->param('scode'), 'order' => $this->order(), 'fuzzy' => true, 'flags' => array()));
    }

    private function search(): void
    {
        if ($_POST === array()) {
            $this->json(0, '请使用POST提交！');
            return;
        }
        $field = $this->param('field');
        $field = preg_match('/^[\w\|]+$/D', $field) === 1 ? $field : '';
        $scode = $this->param('scode');
        $scode = preg_match('/^[\w,\s]+$/D', $scode) === 1 ? $scode : '';
        $criteria = array('scode' => $scode, 'order' => $this->order(), 'fuzzy' => true, 'flags' => array());
        if (($keyword = $this->param('keyword')) !== '') {
            $criteria['anyof'] = array(explode('|', $field !== '' ? $field : 'title'), $keyword);
        }
        if (($tags = $this->param('tags')) !== '') {
            $criteria['tags'] = explode(',', $tags);
        }
        foreach ($this->params as $key => $value) {
            if (! in_array($key, self::SEARCH_RESERVED, true) && $value !== '') {
                $criteria['ext'][$key] = $value; // PbootData only accepts known columns and ext_ fields.
            }
        }
        $this->contents($criteria);
    }

    private function order(): string
    {
        $order = $this->param('order');
        return preg_match('/^[\w\-,\s]+$/D', $order) === 1 ? $order : '';
    }

    private function contents(array $criteria): void
    {
        if ($this->data === null) {
            $this->rowTotal = 0;
            $this->json(1, array());
            return;
        }
        $num = $this->integer('num', (int) ($this->config->get('pagesize') ?: 15));
        $page = $this->integer('page', 0);
        $total = $this->data->contents($criteria, $num, 1, 1, true)['total'];
        if ($page > (int) ceil($total / $num)) {
            $this->rowTotal = $total;
            $this->json(0, '已经到底了！');
            return;
        }
        $rows = $this->data->contents($criteria, $num, max(1, $page), 1, false)['rows'];
        $this->rowTotal = $total;
        $this->json(1, array_map(fn (array $content): array => $this->contentRow($content), $rows));
    }

    /** One ay_content row with its joined fields, in Pboot's field order. */
    private function contentRow(array $content): array
    {
        $single = ($content['type'] ?? '2') === '1';
        $sort = $content['sort'] ?? ($this->data->sort((string) $content['scode']) ?? array());
        $id = (string) $content['id'];
        $body = str_replace(array('/static/upload/', '="/uploads/'), array($this->httpUrl() . '/static/upload/', '="' . $this->httpUrl() . '/uploads/'), (string) $content['content']);
        if ((new PageLevel($this->pdo))->firstDenied(array($sort, $content), null) !== null) {
            $body = '';
        }
        $row = array(
            'id' => $id, 'acode' => $this->acode, 'scode' => $content['scode'], 'subscode' => $content['subscode'], 'title' => $content['title'],
            'titlecolor' => $content['titlecolor'] !== '' ? $content['titlecolor'] : '#333333', 'subtitle' => $content['subtitle'],
            'filename' => (string) $content['filename'] === $id ? '' : $content['filename'], 'author' => $content['author'], 'source' => $content['source'], 'outlink' => $content['outlink'],
            'date' => $content['date'], 'ico' => $content['ico'], 'pics' => $content['pics'], 'content' => $body, 'tags' => $content['tags'], 'enclosure' => $content['enclosure'],
            'keywords' => $content['keywords'], 'description' => $content['description'], 'sorting' => (string) $content['sorting'], 'status' => '1',
            'istop' => $content['istop'], 'isrecommend' => $content['isrecommend'], 'isheadline' => $content['isheadline'],
            'visits' => (string) $content['visits'], 'likes' => (string) $content['likes'], 'oppose' => (string) $content['oppose'],
            'create_user' => '', 'update_user' => '', 'create_time' => $content['create_time'] ?? '', 'update_time' => $content['update_time'] ?? '',
            'gtype' => (string) ($content['gtype'] ?? 4), 'gid' => $this->groupId((string) ($content['gcode'] ?? '')), 'gnote' => $content['gnote'] ?? '', 'picstitle' => $content['picstitle'],
            'sortname' => $content['sortname'], 'sortfilename' => $content['sortfilename'], 'subsortname' => $content['subsortname'] !== '' ? $content['subsortname'] : null,
            'type' => $single ? '1' : '2', 'modelname' => $sort['modelname'] ?? '', 'urlname' => str_starts_with((string) ($sort['urlname'] ?? ''), 'pboot-') ? ($single ? 'about' : 'list') : ($sort['urlname'] ?? ''),
            'extid' => null, 'contentid' => null,
        );
        $hasValues = false;
        foreach ($this->pdo->query('SELECT DISTINCT name FROM model_fields ORDER BY name') as $field) {
            $name = (string) $field['name'];
            $row[$name] = $content[$name] ?? null;
            $hasValues = $hasValues || isset($content[$name]);
        }
        if ($hasValues) {
            $row['extid'] = $row['contentid'] = $id;
        }
        $link = $this->data->contentLink($content);
        if ($content['outlink'] !== '') {
            $row['apilink'] = $content['outlink'];
        } else {
            $row['apilink'] = $this->route($single ? '/about/' . $content['scode'] : '/content/' . $id);
        }
        $row['likeslink'] = $this->route('/home/Do/likes/id/' . $id);
        $row['opposelink'] = $this->route('/home/Do/oppose/id/' . $id);
        $row['contentlink'] = $link;
        return $row;
    }

    private function contentAction(): void
    {
        $id = $this->param('id');
        if (! ctype_digit($id) || (int) $id === 0) {
            $this->json(1, '请求错误，传递的内容id有误！');
            return;
        }
        $content = $this->data?->content($id);
        if ($content === null) {
            $this->json(0, 'id为' . $id . '的内容已经不存在了！');
            return;
        }
        $note = (new PageLevel($this->pdo))->firstDenied(array($this->data->sort((string) $content['scode']) ?? array(), $content), null);
        if ($note !== null) {
            $this->json(0, $note);
            return;
        }
        $this->data->addVisit((int) $id);
        $this->json(1, $this->contentRow($content));
    }

    private function aboutAction(): void
    {
        $scode = $this->param('scode');
        if ($scode === '') {
            $this->json(1, '请求错误，传递的内容scode有误！');
            return;
        }
        $sort = $this->data?->sort($scode);
        if ($sort === null) {
            foreach ($this->data?->sorts() ?? array() as $candidate) {
                if ($candidate['filename'] === $scode) {
                    $sort = $candidate;
                }
            }
        }
        $content = $sort === null ? null : $this->data->about((string) $sort['scode']);
        if ($content === null) {
            $this->json(0, '分类编码为' . $scode . '的内容已经不存在了！');
            return;
        }
        if (($note = (new PageLevel($this->pdo))->firstDenied(array($sort), null)) !== null) {
            $this->json(0, $note);
            return;
        }
        $this->data->addSingleVisit((int) $sort['scode']);
        $this->json(1, $this->contentRow($content));
    }

    private function vote(string $action): void
    {
        $id = $this->param('id');
        $column = array('likes' => 'likes', 'oppose' => 'oppose')[$action] ?? null;
        if ($column === null) {
            $this->json(0, '您调用的接口不存在，请核对后重试！');
            return;
        }
        $done = $action === 'likes' ? '点赞' : '反对';
        if (! ctype_digit($id) || (int) $id === 0) {
            $this->json(0, $done . '失败');
            return;
        }
        $this->pdo->prepare("UPDATE post_meta SET $column = $column + 1 WHERE post_id = ?")->execute(array((int) $id));
        $this->json(1, $done . '成功');
    }

    /** Rows with visitors' contact details stay behind API authentication. */
    private function privateRead(): bool
    {
        if ($this->config->on('api_auth')) {
            // Visitors' contact details: no Referer-based extension, a signature is good for 15 seconds.
            if (! $this->freshTimestamp(15)) {
                $this->json(0, '请求失败：接口时间戳验证失败！');
                return false;
            }
            return true;
        }
        $this->json(0, '读取留言和表单数据需要开启 API 强制认证');
        return false;
    }

    private function messages(): void
    {
        if (! $this->privateRead()) {
            return;
        }
        $num = $this->integer('num', (int) ($this->config->get('pagesize') ?: 15));
        $page = max(1, $this->integer('page', 1));
        $total = (int) $this->pdo->query("SELECT COUNT(*) FROM guestbook_messages WHERE status = 'approved'")->fetchColumn();
        if ($page > max(1, (int) ceil($total / $num))) {
            $this->rowTotal = $total;
            $this->json(0, '已经到底了！');
            return;
        }
        $rows = $this->pdo->query("SELECT * FROM guestbook_messages WHERE status = 'approved' ORDER BY id DESC LIMIT " . $num . ' OFFSET ' . (($page - 1) * $num))->fetchAll();
        $this->rowTotal = $total;
        $this->json(1, array_map(fn (array $row): array => array(
            'id' => (string) $row['id'], 'acode' => $this->acode, 'contacts' => $row['name'], 'mobile' => $row['phone'], 'content' => $row['content'],
            'user_ip' => (string) (ip2long((string) ($row['user_ip'] ?? '')) ?: 0), 'user_os' => $row['user_os'] ?? '', 'user_bs' => $row['user_bs'] ?? '', 'recontent' => $row['recontent'] ?? '', 'status' => '1',
            'create_user' => '', 'update_user' => '', 'create_time' => date('Y-m-d H:i:s', (int) $row['created_at']), 'update_time' => (int) ($row['replied_at'] ?? 0) > 0 ? date('Y-m-d H:i:s', (int) $row['replied_at']) : '', 'uid' => (string) (int) ($row['member_id'] ?? 0),
        ), $rows));
    }

    private function addMessage(): void
    {
        if ($_POST === array()) {
            $this->json(0, '留言提交失败，请使用POST方式提交！');
            return;
        }
        if (! $this->config->on('message_status')) {
            $this->json(0, '系统已经关闭留言功能，请到后台开启再试！');
            return;
        }
        if (! $this->allowed('message')) {
            return;
        }
        $values = array();
        $mail = '';
        foreach (array('contacts' => '联系人', 'mobile' => '手机', 'content' => '内容') as $name => $label) {
            $values[$name] = str_ireplace(array('fd:if', 'pboot:if'), '', $this->post($name));
            if ($values[$name] === '') {
                $this->json(0, $label . '不能为空！');
                return;
            }
            $mail .= View::e($label) . '：' . View::e($values[$name]) . '<br>';
        }
        try {
            $guestbook = new GuestbookRepository($this->pdo);
            $id = $guestbook->create($values['contacts'], '', $values['mobile'], $values['content'], null);
            if (! $this->config->on('message_verify')) {
                $guestbook->updateStatus($id, 'approved');
            }
        } catch (InvalidArgumentException) {
            $this->json(0, '留言提交失败！');
            return;
        }
        $this->notify('message_send_mail', '您有新的在线留言信息，请注意查收！', $mail);
        $this->json(1, '留言提交成功！');
    }

    private function formRows(): void
    {
        $fcode = $this->param('fcode');
        if ($fcode === '') {
            $this->json(0, '必须传递表单编码fcode');
            return;
        }
        $forms = new FormRepository($this->pdo);
        $form = ctype_digit($fcode) ? $forms->byId((int) $fcode) : null;
        if ($form === null) {
            $this->json(0, '传递的fcode有误');
            return;
        }
        if (! $this->privateRead()) {
            return;
        }
        $num = $this->integer('num', (int) ($this->config->get('pagesize') ?: 15));
        $page = max(1, $this->integer('page', 1));
        $rows = $forms->submissions((int) $form['id']);
        if ($page > max(1, (int) ceil(count($rows) / $num))) {
            $this->rowTotal = count($rows);
            $this->json(0, '已经到底了！');
            return;
        }
        $this->rowTotal = count($rows);
        $this->json(1, array_map(static function (array $row) use ($forms, $form): array {
            $values = json_decode((string) $row['values_json'], true);
            $data = array('id' => (string) $row['id']);
            foreach ($forms->fields($form) as $field) {
                $data[(string) $field['name']] = is_array($values) ? (string) ($values[$field['name']] ?? '') : '';
            }
            return $data + array('create_time' => date('Y-m-d H:i:s', (int) $row['created_at']));
        }, array_slice($rows, ($page - 1) * $num, $num)));
    }

    private function addForm(): void
    {
        if ($_POST === array()) {
            $this->json(0, '表单提交失败，请使用POST方式提交！');
            return;
        }
        $fcode = $this->param('fcode');
        if ($fcode === '') {
            $this->json(0, '传递的表单编码fcode有误！');
            return;
        }
        if (! $this->config->on('form_status')) {
            $this->json(0, '系统已经关闭表单功能，请到后台开启再试！');
            return;
        }
        $forms = new FormRepository($this->pdo);
        $form = ctype_digit($fcode) ? $forms->byId((int) $fcode) : null;
        if ($form === null || $form['status'] !== 'published' || ! ($fields = $forms->fields($form))) {
            $this->json(0, '接收表单不存在任何字段，请核对后重试！');
            return;
        }
        if (! $this->allowed('form')) {
            return;
        }
        $mail = '';
        $values = array();
        foreach ($fields as $field) {
            $name = (string) $field['name'];
            $label = (string) ($field['label'] ?? $name);
            $values[$name] = str_ireplace(array('fd:if', 'pboot:if'), '', $this->post($name));
            if (! empty($field['required']) && $values[$name] === '') {
                $this->json(0, $label . '不能为空！');
                return;
            }
            $mail .= View::e($label) . '：' . View::e($values[$name]) . '<br>';
        }
        try {
            $forms->submit((int) $form['id'], $values, null);
        } catch (InvalidArgumentException) {
            $this->json(0, '表单提交失败！');
            return;
        }
        $this->notify('form_send_mail', '您有新的' . $form['name'] . '信息，请注意查收！', $mail);
        $this->json(1, '表单提交成功！');
    }

    /** The API has no captcha, so writes are limited per address (FANGDAYS_RATE_PBOOT_API_* configurable). */
    private function allowed(string $scope): bool
    {
        $limiter = new RateLimiter($this->root . '/var/rate-limits');
        if ($limiter->configuredAllow('pboot-api', $scope . '|' . (string) ($_SERVER['REMOTE_ADDR'] ?? ''), 20, 600)) {
            return true;
        }
        $this->json(0, '您提交太频繁了，请稍后再试！');
        return false;
    }

    private function notify(string $switch, string $subject, string $body): void
    {
        $to = $this->config->get('message_send_to');
        if (! $this->config->on($switch) || $to === '') {
            return;
        }
        try {
            SmtpMailer::sendMail($this->config->all(), $to, '【' . ($this->data?->site()['title'] ?? '') . '】' . $subject, $body . '<br>来自网站 ' . View::e($this->httpUrl()) . ' （' . date('Y-m-d H:i:s') . '）');
        } catch (RuntimeException $exception) {
            error_log('FangdaysCMS API notification mail: ' . $exception->getMessage());
        }
    }

    private function param(string $name): string
    {
        return trim((string) ($this->params[$name] ?? ''));
    }

    private function post(string $name): string
    {
        $value = $_POST[$name] ?? '';
        return is_array($value) ? implode(',', array_filter($value, 'is_string')) : (is_string($value) ? trim($value) : '');
    }

    private function integer(string $name, int $default): int
    {
        $value = $this->param($name);
        return ctype_digit($value) && (int) $value > 0 ? min((int) $value, 1000) : $default;
    }

    private function httpUrl(): string
    {
        return (! empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http') . '://' . (string) ($_SERVER['HTTP_HOST'] ?? '');
    }

    /** url('/api/...', false): /api.php?p=/route in Pboot's compatible mode, /api.php/route otherwise. */
    private function route(string $route): string
    {
        return $this->url?->type() === 3 ? '/api.php?p=' . $route : '/api.php' . $route;
    }

    /** Response::json(). */
    private function json(int $code, mixed $data): void
    {
        $total = $this->rowTotal ?? (is_array($data) ? (array_is_list($data) || $code === 0 ? count($data) : 1) : 1);
        echo json_encode(array('code' => $code, 'data' => $data !== '' && $data !== null && $data !== 0 ? $data : array(), 'tourl' => '', 'rowtotal' => $total), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    }
}
