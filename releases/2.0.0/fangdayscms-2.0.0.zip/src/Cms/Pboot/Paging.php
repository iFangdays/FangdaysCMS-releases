<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Pboot;

use Closure;

/**
 * PbootCMS 3.2.10 core\view\Paging output for one paged list. The link builder
 * returns the unescaped address of a page number (see basic() and PbootUrl::pageLink()).
 */
final class Paging
{
    private int $rows = 0;
    private int $count = 0;
    private int $page = 1;

    /** @param Closure(int): string $builder */
    public function __construct(private readonly Closure $builder, private readonly int $numbers = 5)
    {
    }

    /** Paging::buildBasicPage(): the current path with page=N in the query string. */
    public static function basic(string $path, string $queryString): Closure
    {
        $queryString = trim(preg_replace('/[&\?]?page=([0-9]+)?/i', '', $queryString) ?? '', '&');
        return static function (int $page) use ($path, $queryString): string {
            if ($page <= 1) {
                return $path . ($queryString !== '' ? '?' . $queryString : '');
            }
            return $path . '?' . ($queryString !== '' ? $queryString . '&' : '') . 'page=' . $page;
        };
    }

    public function setup(int $total, int $pageSize, int $requested): void
    {
        $this->rows = max(0, $total);
        $this->count = (int) ceil($this->rows / max(1, $pageSize));
        $page = $requested > 1 ? $requested : 1;
        $this->page = $this->count > 0 && $page > $this->count ? $this->count : $page;
    }

    public function page(): int
    {
        return $this->page;
    }

    /** Values for {page:*} labels, keyed like Pboot's assigned page variables. */
    public function vars(): array
    {
        return array(
            'bar' => $this->bar(), 'current' => $this->count ? $this->page : 0, 'count' => $this->count, 'rows' => $this->rows,
            'index' => $this->count ? $this->link(1) : 'javascript:;',
            'pre' => $this->count && $this->page > 1 ? $this->link($this->page - 1) : 'javascript:;',
            'next' => $this->count && $this->page < $this->count ? $this->link($this->page + 1) : 'javascript:;',
            'last' => $this->count ? $this->link($this->count) : 'javascript:;',
            'status' => $this->status(), 'numbar' => $this->numBar(), 'selectbar' => $this->selectBar(),
        );
    }

    private function link(int $page): string
    {
        // Addresses are built from encoded values; "&" stays raw as in Pboot.
        return strtr(($this->builder)($page), array('"' => '&quot;', "'" => '&#039;', '<' => '&lt;', '>' => '&gt;'));
    }

    private function status(): string
    {
        return $this->count ? '共' . $this->rows . '条 当前' . $this->page . '/' . $this->count . '页' : '';
    }

    private function bar(): string
    {
        if (! $this->count) {
            return "<span class='page-none' style='color:#999'>未查询到任何数据!</span>";
        }
        $vars = array('index' => $this->link(1), 'pre' => $this->page > 1 ? $this->link($this->page - 1) : 'javascript:;', 'next' => $this->page < $this->count ? $this->link($this->page + 1) : 'javascript:;', 'last' => $this->link($this->count));
        return "<span class='page-status'>" . $this->status() . "</span>"
            . "<span class='page-index'><a href='" . $vars['index'] . "'>首页</a></span>"
            . "<span class='page-pre'><a href='" . $vars['pre'] . "'>前一页</a></span>"
            . "<span class='page-numbar'>" . $this->numBar() . "</span>"
            . "<span class='page-next'><a href='" . $vars['next'] . "'>后一页</a></span>"
            . "<span class='page-last'><a href='" . $vars['last'] . "'>尾页</a></span>";
    }

    private function numBar(): string
    {
        if (! $this->count) {
            return '';
        }
        $total = $this->numbers;
        $halfl = intdiv($total, 2);
        $halfu = (int) ceil($total / 2);
        $html = '';
        if ($this->page > $halfu) {
            $html .= '<span class="page-num">···</span>';
        }
        if ($this->page <= $halfl || $this->count < $total) {
            $from = 1;
            $to = min($total, $this->count);
        } elseif ($this->page + $halfl >= $this->count) {
            $from = $this->count - $total + 1;
            $to = $this->count;
        } else {
            $from = $this->page - $halfl;
            $to = $this->page + $halfl;
        }
        for ($i = $from; $i <= $to; $i++) {
            $html .= '<a href="' . $this->link($i) . '" class="page-num' . ($i === $this->page ? ' page-num-current' : '') . '">' . $i . '</a>';
        }
        if ($this->count > $total && $this->page < $this->count - $halfl) {
            $html .= '<span class="page-num">···</span>';
        }
        return $html;
    }

    private function selectBar(): string
    {
        if (! $this->count) {
            return '';
        }
        $html = '<select onchange="changepage(this)" lay-ignore>';
        for ($i = 1; $i <= $this->count; $i++) {
            $html .= '<option value="' . $i . '"' . ($i === $this->page ? ' selected="selected"' : '') . '>跳到' . $i . '页</option>';
        }
        [$before, $after] = explode('987654321', ($this->builder)(987654321), 2) + array('', '');
        $flags = JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
        return $html . '</select><script>function changepage(tag){window.location.href=' . json_encode($before, $flags) . '+tag.value+' . json_encode($after, $flags) . ';}</script>';
    }
}
