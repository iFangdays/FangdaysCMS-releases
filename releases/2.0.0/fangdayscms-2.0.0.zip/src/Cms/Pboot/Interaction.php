<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Pboot;

use FangdaysCMS\Cms\Captcha;
use FangdaysCMS\Cms\CommentRepository;
use FangdaysCMS\Cms\FormRepository;
use FangdaysCMS\Cms\GuestbookRepository;
use FangdaysCMS\Cms\RateLimiter;
use FangdaysCMS\Cms\SmtpMailer;
use FangdaysCMS\Cms\View;
use InvalidArgumentException;
use PDO;

/**
 * Theme submissions as PbootCMS apps/home/controller Message/Form/CommentController handle them:
 * same field names, checks, order and messages. Each method returns [ok, message, redirect address].
 */
final class Interaction
{
    /** Pboot's 留言 form (ay_form_field fcode=1): field => description. */
    private const MESSAGE_FIELDS = array('contacts' => '联系人', 'mobile' => '手机', 'content' => '内容');

    public function __construct(
        private readonly PDO $pdo,
        private readonly PbootConfig $config,
        private readonly ?array $member,
        private readonly string $siteName,
        private readonly string $root,
        private readonly ?PbootUrl $url,
    ) {
    }

    /** @return array{0: bool, 1: string, 2: string} */
    public function message(array $post): array
    {
        if (! $this->config->on('message_status')) {
            return array(false, '系统已经关闭留言功能，请到后台开启再试！', '');
        }
        if (($wait = $this->tooSoon('message')) !== null) {
            return $wait;
        }
        if ($this->config->on('message_rqlogin') && $this->member === null) {
            return array(false, '请先注册登录后再留言！', $this->loginUrl());
        }
        if (($error = Captcha::error('message', self::field($post, 'checkcode'))) !== null) {
            return array(false, $error, '');
        }
        $values = array();
        $mail = '';
        foreach (self::MESSAGE_FIELDS as $name => $description) {
            $values[$name] = str_ireplace(array('fd:if', 'pboot:if'), '', self::field($post, $name));
            if ($values[$name] === '') {
                return array(false, $description . '不能为空！', '');
            }
            $mail .= View::e($description) . '：' . View::e($values[$name]) . '<br>';
        }
        try {
            $guestbook = new GuestbookRepository($this->pdo);
            $id = $guestbook->create($values['contacts'], is_string($post['email'] ?? null) ? trim($post['email']) : '', $values['mobile'], $values['content'], $this->member['id'] ?? null);
            if (! $this->config->on('message_verify')) {
                $guestbook->updateStatus($id, 'approved');
            }
            $this->recordVisitor('guestbook_messages', $id);
        } catch (InvalidArgumentException $exception) {
            return array(false, $exception->getMessage(), '');
        }
        $_SESSION['pboot_lastsub'] = time();
        $this->notify('message_send_mail', '【' . $this->siteName . '】您有新的在线留言信息，请注意查收！', $mail);
        return array(true, '提交成功！', '-1');
    }

    /** @return array{0: bool, 1: string, 2: string} */
    public function form(string $fcode, array $post): array
    {
        if (! $this->config->on('form_status')) {
            return array(false, '系统已经关闭表单功能，请到后台开启再试！', '');
        }
        if (($wait = $this->tooSoon('form')) !== null) {
            return $wait;
        }
        if ($fcode === '' || preg_match('/^[a-z0-9-]{1,64}$/D', $fcode) !== 1) {
            return array(false, '传递的表单编码有误！', '');
        }
        if (($error = Captcha::error('form', self::field($post, 'checkcode'))) !== null) {
            return array(false, $error, '');
        }
        $forms = new FormRepository($this->pdo);
        $form = ctype_digit($fcode) ? $forms->byId((int) $fcode) : null;
        $form = $form !== null && $form['status'] === 'published' ? $form : $forms->publishedBySlug($fcode);
        if ($form === null && $fcode === '1') {
            // In Pboot fcode 1 is the guestbook, which has its own address.
            return array(false, '表单提交地址有误，留言提交请使用留言专用地址!', '');
        }
        if ($form === null || ! ($fields = $forms->fields($form))) {
            return array(false, '接收表单不存在任何字段，请核对后重试！', '');
        }
        $mail = '';
        foreach ($fields as $field) {
            $value = $post[$field['name'] ?? ''] ?? '';
            $value = is_array($value) ? implode(',', array_filter($value, 'is_string')) : (is_string($value) ? trim($value) : '');
            if (! empty($field['required']) && $value === '') {
                return array(false, ($field['label'] ?? $field['name']) . '不能为空！', '');
            }
            $mail .= View::e((string) ($field['label'] ?? $field['name'])) . '：' . View::e($value) . '<br>';
        }
        try {
            $forms->submit((int) $form['id'], $post, $this->member['id'] ?? null);
        } catch (InvalidArgumentException $exception) {
            return array(false, $exception->getMessage(), '');
        }
        $_SESSION['pboot_lastsub'] = time();
        $this->notify('form_send_mail', '【' . $this->siteName . '】您有新的' . $form['name'] . '信息，请注意查收！', $mail);
        return array(true, '提交成功！', '-1');
    }

    /** CommentController::add(): contentid, pid and puid come from the address or the form. */
    public function comment(array $request, array $post): array
    {
        if (! $this->config->on('comment_status')) {
            return array(false, '系统已经关闭评论功能，请到后台开启再试！', '');
        }
        if (($wait = $this->tooSoon('comment')) !== null) {
            return $wait;
        }
        if ($this->member === null && ! $this->config->on('comment_anonymous')) {
            return array(false, '请先注册登录后再评论！', $this->loginUrl());
        }
        if (($error = Captcha::error('comment', self::field($post, 'checkcode'))) !== null) {
            return array(false, $error, '');
        }
        $contentId = self::number($request, 'contentid');
        if ($contentId === 0) {
            return array(false, '文章ID未能正常获取，请使用POST或URL参数传递！', '');
        }
        $post_ = (new PbootData($this->pdo, 'zh-CN', $this->member))->content((string) $contentId);
        if ($post_ === null) {
            return array(false, '提交失败！', '');
        }
        $comment = str_ireplace(array('fd:if', 'pboot:if'), '', self::field($post, 'comment'));
        try {
            $comments = new CommentRepository($this->pdo);
            $id = $comments->create($contentId, (string) ($this->member['display_name'] ?? '游客'), (string) ($this->member['email'] ?? ''), $comment, $this->member['id'] ?? null);
            $approved = ! $this->config->on('comment_verify');
            if ($approved) {
                $comments->updateStatus($id, 'approved');
            }
            $parent = self::number($request, 'pid');
            $parentMember = self::number($request, 'puid');
            $this->pdo->prepare('UPDATE post_comments SET parent_id = ?, parent_member_id = ? WHERE id = ?')->execute(array($parent, $parentMember, $id));
            $this->recordVisitor('post_comments', $id);
        } catch (InvalidArgumentException $exception) {
            return array(false, $exception->getMessage(), '');
        }
        $_SESSION['pboot_lastsub'] = time();
        $this->notify('comment_send_mail', '【' . $this->siteName . '】您有新的文章评论信息，请注意查收！', '评论内容：' . View::e($comment) . '<br>');
        return array(true, $approved ? '评论提交成功！' : '评论提交成功,请等待管理员审核！', '-1');
    }

    /** get_user_os() */
    public static function userOs(): string
    {
        $agent = strtolower((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''));
        foreach (array('windows nt 5.0' => 'Windows 2000', 'windows nt 9' => 'Windows 9X', 'windows nt 5.1' => 'Windows XP', 'windows nt 5.2' => 'Windows 2003', 'windows nt 6.0' => 'Windows Vista', 'windows nt 6.1' => 'Windows 7', 'windows nt 6.2' => 'Windows 8', 'windows nt 6.3' => 'Windows 8.1', 'windows nt 10' => 'Windows 10', 'windows phone' => 'Windows Phone', 'android' => 'Android', 'iphone' => 'iPhone', 'ipad' => 'iPad', 'mac' => 'Mac', 'sunos' => 'Sun OS', 'bsd' => 'BSD', 'ubuntu' => 'Ubuntu', 'linux' => 'Linux', 'unix' => 'Unix') as $needle => $name) {
            if (strpos($agent, $needle)) {
                return $name;
            }
        }
        return 'Other';
    }

    /** get_user_bs() */
    public static function userBs(): string
    {
        $agent = strtolower((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''));
        foreach (array('micromessenger' => 'Weixin', 'qq' => 'QQ', 'weibo' => 'Weibo', 'alipayclient' => 'Alipay', 'trident/7.0' => 'IE11', 'trident/6.0' => 'IE10', 'trident/5.0' => 'IE9', 'trident/4.0' => 'IE8', 'msie 7.0' => 'IE7', 'msie 6.0' => 'IE6', 'edge' => 'Edge', 'firefox' => 'Firefox', 'chrome' => 'Chrome', 'android' => 'Chrome', 'safari' => 'Safari', 'mj12bot' => 'MJ12bot') as $needle => $name) {
            if (strpos($agent, $needle)) {
                return $name;
            }
        }
        return 'Other';
    }

    /** Pboot's 10-second session limit, plus FangdaysCMS's per-IP limit (FANGDAYS_RATE_* configurable). */
    private function tooSoon(string $scope): ?array
    {
        $identity = (string) ($_SERVER['REMOTE_ADDR'] ?? '') . '|' . (string) ($this->member['id'] ?? 'guest');
        if (time() - (int) ($_SESSION['pboot_lastsub'] ?? 0) < 10 || ! (new RateLimiter($this->root . '/var/rate-limits'))->configuredAllow('pboot-' . $scope, $identity, 5, 600)) {
            return array(false, '您提交太频繁了，请稍后再试！', '');
        }
        return null;
    }

    private function recordVisitor(string $table, int $id): void
    {
        $ip = filter_var($_SERVER['REMOTE_ADDR'] ?? '', FILTER_VALIDATE_IP) !== false ? (string) $_SERVER['REMOTE_ADDR'] : '';
        $this->pdo->prepare('UPDATE ' . $table . ' SET user_ip = ?, user_os = ?, user_bs = ? WHERE id = ?')->execute(array($ip, self::userOs(), self::userBs(), $id));
    }

    private function notify(string $switch, string $subject, string $body): void
    {
        if (! $this->config->on($switch) || $this->config->get('message_send_to') === '') {
            return;
        }
        $scheme = ! empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http';
        $body .= '<br>来自网站 ' . View::e($scheme . '://' . (string) ($_SERVER['HTTP_HOST'] ?? '')) . ' （' . date('Y-m-d H:i:s') . '）';
        try {
            SmtpMailer::sendMail($this->config->all(), $this->config->get('message_send_to'), $subject, $body);
        } catch (\RuntimeException $exception) {
            error_log('FangdaysCMS notification mail: ' . $exception->getMessage());
        }
    }

    private function loginUrl(): string
    {
        $back = (string) ($_SERVER['HTTP_REFERER'] ?? '');
        $login = $this->url?->home('member/login', null, $back !== '' ? 'backurl=' . urlencode($back) : '') ?? View::localizedPath('/member/login');
        return $login;
    }

    private static function field(array $post, string $name): string
    {
        return is_string($post[$name] ?? null) ? trim($post[$name]) : '';
    }

    private static function number(array $values, string $name): int
    {
        $value = $values[$name] ?? '';
        return is_string($value) && ctype_digit($value) && strlen($value) < 10 ? (int) $value : 0;
    }
}
