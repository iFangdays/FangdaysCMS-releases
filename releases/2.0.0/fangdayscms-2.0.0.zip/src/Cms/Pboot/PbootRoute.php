<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Pboot;

/**
 * Resolves Pboot front-end addresses (IndexController::_empty()) to categories and content,
 * for Pboot themes and for the built-in views alike.
 */
final class PbootRoute
{
    public function __construct(private readonly PbootData $data, private readonly PbootUrl $url)
    {
    }

    /** The Pboot path of a request for the configured URL mode, or null. */
    public function requestPath(string $path, string $queryString): ?string
    {
        $type = $this->url->type();
        if ($type === 1 && ($path === '/index.php' || str_starts_with($path, '/index.php/'))) {
            return substr($path, strlen('/index.php'));
        }
        if ($type === 2 && $path !== '/') {
            return $path;
        }
        if ($type === 3 && ($path === '/' || $path === '/index.php')) {
            $first = explode('&', $queryString, 2)[0];
            return $first === '' || str_contains($first, '=') ? null : rawurldecode($first);
        }
        return null;
    }

    /** @return array{0: string, 1: bool} the path without its suffix, and whether it had one */
    public function normalize(string $path): array
    {
        $suffix = false;
        $ext = preg_quote(substr($this->url->suffix(), 1), '/');
        if (preg_match('/^(.*)(_|\.)' . $ext . '$/', $path, $match)) {
            $path = $match[1];
            $suffix = true;
        } elseif (preg_match('/^[\w\-\/]+\/$/', $path)) {
            $path = trim($path, '/');
        }
        return array(trim($path, '/'), $suffix);
    }

    /** @return array{sort: array, page: ?int}|array{content: array}|null */
    public function resolve(string $path, bool $suffix): ?array
    {
        if (preg_match('/^[\w\-\/]+$/', $path) !== 1) {
            return null;
        }
        $break = preg_quote($this->url->breakChar(), '/');
        // An outlink only changes the navigation address: a list category still opens at its own URL, as in Pboot.
        $opens = static fn (array $sort): bool => $sort['kind'] !== 'link' || $sort['listtpl'] !== '';
        if (! $suffix && ($sort = $this->data->sort($path)) !== null && $opens($sort)) {
            return array('sort' => $sort, 'page' => null);
        }
        if (! $suffix && preg_match('/^([a-zA-Z0-9\-\/]+)' . $break . '([0-9]+)$/i', $path, $match) && ($sort = $this->data->sort($match[1])) !== null && $opens($sort)) {
            return array('sort' => $sort, 'page' => (int) $match[2]);
        }
        // Content: short path, or category (name or model_scode) followed by the content name/id.
        $content = null;
        $scode = null;
        $name = null;
        if ($this->url->contentPath()) {
            $content = $this->data->content($path);
            $name = $path;
        } else {
            $parent = dirname($path);
            $name = basename($path);
            if ($parent === '.' && $suffix) {
                // Content without a category has no parent segment.
                $content = $this->data->content($name);
                $scode = '';
            }
            while ($parent !== '.' && $parent !== '/') {
                if (($sort = $this->data->sort($parent)) !== null && ($content = $this->data->content($name)) !== null) {
                    $scode = $sort['scode'];
                    break;
                }
                if (preg_match('/^([a-zA-Z0-9\-\/]+)' . $break . '([0-9]+)$/i', $parent, $match) && $this->modelPath($match[1], $match[2])) {
                    $content = $this->data->content($name);
                    $scode = $match[2];
                    break;
                }
                $name = basename($parent) . '/' . $name;
                $parent = dirname($parent);
            }
        }
        if ($content !== null) {
            // Pboot rejects addresses through another category or by id when the content has a name.
            $valid = $suffix && ($scode === null || $scode === (string) $content['scode']) && $name === $content['filename'];
            return $valid ? array('content' => $content) : null;
        }
        // 模型名称_栏目ID[_页码] for categories reached through their model address.
        if (! $suffix && preg_match('/^([a-zA-Z0-9\-\/]+)(' . $break . '([0-9]+))?' . $break . '([0-9]+)$/i', $path, $match)) {
            $sortCode = $match[2] !== '' ? $match[3] : $match[4];
            if ($this->modelPath($match[1], $sortCode) && ($sort = $this->data->sort($sortCode)) !== null) {
                return array('sort' => $sort, 'page' => $match[2] !== '' ? (int) $match[4] : null);
            }
        }
        return null;
    }

    /**
     * The FangdaysCMS route the built-in views serve for a Pboot address, or null.
     * A page number in the address becomes the page query parameter those routes read.
     *
     * @param list<string> $reserved first path segments owned by FangdaysCMS routes
     */
    public function builtinPath(string $path, string $queryString, array $reserved): ?string
    {
        $pboot = $this->requestPath($path, $queryString);
        if ($pboot === null) {
            return null;
        }
        [$pboot, $suffix] = $this->normalize($pboot);
        if ($pboot === '' || in_array(strtolower(explode('/', $pboot)[0]), $reserved, true)) {
            return null;
        }
        $target = $this->resolve($pboot, $suffix);
        if ($target === null) {
            return null;
        }
        if (isset($target['content'])) {
            return '/post/' . rawurlencode((string) $target['content']['filename']);
        }
        if ($target['page'] !== null) {
            $_GET['page'] = (string) $target['page'];
        }
        return '/category/' . $target['sort']['url_path'];
    }

    /** checkModelUrlname(): the model address of a category ("list"/"about" stand for unnamed models). */
    private function modelPath(string $urlname, string $scode): bool
    {
        $sort = $this->data->sort($scode);
        return $sort !== null && $sort['scode'] === $scode && in_array($urlname, array($sort['urlname'], $sort['type'] === '1' ? 'about' : 'list'), true);
    }
}
