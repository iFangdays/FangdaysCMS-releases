<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use PDO;

/**
 * PbootCMS IndexController::checkPageLevel(): the member level a category or content asks for.
 * Levels are group codes. FangdaysCMS also allows non-numeric codes, which rank by group id.
 */
final class PageLevel
{
    public const TYPES = array(1 => '小于', 2 => '小于等于', 3 => '等于', 4 => '大于等于', 5 => '大于');
    public const DEFAULT_NOTE = '您的权限不足，无法浏览本页面！';

    public function __construct(private readonly PDO $pdo)
    {
    }

    /** @param array{gcode?: string, gtype?: int|string} $rule */
    public function denied(array $rule, ?array $member): bool
    {
        $gcode = (string) ($rule['gcode'] ?? '');
        if ($gcode === '') {
            return false;
        }
        $required = $this->rank($gcode);
        $level = $this->memberRank($member);
        return match ((int) ($rule['gtype'] ?? 4) ?: 4) {
            1 => $required <= $level,
            2 => $required < $level,
            3 => $required !== $level,
            5 => $required >= $level,
            default => $required > $level,
        };
    }

    /** The first rule that denies this member; its note is shown (Pboot checks the category, then the content). */
    public function firstDenied(array $rules, ?array $member): ?string
    {
        foreach ($rules as $rule) {
            if ($this->denied($rule, $member)) {
                $note = trim((string) ($rule['gnote'] ?? ''));
                return $note !== '' ? $note : self::DEFAULT_NOTE;
            }
        }
        return null;
    }

    private function rank(string $code): int
    {
        if (ctype_digit($code)) {
            return (int) $code;
        }
        $stmt = $this->pdo->prepare('SELECT id FROM member_groups WHERE code = ?');
        $stmt->execute(array($code));
        return (int) $stmt->fetchColumn();
    }

    private function memberRank(?array $member): int
    {
        if ($member === null) {
            return 0;
        }
        $code = (string) ($member['gcode'] ?? '');
        if ($code === '' && (int) ($member['group_id'] ?? 0) > 0) {
            $stmt = $this->pdo->prepare('SELECT code FROM member_groups WHERE id = ?');
            $stmt->execute(array((int) $member['group_id']));
            $code = (string) $stmt->fetchColumn();
        }
        return $code === '' ? 0 : $this->rank($code);
    }
}
