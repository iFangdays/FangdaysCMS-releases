<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;
use PDO;

final class CommentRepository
{
    public function __construct(private readonly PDO $pdo)
    {
    }

    public function create(int $postId, string $name, string $email, string $content, ?int $memberId = null): int
    {
        $name = trim($name);
        $email = trim($email);
        $content = trim($content);
        if ($name === '' || mb_strlen($name) > 100) {
            throw new InvalidArgumentException('评论昵称不能为空且不超过 100 个字。');
        }
        if ($email !== '' && (mb_strlen($email) > 191 || ! filter_var($email, FILTER_VALIDATE_EMAIL))) {
            throw new InvalidArgumentException('评论邮箱格式无效。');
        }
        if ($content === '' || mb_strlen($content) > 2000) {
            throw new InvalidArgumentException('评论内容不能为空且不超过 2000 个字。');
        }
        $stmt = $this->pdo->prepare('INSERT INTO post_comments (post_id, member_id, name, email, content, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        $now = time();
        $stmt->execute(array($postId, $memberId, $name, $email, $content, 'pending', $now, $now));
        return (int) $this->pdo->lastInsertId();
    }

    public function approvedForPost(int $postId, int $limit = 100, int $offset = 0): array
    {
        $stmt = $this->pdo->prepare('SELECT id, post_id, name, content, created_at FROM post_comments WHERE post_id = ? AND status = ? ORDER BY created_at ASC, id ASC LIMIT ? OFFSET ?');
        $stmt->bindValue(1, $postId, PDO::PARAM_INT);
        $stmt->bindValue(2, 'approved', PDO::PARAM_STR);
        $stmt->bindValue(3, max(1, min(100, $limit)), PDO::PARAM_INT);
        $stmt->bindValue(4, max(0, $offset), PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function countApprovedForPost(int $postId): int
    {
        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM post_comments WHERE post_id = ? AND status = ?');
        $stmt->execute(array($postId, 'approved'));
        return (int) $stmt->fetchColumn();
    }

    public function all(?string $status = null): array
    {
        $sql = 'SELECT c.*, p.title AS post_title, p.slug AS post_slug FROM post_comments c JOIN posts p ON p.id = c.post_id';
        $params = array();
        if ($status !== null && in_array($status, array('pending', 'approved', 'rejected'), true)) {
            $sql .= ' WHERE c.status = ?';
            $params[] = $status;
        }
        $sql .= ' ORDER BY c.created_at DESC, c.id DESC';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function forMember(int $memberId, int $limit = 100): array
    {
        $stmt = $this->pdo->prepare('SELECT c.*, p.title AS post_title, p.slug AS post_slug FROM post_comments c JOIN posts p ON p.id = c.post_id WHERE c.member_id = ? ORDER BY c.created_at DESC, c.id DESC LIMIT ?');
        $stmt->bindValue(1, $memberId, PDO::PARAM_INT);
        $stmt->bindValue(2, max(1, min(100, $limit)), PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function countForMember(int $memberId): int
    {
        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM post_comments WHERE member_id = ?');
        $stmt->execute(array($memberId));
        return (int) $stmt->fetchColumn();
    }

    public function updateStatus(int $id, string $status): void
    {        if (! in_array($status, array('pending', 'approved', 'rejected'), true)) {
            throw new InvalidArgumentException('评论状态无效。');
        }
        $stmt = $this->pdo->prepare('UPDATE post_comments SET status = ?, updated_at = ? WHERE id = ?');
        $stmt->execute(array($status, time(), $id));
        if ($stmt->rowCount() === 0) {
            throw new InvalidArgumentException('评论不存在。');
        }
    }

    public function delete(int $id): void
    {
        $stmt = $this->pdo->prepare('DELETE FROM post_comments WHERE id = ?');
        $stmt->execute(array($id));
        if ($stmt->rowCount() === 0) {
            throw new InvalidArgumentException('评论不存在。');
        }
    }
}
