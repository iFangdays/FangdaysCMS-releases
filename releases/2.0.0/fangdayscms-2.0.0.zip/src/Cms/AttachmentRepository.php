<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;
use PDO;
use RuntimeException;

final class AttachmentRepository
{
    private const EXTENSIONS = array('pdf', 'txt', 'zip', 'docx', 'xlsx', 'pptx');
    /** Files kept from an imported PbootCMS site; uploads stay limited to EXTENSIONS. */
    public const IMPORT_EXTENSIONS = array('pdf', 'txt', 'zip', 'docx', 'xlsx', 'pptx', 'doc', 'xls', 'ppt', 'rar', '7z', 'gz', 'csv', 'mp3', 'mp4');
    private const STORED_NAME = '/^[a-f0-9]{32}\.(pdf|txt|zip|docx|xlsx|pptx|doc|xls|ppt|rar|7z|gz|csv|mp3|mp4)$/D';

    public function __construct(private readonly PDO $pdo, private readonly string $storageRoot)
    {
    }

    public function forPost(int $postId): ?array
    {
        return $this->forOwner('post_attachment', 'post_id', $postId);
    }

    public function forCategory(int $categoryId): ?array
    {
        return $this->forOwner('category_attachment', 'category_id', $categoryId);
    }

    public function forPage(int $pageId): ?array
    {
        return $this->forOwner('page_attachment', 'page_id', $pageId);
    }

    public function modelFilesForPost(int $postId): array
    {
        return $this->modelFilesForOwner('post_field_attachments', 'post_id', $postId);
    }

    public function modelFilesForCategory(int $categoryId): array
    {
        return $this->modelFilesForOwner('category_field_attachments', 'category_id', $categoryId);
    }

    private function modelFilesForOwner(string $table, string $key, int $id): array
    {
        $stmt = $this->pdo->prepare('SELECT field_id, path, original_name, bytes FROM ' . $table . ' WHERE ' . $key . ' = ?');
        $stmt->execute(array($id));
        $files = array();
        foreach ($stmt as $file) {
            $files[(int) $file['field_id']] = $file;
        }
        return $files;
    }

    public function modelFilePathsForField(int $fieldId): array
    {
        $paths = array();
        foreach (array('post_field_attachments', 'category_field_attachments') as $table) {
            $stmt = $this->pdo->prepare('SELECT path FROM ' . $table . ' WHERE field_id = ?');
            $stmt->execute(array($fieldId));
            foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $path) {
                $paths[] = $path;
            }
        }
        return $paths;
    }

    public function replaceModelFile(bool $category, int $ownerId, int $fieldId, array $file): array
    {
        $this->validateUpload($file);
        $table = $category ? 'category_field_attachments' : 'post_field_attachments';
        $key = $category ? 'category_id' : 'post_id';
        $old = $this->modelFilesForOwner($table, $key, $ownerId)[$fieldId]['path'] ?? null;
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $path = bin2hex(random_bytes(16)) . '.' . $extension;
        $directory = $this->storageRoot . '/attachments';
        if (! is_dir($directory) && ! mkdir($directory, 0700, true) && ! is_dir($directory)) {
            throw new RuntimeException('无法创建附件目录。');
        }
        if (! move_uploaded_file($file['tmp_name'], $directory . '/' . $path)) {
            throw new RuntimeException('无法保存附件。');
        }
        if (function_exists('chmod')) {
            chmod($directory . '/' . $path, 0600);
        }
        $name = mb_substr(basename(str_replace('\\', '/', $file['name'])), 0, 150);
        $name = preg_replace('/[\x00-\x1f\x7f]/', '', $name) ?: 'attachment.' . $extension;
        try {
            $stmt = $this->pdo->prepare('DELETE FROM ' . $table . ' WHERE ' . $key . ' = ? AND field_id = ?');
            $stmt->execute(array($ownerId, $fieldId));
            $stmt = $this->pdo->prepare('INSERT INTO ' . $table . ' (' . $key . ', field_id, path, original_name, bytes) VALUES (?, ?, ?, ?, ?)');
            $stmt->execute(array($ownerId, $fieldId, $path, $name, $file['size']));
        } catch (\Throwable $error) {
            unlink($directory . '/' . $path);
            throw $error;
        }
        return array('old' => $old, 'new' => $path);
    }

    public function removeModelFile(bool $category, int $ownerId, int $fieldId): ?string
    {
        $table = $category ? 'category_field_attachments' : 'post_field_attachments';
        $key = $category ? 'category_id' : 'post_id';
        $old = $this->modelFilesForOwner($table, $key, $ownerId)[$fieldId]['path'] ?? null;
        $stmt = $this->pdo->prepare('DELETE FROM ' . $table . ' WHERE ' . $key . ' = ? AND field_id = ?');
        $stmt->execute(array($ownerId, $fieldId));
        return $old;
    }

    private function forOwner(string $table, string $key, int $id): ?array
    {
        $stmt = $this->pdo->prepare('SELECT path, original_name, bytes FROM ' . $table . ' WHERE ' . $key . ' = ?');
        $stmt->execute(array($id));
        return $stmt->fetch() ?: null;
    }

    public function validateUpload(array $file): void
    {
        if (! isset($file['error'], $file['tmp_name'], $file['size'], $file['name']) || $file['error'] !== UPLOAD_ERR_OK || ! is_string($file['tmp_name']) || ! is_string($file['name']) || ! is_int($file['size']) || $file['size'] < 1 || $file['size'] > 20 * 1024 * 1024 || ! is_uploaded_file($file['tmp_name'])) {
            throw new InvalidArgumentException('请选择小于 20 MB 的 PDF、TXT、ZIP 或 Office 附件。');
        }
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
        if (! in_array($extension, self::EXTENSIONS, true) || ! is_string($mime)) {
            throw new InvalidArgumentException('附件格式无效。');
        }
        $expected = match ($extension) {
            'pdf' => array('application/pdf'),
            'txt' => array('text/plain'),
            'docx' => array('application/zip', 'application/x-zip-compressed', 'application/octet-stream', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'),
            'xlsx' => array('application/zip', 'application/x-zip-compressed', 'application/octet-stream', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),
            'pptx' => array('application/zip', 'application/x-zip-compressed', 'application/octet-stream', 'application/vnd.openxmlformats-officedocument.presentationml.presentation'),
            default => array('application/zip', 'application/x-zip-compressed', 'application/octet-stream')
        };
        if (! in_array($mime, $expected, true)) {
            throw new InvalidArgumentException('附件内容与文件类型不符。');
        }
        if ($extension === 'pdf' && file_get_contents($file['tmp_name'], false, null, 0, 5) !== '%PDF-') {
            throw new InvalidArgumentException('PDF 文件无效。');
        }
        if (in_array($extension, array('zip', 'docx', 'xlsx', 'pptx'), true) && ! in_array(file_get_contents($file['tmp_name'], false, null, 0, 4), array("PK\x03\x04", "PK\x05\x06"), true)) {
            throw new InvalidArgumentException('压缩文件无效。');
        }
    }

    /** Stores a file of an imported site for one owner; the private store serves it through the usual routes. */
    public function importFile(string $table, string $key, int $id, string $source, string $name, ?int $fieldId = null): void
    {
        $extension = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if (! in_array($extension, self::IMPORT_EXTENSIONS, true) || ! is_file($source)) {
            throw new InvalidArgumentException('附件文件不可用。');
        }
        $path = bin2hex(random_bytes(16)) . '.' . $extension;
        $directory = $this->storageRoot . '/attachments';
        if (! is_dir($directory) && ! mkdir($directory, 0700, true) && ! is_dir($directory)) {
            throw new RuntimeException('无法创建附件目录。');
        }
        if (! copy($source, $directory . '/' . $path)) {
            throw new RuntimeException('无法保存附件。');
        }
        if (function_exists('chmod')) {
            chmod($directory . '/' . $path, 0600);
        }
        $bytes = (int) filesize($source);
        $name = mb_substr(basename(str_replace('\\', '/', $name)), 0, 150);
        if ($fieldId === null) {
            $this->pdo->prepare('INSERT INTO ' . $table . ' (' . $key . ', path, original_name, bytes) VALUES (?, ?, ?, ?)')->execute(array($id, $path, $name, $bytes));
        } else {
            $this->pdo->prepare('INSERT INTO ' . $table . ' (' . $key . ', field_id, path, original_name, bytes) VALUES (?, ?, ?, ?, ?)')->execute(array($id, $fieldId, $path, $name, $bytes));
        }
    }

    public function replace(int $postId, array $file): ?string
    {
        return $this->replaceForOwner('post_attachment', 'post_id', $postId, $file);
    }

    public function replaceForCategory(int $categoryId, array $file): ?string
    {
        return $this->replaceForOwner('category_attachment', 'category_id', $categoryId, $file);
    }

    public function replaceForPage(int $pageId, array $file): ?string
    {
        return $this->replaceForOwner('page_attachment', 'page_id', $pageId, $file);
    }

    private function replaceForOwner(string $table, string $key, int $id, array $file): ?string
    {
        $this->validateUpload($file);
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $path = bin2hex(random_bytes(16)) . '.' . $extension;
        $directory = $this->storageRoot . '/attachments';
        if (! is_dir($directory) && ! mkdir($directory, 0700, true) && ! is_dir($directory)) {
            throw new RuntimeException('无法创建附件目录。');
        }
        $destination = $directory . '/' . $path;
        if (! move_uploaded_file($file['tmp_name'], $destination)) {
            throw new RuntimeException('无法保存附件。');
        }
        if (function_exists('chmod')) {
            chmod($destination, 0600);
        }
        $old = $this->forOwner($table, $key, $id);
        try {
            $stmt = $this->pdo->prepare('DELETE FROM ' . $table . ' WHERE ' . $key . ' = ?');
            $stmt->execute(array($id));
            $name = mb_substr(basename(str_replace('\\', '/', $file['name'])), 0, 150);
            $name = preg_replace('/[\x00-\x1f\x7f]/', '', $name) ?: 'attachment.' . $extension;
            $stmt = $this->pdo->prepare('INSERT INTO ' . $table . ' (' . $key . ', path, original_name, bytes) VALUES (?, ?, ?, ?)');
            $stmt->execute(array($id, $path, $name, $file['size']));
        } catch (\Throwable $error) {
            unlink($destination);
            throw $error;
        }
        return $old['path'] ?? null;
    }

    public function remove(int $postId): ?string
    {
        return $this->removeForOwner('post_attachment', 'post_id', $postId);
    }

    public function removeForCategory(int $categoryId): ?string
    {
        return $this->removeForOwner('category_attachment', 'category_id', $categoryId);
    }

    public function removeForPage(int $pageId): ?string
    {
        return $this->removeForOwner('page_attachment', 'page_id', $pageId);
    }

    private function removeForOwner(string $table, string $key, int $id): ?string
    {
        $old = $this->forOwner($table, $key, $id);
        $stmt = $this->pdo->prepare('DELETE FROM ' . $table . ' WHERE ' . $key . ' = ?');
        $stmt->execute(array($id));
        return $old['path'] ?? null;
    }

    public function deleteFile(?string $path): void
    {
        if ($path !== null && preg_match(self::STORED_NAME, $path)) {
            $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM post_attachment WHERE path = ?');
            $stmt->execute(array($path));
            if ((int) $stmt->fetchColumn() > 0) {
                return;
            }
            $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM category_attachment WHERE path = ?');
            $stmt->execute(array($path));
            if ((int) $stmt->fetchColumn() > 0) {
                return;
            }
            $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM page_attachment WHERE path = ?');
            $stmt->execute(array($path));
            if ((int) $stmt->fetchColumn() > 0) {
                return;
            }
            foreach (array('post_field_attachments', 'category_field_attachments') as $table) {
                $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM ' . $table . ' WHERE path = ?');
                $stmt->execute(array($path));
                if ((int) $stmt->fetchColumn() > 0) {
                    return;
                }
            }
            $full = $this->storageRoot . '/attachments/' . $path;
            if (is_file($full)) {
                unlink($full);
            }
        }
    }

    public function send(array $attachment): void
    {
        $path = $attachment['path'];
        if (! is_string($path) || ! preg_match(self::STORED_NAME, $path)) {
            throw new RuntimeException('附件不存在。');
        }
        $full = $this->storageRoot . '/attachments/' . $path;
        if (! is_file($full)) {
            throw new RuntimeException('附件不存在。');
        }
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="download.' . pathinfo($path, PATHINFO_EXTENSION) . '"; filename*=UTF-8\'\'' . rawurlencode($attachment['original_name']));
        header('Content-Length: ' . filesize($full));
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: private, no-store');
        readfile($full);
    }
}
