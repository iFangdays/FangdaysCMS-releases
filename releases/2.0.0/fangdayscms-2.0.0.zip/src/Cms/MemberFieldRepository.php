<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;
use PDO;

final class MemberFieldRepository
{
    public function __construct(private readonly PDO $pdo) {}
    public function all(bool $activeOnly=false): array { $sql='SELECT * FROM member_fields'; if($activeOnly)$sql.=" WHERE status='active'"; $sql.=' ORDER BY sorting ASC,id ASC'; return $this->pdo->query($sql)->fetchAll(); }
    public function byId(int $id): ?array { $s=$this->pdo->prepare('SELECT * FROM member_fields WHERE id=?');$s->execute([$id]);return $s->fetch()?:null; }
    public function save(?int $id,array $input): int { $name=trim((string)($input['name']??''));$description=trim((string)($input['description']??''));$length=max(1,min(1000,(int)($input['length']??20)));$required=!empty($input['required'])?1:0;$sorting=(int)($input['sorting']??255);$status=($input['status']??'active')==='active'?'active':'disabled';if(!preg_match('/^[A-Za-z][A-Za-z0-9_]*$/',$name)||str_starts_with(strtolower($name),'id')||$description==='')throw new InvalidArgumentException('字段标识或描述无效。');$s=$this->pdo->prepare('SELECT COUNT(*) FROM member_fields WHERE name=? AND id<>?');$s->execute([$name,$id??0]);if((int)$s->fetchColumn())throw new InvalidArgumentException('字段标识已存在。');if($id===null){$s=$this->pdo->prepare('INSERT INTO member_fields(name,length,required,description,sorting,status) VALUES(?,?,?,?,?,?)');$s->execute([$name,$length,$required,$description,$sorting,$status]);return(int)$this->pdo->lastInsertId();}$s=$this->pdo->prepare('UPDATE member_fields SET required=?,description=?,sorting=?,status=?,length=? WHERE id=?');$s->execute([$required,$description,$sorting,$status,$length,$id]);return$id; }
    public function delete(int $id): void { $s=$this->pdo->prepare('DELETE FROM member_fields WHERE id=?');$s->execute([$id]);if($s->rowCount()===0)throw new InvalidArgumentException('会员字段不存在。'); }
    public function values(int $memberId): array { $s=$this->pdo->prepare('SELECT f.*,COALESCE(v.value,\'\') AS value FROM member_fields f LEFT JOIN member_field_values v ON v.field_id=f.id AND v.member_id=? WHERE f.status=\'active\' ORDER BY f.sorting ASC,f.id ASC');$s->execute([$memberId]);return$s->fetchAll(); }
    public function saveValues(int $memberId,array $raw): void { foreach($this->all(true) as $f){$v=$raw[$f['name']]??'';if(is_array($v))$v=implode(',',array_map('strval',$v));$v=trim((string)$v);if((int)$f['required']&&$v==='')throw new InvalidArgumentException($f['description'].'不能为空。');if(mb_strlen($v)>(int)$f['length'])throw new InvalidArgumentException($f['description'].'长度超限。');$s=$this->pdo->prepare('SELECT COUNT(*) FROM member_field_values WHERE member_id=? AND field_id=?');$s->execute([$memberId,$f['id']]);if((int)$s->fetchColumn())$s=$this->pdo->prepare('UPDATE member_field_values SET value=? WHERE member_id=? AND field_id=?');else$s=$this->pdo->prepare('INSERT INTO member_field_values(value,member_id,field_id) VALUES(?,?,?)');$s->execute([$v,$memberId,$f['id']]);} }
}
