<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use FangdaysCMS\Cms\Geo\GeoHead;
use FangdaysCMS\Cms\Geo\GeoUrl;
use RuntimeException;

final class View
{
    private static string $localePrefix = '';
    private static ?GeoUrl $addresses = null;

    public static function setLocalePrefix(string $prefix): void
    {
        $prefix = trim($prefix);
        self::$localePrefix = preg_match('#^/[a-z0-9]+(?:-[a-z0-9]+)*$#D', $prefix) === 1 ? $prefix : '';
    }

    /** Public addresses for the configured Pboot URL mode; null keeps /category/... and /post/... links. */
    public static function setAddresses(?GeoUrl $addresses): void
    {
        self::$addresses = $addresses;
    }

    public static function localizedPath(string $path): string
    {
        return self::localPath($path);
    }

    private static function localPath(string $path): string
    {
        if (self::$localePrefix === '' || $path === '' || $path[0] !== '/' || str_starts_with($path, self::$localePrefix . '/')) {
            return $path;
        }
        return self::$localePrefix . $path;
    }

    public static function render(string $template, array $data = array(), int $status = 200): void
    {
        http_response_code($status);
        header('Content-Type: text/html; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Referrer-Policy: same-origin');
        header('X-Frame-Options: DENY');
        $root = dirname(__DIR__, 2);
        $pageTitle = $data['page_title'] ?? 'FangdaysCMS';
        $siteName = $data['site_name'] ?? 'FangdaysCMS';
        $admin = $data['admin'] ?? false;
        $flash = $_SESSION['flash'] ?? null;
        unset($_SESSION['flash']);
        extract($data, EXTR_SKIP);
        if (str_starts_with($template, 'site/')) {
            GeoHead::markView($template, $data);
        }
        ob_start();
        require $root . '/views/' . $template . '.php';
        $content = ob_get_clean();
        require $root . (str_starts_with($template, 'site/') ? '/views/site/layout.php' : '/views/layout.php');
    }

    public static function renderSiteHtml(string $html, array $data = array(), int $status = 200): void
    {
        if (preg_match('/^\s*(?:<!doctype\s+html|<html\b)/i', $html)) {
            http_response_code($status);
            header('Content-Type: text/html; charset=utf-8');
            header('X-Content-Type-Options: nosniff');
            header('Referrer-Policy: same-origin');
            header('X-Frame-Options: DENY');
            echo GeoHead::inject($html);
            return;
        }
        $data['html'] = $html;
        self::render('site/template', $data, $status);
    }

    /** Public asset address that changes with the file, so browsers do not keep an old copy after an update. */
    public static function asset(string $path): string
    {
        $modified = @filemtime(dirname(__DIR__, 2) . '/public' . $path);
        return $modified === false ? $path : $path . '?v=' . $modified;
    }

    /** FangdaysCMS mark: a page's top bar and side bar forming an F around its content block. */
    public static function brandMark(): string
    {
        return '<svg class="admin-brand-mark" viewBox="0 0 32 32" aria-hidden="true"><path class="brand-frame" d="M4 4h24v6H11v18H4z"/><path class="brand-block" d="M13.500 13h11v6h-11z"/></svg>';
    }

    public static function e($value): string
    {
        return htmlspecialchars(is_scalar($value) ? (string) $value : '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    public static function pbootFragment(string $name, OperationsRepository $operations, array $labels = array(), array $company = array()): string
    {
        return OperationTags::html(self::fragmentSource($name), $operations, $labels, $company);
    }

    public static function pbootFilterFragment(string $name, array $fields, string $path, array $params, string $fieldName): string
    {
        if (! preg_match('/^ext_[A-Za-z][A-Za-z0-9_]{0,58}$/D', $fieldName)) {
            throw new RuntimeException('筛选字段名称无效。');
        }
        $source = str_replace('{{field}}', $fieldName, self::fragmentSource($name));
        return ContentFilterTags::html($source, $fields, $path, $params);
    }

    private static function fragmentSource(string $name): string
    {
        if (! preg_match('/^[a-z][a-z0-9-]*$/D', $name)) {
            throw new RuntimeException('模板片段名称无效。');
        }
        $source = file_get_contents(dirname(__DIR__, 2) . '/templates/default/' . $name . '.html');
        if ($source === false) {
            throw new RuntimeException('模板片段无法读取。');
        }
        return TemplateTags::normalize($source);
    }

    public static function csrf(): string
    {
        return '<input type="hidden" name="_csrf" value="' . self::e(Auth::csrfToken()) . '">';
    }

    public static function categoryLink(array $category): string
    {
        if (($category['type'] ?? 'list') === 'link' && ($category['outlink'] ?? '') !== '') {
            return (string) $category['outlink'];
        }
        return self::$addresses !== null && isset($category['id'])
            ? self::$addresses->categoryPath($category)
            : self::localPath('/category/' . (($category['url_path'] ?? '') !== '' ? (string) $category['url_path'] : rawurlencode((string) $category['slug'])));
    }

    public static function postLink(array $post): string
    {
        if (($post['outlink'] ?? '') !== '') {
            return (string) $post['outlink'];
        }
        return self::$addresses !== null && isset($post['id']) && array_key_exists('category_id', $post)
            ? self::$addresses->postPath($post)
            : self::localPath('/post/' . rawurlencode((string) $post['slug']));
    }

    /** The form that adminSwitch() buttons outside any form post with. */
    /** 翻译语言 row: the English fields of a content form only open for a site that has that region. */
    public static function adminEnglishSwitch(bool $enabled, bool $filled): string
    {
        if (! $enabled) {
            return '';
        }
        return '<div class="layui-form-item is-wide"><label class="layui-form-label" for="edit-locale">翻译语言</label><div class="layui-input-block"><select class="layui-input" id="edit-locale" name="edit_locale"><option value="">不填写翻译</option><option value="en-US"' . ($filled ? ' selected' : '') . '>English (en-US)</option></select></div></div>';
    }

    public static function adminEnglishFields(bool $enabled): string
    {
        return $enabled ? 'data-show-when="edit_locale=en-US"' : 'hidden';
    }

    public static function adminSwitchForm(string $id = 'list-switch'): string
    {
        return '<form id="' . self::e($id) . '" method="post">' . self::csrf() . '</form>';
    }

    /** PbootCMS admin tab bar: list of [label, href|null, active]; a null href is the current page. */
    public static function adminTabs(array $tabs): string
    {
        $html = '<ul class="layui-tab-title">';
        foreach ($tabs as [$label, $href, $active]) {
            $text = $href === null || $active ? self::e($label) : '<a href="' . self::e(self::localPath($href)) . '">' . self::e($label) . '</a>';
            $html .= '<li' . ($active ? ' class="layui-this"' : '') . '>' . $text . '</li>';
        }
        return $html . '</ul>';
    }

    /** In-page tab titles for a [data-tabs] container whose items are [data-pane] (switched by the admin layout script). */
    public static function adminPaneTabs(array $labels, int $active = 0): string
    {
        $html = '<ul class="layui-tab-title" role="tablist">';
        foreach (array_values($labels) as $index => $label) {
            if (is_array($label)) {
                $html .= '<li><a href="' . self::e(self::localPath($label[1])) . '">' . self::e($label[0]) . '</a></li>';
                continue;
            }
            $html .= '<li role="tab" data-tab="' . $index . '" tabindex="' . ($index === $active ? '0' : '-1') . '" aria-selected="' . ($index === $active ? 'true' : 'false') . '"' . ($index === $active ? ' class="layui-this"' : '') . '>' . self::e($label) . '</li>';
        }
        return $html . '</ul>';
    }

    /** PbootCMS admin {$pagebar}: 共N条 当前x/y页 首页 前一页 1 2 后一页 尾页. */
    public static function adminPager(int $total, int $pageSize, int $page, string $path, array $params = array()): string
    {
        $params = array_filter($params, static fn ($value): bool => $value !== '' && $value !== null);
        unset($params['page']);
        $path = self::localPath($path);
        $paging = new Pboot\Paging(static fn (int $number): string => $path . '?' . http_build_query($number > 1 ? $params + array('page' => $number) : $params));
        $paging->setup($total, $pageSize, $page);
        return '<div class="page">' . $paging->vars()['bar'] . '</div>';
    }

    /**
     * PbootCMS list switch (fa-toggle-on/off). Pboot uses a GET link; here it is a submit button that posts
     * the surrounding list form, or the form named by $form, (which carries the CSRF token) to $action with switch=field:value.
     */
    public static function adminSwitch(string $action, string $field, bool $on, string $form = ''): string
    {
        return '<button type="submit"' . ($form !== '' ? ' form="' . self::e($form) . '"' : '') . ' class="switch" formaction="' . self::e(self::localPath($action)) . '" formnovalidate name="switch" value="' . self::e($field) . ':' . ($on ? '0' : '1') . '" title="' . ($on ? '点击关闭' : '点击开启') . '">'
            . '<i class="fa ' . ($on ? 'fa-toggle-on' : 'fa-toggle-off') . '" aria-hidden="true"></i><span class="sr-only">' . ($on ? '已开启，点击关闭' : '已关闭，点击开启') . '</span></button>';
    }

    public static function pagination(int $page, int $totalPages, string $path, array $params = array(), string $locale = 'zh-CN'): string
    {
        if ($totalPages <= 1) {
            return '';
        }
        $path = self::localPath($path);
        $previous = $locale === 'en-US' ? 'Previous' : '上一页';
        $next = $locale === 'en-US' ? 'Next' : '下一页';
        $pageLabel = $locale === 'en-US' ? 'Page ' : '第 ';
        $pageSeparator = $locale === 'en-US' ? ' of ' : ' / ';
        $link = static fn (int $number): string => self::e($path . (str_contains($path, '?') ? '&' : '?') . http_build_query(array_merge($params, array('page' => $number))));
        $html = '<nav class="pager" aria-label="' . self::e($locale === 'en-US' ? 'Pagination' : '分页') . '">';
        if ($page > 1) {
            $html .= '<a href="' . $link($page - 1) . '">' . $previous . '</a>';
        }
        $html .= '<span>' . $pageLabel . min($page, $totalPages) . $pageSeparator . $totalPages . ($locale === 'en-US' ? '' : ' 页') . '</span>';
        if ($page < $totalPages) {
            $html .= '<a href="' . $link($page + 1) . '">' . $next . '</a>';
        }
        return $html . '</nav>';
    }
}
