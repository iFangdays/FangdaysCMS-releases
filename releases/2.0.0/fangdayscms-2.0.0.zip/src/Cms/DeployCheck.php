<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

/**
 * Requests the live site the way a visitor would and reports whether files
 * outside public/ can be downloaded or executed, and whether scripts run in
 * the upload folder. Meant for virtual hosts where the site root may be the
 * project directory (see .htaccess, web.config and deploy/nginx.conf).
 */
final class DeployCheck
{
    /** Project files that must never be served: label, file, and the URL when it differs from the file path. */
    private const PROBES = array(
        array('数据库文件', 'var/content.sqlite'),
        array('授权码文件', 'var/license.code'),
        array('站点配置', 'config/app.php'),
        array('程序代码', 'src/Cms/App.php'),
        array('自动加载入口', 'autoload.php'),
        array('依赖声明', 'composer.json'),
        array('后台视图', 'views/layout.php'),
        array('主题源文件', 'templates/themes/default/html/index.html'),
        array('命令行工具', 'bin/license.php'),
        array('页面缓存', 'storage/cache/pages/.version'),
        array('Git 仓库', '.git/HEAD'),
        array('隐藏文件', 'public/uploads/.htaccess', '/uploads/.htaccess'),
    );
    private const MAX_BODY = 65536;

    /** First release of each PHP branch with the fixes for CVE-2026-109618 and CVE-2026-109619 (php2shell). */
    private const PHP_FIXED = array('8.2' => '8.2.35', '8.3' => '8.3.36', '8.4' => '8.4.27', '8.5' => '8.5.12');

    /**
     * Known interpreter vulnerabilities the running PHP may have. Application code cannot fix these;
     * hosts such as cPanel or CloudLinux sometimes patch without changing the version number.
     * @return list<string>
     */
    public static function phpAdvisories(string $version = PHP_VERSION, ?bool $uploadProgress = null): array
    {
        $warnings = array();
        $branch = implode('.', array_slice(explode('.', $version), 0, 2));
        if (version_compare($branch, '8.2', '<')) {
            $warnings[] = 'PHP ' . $version . ' 已停止安全更新，请升级到 PHP 8.2 或更高版本。';
        } elseif (isset(self::PHP_FIXED[$branch]) && version_compare($version, self::PHP_FIXED[$branch], '<')) {
            $warnings[] = 'PHP ' . $version . ' 存在 php2shell 远程代码执行漏洞（CVE-2026-109618、CVE-2026-109619），请升级到 ' . self::PHP_FIXED[$branch] . ' 或更高版本；主机商若已打补丁但未改版本号，请向其确认。';
        }
        if ($uploadProgress ?? (bool) ini_get('session.upload_progress.enabled')) {
            $warnings[] = 'PHP 开启了 session.upload_progress（CVE-2026-115560 尚无官方补丁）。本系统不使用该功能，建议在 php.ini 或面板中设为 Off。';
        }
        return $warnings;
    }

    /** Where the web server points: standard (public/), compatibility (project root) or unknown. */
    public static function mode(string $root): string
    {
        $documentRoot = realpath((string) ($_SERVER['DOCUMENT_ROOT'] ?? ''));
        if ($documentRoot === false) {
            return '未知';
        }
        if ($documentRoot === realpath($root . '/public')) {
            return '标准模式（运行目录为 public）';
        }
        return $documentRoot === realpath($root) ? '兼容模式（运行目录为程序根目录）' : '未知';
    }

    /** @return list<array{label: string, path: string, status: string, ok: bool, detail: string}> */
    public static function run(string $baseUrl, string $root): array
    {
        $baseUrl = rtrim($baseUrl, '/');
        $results = array();

        [$code, $body, $error] = self::fetch($baseUrl . '/');
        $results[] = self::row('首页与 URL 重写', '/', $code, $error, match (true) {
            $error !== null => array(false, '无法访问站点：' . $error),
            str_contains($body, 'FD-REWRITE-MISSING') => array(false, 'URL 重写未生效，程序根目录的 index.php 被直接访问。'),
            $code === null || ($code >= 400 && $code !== 503) => array(false, '首页无法正常访问，请检查运行目录与 URL 重写。'),
            default => array(true, '站点由 public/ 提供服务。'),
        });
        // How the site answers an address that does not exist; protected files must not answer better.
        [$missingCode] = self::fetch($baseUrl . '/fd-check-missing-' . bin2hex(random_bytes(6)));
        $missingIsSuccess = $missingCode !== null && $missingCode >= 200 && $missingCode < 300;

        foreach (self::PROBES as $probe) {
            [$label, $file] = $probe;
            $path = $probe[2] ?? '/' . $file;
            if (! is_file($root . '/' . $file)) {
                $results[] = array('label' => $label, 'path' => $path, 'status' => '-', 'ok' => true, 'detail' => '未部署此文件，跳过。');
                continue;
            }
            [$code, $body, $error] = self::fetch($baseUrl . $path);
            $results[] = self::row($label, $path, $code, $error, self::judge($root . '/' . $file, $code, $body, $error, $missingIsSuccess));
        }

        $results[] = self::uploadProbe($baseUrl, $root);
        return $results;
    }

    /** @return array{0: bool, 1: string} */
    private static function judge(string $file, ?int $code, string $body, ?string $error, bool $missingIsSuccess): array
    {
        if ($error !== null) {
            return array(false, '无法完成请求：' . $error);
        }
        if ($code === null || $code < 200 || $code >= 300) {
            return array(true, '已拒绝访问。');
        }
        $head = (string) file_get_contents($file, false, null, 0, 64);
        if ($head !== '' && str_contains($body, $head)) {
            return array(false, '文件内容可以被直接下载。');
        }
        if (str_ends_with($file, '.php') && (trim($body) === '' || ! $missingIsSuccess)) {
            return array(false, '程序文件可以被直接执行。');
        }
        if (! $missingIsSuccess) {
            return array(false, '文件可以被直接访问。');
        }
        // The site answers every address with 2xx, so this is its own page, not the file.
        return array(true, '由站点入口处理，文件本身不可访问。');
    }

    private static function uploadProbe(string $baseUrl, string $root): array
    {
        $directory = $root . '/public/uploads';
        $name = 'fd-check-' . bin2hex(random_bytes(8)) . '.php';
        $token = bin2hex(random_bytes(8));
        $file = $directory . '/' . $name;
        if (! is_dir($directory) || @file_put_contents($file, "<?php echo 'FD-EXEC-' . '" . $token . "';\n") === false) {
            return array('label' => '上传目录脚本执行', 'path' => '/uploads/', 'status' => '-', 'ok' => true, 'detail' => '上传目录不可写，跳过。');
        }
        try {
            [$code, $body, $error] = self::fetch($baseUrl . '/uploads/' . $name);
        } finally {
            @unlink($file);
        }
        return self::row('上传目录脚本执行', '/uploads/*.php', $code, $error, match (true) {
            $error !== null => array(false, '无法完成请求：' . $error),
            str_contains($body, 'FD-EXEC-' . $token) => array(false, '上传目录中的 PHP 文件会被执行。'),
            default => array(true, '上传目录不会执行 PHP。'),
        });
    }

    private static function row(string $label, string $path, ?int $code, ?string $error, array $verdict): array
    {
        return array('label' => $label, 'path' => $path, 'status' => $code === null ? '-' : (string) $code, 'ok' => $verdict[0], 'detail' => $verdict[1]);
    }

    /** @return array{0: ?int, 1: string, 2: ?string} status, body, error */
    private static function fetch(string $url): array
    {
        if (function_exists('curl_init')) {
            $handle = curl_init($url);
            curl_setopt_array($handle, array(
                CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => false, CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_TIMEOUT => 10,
                CURLOPT_USERAGENT => 'FangdaysCMS-deploy-check', CURLOPT_RANGE => '0-' . (self::MAX_BODY - 1),
            ));
            $body = curl_exec($handle);
            $code = (int) curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
            $error = $body === false ? curl_error($handle) : null;
            curl_close($handle);
            return array($code === 0 ? null : $code, is_string($body) ? substr($body, 0, self::MAX_BODY) : '', $error);
        }
        $context = stream_context_create(array('http' => array('ignore_errors' => true, 'follow_location' => 0, 'timeout' => 10, 'user_agent' => 'FangdaysCMS-deploy-check')));
        $stream = @fopen($url, 'rb', false, $context);
        if ($stream === false) {
            return array(null, '', '连接失败');
        }
        $body = (string) stream_get_contents($stream, self::MAX_BODY);
        $meta = stream_get_meta_data($stream);
        fclose($stream);
        $status = null;
        foreach ($meta['wrapper_data'] ?? array() as $header) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', (string) $header, $match)) {
                $status = (int) $match[1];
            }
        }
        return array($status, $body, null);
    }
}
