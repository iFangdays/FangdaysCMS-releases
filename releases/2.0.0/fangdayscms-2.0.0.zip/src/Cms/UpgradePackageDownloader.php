<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;
use RuntimeException;

/** Streams a verified upgrade package into an atomic staging file. */
final class UpgradePackageDownloader
{
    private const MAX_BYTES = 52428800;
    private const MAX_REDIRECTS = 5;

    /** @param callable(int,int):void|null $progress */
    public static function download(string $url, array $manifest, string $destination, ?callable $progress = null): array
    {
        $current = trim($url);
        for ($hop = 0; $hop <= self::MAX_REDIRECTS; $hop++) {
            UpgradeManifest::assertHttpsUrl($current, '升级包地址必须使用 HTTPS。');
            $stream = @fopen($current, 'rb', false, stream_context_create(array(
                'http' => array(
                    'method' => 'GET',
                    'timeout' => 60,
                    'follow_location' => 0,
                    'ignore_errors' => true,
                    'header' => "User-Agent: FangdaysCMS/2.0.0\r\nAccept: application/zip, application/octet-stream, */*\r\n",
                ),
                'ssl' => array('verify_peer' => true, 'verify_peer_name' => true),
            )));
            $meta = is_resource($stream) ? stream_get_meta_data($stream) : array();
            $headers = is_array($meta['wrapper_data'] ?? null) ? $meta['wrapper_data'] : array();
            $status = UpgradeManifest::statusCode($headers);
            if ($status >= 300 && $status < 400) {
                if (is_resource($stream)) {
                    fclose($stream);
                }
                $location = UpgradeManifest::headerValue($headers, 'location');
                if ($location === null || $hop === self::MAX_REDIRECTS) {
                    throw new RuntimeException('升级包重定向无效或次数过多。');
                }
                $current = UpgradeManifest::resolveRedirect($current, $location);
                continue;
            }
            if ($stream === false || $status < 200 || $status >= 300) {
                if (is_resource($stream)) {
                    fclose($stream);
                }
                throw new RuntimeException('升级包服务器响应失败。');
            }
            try {
                return self::stage($stream, $manifest, $destination, $progress);
            } finally {
                fclose($stream);
            }
        }
        throw new RuntimeException('升级包重定向次数过多。');
    }

    /** @param resource $stream @param callable(int,int):void|null $progress */
    public static function stage($stream, array $manifest, string $destination, ?callable $progress = null): array
    {
        if (! is_resource($stream) || ! is_int($manifest['size'] ?? null) || $manifest['size'] < 1 || $manifest['size'] > self::MAX_BYTES || ! is_string($manifest['sha256'] ?? null) || ! preg_match('/^[a-f0-9]{64}$/D', $manifest['sha256'])) {
            throw new InvalidArgumentException('升级包元数据无效。');
        }
        $parent = dirname($destination);
        if (is_link($parent)) {
            throw new RuntimeException('升级包目录不能是符号链接。');
        }
        if (! is_dir($parent) && ! mkdir($parent, 0700, true) && ! is_dir($parent)) {
            throw new RuntimeException('无法创建升级包目录。');
        }
        if (is_link($destination)) {
            throw new RuntimeException('升级包目标不能是符号链接。');
        }
        $temp = $destination . '.part-' . bin2hex(random_bytes(8));
        $output = @fopen($temp, 'xb');
        if ($output === false) {
            throw new RuntimeException('无法创建升级包临时文件。');
        }
        $hash = hash_init('sha256');
        $bytes = 0;
        try {
            while (! feof($stream)) {
                $chunk = fread($stream, 8192);
                if ($chunk === false) {
                    throw new RuntimeException('读取升级包失败。');
                }
                if ($chunk === '') {
                    continue;
                }
                $bytes += strlen($chunk);
                if ($bytes > self::MAX_BYTES || $bytes > $manifest['size']) {
                    throw new RuntimeException('升级包超过声明大小限制。');
                }
                if (fwrite($output, $chunk) !== strlen($chunk)) {
                    throw new RuntimeException('写入升级包失败。');
                }
                hash_update($hash, $chunk);
                if ($progress !== null) {
                    $progress($bytes, $manifest['size']);
                }
            }
            if ($bytes !== $manifest['size'] || hash_final($hash) !== $manifest['sha256']) {
                throw new RuntimeException('升级包大小或 SHA-256 校验失败。');
            }
            if (! fflush($output) || ! fclose($output)) {
                $output = null;
                throw new RuntimeException('升级包落盘失败。');
            }
            $output = null;
            if (! @rename($temp, $destination)) {
                throw new RuntimeException('升级包原子替换失败。');
            }
            return array('path' => $destination, 'bytes' => $bytes, 'sha256' => $manifest['sha256']);
        } finally {
            if (is_resource($output)) {
                fclose($output);
            }
            if (is_file($temp)) {
                @unlink($temp);
            }
        }
    }
}
