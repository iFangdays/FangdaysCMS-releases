<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use FangdaysCMS\Cms\Pboot\PbootConfig;
use GdImage;

/** Ports of PbootCMS core/function/file.php watermark_img(), resize_img() and cut_img(). */
final class ImageTools
{
    /** Stamp the 图片水印 configuration onto an uploaded image in place; false when nothing was done. */
    public static function watermark(string $file, PbootConfig $config, string $publicRoot): bool
    {
        if (! $config->on('watermark_open') || ($source = self::open($file)) === null) {
            return false;
        }
        [$image, $type] = $source;
        $width1 = imagesx($image);
        $height1 = imagesy($image);
        $pic = $config->get('watermark_pic');
        if ($pic !== '') {
            $mark = self::open(self::inside($publicRoot, $pic) ?? '');
            if ($mark === null) {
                return false;
            }
            $stamp = $mark[0];
        } else {
            $font = self::inside($publicRoot, $config->get('watermark_text_font'));
            $text = $config->get('watermark_text') !== '' ? $config->get('watermark_text') : 'FangdaysCMS';
            if ($font === null || ! function_exists('imagettftext')) {
                return false; // Pboot also skips text watermarks without an uploaded font.
            }
            $size = max(6, (int) $config->get('watermark_text_size'));
            $colors = array_map('intval', explode(',', $config->get('watermark_text_color')));
            $stamp = imagecreatetruecolor(mb_strlen($text, 'UTF-8') * ($size + 10) + 20, $size + 10);
            $white = (int) imagecolorallocate($stamp, 255, 255, 255);
            imagefill($stamp, 0, 0, $white);
            imagecolortransparent($stamp, $white);
            imagettftext($stamp, $size, 0, 5, $size + 5, (int) imagecolorallocate($stamp, $colors[0] ?? 100, $colors[1] ?? 100, $colors[2] ?? 100), $font, $text);
        }
        $width2 = imagesx($stamp);
        $height2 = imagesy($stamp);
        if ($width1 < $width2 * 3 || $height1 < $height2) {
            $scale = min(($width1 / 3) / $width2, ($height1 / 2) / $height2);
            $newWidth = (int) floor($scale * $width2);
            $newHeight = (int) floor($scale * $height2);
        } else {
            $newWidth = $width2;
            $newHeight = $height2;
        }
        [$x, $y] = match ($config->get('watermark_position')) {
            '1' => array(15, 15),
            '2' => array($width1 - $newWidth - 15, 20),
            '3' => array(20, $height1 - $newHeight - 15),
            '5' => array(intdiv($width1 - $newWidth, 2), intdiv($height1 - $newHeight, 2)),
            default => array($width1 - $newWidth - 15, $height1 - $newHeight - 15),
        };
        imagealphablending($image, true);
        imagecopyresampled($image, $stamp, (int) $x, (int) $y - 10, 0, 0, max(1, $newWidth), max(1, $newHeight), $width2, $height2);
        return self::save($image, $type, $file);
    }

    /** resize_img(): fit inside max width/height (copies the file when it is already small enough). */
    public static function resize(string $source, string $target, ?int $maxWidth, ?int $maxHeight): bool
    {
        if (($opened = self::open($source)) === null) {
            return false;
        }
        [$image, $type] = $opened;
        $width = imagesx($image);
        $height = imagesy($image);
        $scale = min($maxWidth ? $maxWidth / $width : 1, $maxHeight ? $maxHeight / $height : 1);
        if ($scale >= 1) {
            return self::prepare($target) && copy($source, $target);
        }
        $resized = imagecreatetruecolor(max(1, (int) floor($scale * $width)), max(1, (int) floor($scale * $height)));
        self::keepTransparency($resized, $type);
        imagecopyresampled($resized, $image, 0, 0, 0, 0, imagesx($resized), imagesy($resized), $width, $height);
        return self::prepare($target) && self::save($resized, $type, $target);
    }

    /** cut_img(): scale and centre-crop to exactly width×height (a missing side defaults to 280). */
    public static function cut(string $source, string $target, ?int $newWidth, ?int $newHeight): bool
    {
        if ((! $newWidth && ! $newHeight) || ($opened = self::open($source)) === null) {
            return false;
        }
        [$image, $type] = $opened;
        $targetW = $newWidth ?: 280;
        $targetH = $newHeight ?: 280;
        $sourceW = imagesx($image);
        $sourceH = imagesy($image);
        $wider = ($sourceW / $sourceH) > ($targetW / $targetH);
        $resizeW = (int) round($wider ? $sourceW * $targetH / $sourceH : $targetW);
        $resizeH = (int) round(! $wider ? $sourceH * $targetW / $sourceW : $targetH);
        $resized = imagecreatetruecolor(max(1, $resizeW), max(1, $resizeH));
        self::keepTransparency($resized, $type);
        imagecopyresampled($resized, $image, 0, 0, 0, 0, $resizeW, $resizeH, $sourceW, $sourceH);
        $cropped = imagecreatetruecolor($targetW, $targetH);
        self::keepTransparency($cropped, $type);
        imagecopy($cropped, $resized, 0, 0, (int) ($wider ? ($resizeW - $targetW) / 2 : 0), (int) (! $wider ? ($resizeH - $targetH) / 2 : 0), $targetW, $targetH);
        return self::prepare($target) && self::save($cropped, $type, $target);
    }

    /** Absolute path of a site path such as /uploads/x.png when it exists inside $publicRoot. */
    public static function inside(string $publicRoot, string $path): ?string
    {
        if ($path === '' || ! str_starts_with($path, '/') || str_contains($path, '..')) {
            return null;
        }
        $real = realpath($publicRoot . $path);
        $root = realpath($publicRoot);
        return $real !== false && $root !== false && str_starts_with($real, $root . DIRECTORY_SEPARATOR) && is_file($real) ? $real : null;
    }

    /** @return array{0: GdImage, 1: int}|null */
    private static function open(string $file): ?array
    {
        $info = $file !== '' ? @getimagesize($file) : false;
        if ($info === false || $info[0] < 1 || $info[1] < 1 || $info[0] * $info[1] > 40000000) {
            return null;
        }
        $image = match ($info[2]) {
            IMAGETYPE_GIF => @imagecreatefromgif($file),
            IMAGETYPE_JPEG => @imagecreatefromjpeg($file),
            IMAGETYPE_PNG => @imagecreatefrompng($file),
            IMAGETYPE_WEBP => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($file) : false,
            default => false,
        };
        return $image instanceof GdImage ? array($image, $info[2]) : null;
    }

    private static function keepTransparency(GdImage $image, int $type): void
    {
        if ($type === IMAGETYPE_PNG || $type === IMAGETYPE_WEBP) {
            imagealphablending($image, false);
            imagesavealpha($image, true);
            imagefill($image, 0, 0, (int) imagecolorallocatealpha($image, 0, 0, 0, 127));
        } elseif ($type === IMAGETYPE_GIF) {
            $white = (int) imagecolorallocate($image, 255, 255, 255);
            imagefill($image, 0, 0, $white);
            imagecolortransparent($image, $white);
        }
    }

    private static function prepare(string $target): bool
    {
        $directory = dirname($target);
        return is_dir($directory) || mkdir($directory, 0755, true) || is_dir($directory);
    }

    private static function save(GdImage $image, int $type, string $file): bool
    {
        return match ($type) {
            IMAGETYPE_GIF => imagegif($image, $file),
            IMAGETYPE_PNG => imagepng($image, $file, 9),
            IMAGETYPE_WEBP => function_exists('imagewebp') && imagewebp($image, $file, 90),
            default => imagejpeg($image, $file, 90),
        };
    }
}
