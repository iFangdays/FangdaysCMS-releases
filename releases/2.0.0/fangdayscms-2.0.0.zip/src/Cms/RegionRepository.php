<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;
use PDO;

/** Canonical locale registry shared by routing, APIs and admin editing. */
final class RegionRepository
{
    public function __construct(private readonly PDO $pdo)
    {
    }

    public function all(bool $enabledOnly = false): array
    {
        $sql = 'SELECT locale, prefix, name, parent_locale, domain, is_default, is_enabled, sort_order FROM regions';
        if ($enabledOnly) {
            $sql .= ' WHERE is_enabled = 1';
        }
        $sql .= ' ORDER BY sort_order ASC, locale ASC';
        return $this->pdo->query($sql)->fetchAll();
    }

    public function find(string $locale): ?array
    {
        $stmt = $this->pdo->prepare('SELECT locale, prefix, name, parent_locale, domain, is_default, is_enabled, sort_order FROM regions WHERE locale = ?');
        $stmt->execute(array($locale));
        $row = $stmt->fetch();
        return is_array($row) ? $row : null;
    }

    public function localeForPrefix(string $prefix): ?string
    {
        $prefix = trim($prefix, '/');
        if ($prefix === '') {
            return null;
        }
        $stmt = $this->pdo->prepare('SELECT locale FROM regions WHERE prefix = ? AND is_enabled = 1');
        $stmt->execute(array($prefix));
        $value = $stmt->fetchColumn();
        return is_string($value) && $value !== '' ? $value : null;
    }

    public function localeForDomain(string $domain): ?string
    {
        $domain = self::normalizeDomain($domain);
        if ($domain === '') {
            return null;
        }
        $stmt = $this->pdo->prepare('SELECT locale FROM regions WHERE domain = ? AND is_enabled = 1');
        $stmt->execute(array($domain));
        $value = $stmt->fetchColumn();
        return is_string($value) && $value !== '' ? $value : null;
    }

    public function save(?string $originalLocale, string $locale, string $prefix, string $name, string $parentLocale = '', string $domain = '', bool $isDefault = false, bool $isEnabled = true, int $sortOrder = 0): void
    {
        $locale = trim($locale);
        $prefix = trim($prefix, '/');
        $name = trim($name);
        $parentLocale = trim($parentLocale);
        $domain = trim($domain);
        if (! preg_match('/^[A-Za-z][A-Za-z0-9]*(?:-[A-Za-z0-9]+)*$/D', $locale) || strlen($locale) > 32) {
            throw new InvalidArgumentException('区域标识必须是 canonical locale 字符串。');
        }
        if ($domain !== '') {
            $domain = self::normalizeDomain($domain);
            if ($domain === '' || strlen($domain) > 255) {
                throw new InvalidArgumentException('区域绑定域名无效。');
            }
            $stmt = $this->pdo->prepare('SELECT locale FROM regions WHERE domain = ? AND locale <> ?');
            $stmt->execute(array($domain, $originalLocale ?? ''));
            if ($stmt->fetchColumn() !== false) {
                throw new InvalidArgumentException('区域绑定域名已被其他区域使用。');
            }
        }
        if (! preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/D', $prefix) || strlen($prefix) > 16) {
            throw new InvalidArgumentException('区域 URL 前缀无效。');
        }
        if (in_array($prefix, array('api', 'admin', 'member', 'category', 'post', 'page', 'tag', 'search', 'rss', 'sitemap', 'message', 'form', 'login', 'logout', 'install'), true)) {
            throw new InvalidArgumentException('区域 URL 前缀与系统路由冲突。');
        }
        if ($name === '' || strlen($name) > 100 || $sortOrder < 0 || $sortOrder > 1000000) {
            throw new InvalidArgumentException('区域名称或排序无效。');
        }
        if ($isDefault && ! $isEnabled) {
            throw new InvalidArgumentException('默认区域必须保持启用。');
        }
        if (! $isEnabled && $originalLocale !== null) {
            $current = $this->find($originalLocale);
            if ($current !== null && (int) $current['is_default'] === 1) {
                throw new InvalidArgumentException('请先指定新的默认区域。');
            }
        }
        if ($parentLocale !== '' && $parentLocale === $locale) {
            throw new InvalidArgumentException('区域不能将自身设为父区域。');
        }
        if ($parentLocale !== '' && $this->find($parentLocale) === null) {
            throw new InvalidArgumentException('父区域不存在。');
        }
        $parentDb = $parentLocale === '' ? null : $parentLocale;
        $this->pdo->beginTransaction();
        try {
            if ($originalLocale !== null && $originalLocale !== $locale) {
                $stmt = $this->pdo->prepare('UPDATE regions SET locale = ?, prefix = ?, name = ?, parent_locale = ?, domain = ?, is_default = ?, is_enabled = ?, sort_order = ? WHERE locale = ?');
                $stmt->execute(array($locale, $prefix, $name, $parentDb, $domain, $isDefault ? 1 : 0, $isEnabled ? 1 : 0, $sortOrder, $originalLocale));
            } elseif ($originalLocale !== null) {
                $stmt = $this->pdo->prepare('UPDATE regions SET prefix = ?, name = ?, parent_locale = ?, domain = ?, is_default = ?, is_enabled = ?, sort_order = ? WHERE locale = ?');
                $stmt->execute(array($prefix, $name, $parentDb, $domain, $isDefault ? 1 : 0, $isEnabled ? 1 : 0, $sortOrder, $locale));
            } else {
                $stmt = $this->pdo->prepare('INSERT INTO regions (locale, prefix, name, parent_locale, domain, is_default, is_enabled, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
                $stmt->execute(array($locale, $prefix, $name, $parentDb, $domain, $isDefault ? 1 : 0, $isEnabled ? 1 : 0, $sortOrder));
            }
            if ($isDefault) {
                $stmt = $this->pdo->prepare('UPDATE regions SET is_default = CASE WHEN locale = ? THEN 1 ELSE 0 END');
                $stmt->execute(array($locale));
                $this->pdo->prepare("DELETE FROM site_settings WHERE name = 'locale'")->execute();
                $stmt = $this->pdo->prepare("INSERT INTO site_settings (name, value) VALUES ('locale', ?)");
                $stmt->execute(array($locale));
            }
            $this->pdo->commit();
        } catch (\Throwable $error) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            throw $error;
        }
    }

    /** Pboot 区域列表 switch. The default region stays enabled. */
    public function setEnabled(string $locale, bool $enabled): void
    {
        $region = $this->find($locale) ?? throw new InvalidArgumentException('区域不存在。');
        if (! $enabled && (int) $region['is_default'] === 1) {
            throw new InvalidArgumentException('默认区域不能停用。');
        }
        $this->pdo->prepare('UPDATE regions SET is_enabled = ? WHERE locale = ?')->execute(array((int) $enabled, $locale));
    }

    public function delete(string $locale): void
    {
        $region = $this->find($locale);
        if ($region === null) {
            throw new InvalidArgumentException('区域不存在。');
        }
        if ((int) $region['is_default'] === 1 || in_array($locale, array('zh-CN', 'en-US'), true)) {
            throw new InvalidArgumentException('内置区域或默认区域不允许删除。');
        }
        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM regions WHERE parent_locale = ?');
        $stmt->execute(array($locale));
        if ((int) $stmt->fetchColumn() > 0) {
            throw new InvalidArgumentException('请先移除子区域。');
        }
        $stmt = $this->pdo->prepare('DELETE FROM regions WHERE locale = ?');
        $stmt->execute(array($locale));
    }

    private static function normalizeDomain(string $domain): string
    {
        $domain = strtolower(trim($domain));
        if ($domain === '' || strlen($domain) > 255 || str_contains($domain, '/') || str_contains($domain, ':') || preg_match('/[^a-z0-9.-]/', $domain) === 1 || str_starts_with($domain, '.') || str_ends_with($domain, '.') || str_contains($domain, '..')) {
            return '';
        }
        return $domain;
    }
}
