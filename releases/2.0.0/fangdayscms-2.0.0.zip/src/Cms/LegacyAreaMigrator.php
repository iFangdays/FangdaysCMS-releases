<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;
use PDO;
use RuntimeException;

/**
 * Copies the legacy Pboot ay_area tree into the canonical region registry.
 * The source connection is read-only by convention; this class never writes it.
 */
final class LegacyAreaMigrator
{
    /** @return array{source_rows:int,inserted:int,updated:int,skipped:int,unresolved:string[]} */
    public static function migrate(PDO $source, PDO $target): array
    {
        $driver = $source->getAttribute(PDO::ATTR_DRIVER_NAME);
        if (! self::tableExists($source, $driver, 'ay_area')) {
            throw new InvalidArgumentException('旧库缺少 ay_area，未执行迁移。');
        }
        foreach (array('acode', 'pcode', 'name', 'domain', 'is_default') as $column) {
            if (! self::columnExists($source, $driver, 'ay_area', $column)) {
                throw new InvalidArgumentException('ay_area 缺少必需列：' . $column);
            }
        }
        Migrator::ensure($target);
        $rows = $source->query('SELECT acode, pcode, name, domain, is_default FROM ay_area ORDER BY pcode, acode')->fetchAll(PDO::FETCH_ASSOC);
        $unresolved = array();
        $mapped = array();
        foreach ($rows as $row) {
            $acode = trim((string) $row['acode']);
            $pcode = trim((string) $row['pcode']);
            if (! self::safeCode($acode)) {
                $unresolved[] = $acode . ': acode 不能作为 URL 前缀';
                continue;
            }
            if ($pcode !== '0' && $pcode !== '' && ! self::safeCode($pcode)) {
                $unresolved[] = $acode . ': pcode 不安全';
                continue;
            }
            $mapped[$acode] = array($row, self::localeForAcode($acode));
        }
        foreach ($mapped as $acode => [$row, $locale]) {
            if ($row['pcode'] !== '0' && $row['pcode'] !== '' && ! isset($mapped[(string) $row['pcode']])) {
                $unresolved[] = $acode . ': 父区域 ' . $row['pcode'] . ' 不存在';
            }
        }
        if ($unresolved !== array()) {
            return array('source_rows' => count($rows), 'inserted' => 0, 'updated' => 0, 'skipped' => 0, 'unresolved' => array_values(array_unique($unresolved)));
        }

        $target->beginTransaction();
        $inserted = 0;
        $updated = 0;
        $skipped = 0;
        try {
            foreach ($mapped as $acode => [$row, $locale]) {
                $parent = ((string) $row['pcode'] === '0' || (string) $row['pcode'] === '') ? null : self::localeForAcode((string) $row['pcode']);
                $existing = self::findExisting($target, $locale, $acode);
                $domain = strtolower(trim((string) $row['domain']));
                $default = ((string) $row['is_default'] === '1') ? 1 : 0;
                if ($existing === null) {
                    $stmt = $target->prepare('INSERT INTO regions (locale, prefix, name, parent_locale, domain, is_default, is_enabled, sort_order, legacy_acode, legacy_pcode) VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, ?)');
                    $stmt->execute(array($locale, $acode, (string) $row['name'], $parent, $domain, $default, $default ? 0 : 100, $acode, (string) $row['pcode']));
                    $inserted++;
                    continue;
                }
                if ((string) $existing['prefix'] !== $acode && (string) $existing['prefix'] !== self::prefixForExisting($target, $locale)) {
                    throw new RuntimeException('区域前缀冲突：' . $acode);
                }
                $stmt = $target->prepare('UPDATE regions SET legacy_acode = ?, legacy_pcode = ? WHERE locale = ?');
                $stmt->execute(array($acode, (string) $row['pcode'], (string) $existing['locale']));
                if ($stmt->rowCount() > 0) {
                    $updated++;
                } else {
                    $skipped++;
                }
            }
            if (count(array_filter($mapped, static fn(array $item): bool => (string) $item[0]['is_default'] === '1')) > 0) {
                $default = array_values(array_filter($mapped, static fn(array $item): bool => (string) $item[0]['is_default'] === '1'))[0][1];
                $target->prepare('UPDATE regions SET is_default = CASE WHEN locale = ? THEN 1 ELSE 0 END')->execute(array($default));
                $target->prepare("DELETE FROM site_settings WHERE name = 'locale'")->execute();
                $target->prepare("INSERT INTO site_settings (name, value) VALUES ('locale', ?)")->execute(array($default));
            }
            $target->commit();
        } catch (\Throwable $error) {
            if ($target->inTransaction()) {
                $target->rollBack();
            }
            throw $error;
        }
        return array('source_rows' => count($rows), 'inserted' => $inserted, 'updated' => $updated, 'skipped' => $skipped, 'unresolved' => array());
    }

    private static function localeForAcode(string $acode): string
    {
        if ($acode === 'cn') return 'zh-CN';
        if ($acode === 'en') return 'en-US';
        if (preg_match('/^[A-Za-z]{2,3}(?:-[A-Za-z]{2}|-[0-9]{3})$/D', $acode) === 1) return $acode;
        return 'x-pboot-' . strtolower($acode);
    }

    private static function safeCode(string $code): bool
    {
        return preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/D', $code) === 1 && strlen($code) <= 16;
    }

    private static function findExisting(PDO $pdo, string $locale, string $acode): ?array
    {
        $stmt = $pdo->prepare('SELECT locale, prefix FROM regions WHERE legacy_acode = ? OR locale = ?');
        $stmt->execute(array($acode, $locale));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return is_array($row) ? $row : null;
    }

    private static function prefixForExisting(PDO $pdo, string $locale): string
    {
        $stmt = $pdo->prepare('SELECT prefix FROM regions WHERE locale = ?');
        $stmt->execute(array($locale));
        return (string) $stmt->fetchColumn();
    }

    private static function tableExists(PDO $pdo, string $driver, string $table): bool
    {
        if ($driver === 'sqlite') return (bool) $pdo->query("SELECT COUNT(*) FROM sqlite_master WHERE type = 'table' AND name = '" . $table . "'")->fetchColumn();
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?');
        $stmt->execute(array($table));
        return (bool) $stmt->fetchColumn();
    }

    private static function columnExists(PDO $pdo, string $driver, string $table, string $column): bool
    {
        if ($driver === 'sqlite') {
            foreach ($pdo->query('PRAGMA table_info(' . $table . ')') as $item) if ($item['name'] === $column) return true;
            return false;
        }
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?');
        $stmt->execute(array($table, $column));
        return (bool) $stmt->fetchColumn();
    }
}
