<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;

/** Validates signed, immutable upgrade metadata before any package is downloaded. */
final class UpgradeManifest
{
    public const DEFAULT_FEED_URL = 'https://raw.githubusercontent.com/iFangdays/FangdaysCMS-releases/main/latest.fdu1';
    private const PREFIX = 'FDU1';
    private const MAX_BYTES = 32768;
    private const MAX_REDIRECTS = 5;

    public static function fetch(string $url, int $timeout = 10): string
    {
        $current = trim($url);
        $timeout = max(1, min(30, $timeout));
        for ($hop = 0; $hop <= self::MAX_REDIRECTS; $hop++) {
            self::assertHttpsUrl($current, '升级清单地址必须使用 HTTPS。');
            $context = stream_context_create(array(
                'http' => array(
                    'method' => 'GET',
                    'timeout' => $timeout,
                    'follow_location' => 0,
                    'ignore_errors' => true,
                    'header' => "User-Agent: FangdaysCMS/2.0.0\r\nAccept: text/plain, */*\r\n",
                ),
                'ssl' => array('verify_peer' => true, 'verify_peer_name' => true),
            ));
            $stream = @fopen($current, 'rb', false, $context);
            $meta = is_resource($stream) ? stream_get_meta_data($stream) : array();
            $headers = is_array($meta['wrapper_data'] ?? null) ? $meta['wrapper_data'] : array();
            $status = self::statusCode($headers);
            if ($status >= 300 && $status < 400) {
                if (is_resource($stream)) {
                    fclose($stream);
                }
                $location = self::headerValue($headers, 'location');
                if ($location === null || $hop === self::MAX_REDIRECTS) {
                    throw new InvalidArgumentException('升级清单重定向无效或次数过多。');
                }
                $current = self::resolveRedirect($current, $location);
                continue;
            }
            $body = is_resource($stream) ? @stream_get_contents($stream, self::MAX_BYTES + 1) : false;
            if (is_resource($stream)) {
                fclose($stream);
            }
            if ($status < 200 || $status >= 300) {
                throw new InvalidArgumentException('升级清单服务器响应失败。');
            }
            if (! is_string($body) || strlen($body) > self::MAX_BYTES) {
                throw new InvalidArgumentException('升级清单下载失败或超过大小限制。');
            }
            return trim($body);
        }
        throw new InvalidArgumentException('升级清单重定向次数过多。');
    }

    /** Signs upgrade metadata with the vendor Ed25519 private key. */
    public static function sign(array $claims, string $secretKey): string
    {
        \FangdaysCMS\Licensing\LicenseCode::requireSodium();
        if (strlen($secretKey) !== SODIUM_CRYPTO_SIGN_SECRETKEYBYTES) {
            throw new InvalidArgumentException('签发私钥无效。');
        }
        $normalized = self::normalizeClaims($claims);
        $payload = json_encode($normalized, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        $message = self::PREFIX . '.' . self::encode($payload);
        $signature = sodium_crypto_sign_detached($message, $secretKey);
        return $message . '.' . self::encode($signature);
    }

    /** Verifies signature and metadata without requiring version > currentVersion. */
    public static function inspect(string $manifest, array $publicKeys): array
    {
        \FangdaysCMS\Licensing\LicenseCode::requireSodium();
        $manifest = trim($manifest);
        if (strlen($manifest) > self::MAX_BYTES || ! preg_match('/^FDU1\.([A-Za-z0-9_-]+)\.([A-Za-z0-9_-]+)$/D', $manifest, $parts)) {
            throw new InvalidArgumentException('升级清单格式无效。');
        }
        $payload = self::decode($parts[1]);
        $signature = self::decode($parts[2]);
        if ($payload === null || $signature === null || strlen($signature) !== SODIUM_CRYPTO_SIGN_BYTES) {
            throw new InvalidArgumentException('升级清单签名无效。');
        }
        $claims = json_decode($payload, true, 16);
        if (! is_array($claims) || ! is_string($claims['key_id'] ?? null)) {
            throw new InvalidArgumentException('升级清单字段无效。');
        }
        $key = $publicKeys[$claims['key_id']] ?? null;
        $publicKey = is_string($key) ? base64_decode($key, true) : false;
        if ($publicKey === false || strlen($publicKey) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES || ! sodium_crypto_sign_verify_detached($signature, self::PREFIX . '.' . $parts[1], $publicKey)) {
            throw new InvalidArgumentException('升级清单签名验证失败。');
        }
        return self::normalizeClaims($claims);
    }

    public static function verify(string $manifest, array $publicKeys, string $currentVersion): array
    {
        $verified = self::inspect($manifest, $publicKeys);
        if (version_compare($verified['version'], $currentVersion, '<=')) {
            throw new InvalidArgumentException('升级清单内容无效。');
        }
        return $verified;
    }

    /** @return array{key_id:string,version:string,sha256:string,size:int,url:string,notes?:string,released_at?:int} */
    private static function normalizeClaims(array $claims): array
    {
        $keyId = (string) ($claims['key_id'] ?? '');
        $version = (string) ($claims['version'] ?? '');
        $sha256 = (string) ($claims['sha256'] ?? '');
        $size = $claims['size'] ?? null;
        $url = (string) ($claims['url'] ?? '');
        if ($keyId === '' || ! preg_match('/^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/D', $version) || ! preg_match('/^[a-f0-9]{64}$/D', $sha256) || ! is_int($size) || $size < 1 || $size > 52428800 || ! filter_var($url, FILTER_VALIDATE_URL) || parse_url($url, PHP_URL_SCHEME) !== 'https') {
            throw new InvalidArgumentException('升级清单内容无效。');
        }
        $result = array('key_id' => $keyId, 'version' => $version, 'sha256' => $sha256, 'size' => $size, 'url' => $url);
        if (array_key_exists('notes', $claims) && $claims['notes'] !== null && $claims['notes'] !== '') {
            if (! is_string($claims['notes']) || strlen($claims['notes']) > 4000) {
                throw new InvalidArgumentException('升级清单更新说明无效。');
            }
            $result['notes'] = $claims['notes'];
        }
        if (array_key_exists('released_at', $claims) && $claims['released_at'] !== null) {
            if (! is_int($claims['released_at']) || $claims['released_at'] < 0) {
                throw new InvalidArgumentException('升级清单发布时间无效。');
            }
            $result['released_at'] = $claims['released_at'];
        }
        return $result;
    }

    public static function assertHttpsUrl(string $url, string $message): void
    {
        if (parse_url($url, PHP_URL_SCHEME) !== 'https' || filter_var($url, FILTER_VALIDATE_URL) === false) {
            throw new InvalidArgumentException($message);
        }
    }

    public static function resolveRedirect(string $baseUrl, string $location): string
    {
        $location = trim($location);
        if ($location === '' || str_contains($location, "\r") || str_contains($location, "\n")) {
            throw new InvalidArgumentException('重定向地址无效。');
        }
        if (preg_match('#^[A-Za-z][A-Za-z0-9+.-]*://#', $location)) {
            self::assertHttpsUrl($location, '重定向目标必须使用 HTTPS。');
            return $location;
        }
        $parts = parse_url($baseUrl);
        if (! is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) {
            throw new InvalidArgumentException('重定向基础地址无效。');
        }
        $origin = $parts['scheme'] . '://' . $parts['host'] . (isset($parts['port']) ? ':' . $parts['port'] : '');
        if (str_starts_with($location, '//')) {
            $resolved = $parts['scheme'] . ':' . $location;
            self::assertHttpsUrl($resolved, '重定向目标必须使用 HTTPS。');
            return $resolved;
        }
        if (str_starts_with($location, '/')) {
            $resolved = $origin . $location;
            self::assertHttpsUrl($resolved, '重定向目标必须使用 HTTPS。');
            return $resolved;
        }
        $dir = dirname((string) ($parts['path'] ?? '/'));
        $resolved = $origin . rtrim($dir, '/') . '/' . $location;
        self::assertHttpsUrl($resolved, '重定向目标必须使用 HTTPS。');
        return $resolved;
    }

    public static function statusCode(array $headers): int
    {
        $statusLine = (string) ($headers[0] ?? '');
        return preg_match('/^HTTP\/\S+\s+(\d{3})\b/', $statusLine, $match) ? (int) $match[1] : 0;
    }

    public static function headerValue(array $headers, string $name): ?string
    {
        $prefix = strtolower($name) . ':';
        foreach (array_slice($headers, 1) as $header) {
            if (is_string($header) && str_starts_with(strtolower($header), $prefix)) {
                return trim(substr($header, strlen($prefix)));
            }
        }
        return null;
    }

    private static function encode(string $bytes): string
    {
        return rtrim(strtr(base64_encode($bytes), '+/', '-_'), '=');
    }

    private static function decode(string $value): ?string
    {
        $decoded = base64_decode(strtr($value, '-_', '+/'), true);
        return $decoded === false ? null : $decoded;
    }
}
