<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;
use PDO;
use RuntimeException;

final class DatabaseMaintenance
{
    public function __construct(private readonly PDO $pdo, private readonly array $config, private readonly string $root)
    {
    }

    public function backup(): string
    {
        $dir = $this->backupDirectory();
        if (($this->config['driver'] ?? '') === 'sqlite') {
            $source = $this->config['path'] ?? '';
            if (! is_string($source) || ! is_file($source)) {
                throw new RuntimeException('SQLite 数据库文件不存在。');
            }
            $this->pdo->exec('PRAGMA wal_checkpoint(FULL)');
            $target = $this->backupDirectory() . '/' . $this->availablePath('content-', '.sqlite');
            if (! copy($source, $target)) {
                throw new RuntimeException('数据库备份写入失败。');
            }
            $this->pruneBackups();
            return basename($target);
        }
        if (($this->config['driver'] ?? '') !== 'mysql') {
            throw new InvalidArgumentException('不支持的数据库驱动。');
        }
        $target = $dir . '/' . $this->availablePath('content-', '.sql');
        $sql = "-- FangdaysCMS logical backup\nSET FOREIGN_KEY_CHECKS=0;\n\n";
        foreach ($this->pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN) as $table) {
            $table = (string) $table;
            $quoted = '`' . str_replace('`', '``', $table) . '`';
            $create = $this->pdo->query('SHOW CREATE TABLE ' . $quoted)->fetch(PDO::FETCH_NUM);
            if (! $create) {
                continue;
            }
            $sql .= 'DROP TABLE IF EXISTS ' . $quoted . ";\n" . $create[1] . ";\n";
            foreach ($this->pdo->query('SELECT * FROM ' . $quoted)->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $values = array();
                foreach ($row as $value) {
                    $values[] = $value === null ? 'NULL' : $this->pdo->quote((string) $value);
                }
                $sql .= 'INSERT INTO ' . $quoted . ' VALUES (' . implode(', ', $values) . ");\n";
            }
            $sql .= "\n";
        }
        $sql .= "SET FOREIGN_KEY_CHECKS=1;\n";
        if (file_put_contents($target, $sql, LOCK_EX) === false) {
            throw new RuntimeException('数据库备份写入失败。');
        }
        $this->pruneBackups();
        return basename($target);
    }

    public function optimize(): void
    {
        if (($this->config['driver'] ?? '') === 'sqlite') {
            $this->pdo->exec('VACUUM');
            return;
        }
        foreach ($this->pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN) as $table) {
            $quoted = '`' . str_replace('`', '``', (string) $table) . '`';
            $this->pdo->exec('OPTIMIZE TABLE ' . $quoted);
        }
    }

    public function restore(string $name): void
    {
        if (($this->config['driver'] ?? '') === 'mysql') {
            if (! preg_match('/^content-[0-9]{8}-[0-9]{6}\.sql$/D', $name)) {
                throw new InvalidArgumentException('MySQL 备份文件名无效。');
            }
            $source = $this->backupDirectory() . '/' . $name;
            if (! is_file($source) || filesize($source) > 50000000) {
                throw new RuntimeException('MySQL 备份文件不存在或过大。');
            }
            $sql = file_get_contents($source);
            if (! is_string($sql) || ! str_starts_with($sql, '-- FangdaysCMS logical backup')) {
                throw new RuntimeException('备份文件格式无效，未执行恢复。');
            }
            $this->backup();
            $this->pdo->exec($sql);
            return;
        }
        if (($this->config['driver'] ?? '') !== 'sqlite' || ! preg_match('/^content-[0-9]{8}-[0-9]{6}\.sqlite$/D', $name)) {
            throw new InvalidArgumentException('当前仅支持恢复 SQLite 备份。');
        }
        $source = $this->backupDirectory() . '/' . $name;
        $target = $this->config['path'] ?? '';
        if (! is_file($source) || ! is_string($target) || $target === '') {
            throw new RuntimeException('备份文件或数据库文件不存在。');
        }
        $check = new PDO('sqlite:' . $source, null, null, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
        $version = $check->query('SELECT version FROM cms_schema WHERE id = 1')->fetchColumn();
        if ($version === false || (int) $version < Migrator::VERSION) {
            throw new RuntimeException('备份 schema 版本过旧，未执行恢复。');
        }
        $preRestore = $this->backupDirectory() . '/' . $this->availablePath('pre-restore-', '.sqlite');
        if (is_file($target) && ! copy($target, $preRestore)) {
            throw new RuntimeException('恢复前备份创建失败。');
        }
        if (! copy($source, $target)) {
            throw new RuntimeException('数据库恢复失败。');
        }
    }

    public function backups(): array
    {
        $files = glob($this->backupDirectory() . '/content-*') ?: array();
        usort($files, static fn (string $a, string $b): int => filemtime($b) <=> filemtime($a));
        return array_map(static fn (string $file): array => array('name' => basename($file), 'bytes' => (int) filesize($file), 'updated_at' => (int) filemtime($file)), $files);
    }

    public function send(string $name): never
    {
        if (! preg_match('/^content-[0-9]{8}-[0-9]{6}\.(?:sqlite|sql)$/D', $name)) {
            throw new InvalidArgumentException('备份文件名无效。');
        }
        $file = $this->backupDirectory() . '/' . $name;
        if (! is_file($file)) {
            throw new RuntimeException('备份文件不存在。');
        }
        header('Content-Type: application/octet-stream');
        header('Content-Length: ' . (string) filesize($file));
        header('Content-Disposition: attachment; filename="' . $name . '"');
        readfile($file);
        exit;
    }

    private function pruneBackups(): void
    {
        $files = glob($this->backupDirectory() . '/content-*') ?: array();
        usort($files, static fn (string $a, string $b): int => filemtime($b) <=> filemtime($a));
        foreach (array_slice($files, 10) as $file) {
            @unlink($file);
        }
    }

    private function availablePath(string $prefix, string $suffix): string
    {
        $stamp = time();
        do {
            $name = $prefix . date('Ymd-His', $stamp) . $suffix;
            $stamp++;
        } while (is_file($this->backupDirectory() . '/' . $name));
        return $name;
    }

    private function backupDirectory(): string
    {
        $dir = $this->root . '/var/backups';
        if (! is_dir($dir) && ! mkdir($dir, 0700, true) && ! is_dir($dir)) {
            throw new RuntimeException('无法创建数据库备份目录。');
        }
        return $dir;
    }
}
