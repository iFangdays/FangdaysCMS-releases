<?php
declare(strict_types=1);

namespace FangdaysCMS\Licensing;

use RuntimeException;

/** Stores a verified code outside the public document root. */
final class LicenseStore
{
    private ?array $status = null;

    /** @param array<string, string> $publicKeys Defaults to the built-in vendor keys; tests may pass their own. */
    public function __construct(
        private readonly string $file,
        private readonly string $domain,
        private readonly array $publicKeys = TrustedKeys::KEYS
    ) {
    }

    /** Host name the activated code must cover. */
    public function domain(): string
    {
        return LicenseCode::normalizeDomain($this->domain) ?? $this->domain;
    }

    /** Chinese text for a verify() reason. */
    public static function reasonText(string $reason): string
    {
        return array(
            'ok' => '有效', 'missing' => '尚未激活', 'unreadable' => '授权文件无法读取', 'format' => '授权码格式错误',
            'claims' => '授权码内容无效', 'unknown_key' => '授权码不是由本产品的厂商密钥签发', 'signature' => '签名校验失败（授权码被修改或伪造）',
            'not_yet_valid' => '授权尚未生效', 'expired' => '授权已过期', 'domain_mismatch' => '授权码不包含当前域名',
        )[$reason] ?? $reason;
    }

    public function activate(string $code, ?int $now = null): array
    {
        $code = trim($code);
        $result = LicenseCode::verify($code, $this->publicKeys, $this->domain, $now);
        if (! $result['valid']) {
            return $result;
        }
        $directory = dirname($this->file);
        if (! is_dir($directory) && ! mkdir($directory, 0700, true) && ! is_dir($directory)) {
            throw new RuntimeException('Cannot create license storage directory.');
        }
        $temporary = tempnam($directory, '.license-');
        if ($temporary === false) {
            throw new RuntimeException('Cannot create temporary license file.');
        }
        try {
            $bytes = $code . "\n";
            if (file_put_contents($temporary, $bytes, LOCK_EX) !== strlen($bytes)) {
                throw new RuntimeException('Cannot write complete license code.');
            }
            if (function_exists('chmod')) {
                chmod($temporary, 0600);
            }
            if (! rename($temporary, $this->file)) {
                throw new RuntimeException('Cannot activate license code.');
            }
        } finally {
            if (is_file($temporary)) {
                unlink($temporary);
            }
        }
        $this->status = null;
        return $result;
    }

    /** Verified once per request unless a time is given. */
    public function status(?int $now = null): array
    {
        if ($now !== null) {
            return $this->read($now);
        }
        return $this->status ??= $this->read(null);
    }

    /** Whole days left when a valid license ends within $withinDays, else null; 0 means it ends today. */
    public function daysUntilExpiry(int $withinDays = 30, ?int $now = null): ?int
    {
        $status = $this->status($now);
        $expiresAt = $status['claims']['expires_at'] ?? null;
        if (! $status['valid'] || $expiresAt === null) {
            return null;
        }
        $days = (int) floor(($expiresAt - ($now ?? time())) / 86400);
        return $days <= $withinDays ? $days : null;
    }

    private function read(?int $now): array
    {
        if (! is_file($this->file)) {
            return array('valid' => false, 'reason' => 'missing', 'claims' => null);
        }
        $code = file_get_contents($this->file, false, null, 0, 8193);
        if ($code === false) {
            return array('valid' => false, 'reason' => 'unreadable', 'claims' => null);
        }
        if (strlen($code) > 8192) {
            return array('valid' => false, 'reason' => 'format', 'claims' => null);
        }
        return LicenseCode::verify(trim($code), $this->publicKeys, $this->domain, $now);
    }
}
