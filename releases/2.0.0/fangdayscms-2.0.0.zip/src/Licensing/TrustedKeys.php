<?php
declare(strict_types=1);

namespace FangdaysCMS\Licensing;

/**
 * Vendor Ed25519 public keys (base64) by key ID. Only codes signed by one of
 * these keys activate a site; customer configuration cannot add keys.
 * Rotate with: php tools/license_issuer.php trust PUBLIC_KEY KEY_ID [--add]
 */
final class TrustedKeys
{
    public const KEYS = array(
        'fd-2026' => 'g8BeNx2fICEkQn8iEFQfKliAX42Z6ZxRdfuKpE4KBBc=',
    );
}
