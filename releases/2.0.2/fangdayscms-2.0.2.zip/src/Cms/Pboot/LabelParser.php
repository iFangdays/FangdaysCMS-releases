<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Pboot;

use FangdaysCMS\Cms\Geo\GeoHead;
use FangdaysCMS\Cms\TemplateTags;
use FangdaysCMS\Cms\View;

/**
 * Port of PbootCMS 3.2.10 apps/home/controller/ParserController (Apache-2.0).
 *
 * Labels are resolved in Pboot's original order with the same regular
 * expressions, so templates behave identically. Differences on purpose:
 * data comes from {@see PbootData}; plain values are HTML-escaped on output;
 * HTML values are kept in the pre-store so they are never parsed as labels.
 */
final class LabelParser
{
    private const STATIC_DIR = '/static';
    /** Default avatar Pboot uses for messages and comments. */
    private const HEADPIC = '/apps/admin/view/default/images/logo.png';

    private array $pre = array();
    private ?array $pageVars = null;
    private bool $paging = false;
    private ?string $redirect = null;

    public function __construct(
        private readonly PbootData $data,
        private readonly array $env,
    ) {
    }

    /** Redirect requested by {fd:mustlogin}, if any. */
    public function redirect(): ?string
    {
        return $this->redirect;
    }

    public function pageVars(): ?array
    {
        return $this->pageVars;
    }

    public function parserBefore(string $content): string
    {
        $content = $this->savePreLabel($content);
        $content = $this->parserSingleLabel($content);
        return $this->parserUserLabel($content);
    }

    public function parserAfter(string $content): string
    {
        $content = str_replace('{fd:pagetitle}', $this->config('other_title') ?: '{fd:sitetitle}-{fd:sitesubtitle}', $content);
        $content = str_replace('{fd:pagekeywords}', '{fd:sitekeywords}', $content);
        $content = str_replace('{fd:pagedescription}', '{fd:sitedescription}', $content);
        $content = str_replace('{fd:keyword}', $this->escape((string) ($this->env['query']['keyword'] ?? '')), $content);
        $content = $this->parserSiteLabel($content);
        $content = $this->parserCompanyLabel($content);
        $content = $this->parserCustomerServiceLabel($content);
        $content = $this->parserMemberLabel($content);
        $content = $this->parserNavLabel($content);
        $content = $this->parserSelectAllLabel($content);
        $content = $this->parserSelectLabel($content);
        $content = $this->parserSpecifySortLabel($content);
        $content = $this->parserListLabel($content);
        $content = $this->parserSpecifyContentLabel($content);
        $content = $this->parserContentPicsLabel($content);
        $content = $this->parserContentCheckboxLabel($content);
        $content = $this->parserContentTagsLabel($content);
        $content = $this->parserSlideLabel($content);
        $content = $this->parserLinkLabel($content);
        $content = $this->parserMessageLabel($content);
        $content = $this->parserFormListLabel($content);
        $content = $this->parserSubmitFormLabel($content);
        $content = $this->parserQrcodeLabel($content);
        $content = $this->parserPageLabel($content);
        $content = $this->parserIfLabel($content);
        $content = $this->parserLoopLabel($content);
        $content = $this->restorePreLabel($content);
        foreach (array('{fd:geosummary}' => GeoHead::summaryHtml(...), '{fd:geofaq}' => GeoHead::faqHtml(...)) as $label => $html) {
            if (str_contains($content, $label)) {
                $content = str_replace($label, $html(), $content);
            }
        }
        return $this->parserReplaceKeyword($content);
    }

    public function savePreLabel(string $content): string
    {
        return preg_replace_callback('/\{fd:pre}([\s\S]*?)\{\/fd:pre\}/', fn (array $match): string => $this->protect($match[1]), $content) ?? $content;
    }

    public function restorePreLabel(string $content): string
    {
        // Restored values may contain other placeholders; each pass removes one level.
        for ($guard = 0; $guard < 8 && str_contains($content, '#pre:'); $guard++) {
            $content = preg_replace_callback('/\#pre:([0-9]+)\#/', fn (array $match): string => $this->pre[(int) $match[1]] ?? '', $content) ?? $content;
        }
        return $content;
    }

    public function parserSingleLabel(string $content): string
    {
        // Pboot only accepts member/sendEmail from pages that show {fd:sendemail}.
        $_SESSION['pboot_sendemail'] = str_contains($content, '{fd:sendemail}');
        $member = $this->data->member();
        $local = static fn (string $path): string => View::localizedPath($path);
        $url = $this->url();
        if ($url !== null) {
            return $this->parserPbootSingleLabel($content, $url);
        }
        $replace = array(
            ...$this->statusLabels(),
            '{fd:ucenter}' => $local('/member/ucenter'),
            '{fd:login}' => $local('/member/login'),
            '{fd:register}' => $local('/member/register'),
            '{fd:retrieve}' => $local('/member/retrieve'),
            '{fd:isregister}' => $local('/member/isRegister'),
            '{fd:umodify}' => $local('/member/umodify'),
            '{fd:logout}' => $local('/member/logout'),
            '{fd:upload}' => $local('/member/upload'),
            '{fd:sendemail}' => $local('/member/sendEmail'),
            '{fd:islogin}' => $member !== null ? '1' : '0',
            '{fd:msgaction}' => $local('/message'),
            '{fd:scaction}' => $local('/search'),
            '{fd:checkcode}' => '/core/code.php',
            '{fd:lgpath}' => 'javascript:;',
            '{fd:appid}' => $this->escape($this->config('api_appid')),
            '{fd:timestamp}' => (string) time(),
            '{fd:signature}' => md5(md5($this->config('api_appid') . $this->config('api_secret') . time())),
            '{fd:httpurl}' => $this->escape((string) ($this->env['http_url'] ?? '')),
            '{fd:pageurl}' => $this->escape((string) ($this->env['page_url'] ?? '')),
            '{fd:commentaction}' => $local('/comment/add') . '?contentid={content:id}',
            '{fd:mycommentpage}' => $local('/comment/my'),
        );
        if (str_contains($content, '{fd:mustlogin}')) {
            $replace['{fd:mustlogin}'] = '';
            if ($member === null) {
                $this->redirect = $local('/member/login');
            }
        }
        return strtr($content, $replace);
    }

    /** parserSingleLabel() switches from 配置参数: captchas (registercodestatus may be 2, the e-mail code) and features. */
    private function statusLabels(): array
    {
        $on = fn (string $key): string => $this->config($key) === '1' ? '1' : '0';
        return array(
            '{fd:msgcodestatus}' => $on('message_check_code'),
            '{fd:formcodestatus}' => $on('form_check_code'),
            '{fd:registercodestatus}' => in_array($this->config('register_check_code'), array('1', '2'), true) ? $this->config('register_check_code') : '0',
            '{fd:logincodestatus}' => $on('login_check_code'),
            '{fd:commentcodestatus}' => $on('comment_check_code'),
            '{fd:registerstatus}' => $on('register_status'),
            '{fd:loginstatus}' => $on('login_status'),
            '{fd:commentstatus}' => $on('comment_status'),
        );
    }

    /** Pboot addresses of the single labels, as Url::home() builds them for the configured URL mode. */
    private function parserPbootSingleLabel(string $content, PbootUrl $url): string
    {
        $member = $this->data->member();
        $backurl = is_string($this->env['query']['backurl'] ?? null) ? $this->env['query']['backurl'] : '';
        $replace = array(
            ...$this->statusLabels(),
            '{fd:ucenter}' => $url->home('member/ucenter'),
            '{fd:login}' => $url->home('member/login', null, $backurl !== '' ? 'backurl=' . urlencode($backurl) : ''),
            '{fd:register}' => $url->home('member/register'),
            '{fd:retrieve}' => $url->home('member/retrieve'),
            '{fd:isregister}' => $url->home('member/isRegister'),
            '{fd:umodify}' => $url->home('member/umodify'),
            '{fd:logout}' => $url->home('member/logout'),
            '{fd:upload}' => $url->home('member/upload'),
            '{fd:sendemail}' => $url->home('member/sendEmail'),
            '{fd:islogin}' => $member !== null ? '1' : '0',
            '{fd:msgaction}' => $url->home('message'),
            '{fd:scaction}' => $url->home('search'),
            '{fd:checkcode}' => '/core/code.php',
            '{fd:lgpath}' => 'javascript:;',
            '{fd:appid}' => $this->escape($this->config('api_appid')),
            '{fd:timestamp}' => (string) time(),
            '{fd:signature}' => md5(md5($this->config('api_appid') . $this->config('api_secret') . time())),
            '{fd:httpurl}' => $this->escape((string) ($this->env['http_url'] ?? '')),
            '{fd:pageurl}' => $this->escape((string) ($this->env['page_url'] ?? '')),
            '{fd:commentaction}' => $url->home('comment/add', null, 'contentid={content:id}'),
            '{fd:mycommentpage}' => $url->home('comment/my'),
        );
        if (str_contains($content, '{fd:mustlogin}')) {
            $replace['{fd:mustlogin}'] = '';
            if ($member === null) {
                $this->redirect = View::localizedPath('/member/login');
            }
        }
        return strtr($content, $replace);
    }

    public function parserSiteLabel(string $content): string
    {
        $pattern = '/\{fd:site([\w]+)(\s+[^}]+)?\}/';
        if (! preg_match($pattern, $content)) {
            return $content;
        }
        $site = $this->data->site();
        if ($site['subtitle'] === '') {
            $content = str_replace('{fd:sitetitle}-{fd:sitesubtitle}', '{fd:sitetitle}', $content);
        }
        return preg_replace_callback($pattern, function (array $match) use ($site): string {
            $params = $this->parserParam($match[2] ?? '');
            return match ($match[1]) {
                'index' => $this->url()?->home('home/Index/') ?? View::localizedPath('/'),
                'path' => '',
                'enter' => '',
                'logo' => $site['logo'] !== '' ? $this->value($params, $site['logo']) : self::STATIC_DIR . '/images/logo.png',
                'tplpath' => $this->escape((string) $this->env['tpl_path']),
                'language' => $this->escape($this->data->english() ? 'en' : 'cn'),
                'statistical' => $this->protect($site['statistical']),
                'copyright' => $this->value($params, $site['copyright'], true),
                default => isset($site[$match[1]]) ? $this->value($params, $site[$match[1]]) : '',
            };
        }, $content) ?? $content;
    }

    public function parserCompanyLabel(string $content): string
    {
        $pattern = '/\{fd:company([\w]+)(\s+[^}]+)?\}/';
        if (! preg_match($pattern, $content)) {
            return $content;
        }
        $company = $this->data->company();
        return preg_replace_callback($pattern, function (array $match) use ($company): string {
            $params = $this->parserParam($match[2] ?? '');
            if (strcasecmp($match[1], 'map') === 0) {
                $height = isset($params['height']) && ctype_digit((string) $params['height']) ? (int) $params['height'] : 320;
                return $this->protect(\FangdaysCMS\Cms\CompanyMap::embed($company, $height, (string) ($company['name'] ?? '')));
            }
            if (! array_key_exists($match[1], $company)) {
                return $match[0];
            }
            return $this->value($params, $company[$match[1]]);
        }, $content) ?? $content;
    }

    public function parserCustomerServiceLabel(string $content): string
    {
        if (! preg_match('/\{fd:customerservice(?:\s+[^}]*)?\}/i', $content)) {
            return $content;
        }
        $html = \FangdaysCMS\Cms\CustomerService::embed($this->data->company());
        return preg_replace('/\{fd:customerservice(?:\s+[^}]*)?\}/i', $this->protect($html), $content) ?? $content;
    }

    public function parserUserLabel(string $content): string
    {
        $pattern = '/\{label:([\w]+)(\s+[^}]+)?\}/';
        if (! preg_match($pattern, $content)) {
            return $content;
        }
        $labels = $this->data->labels();
        return preg_replace_callback($pattern, function (array $match) use ($labels): string {
            if (! $labels) {
                return '';
            }
            if (! isset($labels[$match[1]])) {
                return $match[0];
            }
            $label = $labels[$match[1]];
            return $this->value($this->parserParam($match[2] ?? ''), TemplateTags::normalize((string) $label['value']), $label['type'] === 2);
        }, $content) ?? $content;
    }

    /** Pboot parserMemberLabel(): {user:*} for the signed-in member (see MemberCenter::user()). */
    private function parserMemberLabel(string $content): string
    {
        $pattern = '/\{user:([\w]+)(\s+[^}]+)?\}/';
        if (! preg_match($pattern, $content)) {
            return $content;
        }
        $user = $this->data->member();
        return preg_replace_callback($pattern, function (array $match) use ($user): string {
            if ($user === null || $match[1] === 'password') {
                return '';
            }
            $params = $this->parserParam($match[2] ?? '');
            if ($match[1] === 'headpic') {
                return (string) ($user['headpic'] ?? '') !== '' ? $this->value($params, (string) $user['headpic']) : self::HEADPIC;
            }
            return isset($user[$match[1]]) && ! is_array($user[$match[1]]) ? $this->value($params, (string) $user[$match[1]]) : '';
        }, $content) ?? $content;
    }

    /** Pboot parserMyCommentLabel(): the signed-in member's comments with [mycomment:delaction]. */
    public function parserMyCommentLabel(string $content, MemberCenter $members, int $memberId): string
    {
        $pattern = '/\{fd:mycomment(\s+[^}]+)?\}([\s\S]*?)\{\/fd:mycomment\}/';
        $pattern2 = '/\[mycomment:([\w]+)(\s+[^]]+)?\]/';
        if (! preg_match_all($pattern, $content, $matches)) {
            return $content;
        }
        foreach ($matches[0] as $i => $whole) {
            $params = $this->parserParam($matches[1][$i]);
            $num = (int) ($params['num'] ?? ($this->config('pagesize') ?: 20));
            $start = is_numeric($params['start'] ?? null) && (int) $params['start'] >= 1 ? (int) $params['start'] : 1;
            $rows = $this->paged((bool) ($params['page'] ?? true), $num, fn (int $page, bool $count): array => $members->myComments($memberId, $num, $page, $start, $count));
            if (! $rows) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            preg_match_all($pattern2, $matches[2][$i], $matches2);
            $out = '';
            $key = 1;
            foreach ($rows as $value) {
                $one = $matches[2][$i];
                foreach ($matches2[0] as $j => $search) {
                    $p = $this->parserParam($matches2[2][$j]);
                    $label = $matches2[1][$j];
                    $replace = match ($label) {
                        'n' => (string) ($this->adjustLabelData($p, $key) - 1),
                        'i' => (string) $this->adjustLabelData($p, $key),
                        'delaction' => $this->href($members->address('comment/del', 'id=' . $value['id'])),
                        'link' => $this->href($this->data->contentLink(array('type' => '2', 'filename' => (string) $value['slug'], 'id' => (string) $value['contentid'], 'scode' => '', 'urlname' => '', 'sortfilename' => ''))),
                        'ip', 'os', 'bs' => $this->value($p, (string) $value['user_' . $label]),
                        default => array_key_exists($label, $value) ? $this->value($p, (string) $value[$label]) : '',
                    };
                    $one = str_replace($search, $replace, $one);
                }
                $key++;
                $out .= $one;
            }
            $content = $this->replaceOnce($whole, $out, $content);
        }
        return $content;
    }

    public function parserNavLabel(string $content): string
    {
        $pattern = '/\{fd:nav(\s+[^}]+)?\}([\s\S]*?)\{\/fd:nav\}/';
        $pattern2 = '/\[nav:([\w]+)(\s+[^]]+)?\]/';
        $pattern3 = '/fd:([0-9])+nav/';
        if (! preg_match_all($pattern, $content, $matches)) {
            return $content;
        }
        $data = $this->data->sortsTree();
        foreach ($matches[0] as $i => $whole) {
            if (! $data['tree']) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            $params = $this->parserParam($matches[1][$i]);
            if (! $this->checkLabelLevel($params)) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            $parent = (string) ($params['parent'] ?? '');
            $num = (int) ($params['num'] ?? 0);
            $scodes = isset($params['scode']) ? explode(',', (string) $params['scode']) : array();
            if ($parent !== '' && $parent !== '0') {
                $items = array();
                foreach (explode(',', $parent) as $value) {
                    $items = array_merge($items, $data['tree'][trim($value)]['son'] ?? array());
                }
            } else {
                $items = $data['top'];
            }
            if ($num) {
                $items = array_slice($items, 0, $num);
            }
            preg_match_all($pattern2, $matches[2][$i], $matches2);
            $out = '';
            $key = 1;
            foreach ($items as $value) {
                if ($scodes && ! in_array($value['scode'], $scodes, true)) {
                    continue;
                }
                $one = $matches[2][$i];
                foreach ($matches2[0] as $j => $search) {
                    $label = $matches2[1][$j];
                    $p = $this->parserParam($matches2[2][$j]);
                    $replace = match ($label) {
                        'n' => (string) ($this->adjustLabelData($p, $key) - 1),
                        'i' => (string) $this->adjustLabelData($p, $key),
                        'link' => $this->href($this->data->sortLink($value)),
                        'soncount' => (string) count($data['tree'][$value['scode']]['son'] ?? array()),
                        'rows' => (string) $this->data->sortRows($value['scode']),
                        'ico', 'pic' => $value[$label] !== '' ? $this->value($p, $value[$label]) : '',
                        default => array_key_exists($label, $value) && ! is_array($value[$label]) ? $this->value($p, $value[$label]) : null,
                    };
                    if ($replace !== null) {
                        $one = str_replace($search, $replace, $one);
                    }
                }
                $key++;
                $out .= $one;
            }
            if (preg_match($pattern3, $out, $matches3)) {
                $out = str_replace('fd:' . $matches3[1] . 'nav', 'fd:nav', $out);
                $out = str_replace('[' . $matches3[1] . 'nav:', '[nav:', $out);
                $out = $this->parserNavLabel($out);
            }
            $content = $this->replaceOnce($whole, $out, $content);
        }
        return $content;
    }

    public function parserPositionLabel(string $content, string $scode, ?string $page = null, ?string $link = null): string
    {
        $pattern = '/\{fd:position(\s+[^}]+)?\}/';
        if (! preg_match($pattern, $content)) {
            return $content;
        }
        $data = $scode !== '' && $scode !== '-1' && $scode !== '0' ? $this->data->position($scode) : array();
        return preg_replace_callback($pattern, function (array $match) use ($data, $scode, $page, $link): string {
            $params = $this->parserParam($match[1] ?? '', false);
            $separator = (string) ($params['separator'] ?? '');
            $indextext = (string) ($params['indextext'] ?? '');
            if (($params['separatoricon'] ?? '') !== '') {
                $separator = ' <i class="' . $this->escape((string) $params['separatoricon']) . '"></i> ';
            } elseif ($separator === '') {
                $separator = ' >> ';
            }
            if (($params['indexicon'] ?? '') !== '') {
                $indextext = '<i class="' . $this->escape((string) $params['indexicon']) . '"></i>';
            } elseif ($indextext === '') {
                $indextext = '首页';
            }
            $out = '<a href="' . $this->escape(View::localizedPath('/')) . '">' . $indextext . '</a>';
            if ($page !== null && ($scode === '0' || $scode === '-1')) {
                $out .= $separator . '<a href="' . $this->escape((string) $link) . '">' . $this->escape($page) . '</a>';
            } else {
                foreach ($data as $value) {
                    $out .= $separator . '<a href="' . $this->href($this->data->sortLink($value)) . '">' . $this->escape($value['name']) . '</a>';
                }
            }
            return $out;
        }, $content) ?? $content;
    }

    public function parserSortLabel(string $content, array $sort): string
    {
        $pattern = '/\{sort:([\w]+)(\s+[^}]+)?\}/';
        if (! preg_match($pattern, $content)) {
            return $content;
        }
        $tcode = null;
        return preg_replace_callback($pattern, function (array $match) use ($sort, &$tcode): string {
            $params = $this->parserParam($match[2] ?? '');
            $top = function () use ($sort, &$tcode): string {
                return $tcode ??= $this->data->topScode($sort['scode']);
            };
            switch ($match[1]) {
                case 'link':
                    return $this->href($this->data->sortLink($sort));
                case 'tcode':
                    return $this->escape($top());
                case 'topname':
                    return $this->value($params, (string) ($this->data->sort($top())['name'] ?? ''));
                case 'toplink':
                    $topSort = $this->data->sort($top());
                    return $topSort === null ? '' : $this->href($this->data->sortLink($topSort));
                case 'parentname':
                    return $this->value($params, $sort['pcode'] === '0' ? $sort['name'] : $sort['parentname']);
                case 'parentlink':
                    $parent = $sort['pcode'] === '0' ? $sort : $this->data->sort($sort['pcode']);
                    return $parent === null ? '' : $this->href($this->data->sortLink($parent));
                case 'toprows':
                    return (string) $this->data->sortRows($top());
                case 'parentrows':
                    return (string) $this->data->sortRows($sort['pcode'] === '0' ? $sort['scode'] : $sort['pcode']);
                case 'rows':
                    return (string) $this->data->sortRows($sort['scode']);
                case 'ico':
                    return $sort['ico'] !== '' ? $this->value($params, $sort['ico']) : '';
                case 'pic':
                    if ($sort['pic'] !== '') {
                        return $this->value($params, $sort['pic']);
                    }
                    $topPic = (string) ($this->data->sort($top())['pic'] ?? '');
                    return $this->value($params, $topPic !== '' ? $topPic : '/images/nobanner.jpg');
                case 'keywords':
                    return $sort['keywords'] !== '' ? $this->value($params, $sort['keywords']) : '{fd:sitekeywords}';
                case 'description':
                    return $sort['description'] !== '' ? $this->value($params, $sort['description']) : '{fd:sitedescription}';
                default:
                    return array_key_exists($match[1], $sort) && ! is_array($sort[$match[1]]) ? $this->value($params, $sort[$match[1]]) : '';
            }
        }, $content) ?? $content;
    }

    /** {sort:*} on pages without a category (home, search, tags). */
    public function parserSpecialPageSortLabel(string $content, string $id, string $page, string $link): string
    {
        return preg_replace_callback('/\{sort:([\w]+)(\s+[^}]+)?\}/', function (array $match) use ($id, $page, $link): string {
            return match ($match[1]) {
                'tcode', 'pcode', 'scode' => $this->escape($id),
                'topname', 'parentname', 'name' => $this->escape($page),
                'toplink', 'parentlink', 'link' => $this->escape($link),
                'keywords' => '{fd:sitekeywords}',
                'description' => '{fd:sitedescription}',
                default => '',
            };
        }, $content) ?? $content;
    }

    public function parserSpecifySortLabel(string $content): string
    {
        $pattern = '/\{fd:sort(\s+[^}]+)?\}([\s\S]*?)\{\/fd:sort\}/';
        $pattern2 = '/\[sort:([\w]+)(\s+[^]]+)?\]/';
        if (! preg_match_all($pattern, $content, $matches)) {
            return $content;
        }
        foreach ($matches[0] as $i => $whole) {
            $params = $this->parserParam($matches[1][$i]);
            if (! array_key_exists('scode', $params)) {
                continue;
            }
            if (! $this->checkLabelLevel($params)) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            $data = $this->data->multSort((string) ($params['scode'] ?: '-1'));
            if (! $data) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            preg_match_all($pattern2, $matches[2][$i], $matches2);
            $out = '';
            $key = 1;
            foreach ($data as $value) {
                $one = $matches[2][$i];
                foreach ($matches2[0] as $j => $search) {
                    $label = $matches2[1][$j];
                    $p = $this->parserParam($matches2[2][$j]);
                    $replace = match ($label) {
                        'n' => (string) ($this->adjustLabelData($p, $key) - 1),
                        'i' => (string) $this->adjustLabelData($p, $key),
                        'link' => $this->href($this->data->sortLink($value)),
                        'ico', 'pic' => $value[$label] !== '' ? $this->value($p, $value[$label]) : '',
                        'rows' => (string) $this->data->sortRows($value['scode']),
                        default => array_key_exists($label, $value) && ! is_array($value[$label]) ? $this->value($p, $value[$label]) : null,
                    };
                    if ($replace !== null) {
                        $one = str_replace($search, $replace, $one);
                    }
                }
                $key++;
                $out .= $one;
            }
            $content = $this->replaceOnce($whole, $out, $content);
        }
        return $content;
    }

    public function parserListLabel(string $content, string $cscode = ''): string
    {
        $pattern = '/\{fd:list(\s+[^}]+)?\}([\s\S]*?)\{\/fd:list\}/';
        $pattern2 = '/\[list:([\w\+\-\*\/\%]+)(\s+[^]]+)?\]/';
        if (! preg_match_all($pattern, $content, $matches)) {
            return $content;
        }
        foreach ($matches[0] as $i => $whole) {
            $params = $this->parserParam($matches[1][$i]);
            if (! $this->checkLabelLevel($params)) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            if ($cscode !== '' && ! array_key_exists('scode', $params)) {
                $scode = $cscode;
                $page = true;
            } elseif ($cscode === '' && array_key_exists('scode', $params)) {
                $scode = (string) $params['scode'];
                $page = false;
            } else {
                continue;
            }
            if ($scode === '*') {
                $scode = '';
            }
            [$criteria, $num, $start, $page] = $this->listParams($params, $scode, $page);
            if ($page) {
                $query = $this->env['query'] ?? array();
                if (is_string($query['tag'] ?? null) && $query['tag'] !== '') {
                    $criteria['tags'] = array_merge($criteria['tags'] ?? array(), array($query['tag']));
                }
                foreach ($query as $key => $value) {
                    if (is_string($key) && preg_match('/^ext_[\w\-]+$/', $key) && is_string($value)) {
                        $criteria['ext'][$key] = $value;
                    }
                }
            }
            $rows = $this->fetchContents($criteria, $num, $start, $page);
            if (! $rows) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            preg_match_all($pattern2, $matches[2][$i], $matches2);
            $out = '';
            $key = 1;
            foreach ($rows as $value) {
                $one = $matches[2][$i];
                foreach ($matches2[0] as $j => $search) {
                    $one = $this->parserList($matches2[1][$j], $search, $one, $value, $this->parserParam($matches2[2][$j]), $key);
                }
                $key++;
                $out .= $one;
            }
            $content = $this->replaceOnce($whole, $out, $content);
        }
        return $content;
    }

    public function parserCurrentContentLabel(string $content, array $sort, array $data): string
    {
        return preg_replace_callback('/\{content:([\w]+)(\s+[^}]+)?\}/', function (array $match) use ($sort, $data): string {
            return $this->contentField($match[1], $data, $this->parserParam($match[2] ?? ''), $sort) ?? $match[0];
        }, $content) ?? $content;
    }

    public function parserSpecifyContentLabel(string $content): string
    {
        $pattern = '/\{fd:content(\s+[^}]+)?\}([\s\S]*?)\{\/fd:content\}/';
        $pattern2 = '/\[content:([\w]+)(\s+[^]]+)?\]/';
        if (! preg_match_all($pattern, $content, $matches)) {
            return $content;
        }
        foreach ($matches[0] as $i => $whole) {
            $params = $this->parserParam($matches[1][$i]);
            if (! $this->checkLabelLevel($params)) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            if (array_key_exists('id', $params)) {
                $data = $this->data->content((string) $params['id']) ?? $this->data->singleByContentId((string) $params['id']);
            } elseif (array_key_exists('scode', $params)) {
                $data = $this->data->about((string) $params['scode']);
            } else {
                continue;
            }
            if ($data === null) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            $sort = $this->data->sort((string) $data['scode']) ?? array('scode' => (string) $data['scode']);
            $out = preg_replace_callback($pattern2, function (array $match) use ($data, $sort): string {
                return $this->contentField($match[1], $data, $this->parserParam($match[2] ?? ''), $sort) ?? $match[0];
            }, $matches[2][$i]) ?? $matches[2][$i];
            $content = $this->replaceOnce($whole, $out, $content);
        }
        return $content;
    }

    public function parserContentPicsLabel(string $content): string
    {
        $pattern = '/\{fd:pics(\s+[^}]+)?\}([\s\S]*?)\{\/fd:pics\}/';
        $pattern2 = '/\[pics:([\w]+)(\s+[^]]+)?\]/';
        if (! preg_match_all($pattern, $content, $matches)) {
            return $content;
        }
        foreach ($matches[0] as $i => $whole) {
            $params = $this->parserParam($matches[1][$i]);
            if (! $this->checkLabelLevel($params)) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            if (! array_key_exists('id', $params)) {
                continue;
            }
            $num = isset($params['num']) ? (int) $params['num'] : null;
            $set = $this->data->contentPics((string) $params['id'], (string) ($params['field'] ?? 'pics'));
            $pics = array_values(array_filter($set['pics'], static fn (string $pic): bool => $pic !== ''));
            if (! $pics) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            preg_match_all($pattern2, $matches[2][$i], $matches2);
            $out = '';
            $key = 1;
            foreach ($set['pics'] as $vkey => $value) {
                if ($value === '') {
                    continue;
                }
                $one = $matches[2][$i];
                foreach ($matches2[0] as $j => $search) {
                    $p = $this->parserParam($matches2[2][$j]);
                    $one = str_replace($search, match ($matches2[1][$j]) {
                        'n' => (string) ($this->adjustLabelData($p, $key) - 1),
                        'i' => (string) $this->adjustLabelData($p, $key),
                        'src' => $this->value($p, $value),
                        'title' => $this->value($p, (string) ($set['titles'][$vkey] ?? '')),
                        default => '',
                    }, $one);
                }
                $key++;
                $out .= $one;
                if ($num !== null && $key > $num) {
                    break;
                }
            }
            $content = $this->replaceOnce($whole, $out, $content);
        }
        return $content;
    }

    public function parserContentCheckboxLabel(string $content): string
    {
        $pattern = '/\{fd:checkbox(\s+[^}]+)?\}([\s\S]*?)\{\/fd:checkbox\}/';
        $pattern2 = '/\[checkbox:([\w]+)(\s+[^]]+)?\]/';
        if (! preg_match_all($pattern, $content, $matches)) {
            return $content;
        }
        foreach ($matches[0] as $i => $whole) {
            $params = $this->parserParam($matches[1][$i]);
            if (! $this->checkLabelLevel($params)) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            if (! array_key_exists('id', $params) || ! array_key_exists('field', $params)) {
                continue;
            }
            $raw = $this->data->contentField((string) $params['id'], (string) $params['field']);
            if ($raw === '') {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            preg_match_all($pattern2, $matches[2][$i], $matches2);
            $out = '';
            $key = 1;
            foreach (explode(',', $raw) as $value) {
                $one = $matches[2][$i];
                foreach ($matches2[0] as $j => $search) {
                    $p = $this->parserParam($matches2[2][$j]);
                    $replace = match ($matches2[1][$j]) {
                        'n' => (string) ($this->adjustLabelData($p, $key) - 1),
                        'i' => (string) $this->adjustLabelData($p, $key),
                        'text' => $this->value($p, $value),
                        default => null,
                    };
                    if ($replace !== null) {
                        $one = str_replace($search, $replace, $one);
                    }
                }
                $key++;
                $out .= $one;
            }
            $content = $this->replaceOnce($whole, $out, $content);
        }
        return $content;
    }

    public function parserContentTagsLabel(string $content): string
    {
        $pattern = '/\{fd:tags(\s+[^}]+)?\}([\s\S]*?)\{\/fd:tags\}/';
        $pattern2 = '/\[tags:([\w]+)(\s+[^]]+)?\]/';
        if (! preg_match_all($pattern, $content, $matches)) {
            return $content;
        }
        foreach ($matches[0] as $i => $whole) {
            $params = $this->parserParam($matches[1][$i]);
            if (! $this->checkLabelLevel($params)) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            $id = (string) ($params['id'] ?? '');
            $scode = (string) ($params['scode'] ?? '');
            $num = isset($params['num']) ? (int) $params['num'] : null;
            $target = (string) ($params['target'] ?? 'list');
            $data = array();
            if ($id !== '') {
                $row = ctype_digit($id) ? $this->data->content($id) : null;
                if ($row !== null && $row['tags'] !== '') {
                    $sort = $this->data->sort($scode !== '' ? $scode : (string) $row['scode']);
                    foreach (explode(',', (string) $row['tags']) as $tag) {
                        $data[] = array('sort' => $sort, 'tags' => $tag);
                    }
                }
            } elseif ($scode !== '') {
                foreach (explode(',', $scode) as $value) {
                    $sort = $this->data->sort(trim($value));
                    foreach ($this->data->sortTags(trim($value)) as $tag) {
                        if (! in_array($tag, array_column($data, 'tags'), true)) {
                            $data[] = array('sort' => $sort, 'tags' => $tag);
                        }
                    }
                }
            } else {
                $target = 'tag';
                foreach (array_unique($this->data->sortTags('')) as $tag) {
                    $data[] = array('sort' => null, 'tags' => $tag);
                }
            }
            if (! $data) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            preg_match_all($pattern2, $matches[2][$i], $matches2);
            $out = '';
            $key = 1;
            foreach ($data as $value) {
                $one = $matches[2][$i];
                foreach ($matches2[0] as $j => $search) {
                    $p = $this->parserParam($matches2[2][$j]);
                    $replace = match ($matches2[1][$j]) {
                        'n' => (string) ($this->adjustLabelData($p, $key) - 1),
                        'i' => (string) $this->adjustLabelData($p, $key),
                        'text' => $this->value($p, $value['tags']),
                        'link' => $this->href($this->tagLink($value['tags'], $target === 'tag' ? null : $value['sort'])),
                        default => null,
                    };
                    if ($replace !== null) {
                        $one = str_replace($search, $replace, $one);
                    }
                }
                $key++;
                $out .= $one;
                if ($num !== null && $key > $num) {
                    break;
                }
            }
            $content = $this->replaceOnce($whole, $out, $content);
        }
        return $content;
    }

    public function parserSlideLabel(string $content): string
    {
        return $this->parserGroupLabel($content, 'slide', 20, 'pic', 'src', fn (int $gid, int $num, int $start): array => $this->data->slides($gid, $num, $start));
    }

    public function parserLinkLabel(string $content): string
    {
        return $this->parserGroupLabel($content, 'link', 10, 'logo', 'logo', fn (int $gid, int $num, int $start): array => $this->data->links($gid, $num, $start));
    }

    public function parserPageLabel(string $content): string
    {
        return preg_replace_callback('/\{page:([\w]+)\}/', function (array $match): string {
            $vars = $this->pageVars;
            return match ($match[1]) {
                'bar', 'numbar', 'selectbar', 'index', 'pre', 'next', 'last', 'status' => (string) ($vars[$match[1]] ?? ''),
                'current', 'count', 'rows' => (string) ($vars[$match[1]] ?? 0),
                default => $match[0],
            };
        }, $content) ?? $content;
    }

    public function parserLoopLabel(string $content): string
    {
        $pattern = '/\{fd:loop(\s+[^}]+)?\}([\s\S]*?)\{\/fd:loop\}/';
        if (! preg_match_all($pattern, $content, $matches)) {
            return $content;
        }
        foreach ($matches[0] as $i => $whole) {
            $params = $this->parserParam($matches[1][$i]);
            if (! $this->checkLabelLevel($params)) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            $start = (int) ($params['start'] ?? 1);
            $end = min((int) ($params['end'] ?? ($this->config('pagesize') ?: 20)), $start + 1000);
            $out = '';
            $key = 1;
            for ($n = $start; $n <= $end; $n++) {
                $out .= str_replace(array('[loop:n]', '[loop:i]', '[loop:index]'), array((string) ($key - 1), (string) $key, (string) $n), $matches[2][$i]);
                $key++;
            }
            $content = $this->replaceOnce($whole, $out, $content);
        }
        return $content;
    }

    public function parserIfLabel(string $content): string
    {
        $pattern = '/\{fd:if\(([^}^\$]+)\)\}([\s\S]*?)\{\/fd:if\}/';
        $pattern2 = '/fd:([0-9])+if/';
        if (! preg_match_all($pattern, $content, $matches)) {
            return $content;
        }
        foreach ($matches[0] as $i => $whole) {
            // Pboot also skips conditions naming PHP functions; symbol() never executes code, so that guard is not needed here.
            $condition = $this->restorePreLabel($matches[1][$i]);
            $condition = strtolower(str_ireplace(array('.', '\\x', '//', '%2F%2F', '/*', '/%2A', '%2F%2A', '%2F*', '%28', '%29', '(', ')', ';', '%3B', '%60', '`'), '', $condition));
            $flag = self::symbol($condition);
            $out = '';
            if (preg_match('/^([\s\S]*)\{else\}([\s\S]*)$/', $matches[2][$i], $branches)) {
                $out = $flag === 'if' ? $branches[1] : ($flag === 'else' ? $branches[2] : '');
            } elseif ($flag === 'if') {
                $out = $matches[2][$i];
            }
            if (preg_match($pattern2, $out, $matches3)) {
                $out = str_replace('fd:' . $matches3[1] . 'if', 'fd:if', $out);
                $out = str_replace('{' . $matches3[1] . 'else}', '{else}', $out);
                $out = $this->parserIfLabel($out);
            }
            $content = $this->replaceOnce($whole, $out, $content);
        }
        return $content;
    }

    /** Pboot core helper symbol(): evaluates a label condition without eval(). */
    public static function symbol(string $condition): string
    {
        foreach (array('&&', '||') as $operator) {
            if (str_contains($condition, $operator)) {
                $parts = explode($operator, $condition);
                $left = self::compare($parts[0]);
                $right = self::compare($parts[1]);
                return ($operator === '&&' ? ($left && $right) : ($left || $right)) ? 'if' : 'else';
            }
        }
        return self::compare($condition) ? 'if' : 'else';
    }

    private static function compare(string $string): bool
    {
        foreach (array('>=', '<=', '!=', '==', '>', '<') as $operator) {
            if (str_contains($string, $operator)) {
                $parts = explode($operator, $string);
                $left = self::operand($parts[0]);
                $right = self::operand($parts[1]);
                return match ($operator) {
                    '>' => $left > $right,
                    '>=' => $left >= $right,
                    '!=' => $left != $right,
                    '==' => $left == $right,
                    '<=' => $left <= $right,
                    '<' => $left < $right,
                };
            }
        }
        return trim((string) self::operand($string)) !== '' && trim((string) self::operand($string)) !== '0';
    }

    private static function operand(string $string): int|float|string
    {
        if (str_contains($string, '%')) {
            $parts = explode('%', $string);
            $divisor = (int) trim($parts[1], " '");
            return $divisor === 0 ? 0 : (int) trim($parts[0], " '") % $divisor;
        }
        return (string) trim(trim($string), "'");
    }

    /** Pboot adjustLabelData(): filters such as len, lencn, style, drophtml. */
    public function adjustLabelData(array $params, mixed $data, ?string $label = null): mixed
    {
        if ($data === '' || $data === null || $data === 0 || $data === '0') {
            return $data;
        }
        $data = $this->thumbnail($params, $data);
        if (! $this->checkLabelLevel($params)) {
            return '';
        }
        foreach ($params as $key => $value) {
            switch ($key) {
                case 'style':
                    if ($value !== '' && is_string($data) && ($time = strtotime($data)) !== false) {
                        $data = date((string) $value, $time);
                    }
                    break;
                case 'len':
                    if ((int) $value > 0 && is_string($data) && mb_strlen($data, 'UTF-8') > (int) $value) {
                        $data = mb_substr($data, 0, (int) $value, 'UTF-8') . ($params['more'] ?? '···');
                    }
                    break;
                case 'lencn':
                    if ((int) $value > 0 && is_string($data) && self::strlenBoth($data) > (int) $value) {
                        $data = self::substrBoth($data, 0, (int) $value) . ($params['more'] ?? '···');
                    }
                    break;
                case 'drophtml':
                    if ($value) {
                        $data = strip_tags((string) $data);
                    }
                    break;
                case 'dropblank':
                    if ($value) {
                        $data = preg_replace('/\s+/', ' ', str_replace(array("\r\n", "\n", "\t", '　', '&nbsp;', "\u{00A0}"), '', (string) $data)) ?? (string) $data;
                    }
                    break;
                case 'substr':
                    if ($value !== '' && is_string($data)) {
                        $arr = explode(',', (string) $value);
                        $data = count($arr) === 2 && $arr[1] ? mb_substr($data, (int) $arr[0] - 1, (int) $arr[1], 'UTF-8') : mb_substr($data, (int) $arr[0] - 1, null, 'UTF-8');
                    }
                    break;
                case 'unit':
                    $powers = array('kb' => 1, 'mb' => 2, 'gb' => 3, 'tb' => 4, 'pb' => 5, 'eb' => 6);
                    if (isset($powers[strtolower((string) $value)])) {
                        $data = (float) $data / (1024 ** $powers[strtolower((string) $value)]);
                    }
                    break;
                case 'decimal':
                    if ($value) {
                        $data = number_format((float) $data, (int) $value);
                    }
                    break;
                case 'operate':
                    if (preg_match('/^([\+\-\*\/\%])([0-9\.]+)$/', (string) $value, $math)) {
                        $number = is_numeric($data) ? $data + 0 : 0;
                        $operand = $math[2] + 0;
                        $data = match ($math[1]) {
                            '+' => $number + $operand,
                            '-' => $number - $operand,
                            '*' => $number * $operand,
                            '/' => $operand == 0 ? 0 : $number / $operand,
                            '%' => (int) $operand === 0 ? 0 : (int) $number % (int) $operand,
                        };
                    }
                    break;
            }
        }
        return $data;
    }

    /**
     * adjustLabelData() image parameters: maxwidth/maxheight scale down, width/height crop. Copies are
     * kept under /runtime/image like Pboot's RUN_PATH; only existing images of this site are touched.
     */
    private function thumbnail(array $params, mixed $data): mixed
    {
        $root = (string) ($this->env['public_root'] ?? '');
        if ($root === '' || ! is_string($data) || ! array_intersect_key($params, array('maxwidth' => 1, 'maxheight' => 1, 'width' => 1, 'height' => 1))) {
            return $data;
        }
        $size = static fn (string $key): ?int => isset($params[$key]) && ctype_digit((string) $params[$key]) && (int) $params[$key] > 0 && (int) $params[$key] <= 4000 ? (int) $params[$key] : null;
        $source = \FangdaysCMS\Cms\ImageTools::inside($root, $data);
        if ($source === null) {
            return $data;
        }
        foreach (array(array('maxwidth', 'maxheight', 'mw', 'mh'), array('width', 'height', 'w', 'h')) as [$wKey, $hKey, $wTag, $hTag]) {
            $width = $size($wKey);
            $height = $size($hKey);
            if ($width === null && $height === null) {
                continue;
            }
            $name = '/runtime/image/' . $wTag . $width . '_' . $hTag . $height . '_' . basename($data);
            $target = $root . $name;
            if (! is_file($target)) {
                $made = $wTag === 'mw'
                    ? \FangdaysCMS\Cms\ImageTools::resize($source, $target, $width, $height)
                    : \FangdaysCMS\Cms\ImageTools::cut($source, $target, $width, $height);
                if (! $made) {
                    continue;
                }
            }
            $data = $name;
            $source = $target;
        }
        return $data;
    }

    /** Pboot parserParam(): name=value pairs inside a label. */
    public function parserParam(string $string, bool $striptags = true): array
    {
        $string = trim($string);
        if ($string === '') {
            return array();
        }
        $string = preg_replace('/\s+/', ' ', $string) ?? $string;
        if ($striptags) {
            $string = strip_tags($string);
        }
        $param = array();
        if (preg_match_all('/([\w]+)[\s]?=[\s]?([\"]([^\"]+)?[\"]|[\']([^\']+)?[\']|([^\s]+))/i', $string, $matches)) {
            foreach ($matches[1] as $key => $value) {
                $param[$value] = ($matches[3][$key] ?? '') ?: (($matches[4][$key] ?? '') ?: ($matches[5][$key] ?? ''));
            }
        }
        return $param;
    }

    /** Pboot checkLabelLevel(): member group / login visibility parameters. */
    public function checkLabelLevel(array $params): bool
    {
        $member = $this->data->member();
        $gcode = (string) ($member['gcode'] ?? ($member['group_id'] ?? ''));
        $ucode = (string) ($member['id'] ?? '');
        $level = (int) $gcode;
        foreach ($params as $key => $value) {
            $value = (string) $value;
            $ok = match ($key) {
                'showgcode' => in_array($gcode, explode(',', $value), true),
                'showucode' => in_array($ucode, explode(',', $value), true),
                'hidegcode' => ! in_array($gcode, explode(',', $value), true),
                'hideucode' => ! in_array($ucode, explode(',', $value), true),
                'showgcodelt' => (int) $value > $level,
                'showgcodegt' => (int) $value < $level,
                'showgcodele' => (int) $value >= $level,
                'showgcodege' => (int) $value <= $level,
                'hidegcodelt' => (int) $value <= $level,
                'hidegcodegt' => (int) $value >= $level,
                'hidegcodele' => (int) $value < $level,
                'hidegcodege' => (int) $value > $level,
                'showlogin' => ! $value || $member !== null,
                'hidelogin' => ! $value || $member === null,
                default => true,
            };
            if (! $ok) {
                return false;
            }
        }
        return true;
    }

    /** Pboot parserSearchLabel(): results for keyword, field and other query conditions. */
    public function parserSearchLabel(string $content): string
    {
        $pattern = '/\{fd:search(\s+[^}]+)?\}([\s\S]*?)\{\/fd:search\}/';
        $pattern2 = '/\[search:([\w]+)(\s+[^]]+)?\]/';
        if (! preg_match_all($pattern, $content, $matches)) {
            return $content;
        }
        $query = $this->env['query'] ?? array();
        $requestField = is_string($query['field'] ?? null) && preg_match('/^[\w\|\s]+$/', $query['field']) ? $query['field'] : '';
        $requestScode = is_string($query['scode'] ?? null) && preg_match('/^[\w,\s]+$/', $query['scode']) ? $query['scode'] : '';
        $keyword = is_string($query['keyword'] ?? null) ? trim($query['keyword']) : '';
        foreach ($matches[0] as $i => $whole) {
            $params = $this->parserParam($matches[1][$i]);
            if (! $this->checkLabelLevel($params)) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            $field = (string) ($params['field'] ?? $requestField);
            $scode = (string) ($params['scode'] ?? $requestScode);
            [$criteria, $num, $start, $page] = $this->listParams($params, $scode === '*' ? '' : $scode, true);
            $conditions = array();
            if ($keyword !== '') {
                if (str_contains($field, '|')) {
                    $criteria['anyof'] = array(array_map('trim', explode('|', $field)), $keyword);
                } else {
                    $conditions[$field !== '' ? trim($field) : 'title'] = $keyword;
                }
            }
            foreach ($query as $key => $value) {
                if (is_string($key) && is_string($value) && trim($value) !== '' && preg_match('/^[\w\-\.]+$/', $key) && ! in_array($key, array('keyword', 'field', 'scode', 'page', 'from', 'isappinstalled', 'tdsourcetag', 'x', 'y', 'searchtpl', 'p', 's'), true) && $this->data->searchable($key)) {
                    $conditions[$key] = trim($value);
                }
            }
            if (! $conditions && ! isset($criteria['anyof'])) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            $criteria['ext'] = $conditions + ($criteria['ext'] ?? array());
            $rows = $this->fetchContents($criteria, $num, $start, $page);
            if (! $rows) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            preg_match_all($pattern2, $matches[2][$i], $matches2);
            $out = '';
            $key = 1;
            foreach ($rows as $value) {
                $one = $matches[2][$i];
                foreach ($matches2[0] as $j => $search) {
                    $one = $this->parserList($matches2[1][$j], $search, $one, $value, $this->parserParam($matches2[2][$j]), $key);
                }
                $key++;
                $out .= $one;
            }
            $content = $this->replaceOnce($whole, $out, $content);
        }
        return $content;
    }

    /** Pboot parserSelectAllLabel(): the "all" link of an extension-field filter. */
    public function parserSelectAllLabel(string $content): string
    {
        return preg_replace_callback('/\{fd:selectall(\s+[^}]+)?\}/', function (array $match): string {
            $params = $this->parserParam($match[1] ?? '');
            $field = (string) ($params['field'] ?? '');
            if ($field === '') {
                return $match[0];
            }
            $query = $this->filterQuery();
            unset($query[$field]);
            $current = $this->env['query'][$field] ?? '';
            $class = is_string($current) && $current !== '' ? (string) ($params['class'] ?? '') : (string) ($params['active'] ?? '');
            return '<a href="' . $this->href($this->filterLink($query)) . '" class="' . $this->escape($class) . '">' . $this->escape((string) ($params['text'] ?? '全部')) . '</a>';
        }, $content) ?? $content;
    }

    /** Pboot parserSelectLabel(): one link per option of an extension field. */
    public function parserSelectLabel(string $content): string
    {
        $pattern = '/\{fd:select(\s+[^}]+)?\}([\s\S]*?)\{\/fd:select\}/';
        $pattern2 = '/\[select:([\w]+)(\s+[^]]+)?\]/';
        if (! preg_match_all($pattern, $content, $matches)) {
            return $content;
        }
        foreach ($matches[0] as $i => $whole) {
            $params = $this->parserParam($matches[1][$i]);
            $field = (string) ($params['field'] ?? '');
            if ($field === '') {
                continue;
            }
            $options = $this->data->selectOptions($field);
            if (! $options) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            $current = is_string($this->env['query'][$field] ?? null) ? (string) $this->env['query'][$field] : '';
            preg_match_all($pattern2, $matches[2][$i], $matches2);
            $out = '';
            $key = 1;
            foreach ($options as $value) {
                $one = $matches[2][$i];
                foreach ($matches2[0] as $j => $search) {
                    $p = $this->parserParam($matches2[2][$j]);
                    $replace = match ($matches2[1][$j]) {
                        'n' => (string) ($this->adjustLabelData($p, $key) - 1),
                        'i' => (string) $this->adjustLabelData($p, $key),
                        'value' => $this->escape($value),
                        'current' => $this->escape($current),
                        'link' => $this->href($this->filterLink(array_merge($this->filterQuery(), array($field => $value)))),
                        default => null,
                    };
                    if ($replace !== null) {
                        $one = str_replace($search, $replace, $one);
                    }
                }
                $key++;
                $out .= $one;
            }
            $content = $this->replaceOnce($whole, $out, $content);
        }
        return $content;
    }

    /** Pboot parserSubmitFormLabel(): {fd:form fcode=...} as the form's submit address. */
    public function parserSubmitFormLabel(string $content): string
    {
        return preg_replace_callback('/\{fd:form(\s+[^}]+)?\}/', function (array $match): string {
            $fcode = (string) ($this->parserParam($match[1] ?? '')['fcode'] ?? '');
            if ($fcode === '') {
                return $match[0];
            }
            return $this->href($this->url()?->home('form/' . $fcode) ?? View::localizedPath('/form/') . rawurlencode($fcode));
        }, $content) ?? $content;
    }

    /** Pboot parserQrcodeLabel(): an image served by the /qrcode route. */
    public function parserQrcodeLabel(string $content): string
    {
        return preg_replace_callback('/\{fd:qrcode(\s+[^}]+)?\}/', function (array $match): string {
            $string = html_entity_decode((string) ($this->parserParam($match[1] ?? '')['string'] ?? ''), ENT_QUOTES | ENT_HTML5, 'UTF-8');
            if ($string === '') {
                return $match[0];
            }
            $base = $this->url() !== null ? '/core/qrcode.php' : View::localizedPath('/qrcode');
            return '<img src="' . $this->escape($base . '?string=' . urlencode($string)) . '" class="qrcode" alt="二维码">';
        }, $content) ?? $content;
    }

    /** Pboot parserCommentLabel(): approved comments of the current content. */
    /** Pboot parserCommentLabel(): approved comments of a content, each with its {fd:commentsub} replies. */
    public function parserCommentLabel(string $content): string
    {
        $pattern = '/\{fd:comment(\s+[^}]+)?\}([\s\S]*?)\{\/fd:comment\}/';
        $pattern2 = '/\[comment:([\w]+)(\s+[^]]+)?\]/';
        $pattern3 = '/\{fd:commentsub(\s+[^}]+)?\}([\s\S]*?)\{\/fd:commentsub\}/';
        $pattern4 = '/\[commentsub:([\w]+)(\s+[^]]+)?\]/';
        if (! preg_match_all($pattern, $content, $matches)) {
            return $content;
        }
        foreach ($matches[0] as $i => $whole) {
            $params = $this->parserParam($matches[1][$i]);
            if (! $this->checkLabelLevel($params)) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            if (! ctype_digit((string) ($params['contentid'] ?? ''))) {
                continue;
            }
            $num = (int) ($params['num'] ?? ($this->config('pagesize') ?: 20));
            $start = is_numeric($params['start'] ?? null) && (int) $params['start'] >= 1 ? (int) $params['start'] : 1;
            $postId = (int) $params['contentid'];
            $rows = $this->paged((bool) ($params['page'] ?? true), $num, fn (int $page, bool $count): array => $this->data->comments($postId, $num, $page, $start, $count));
            if (! $rows) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            preg_match_all($pattern2, $matches[2][$i], $matches2);
            $out = '';
            $key = 1;
            foreach ($rows as $value) {
                $one = $this->commentFields($matches[2][$i], $matches2, $value, $key);
                $one = preg_replace_callback($pattern3, function (array $sub) use ($value, $postId, $pattern4): string {
                    $replies = $this->data->comments($postId, 100, 1, 1, false, (int) $value['id'])['rows'];
                    preg_match_all($pattern4, $sub[2], $fields);
                    $html = '';
                    foreach ($replies as $n => $reply) {
                        $html .= $this->commentFields($sub[2], $fields, $reply, $n + 1);
                    }
                    return $html;
                }, $one) ?? $one;
                $out .= $one;
                $key++;
            }
            $content = $this->replaceOnce($whole, $out, $content);
        }
        return $content;
    }

    /** Pboot parserMessageLabel(): approved guestbook messages. */
    public function parserMessageLabel(string $content): string
    {
        $pattern = '/\{fd:message(\s+[^}]+)?\}([\s\S]*?)\{\/fd:message\}/';
        $pattern2 = '/\[message:([\w]+)(\s+[^]]+)?\]/';
        if (! preg_match_all($pattern, $content, $matches)) {
            return $content;
        }
        foreach ($matches[0] as $i => $whole) {
            $params = $this->parserParam($matches[1][$i]);
            if (! $this->checkLabelLevel($params)) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            $num = (int) ($params['num'] ?? ($this->config('pagesize') ?: 20));
            $start = is_numeric($params['start'] ?? null) && (int) $params['start'] >= 1 ? (int) $params['start'] : 1;
            $rows = $this->paged((bool) ($params['page'] ?? true), $num, fn (int $page, bool $count): array => $this->data->messages($num, $page, $start, $count));
            if (! $rows) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            preg_match_all($pattern2, $matches[2][$i], $matches2);
            $out = '';
            $key = ($this->pageVars !== null ? max(1, (int) $this->pageVars['current']) - 1 : 0) * $num + 1;
            foreach ($rows as $value) {
                $one = $matches[2][$i];
                foreach ($matches2[0] as $j => $search) {
                    $p = $this->parserParam($matches2[2][$j]);
                    $replace = match ($matches2[1][$j]) {
                        'n' => (string) ($this->adjustLabelData($p, $key) - 1),
                        'i' => (string) $this->adjustLabelData($p, $key),
                        'ip' => $this->value($p, (string) $value['user_ip']),
                        'os' => $this->value($p, (string) $value['user_os']),
                        'bs' => $this->value($p, (string) $value['user_bs']),
                        'askdate' => $this->value($p, (string) $value['create_time']),
                        'replydate' => $this->value($p, (string) $value['update_time']),
                        'headpic' => self::HEADPIC,
                        'nickname' => $value['nickname'] !== '' ? $this->value($p, (string) $value['nickname']) : ($value['username'] === '' ? $this->value($p, '匿名用户') : null),
                        default => array_key_exists($matches2[1][$j], $value) ? $this->value($p, (string) $value[$matches2[1][$j]]) : '',
                    };
                    if ($replace !== null) {
                        $one = str_replace($search, $replace, $one);
                    }
                }
                $key++;
                $out .= $one;
            }
            $content = $this->replaceOnce($whole, $out, $content);
        }
        return $content;
    }

    /** Pboot parserFormLabel(): {fd:formlist fcode=...} submissions of a custom form. */
    public function parserFormListLabel(string $content): string
    {
        $pattern = '/\{fd:formlist(\s+[^}]+)?\}([\s\S]*?)\{\/fd:formlist\}/';
        $pattern2 = '/\[form:([\w]+)(\s+[^]]+)?\]/';
        if (! preg_match_all($pattern, $content, $matches)) {
            return $content;
        }
        foreach ($matches[0] as $i => $whole) {
            $params = $this->parserParam($matches[1][$i]);
            if (! $this->checkLabelLevel($params)) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            if (! array_key_exists('fcode', $params)) {
                continue;
            }
            $fcode = (string) $params['fcode'];
            $num = (int) ($params['num'] ?? ($this->config('pagesize') ?: 20));
            $start = is_numeric($params['start'] ?? null) && (int) $params['start'] >= 1 ? (int) $params['start'] : 1;
            $rows = $this->data->formRows($fcode, $num, 1, $start, false) === null ? array()
                : $this->paged((bool) ($params['page'] ?? true), $num, fn (int $page, bool $count): array => $this->data->formRows($fcode, $num, $page, $start, $count) ?? array('rows' => array(), 'total' => 0));
            if (! $rows) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            preg_match_all($pattern2, $matches[2][$i], $matches2);
            $out = '';
            $key = ($this->pageVars !== null ? max(1, (int) $this->pageVars['current']) - 1 : 0) * $num + 1;
            foreach ($rows as $value) {
                $one = $matches[2][$i];
                foreach ($matches2[0] as $j => $search) {
                    $p = $this->parserParam($matches2[2][$j]);
                    $one = str_replace($search, match ($matches2[1][$j]) {
                        'n' => (string) ($this->adjustLabelData($p, $key) - 1),
                        'i' => (string) $this->adjustLabelData($p, $key),
                        'date' => $this->value($p, (string) $value['create_time']),
                        default => array_key_exists($matches2[1][$j], $value) ? $this->value($p, (string) $value[$matches2[1][$j]]) : '',
                    }, $one);
                }
                $key++;
                $out .= $one;
            }
            $content = $this->replaceOnce($whole, $out, $content);
        }
        return $content;
    }

    /** parserComment(): one comment or reply. */
    private function commentFields(string $html, array $matches, array $value, int $key): string
    {
        foreach ($matches[0] as $j => $search) {
            $p = $this->parserParam($matches[2][$j]);
            $label = $matches[1][$j];
            $replace = match ($label) {
                'n' => (string) ($this->adjustLabelData($p, $key) - 1),
                'i' => (string) $this->adjustLabelData($p, $key),
                'ip' => $this->value($p, (string) $value['user_ip']),
                'os' => $this->value($p, (string) $value['user_os']),
                'bs' => $this->value($p, (string) $value['user_bs']),
                'date' => $this->value($p, (string) $value['create_time']),
                'headpic', 'pheadpic' => self::HEADPIC,
                'replyaction' => $this->href($this->commentAddress('contentid=' . $value['contentid'] . '&pid=' . ((int) $value['pid'] ?: (int) $value['id']) . '&puid=' . (int) $value['uid'])),
                'nickname' => $this->value($p, $value['nickname'] !== '' ? (string) $value['nickname'] : ((int) $value['uid'] > 0 ? '匿名' : ((string) ($value['name'] ?? '') !== '' ? (string) $value['name'] : '游客'))),
                'pnickname' => $this->value($p, $value['pnickname'] !== '' ? (string) $value['pnickname'] : ((int) $value['puid'] > 0 ? '匿名' : '游客')),
                'likeslink', 'opposelink' => 'javascript:;',
                default => array_key_exists($label, $value) ? $this->value($p, (string) $value[$label]) : null,
            };
            if ($replace !== null) {
                $html = str_replace($search, $replace, $html);
            }
        }
        return $html;
    }

    /** DoController likes/oppose: Pboot's Url::get() form, or /do/{kind}?id= on FangdaysCMS URLs. */
    private function voteLink(string $kind, string $id): string
    {
        return $this->url() !== null ? '/?p=/home/Do/' . $kind . '/id/' . $id : View::localizedPath('/do/' . $kind) . '?id=' . rawurlencode($id);
    }

    /** Pboot comment/add address with its query (contentid, pid, puid). */
    private function commentAddress(string $query): string
    {
        return $this->url()?->home('comment/add', null, $query) ?? View::localizedPath('/comment/add') . '?' . $query;
    }

    /** A paged (first on the page) or plain fetch; $fetch(page, count) returns rows and total. */
    private function paged(bool $page, int $num, callable $fetch): array
    {
        if (! $page || $this->paging) {
            return $fetch(1, false)['rows'];
        }
        $this->paging = true;
        $paging = $this->newPaging();
        $paging->setup($fetch(1, true)['total'], $num, $this->requestedPage());
        $rows = $fetch($paging->page(), false)['rows'];
        $this->pageVars = $paging->vars();
        return $rows;
    }

    /** Shared {fd:list}/{fd:search} parameters. @return array{0: array, 1: int, 2: int, 3: bool} */
    private function listParams(array $params, string $scode, bool $page): array
    {
        $num = (int) ($this->config('pagesize') ?: 20);
        $criteria = array('scode' => $scode, 'order' => '', 'fuzzy' => true, 'flags' => array());
        $start = 1;
        foreach ($params as $key => $value) {
            switch ($key) {
                case 'num':
                    $num = (int) $value;
                    break;
                case 'order':
                    $criteria['order'] = (string) $value;
                    break;
                case 'filter':
                    $filter = explode('|', (string) $value);
                    if (count($filter) === 2) {
                        $criteria['filter'] = array($filter[0], explode(',', $filter[1]));
                    }
                    break;
                case 'fuzzy':
                    $criteria['fuzzy'] = (bool) $value;
                    break;
                case 'tags':
                    $criteria['tags'] = explode(',', (string) $value);
                    break;
                case 'ispics':
                case 'isico':
                case 'istop':
                case 'isrecommend':
                case 'isheadline':
                    $criteria['flags'][$key] = (bool) $value;
                    break;
                case 'page':
                    $page = (bool) $value;
                    break;
                case 'start':
                    $start = is_numeric($value) && (int) $value >= 1 ? (int) $value : 1;
                    break;
            }
        }
        return array($criteria, $num, $start, $page);
    }

    private function fetchContents(array $criteria, int $num, int $start, bool $page): array
    {
        // Pboot rejects a second paged list on one page; later ones are simply not paged here.
        if (! $page || $this->paging) {
            return $this->data->contents($criteria, $num, 1, $start, false, true)['rows'];
        }
        $this->paging = true;
        $paging = $this->newPaging();
        $paging->setup($this->data->contents($criteria, $num, 1, $start, true)['total'], $num, $this->requestedPage());
        $rows = $this->data->contents($criteria, $num, $paging->page(), $start, false, true)['rows'];
        $this->pageVars = $paging->vars();
        return $rows;
    }

    private function newPaging(): Paging
    {
        $builder = $this->env['page_link'] ?? Paging::basic((string) $this->env['path'], http_build_query($this->env['query'] ?? array()));
        return new Paging($builder, (int) ($this->config('pagenum') ?: 5));
    }

    private function url(): ?PbootUrl
    {
        return ($this->env['url'] ?? null) instanceof PbootUrl ? $this->env['url'] : null;
    }

    /** {fd:tags} addresses: the tag page, or a category list filtered by the tag. */
    private function tagLink(string $tag, ?array $sort): string
    {
        $url = $this->url();
        if ($sort === null) {
            if ($url === null) {
                return View::localizedPath('/tag/') . rawurlencode($tag);
            }
            return $url->type() === 3 ? $url->home('tag=' . urlencode($tag), false) : $url->home('tag/' . urlencode($tag), false);
        }
        $link = $this->data->sortLink($sort);
        return $link . ($url !== null ? $url->querySeparator($link) : '?') . 'tag=' . urlencode($tag);
    }

    private function requestedPage(): int
    {
        $page = $this->env['query']['page'] ?? '1';
        return is_string($page) && ctype_digit($page) ? (int) $page : 1;
    }

    /** Current query without paging, the basis of filter links. */
    private function filterQuery(): array
    {
        $query = array_filter($this->env['query'] ?? array(), 'is_string');
        unset($query['page'], $query['p'], $query['s']);
        return $query;
    }

    /** Filter addresses: the page address plus the filter query (Pboot keeps "/&" in 兼容 mode). */
    private function filterLink(array $query): string
    {
        $string = http_build_query($query);
        $base = (string) ($this->env['page_base'] ?? '') !== '' ? (string) $this->env['page_base'] : (string) $this->env['path'];
        if ($this->url()?->type() === 3 && str_starts_with($base, '/?')) {
            return $string !== '' ? rtrim($base, '/') . '/&' . $string : $base;
        }
        return $base . ($string !== '' ? '?' . $string : '');
    }

    private function parserList(string $label, string $search, string $content, array $data, array $params, int $key): string
    {
        $replace = match ($label) {
            'n' => (string) ($this->adjustLabelData($params, $key) - 1),
            'i' => (string) $this->adjustLabelData($params, $key),
            default => $this->contentField($label, $data, $params, null),
        };
        return $replace === null ? $content : str_replace($search, $replace, $content);
    }

    /** Shared field rules of Pboot parserList() and parserContent(); null keeps the label. */
    private function contentField(string $label, array $data, array $params, ?array $sort): ?string
    {
        $single = ($data['type'] ?? '2') === '1';
        switch ($label) {
            case 'link':
                return $this->href($single && ($data['sortoutlink'] ?? '') !== '' ? (string) $data['sortoutlink'] : (($data['outlink'] ?? '') !== '' ? (string) $data['outlink'] : $this->data->contentLink($data)));
            case 'sortlink':
                $owner = $this->data->sort((string) $data['scode']);
                return $owner === null ? '' : $this->href($this->data->sortLink($owner));
            case 'subsortlink':
                return $sort === null ? 'javascript:;' : '';
            case 'ico':
                if (($data['ico'] ?? '') !== '') {
                    return $this->value($params, (string) $data['ico']);
                }
                if (preg_match('/<img\s+.*?src=\s?[\'|\"](.*?(\.gif|\.jpg|\.png|\.jpeg))[\'|\"].*?[\/]?>/i', $this->data->body($data), $srcs) && isset($srcs[1])) {
                    return $this->value($params, $srcs[1]);
                }
                return $this->value($params, self::STATIC_DIR . '/images/nopic.png');
            case 'isico':
                return ($data['ico'] ?? '') !== '' ? '1' : '0';
            case 'ispics':
                return ($data['pics'] ?? '') !== '' ? '1' : '0';
            case 'enclosure':
                return ($data['enclosure'] ?? '') !== '' ? $this->value($params, (string) $data['enclosure']) : '';
            case 'enclosuresize':
                return ($data['enclosure'] ?? '') !== '' ? $this->value($params, (int) ($data['enclosuresize'] ?? 0)) : '0';
            case 'likeslink':
            case 'opposelink':
                return $this->href($this->voteLink(substr($label, 0, -4), (string) ($data['id'] ?? '')));
            case 'content':
                $body = $this->data->body($data);
                return $this->value($params, $sort !== null ? $this->linkKeywords($body) : $body, true, $label);
            case 'keywords':
            case 'description':
                if ($sort !== null && ($data[$label] ?? '') === '') {
                    return '{fd:site' . $label . '}';
                }
                return $this->protect($this->value($params, (string) ($data[$label] ?? ''), false, $label));
            case 'precontent':
            case 'prelink':
            case 'pretitle':
            case 'preico':
            case 'nextcontent':
            case 'nextlink':
            case 'nexttitle':
            case 'nextico':
                if ($sort === null || $single) {
                    return null;
                }
                $previous = str_starts_with($label, 'pre');
                $other = $this->data->neighbour((string) $sort['scode'], (int) $data['id'], $previous);
                $field = substr($label, $previous ? 3 : 4);
                if ($other === null) {
                    return match ($field) {
                        'link' => 'javascript:;',
                        'ico' => $this->value($params, self::STATIC_DIR . '/images/nopic.png'),
                        default => $this->escape((string) ($params['notext'] ?? '没有了！')),
                    };
                }
                return match ($field) {
                    'content' => '<a href="' . $this->href($this->data->contentLink($other)) . '">' . $this->value($params, (string) $other['title']) . '</a>',
                    'link' => $this->href($this->data->contentLink($other)),
                    'title' => $this->value($params, (string) $other['title']),
                    default => $this->value($params, (string) ($other['ico'] ?: self::STATIC_DIR . '/images/nopic.png')),
                };
            case 'sortname':
            case 'subsortname':
                return ($data[$label] ?? '') !== '' ? $this->value($params, (string) $data[$label], false, $label) : '';
        }
        if (array_key_exists($label, $data) && ! is_array($data[$label]) && ! str_starts_with($label, '_')) {
            return $this->value($params, $data[$label], isset($data['_html'][$label]), $label);
        }
        return str_starts_with($label, 'ext_') ? '' : null;
    }

    /** Pboot content internal links: link configured keywords, longest first, outside existing links. */
    private function linkKeywords(string $body): string
    {
        $links = $this->data->contentLinks();
        if (! $links || $body === '') {
            return $body;
        }
        $protected = array();
        $body = preg_replace_callback('/(<a .*?>.*?<\/a>)|(alt=.*?>)|(title=.*?>)/is', static function (array $match) use (&$protected): string {
            $protected[] = $match[0];
            return '#rega:' . (count($protected) - 1) . '#';
        }, $body) ?? $body;
        foreach ($links as $key => $value) {
            foreach ($links as $key2 => $value2) {
                if ($key !== $key2 && str_contains((string) $value2['name'], (string) $value['name'])) {
                    unset($links[$key]);
                }
            }
        }
        $limit = (int) ($this->config('content_tags_replace_num') ?: 3);
        foreach ($links as $value) {
            if ((string) $value['name'] !== '') {
                $body = preg_replace('/' . preg_quote((string) $value['name'], '/') . '/', '<a href="' . $this->escape((string) $value['link']) . '">' . $this->escape((string) $value['name']) . '</a>', $body, $limit) ?? $body;
            }
        }
        return preg_replace_callback('/\#rega:([0-9]+)\#/', static fn (array $match): string => $protected[(int) $match[1]] ?? '', $body) ?? $body;
    }

    private function parserGroupLabel(string $content, string $name, int $defaultNum, string $imageField, string $imageLabel, callable $fetch): string
    {
        $pattern = '/\{fd:' . $name . '(\s+[^}]+)?\}([\s\S]*?)\{\/fd:' . $name . '\}/';
        $pattern2 = '/\[' . $name . ':([\w]+)(\s+[^]]+)?\]/';
        if (! preg_match_all($pattern, $content, $matches)) {
            return $content;
        }
        foreach ($matches[0] as $i => $whole) {
            $params = $this->parserParam($matches[1][$i]);
            if (! $this->checkLabelLevel($params)) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            if (! array_key_exists('gid', $params)) {
                continue;
            }
            $start = is_numeric($params['start'] ?? null) && (int) $params['start'] >= 1 ? (int) $params['start'] : 1;
            $rows = $fetch((int) $params['gid'], (int) ($params['num'] ?? $defaultNum), $start);
            if (! $rows) {
                $content = $this->replaceOnce($whole, '', $content);
                continue;
            }
            preg_match_all($pattern2, $matches[2][$i], $matches2);
            $out = '';
            $key = 1;
            foreach ($rows as $value) {
                $one = $matches[2][$i];
                foreach ($matches2[0] as $j => $search) {
                    $label = $matches2[1][$j];
                    $p = $this->parserParam($matches2[2][$j]);
                    $replace = match (true) {
                        $label === 'n' => (string) ($this->adjustLabelData($p, $key) - 1),
                        $label === 'i' => (string) $this->adjustLabelData($p, $key),
                        $label === $imageLabel => (string) ($value[$imageField] ?? '') !== '' ? $this->value($p, (string) $value[$imageField]) : '',
                        array_key_exists($label, $value) => $this->value($p, (string) $value[$label]),
                        default => null,
                    };
                    if ($replace !== null) {
                        $one = str_replace($search, $replace, $one);
                    }
                }
                $key++;
                $out .= $one;
            }
            $content = $this->replaceOnce($whole, $out, $content);
        }
        return $content;
    }

    private function parserReplaceKeyword(string $content): string
    {
        foreach (explode(',', strip_tags($this->config('content_keyword_replace'))) as $word) {
            if ($word !== '') {
                $content = str_replace($word, str_repeat('*', mb_strlen($word, 'UTF-8')), $content);
            }
        }
        return $content;
    }

    /** Output a label value: filters, then escaping (plain) or the pre-store (HTML). */
    private function value(array $params, mixed $raw, bool $html = false, ?string $label = null): string
    {
        $data = (string) $this->adjustLabelData($params, $raw, $label);
        // mark highlights the search keyword; on HTML only once drophtml has turned it into text.
        $mark = isset($params['mark']) && (! $html || ! empty($params['drophtml']));
        if (! $mark && ($html || ! empty($params['decode']))) {
            return $this->protect($data);
        }
        if (! $html) {
            $data = $this->escape($data);
        }
        if ($mark) {
            $keyword = $this->env['query'][$label ?? ''] ?? null;
            $keyword = is_string($keyword) && $keyword !== '' ? $keyword : ($this->env['query']['keyword'] ?? '');
            if (is_string($keyword) && $keyword !== '') {
                $data = preg_replace('/(' . preg_quote($this->escape($keyword), '/') . ')/iu', '<span style="color:red">$1</span>', $data) ?? $data;
            }
        }
        return $html ? $this->protect($data) : $data;
    }

    /** HTML-escape a plain value and neutralise label syntax inside it. */
    private function escape(string $value): string
    {
        return strtr(htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'), array('{' => '&#123;', '}' => '&#125;', '[' => '&#91;', ']' => '&#93;', '#pre:' => '&#35;pre:'));
    }

    /** An address inside an attribute: like Pboot, "&" stays as is; quotes, brackets and label syntax are escaped. */
    private function href(string $value): string
    {
        return strtr($value, array('"' => '&quot;', "'" => '&#039;', '<' => '&lt;', '>' => '&gt;', '{' => '&#123;', '}' => '&#125;', '[' => '&#91;', ']' => '&#93;', '#pre:' => '&#35;pre:'));
    }

    /** Keep trusted HTML out of later label passes; restored at the end. */
    private function protect(string $value): string
    {
        if ($value === '') {
            return '';
        }
        $this->pre[] = $value;
        return '#pre:' . array_key_last($this->pre) . '#';
    }

    private function config(string $name): string
    {
        return (string) ($this->env['config'][$name] ?? '');
    }

    private function replaceOnce(string $search, string $replace, string $content): string
    {
        // Pboot replaces every identical occurrence of a parsed block.
        return str_replace($search, $replace, $content);
    }

    private static function strlenBoth(string $string): float
    {
        $n = 0.0;
        foreach (mb_str_split($string, 1, 'UTF-8') as $char) {
            $n += strlen($char) > 1 ? 1 : 0.5;
        }
        return $n;
    }

    private static function substrBoth(string $string, int $start, int $length): string
    {
        $n = 0.0;
        $out = '';
        foreach (mb_str_split($string, 1, 'UTF-8') as $char) {
            if ($n >= $length) {
                break;
            }
            $n += strlen($char) > 1 ? 1 : 0.5;
            if ($n > $start) {
                $out .= $char;
            }
        }
        return $out;
    }
}
