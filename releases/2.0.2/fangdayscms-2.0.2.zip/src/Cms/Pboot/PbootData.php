<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Pboot;

use FangdaysCMS\Cms\ContentModelRepository;
use FangdaysCMS\Cms\RichText;
use FangdaysCMS\Cms\View;
use PDO;

/**
 * Read model that exposes FangdaysCMS records with PbootCMS 3.2.10 field names
 * (ay_content_sort / ay_content), so ported labels keep their original meaning.
 * Values are raw; the parser escapes them on output.
 */
final class PbootData
{
    private const NOW_SQL = 'COALESCE(NULLIF(pm.published_at, 0), p.created_at)';
    private const ORDER_COLUMNS = array(
        'id' => 'p.id', 'date' => self::NOW_SQL, 'sorting' => 'COALESCE(pm.sort_order, 255)',
        'istop' => 'COALESCE(pm.is_top, 0)', 'isrecommend' => 'COALESCE(pm.is_recommended, 0)', 'isheadline' => 'COALESCE(pm.is_headline, 0)',
        'title' => 'p.title', 'create_time' => 'p.created_at', 'update_time' => 'p.updated_at',
        'visits' => 'COALESCE(pm.visits, 0)', 'likes' => 'COALESCE(pm.likes, 0)', 'oppose' => 'COALESCE(pm.oppose, 0)',
    );
    private const DEFAULT_ORDER = 'COALESCE(pm.is_top, 0) DESC, COALESCE(pm.is_recommended, 0) DESC, COALESCE(pm.is_headline, 0) DESC, COALESCE(pm.sort_order, 255) ASC, ' . self::NOW_SQL . ' DESC, p.id DESC';
    private const FILTER_COLUMNS = array('title' => 'p.title', 'content' => 'p.body', 'subtitle' => 'pm.subtitle', 'author' => 'pm.author', 'source' => 'pm.source', 'keywords' => 'pm.seo_keywords', 'description' => 'pm.seo_description');

    private ?array $sorts = null;
    private ?string $area = null;
    private bool $scoped = false;
    private ?array $site = null;
    private array $neighbours = array();

    public function __construct(private readonly PDO $pdo, private readonly string $locale = 'zh-CN', private readonly ?array $member = null, private readonly ?PbootUrl $url = null)
    {
    }

    public function english(): bool
    {
        return $this->locale === 'en-US';
    }

    /**
     * Imported sites keep each Pboot area's categories, slides and links in their own rows: this locale's area
     * when it has one, otherwise the shared rows. Sites without area rows see every row, as before.
     */
    private function area(): string
    {
        if ($this->area === null) {
            $areas = $this->pdo->query("SELECT DISTINCT area FROM categories WHERE area <> ''")->fetchAll(PDO::FETCH_COLUMN);
            $this->scoped = $areas !== array();
            $this->area = in_array($this->locale, $areas, true) ? $this->locale : '';
        }
        return $this->area;
    }

    /** site or company values of an imported area, over the shared ones. */
    private function areaValues(string $kind, array $values): array
    {
        $own = $this->area() === '' ? null : json_decode($this->setting('pboot_area_' . $kind . '_' . $this->area()), true);
        return is_array($own) ? array_merge($values, array_intersect_key($own, $values)) : $values;
    }

    public function member(): ?array
    {
        return $this->member;
    }

    public function setting(string $name, string $default = ''): string
    {
        $stmt = $this->pdo->prepare('SELECT value FROM site_settings WHERE name = ?');
        $stmt->execute(array($name));
        $value = $stmt->fetchColumn();
        return $value === false ? $default : (string) $value;
    }

    public function site(): array
    {
        if ($this->site !== null) {
            return $this->site;
        }
        $settings = array();
        foreach ($this->pdo->query('SELECT name, value FROM site_settings') as $row) {
            $settings[$row['name']] = (string) $row['value'];
        }
        $pick = fn (string $name): string => $this->english() && ($settings[$name . '_en'] ?? '') !== '' ? $settings[$name . '_en'] : ($settings[$name] ?? '');
        return $this->site = $this->areaValues('site', array(
            'title' => $pick('site_name') !== '' ? $pick('site_name') : 'FangdaysCMS',
            'subtitle' => $pick('site_subtitle'),
            'domain' => $settings['pboot_domain'] ?? ($settings['site_domain'] ?? ''),
            'logo' => $settings['site_logo'] ?? '',
            'keywords' => $pick('seo_keywords'),
            'description' => $pick('seo_description') !== '' ? $pick('seo_description') : $pick('description'),
            'icp' => $settings['site_icp'] ?? '',
            'theme' => $settings['pboot_theme'] ?? '',
            'statistical' => $settings['site_statistical'] ?? '',
            'copyright' => ($settings['site_copyright'] ?? '') !== '' ? $settings['site_copyright'] : $pick('footer_text'),
        ));
    }

    public function company(): array
    {
        $row = $this->pdo->query('SELECT * FROM company_profile WHERE id = 1')->fetch() ?: array();
        $values = array();
        foreach (array('name', 'address', 'postcode', 'contact', 'mobile', 'phone', 'fax', 'email', 'qq', 'weixin', 'blicense', 'other', 'map_provider', 'map_baidu_lng', 'map_baidu_lat', 'map_amap_lng', 'map_amap_lat', 'cs_enabled', 'cs_show_phone', 'cs_show_weixin', 'cs_show_qq', 'cs_weixin_qr', 'cs_show_chat', 'cs_chat_mode', 'cs_chat_label', 'cs_chat_url', 'cs_chat_script') as $field) {
            $values[$field] = (string) ($row[$field] ?? '');
            if ($this->english() && ($row[$field . '_en'] ?? '') !== '') {
                $values[$field] = (string) $row[$field . '_en'];
            }
        }
        return $this->areaValues('company', $values);
    }

    /** @return array<string, array{type: int, value: string}> Pboot label types: 1 text, 2 rich text, 3 image. */
    public function labels(): array
    {
        $labels = array();
        $column = $this->english() ? "COALESCE(NULLIF(value_en, ''), value)" : 'value';
        foreach ($this->pdo->query("SELECT name, type, $column AS label_value FROM custom_labels") as $row) {
            $labels[(string) $row['name']] = array('type' => array('editor' => 2, 'image' => 3)[$row['type']] ?? 1, 'value' => (string) $row['label_value']);
        }
        return $labels;
    }

    /** All categories keyed by scode, with Pboot sort fields. */
    public function sorts(): array
    {
        if ($this->sorts !== null) {
            return $this->sorts;
        }
        $area = $this->pdo->quote($this->area());
        $rows = $this->pdo->query("SELECT c.id, c.parent_id, c.name, c.name_en, c.slug, c.sort_order, m.slug AS model_slug, m.name AS model_name, m.list_template AS model_list_template, m.content_template AS model_content_template, COALESCE(s.type, 'list') AS kind, COALESCE(s.is_visible, 1) AS is_visible, COALESCE(s.list_template, '') AS list_template, COALESCE(s.content_template, '') AS content_template, COALESCE(s.outlink, '') AS outlink, COALESCE(s.seo_title, '') AS seo_title, COALESCE(s.seo_title_en, '') AS seo_title_en, COALESCE(s.seo_keywords, '') AS seo_keywords, COALESCE(s.seo_keywords_en, '') AS seo_keywords_en, COALESCE(s.seo_description, '') AS seo_description, COALESCE(s.seo_description_en, '') AS seo_description_en, COALESCE(s.single_status, 'draft') AS single_status, COALESCE(s.subname, '') AS subname, COALESCE(s.gcode, '') AS gcode, COALESCE(s.gtype, 4) AS gtype, COALESCE(s.gnote, '') AS gnote, COALESCE(s.def1, '') AS def1, COALESCE(s.def2, '') AS def2, COALESCE(s.def3, '') AS def3, tm.path AS ico, bm.path AS pic FROM categories c LEFT JOIN category_models cm ON cm.category_id = c.id LEFT JOIN content_models m ON m.id = COALESCE(cm.model_id, (SELECT id FROM content_models WHERE slug = 'article')) LEFT JOIN category_settings s ON s.category_id = c.id LEFT JOIN category_images ti ON ti.category_id = c.id AND ti.kind = 'thumbnail' LEFT JOIN media tm ON tm.id = ti.media_id LEFT JOIN category_images bi ON bi.category_id = c.id AND bi.kind = 'banner' LEFT JOIN media bm ON bm.id = bi.media_id WHERE c.area = $area ORDER BY c.sort_order ASC, c.id ASC")->fetchAll();
        $byId = array();
        foreach ($rows as $row) {
            $byId[(int) $row['id']] = $row;
        }
        $urlnames = json_decode((string) $this->pdo->query("SELECT value FROM site_settings WHERE name = 'pboot_model_urlnames'")->fetchColumn(), true);
        $urlnames = is_array($urlnames) ? $urlnames : array();
        $sorts = array();
        foreach ($rows as $row) {
            $segments = array();
            $current = $row;
            for ($guard = 0; $current !== null && $guard < 64; $guard++) {
                array_unshift($segments, rawurlencode((string) $current['slug']));
                $current = $current['parent_id'] === null ? null : ($byId[(int) $current['parent_id']] ?? null);
            }
            $pick = fn (string $field): string => $this->english() && ($row[$field . '_en'] ?? '') !== '' ? (string) $row[$field . '_en'] : (string) ($row[$field] ?? '');
            $scode = (string) $row['id'];
            $sorts[$scode] = array(
                'id' => $scode,
                'scode' => $scode,
                'pcode' => $row['parent_id'] === null ? '0' : (string) $row['parent_id'],
                'mcode' => (string) ($row['model_slug'] ?? ''),
                'name' => $pick('name'),
                'subname' => (string) $row['subname'],
                'type' => $row['kind'] === 'single' ? '1' : '2',
                'kind' => (string) $row['kind'],
                'urlname' => (string) ($urlnames[$row['model_slug'] ?? ''] ?? $row['model_slug'] ?? ''),
                'modelname' => (string) ($row['model_name'] ?? ''),
                'listtpl' => $row['list_template'] !== '' ? (string) $row['list_template'] : (string) ($row['model_list_template'] ?? ''),
                'contenttpl' => $row['content_template'] !== '' ? (string) $row['content_template'] : (string) ($row['model_content_template'] ?? ''),
                'status' => (int) $row['is_visible'] === 1 && ($row['kind'] !== 'single' || $row['single_status'] === 'published') ? '1' : '0',
                'outlink' => $row['kind'] === 'link' ? (string) $row['outlink'] : '',
                'ico' => (string) ($row['ico'] ?? ''),
                'pic' => (string) ($row['pic'] ?? ''),
                'title' => $pick('seo_title'),
                'keywords' => $pick('seo_keywords'),
                'description' => $pick('seo_description'),
                // Imported categories without a URL name are addressed by model and code again, as in Pboot.
                'filename' => (string) $row['slug'] === 'sort-' . $scode ? '' : (string) $row['slug'],
                'url_path' => implode('/', $segments),
                'sorting' => (string) $row['sort_order'],
                'gcode' => (string) $row['gcode'], 'gtype' => (int) $row['gtype'], 'gnote' => (string) $row['gnote'],
                'def1' => (string) $row['def1'], 'def2' => (string) $row['def2'], 'def3' => (string) $row['def3'],
                'single_status' => (string) $row['single_status'],
            );
        }
        foreach ($sorts as $scode => $sort) {
            $sorts[$scode]['parentname'] = $sort['pcode'] !== '0' ? (string) ($sorts[$sort['pcode']]['name'] ?? '') : '';
        }
        return $this->sorts = $sorts;
    }

    /** Pboot getSortsTree(): visible categories grouped by parent. */
    public function sortsTree(): array
    {
        $tree = array();
        $top = array();
        foreach ($this->sorts() as $scode => $sort) {
            if ($sort['status'] !== '1') {
                continue;
            }
            $tree[$scode] = ($tree[$scode] ?? array()) + $sort;
        }
        $ordered = $tree;
        uasort($ordered, static fn (array $a, array $b): int => array((int) $a['pcode'], (int) $a['sorting'], (int) $a['id']) <=> array((int) $b['pcode'], (int) $b['sorting'], (int) $b['id']));
        foreach ($ordered as $scode => $sort) {
            if ($sort['pcode'] !== '0') {
                // A hidden parent still records its visible children, so {pboot:nav parent=...} can list them.
                $tree[$sort['pcode']]['son'][] = $sort;
            } else {
                $top[] = $sort;
            }
        }
        return array('tree' => $tree, 'top' => $top);
    }

    /** Lookup by scode or URL name (Pboot getSort). */
    public function sort(string $scode): ?array
    {
        $sorts = $this->sorts();
        if (isset($sorts[$scode])) {
            return $sorts[$scode];
        }
        foreach ($sorts as $sort) {
            if (strcasecmp($sort['filename'], $scode) === 0 || $sort['url_path'] === $scode) {
                return $sort;
            }
        }
        return null;
    }

    public function multSort(string $scodes): array
    {
        $wanted = array_map('trim', explode(',', $scodes));
        $result = array_values(array_filter($this->sorts(), static fn (array $sort): bool => in_array($sort['scode'], $wanted, true)));
        usort($result, static fn (array $a, array $b): int => array((int) $a['sorting'], (int) $a['id']) <=> array((int) $b['sorting'], (int) $b['id']));
        return $result;
    }

    public function topScode(string $scode): string
    {
        $position = $this->position($scode);
        return $position ? (string) $position[0]['scode'] : '';
    }

    public function position(string $scode): array
    {
        $sorts = $this->sorts();
        $chain = array();
        for ($guard = 0; isset($sorts[$scode]) && $guard < 64; $guard++) {
            array_unshift($chain, $sorts[$scode]);
            $scode = $sorts[$scode]['pcode'];
        }
        return $chain;
    }

    /** Pboot getSubScodes(): the category and its non-link descendants. */
    public function subScodes(string $scodes): array
    {
        $children = array();
        foreach ($this->sorts() as $sort) {
            if ($sort['outlink'] === '') {
                $children[$sort['pcode']][] = $sort['scode'];
            }
        }
        $result = array();
        $walk = static function (string $scode) use (&$walk, &$result, $children): void {
            if ($scode === '' || in_array($scode, $result, true)) {
                return;
            }
            $result[] = $scode;
            foreach ($children[$scode] ?? array() as $child) {
                $walk($child);
            }
        };
        foreach (explode(',', $scodes) as $scode) {
            $walk(trim($scode));
        }
        return array_values(array_filter($result, static fn (string $value): bool => ctype_digit($value)));
    }

    public function sortRows(string $scodes): int
    {
        $ids = $this->subScodes($scodes);
        if (! $ids) {
            return 0;
        }
        [$where, $params] = $this->baseWhere();
        $where[] = $this->categoryClause($ids, $scodes, $params);
        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM posts p LEFT JOIN post_visibility v ON v.post_id = p.id LEFT JOIN post_meta pm ON pm.post_id = p.id WHERE ' . implode(' AND ', $where));
        $stmt->execute($params);
        return (int) $stmt->fetchColumn();
    }

    /**
     * Pboot getLists()/getList(). $criteria keys: scode, filter [field, values[]], tags[], ext [name => value],
     * flags [ispics|isico|istop|isrecommend|isheadline => bool], fuzzy, order (raw Pboot order value).
     * With $deferBody, rows carry the raw body and body() renders it for the labels that use it.
     * @return array{rows: array, total: int}
     */
    public function contents(array $criteria, int $num, int $page, int $start, bool $count, bool $deferBody = false): array
    {
        [$where, $params] = $this->baseWhere();
        $fuzzy = (bool) ($criteria['fuzzy'] ?? true);
        $scode = (string) ($criteria['scode'] ?? '');
        if ($scode !== '') {
            $ids = $this->subScodes($scode);
            if (! $ids) {
                return array('rows' => array(), 'total' => 0);
            }
            $where[] = $this->categoryClause($ids, $scode, $params);
        }
        $where[] = "COALESCE(s.type, 'list') <> 'single'";
        if (isset($criteria['filter'])) {
            [$field, $values] = $criteria['filter'];
            $parts = array();
            foreach ($values as $value) {
                if ($value !== '') {
                    $parts[] = $this->fieldClause($field, $value, $fuzzy, $params);
                }
            }
            $parts = array_values(array_filter($parts));
            if ($parts) {
                $where[] = '(' . implode(' OR ', $parts) . ')';
            }
        }
        $tagParts = array();
        foreach ($criteria['tags'] ?? array() as $tag) {
            if ($tag !== '') {
                $tagParts[] = 'EXISTS (SELECT 1 FROM post_tags pt JOIN tags t ON t.id = pt.tag_id WHERE pt.post_id = p.id AND ' . ($fuzzy ? "(t.name LIKE ? ESCAPE '!' OR t.name_en LIKE ? ESCAPE '!')" : '(t.name = ? OR t.name_en = ?)') . ')';
                $value = $fuzzy ? '%' . self::likeEscape($tag) . '%' : $tag;
                array_push($params, $value, $value);
            }
        }
        if ($tagParts) {
            $where[] = '(' . implode(' OR ', $tagParts) . ')';
        }
        if (isset($criteria['anyof'])) {
            [$fields, $value] = $criteria['anyof'];
            $parts = array();
            foreach ($fields as $field) {
                if (($clause = $this->fieldClause($field, $value, $fuzzy, $params)) !== '') {
                    $parts[] = $clause;
                }
            }
            $where[] = $parts ? '(' . implode(' OR ', $parts) . ')' : '1 = 0';
        }
        foreach ($criteria['ext'] ?? array() as $field => $value) {
            if ($value !== '' && ($clause = $this->fieldClause($field, $value, $fuzzy, $params)) !== '') {
                $where[] = $clause;
            }
        }
        $flagSql = array('ispics' => 'EXISTS (SELECT 1 FROM post_gallery g WHERE g.post_id = p.id)', 'isico' => 'EXISTS (SELECT 1 FROM post_cover c2 WHERE c2.post_id = p.id)', 'istop' => 'COALESCE(pm.is_top, 0) = 1', 'isrecommend' => 'COALESCE(pm.is_recommended, 0) = 1', 'isheadline' => 'COALESCE(pm.is_headline, 0) = 1');
        foreach ($criteria['flags'] ?? array() as $flag => $on) {
            if (isset($flagSql[$flag])) {
                $where[] = ($on ? '' : 'NOT ') . $flagSql[$flag];
            }
        }
        $from = ' FROM posts p LEFT JOIN post_visibility v ON v.post_id = p.id LEFT JOIN post_meta pm ON pm.post_id = p.id LEFT JOIN category_settings s ON s.category_id = p.category_id WHERE ' . implode(' AND ', $where);
        $total = 0;
        if ($count) {
            $stmt = $this->pdo->prepare('SELECT COUNT(*)' . $from);
            $stmt->execute($params);
            $total = max(0, (int) $stmt->fetchColumn() - ($start - 1));
        }
        $num = max(1, min(1000, $num));
        $offset = ($start - 1) + (max(1, $page) - 1) * $num;
        $stmt = $this->pdo->prepare('SELECT p.id' . $from . ' ORDER BY ' . $this->orderSql((string) ($criteria['order'] ?? '')) . ' LIMIT ' . $num . ' OFFSET ' . max(0, $offset));
        $stmt->execute($params);
        $ids = array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
        return array('rows' => $this->postsByIds($ids, $deferBody), 'total' => $total);
    }

    /** Rendered body of a content row, including one fetched with $deferBody. */
    public function body(array $row): string
    {
        return (string) ($row['content'] ?? RichText::render((string) ($row['_body'] ?? ''), (string) ($row['_body_format'] ?? 'plain')));
    }

    public function content(string $idOrSlug): ?array
    {
        [$where, $params] = $this->baseWhere();
        if (ctype_digit($idOrSlug)) {
            $where[] = '(p.id = ? OR p.slug = ?)';
            array_push($params, (int) $idOrSlug, $idOrSlug);
        } else {
            $where[] = 'p.slug = ?';
            $params[] = $idOrSlug;
        }
        $stmt = $this->pdo->prepare('SELECT p.id FROM posts p LEFT JOIN post_visibility v ON v.post_id = p.id LEFT JOIN post_meta pm ON pm.post_id = p.id WHERE ' . implode(' AND ', $where) . ' LIMIT 1');
        $stmt->execute($params);
        $id = $stmt->fetchColumn();
        return $id === false ? null : ($this->postsByIds(array((int) $id))[0] ?? null);
    }

    /** Pboot getAbout(): the single-page body of a category. */
    public function about(string $scode): ?array
    {
        $sort = $this->sort($scode);
        if ($sort === null || $sort['kind'] !== 'single' || $sort['single_status'] !== 'published') {
            return null;
        }
        $stmt = $this->pdo->prepare("SELECT COALESCE(single_title, '') AS single_title, COALESCE(single_title_en, '') AS single_title_en, COALESCE(single_updated_at, 0) AS single_updated_at, COALESCE(single_visits, 0) AS single_visits, COALESCE(single_body, '') AS single_body, COALESCE(single_body_en, '') AS single_body_en, COALESCE(single_body_format, 'plain') AS single_body_format FROM category_settings WHERE category_id = ?");
        $stmt->execute(array((int) $sort['scode']));
        $row = $stmt->fetch() ?: array();
        $cover = $this->pdo->prepare('SELECT m.path FROM category_cover c JOIN media m ON m.id = c.media_id WHERE c.category_id = ?');
        $cover->execute(array((int) $sort['scode']));
        $gallery = $this->pdo->prepare('SELECT m.path, g.title FROM category_gallery g JOIN media m ON m.id = g.media_id WHERE g.category_id = ? ORDER BY g.position');
        $gallery->execute(array((int) $sort['scode']));
        $pics = $gallery->fetchAll();
        $attachment = $this->pdo->prepare('SELECT bytes FROM category_attachment WHERE category_id = ?');
        $attachment->execute(array((int) $sort['scode']));
        $bytes = $attachment->fetchColumn();
        $title = $this->english() && ($row['single_title_en'] ?? '') !== '' ? $row['single_title_en'] : (string) ($row['single_title'] ?? '');
        $body = $this->english() && ($row['single_body_en'] ?? '') !== '' ? $row['single_body_en'] : (string) ($row['single_body'] ?? '');
        $data = array(
            'id' => $sort['scode'], 'acode' => $this->locale, 'scode' => $sort['scode'], 'subscode' => '',
            'title' => $title !== '' ? $title : $sort['name'], 'titlecolor' => '', 'subtitle' => '', 'filename' => '',
            'author' => '', 'source' => '', 'outlink' => '', 'date' => (int) ($row['single_updated_at'] ?? 0) > 0 ? date('Y-m-d H:i:s', (int) $row['single_updated_at']) : '', 'ico' => (string) ($cover->fetchColumn() ?: ''),
            'pics' => implode(',', array_column($pics, 'path')), 'picstitle' => implode(',', array_column($pics, 'title')),
            'content' => RichText::render($body, (string) ($row['single_body_format'] ?? 'plain')),
            'tags' => '', 'enclosure' => $bytes === false ? '' : View::categoryLink(array('slug' => $sort['filename'], 'url_path' => $sort['url_path'])) . '/attachment',
            'enclosuresize' => $bytes === false ? 0 : (int) $bytes,
            'keywords' => $sort['keywords'], 'description' => $sort['description'], 'sorting' => $sort['sorting'],
            'status' => '1', 'istop' => '0', 'isrecommend' => '0', 'isheadline' => '0', 'visits' => (int) ($row['single_visits'] ?? 0), 'likes' => 0, 'oppose' => 0,
            'sortname' => $sort['name'], 'sortfilename' => $sort['filename'], 'sortoutlink' => $sort['outlink'], 'subsortname' => '', 'subfilename' => '',
            'type' => '1', 'urlname' => $sort['urlname'], 'modelname' => $sort['modelname'], 'gcode' => '', 'sort' => $sort,
            '_images' => array(), '_html' => array('content' => true),
        );
        $models = new ContentModelRepository($this->pdo);
        foreach ($models->publicFieldsForSingleCategory((int) $sort['scode']) as $field) {
            $data[(string) $field['name']] = self::fieldValue($field);
            if (($field['type'] ?? '') === 'editor') {
                $data['_html'][(string) $field['name']] = true;
            }
        }
        return $data;
    }

    /** Single page addressed by its imported Pboot content id (see tools/pboot_import.php). */
    public function singleByContentId(string $id): ?array
    {
        $map = json_decode($this->setting('pboot_single_ids', '{}'), true);
        return is_array($map) && isset($map[$id]) ? $this->about((string) $map[$id]) : null;
    }

    public function neighbour(string $scode, int $id, bool $previous): ?array
    {
        $key = $scode . ':' . $id . ':' . ($previous ? 'pre' : 'next');
        if (! array_key_exists($key, $this->neighbours)) {
            $ids = $this->subScodes($scode);
            $row = null;
            if ($ids) {
                [$where, $params] = $this->baseWhere();
                $where[] = 'p.category_id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')';
                array_push($params, ...array_map('intval', $ids));
                $where[] = $previous ? 'p.id < ?' : 'p.id > ?';
                $params[] = $id;
                $stmt = $this->pdo->prepare('SELECT p.id FROM posts p LEFT JOIN post_visibility v ON v.post_id = p.id LEFT JOIN post_meta pm ON pm.post_id = p.id WHERE ' . implode(' AND ', $where) . ' ORDER BY p.id ' . ($previous ? 'DESC' : 'ASC') . ' LIMIT 1');
                $stmt->execute($params);
                $found = $stmt->fetchColumn();
                $row = $found === false ? null : ($this->postsByIds(array((int) $found))[0] ?? null);
            }
            $this->neighbours[$key] = $row;
        }
        return $this->neighbours[$key];
    }

    /** @return array{pics: list<string>, titles: list<string>} */
    public function contentPics(string $id, string $field): array
    {
        $content = ctype_digit($id) ? $this->content($id) : null;
        if ($content === null) {
            return array('pics' => array(), 'titles' => array());
        }
        if ($field === 'pics') {
            return array('pics' => explode(',', (string) $content['pics']), 'titles' => explode(',', (string) $content['picstitle']));
        }
        $items = $content['_images'][$field] ?? array();
        return array('pics' => array_column($items, 'path'), 'titles' => array_column($items, 'title'));
    }

    public function contentField(string $id, string $field): string
    {
        $content = ctype_digit($id) ? $this->content($id) : null;
        return $content === null ? '' : (string) ($content[$field] ?? '');
    }

    /** Tag names used by a category subtree (or the whole site). */
    public function sortTags(string $scode): array
    {
        $sql = "SELECT DISTINCT t.id, t.name, t.name_en FROM tags t JOIN post_tags pt ON pt.tag_id = t.id JOIN posts p ON p.id = pt.post_id LEFT JOIN post_visibility v ON v.post_id = p.id LEFT JOIN post_meta pm ON pm.post_id = p.id";
        [$where, $params] = $this->baseWhere();
        if ($scode !== '') {
            $ids = $this->subScodes($scode);
            if (! $ids) {
                return array();
            }
            $where[] = $this->categoryClause($ids, $scode, $params);
        }
        $stmt = $this->pdo->prepare($sql . ' WHERE ' . implode(' AND ', $where) . ' ORDER BY t.id');
        $stmt->execute($params);
        return array_map(fn (array $row): string => $this->english() && $row['name_en'] !== '' ? (string) $row['name_en'] : (string) $row['name'], $stmt->fetchAll());
    }

    public function slides(int $gid, int $num, int $start): array
    {
        $stmt = $this->pdo->prepare('SELECT s.id, s.group_id AS gid, s.title, s.subtitle, s.link, s.sort_order AS sorting, m.path AS pic FROM slides s JOIN media m ON m.id = s.media_id WHERE s.area = ' . $this->pdo->quote($this->area()) . ' AND s.group_id = ? ORDER BY s.sort_order, s.id LIMIT ? OFFSET ?');
        $stmt->bindValue(1, $gid, PDO::PARAM_INT);
        $stmt->bindValue(2, max(1, min($num, 200)), PDO::PARAM_INT);
        $stmt->bindValue(3, max(0, $start - 1), PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function links(int $gid, int $num, int $start): array
    {
        $stmt = $this->pdo->prepare('SELECT l.id, l.group_id AS gid, l.name, l.link, l.sort_order AS sorting, COALESCE(m.path, \'\') AS logo FROM friend_links l LEFT JOIN media m ON m.id = l.media_id WHERE l.area = ' . $this->pdo->quote($this->area()) . ' AND l.group_id = ? ORDER BY l.sort_order, l.id LIMIT ? OFFSET ?');
        $stmt->bindValue(1, $gid, PDO::PARAM_INT);
        $stmt->bindValue(2, max(1, min($num, 200)), PDO::PARAM_INT);
        $stmt->bindValue(3, max(0, $start - 1), PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /** Whether a search/filter field name maps to stored data. */
    public function searchable(string $field): bool
    {
        return isset(self::FILTER_COLUMNS[$field]) || $field === 'tags' || preg_match('/^ext_[A-Za-z0-9_]{1,60}$/D', $field) === 1;
    }

    /** Options of a select/radio/multi extension field (Pboot getSelect()). */
    public function selectOptions(string $field): array
    {
        $stmt = $this->pdo->prepare("SELECT options_json FROM model_fields WHERE name = ? AND field_type IN ('select', 'radio', 'multi') ORDER BY id LIMIT 1");
        $stmt->execute(array($field));
        $options = json_decode((string) ($stmt->fetchColumn() ?: '[]'), true);
        return is_array($options) ? array_values(array_filter($options, 'is_string')) : array();
    }

    /** Keywords linked inside content bodies (Pboot getTags()). */
    public function contentLinks(): array
    {
        return $this->pdo->query('SELECT name, link FROM content_links WHERE area = ' . $this->pdo->quote($this->area()) . ' ORDER BY sort_order, id')->fetchAll();
    }

    /** Pboot lists match the category tree or, for one requested code, the content's subscode. */
    private function categoryClause(array $ids, string $scode, array &$params): string
    {
        array_push($params, ...array_map('intval', $ids));
        $clause = 'p.category_id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')';
        if (ctype_digit($scode)) {
            $params[] = (int) $scode;
            return '(' . $clause . ' OR pm.sub_category_id = ?)';
        }
        return $clause;
    }

    public function addSingleVisit(int $scode): void
    {
        $this->pdo->prepare('UPDATE category_settings SET single_visits = single_visits + 1 WHERE category_id = ?')->execute(array($scode));
    }

    public function addVisit(int $id): void
    {
        $this->pdo->prepare('UPDATE post_meta SET visits = visits + 1 WHERE post_id = ?')->execute(array($id));
    }

    /** Approved comments of a post: top level newest first (pid 0), or the replies of one comment oldest first. */
    public function comments(int $postId, int $num, int $page, int $start, bool $count, int $parentId = 0): array
    {
        $total = 0;
        if ($count) {
            $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM post_comments WHERE post_id = ? AND parent_id = ? AND status = 'approved'");
            $stmt->execute(array($postId, $parentId));
            $total = max(0, (int) $stmt->fetchColumn() - ($start - 1));
        }
        $stmt = $this->pdo->prepare("SELECT c.id, c.post_id AS contentid, c.parent_id AS pid, COALESCE(c.member_id, 0) AS uid, c.parent_member_id AS puid, c.name, c.content AS comment, c.created_at, c.user_ip, c.user_os, c.user_bs, c.likes, c.oppose, COALESCE(m.display_name, '') AS nickname, COALESCE(m.email, '') AS username, COALESCE(pm.display_name, '') AS pnickname, COALESCE(pm.email, '') AS pusername FROM post_comments c LEFT JOIN members m ON m.id = c.member_id LEFT JOIN members pm ON pm.id = c.parent_member_id WHERE c.post_id = ? AND c.parent_id = ? AND c.status = 'approved' ORDER BY c.id " . ($parentId === 0 ? 'DESC' : 'ASC') . ' LIMIT ' . max(1, min(200, $num)) . ' OFFSET ' . max(0, ($start - 1) + (max(1, $page) - 1) * $num));
        $stmt->execute(array($postId, $parentId));
        $rows = array_map(static fn (array $row): array => $row + array('date' => date('Y-m-d H:i:s', (int) $row['created_at']), 'create_time' => date('Y-m-d H:i:s', (int) $row['created_at']), 'status' => '1'), $stmt->fetchAll());
        return array('rows' => $rows, 'total' => $total);
    }

    /** Pboot getMessage(): approved guestbook messages, newest first, with Pboot ay_message field names. */
    public function messages(int $num, int $page, int $start, bool $count): array
    {
        $total = 0;
        if ($count) {
            $total = max(0, (int) $this->pdo->query("SELECT COUNT(*) FROM guestbook_messages WHERE status = 'approved'")->fetchColumn() - ($start - 1));
        }
        $stmt = $this->pdo->query("SELECT g.id, g.name AS contacts, g.phone AS mobile, g.email, g.content, g.recontent, g.user_ip, g.user_os, g.user_bs, g.created_at, g.replied_at, COALESCE(g.member_id, 0) AS uid, COALESCE(m.display_name, '') AS nickname, COALESCE(m.email, '') AS username FROM guestbook_messages g LEFT JOIN members m ON m.id = g.member_id WHERE g.status = 'approved' ORDER BY g.id DESC LIMIT " . max(1, min(200, $num)) . ' OFFSET ' . max(0, ($start - 1) + (max(1, $page) - 1) * $num));
        $rows = array();
        foreach ($stmt->fetchAll() as $row) {
            $row['create_time'] = date('Y-m-d H:i:s', (int) $row['created_at']);
            $row['update_time'] = (int) $row['replied_at'] > 0 ? date('Y-m-d H:i:s', (int) $row['replied_at']) : $row['create_time'];
            $row['status'] = '1';
            $rows[] = $row;
        }
        return array('rows' => $rows, 'total' => $total);
    }

    /** Pboot getForm(): submissions of a form (by id or slug), newest first, one key per form field. */
    public function formRows(string $fcode, int $num, int $page, int $start, bool $count): ?array
    {
        $stmt = $this->pdo->prepare("SELECT id FROM custom_forms WHERE (id = ? OR slug = ?) AND status = 'published' ORDER BY id LIMIT 1");
        $stmt->execute(array(ctype_digit($fcode) ? (int) $fcode : 0, $fcode));
        $formId = $stmt->fetchColumn();
        if ($formId === false) {
            return null;
        }
        $total = 0;
        if ($count) {
            $counter = $this->pdo->prepare('SELECT COUNT(*) FROM form_submissions WHERE form_id = ?');
            $counter->execute(array((int) $formId));
            $total = max(0, (int) $counter->fetchColumn() - ($start - 1));
        }
        $stmt = $this->pdo->prepare('SELECT id, values_json, created_at FROM form_submissions WHERE form_id = ? ORDER BY id DESC LIMIT ' . max(1, min(200, $num)) . ' OFFSET ' . max(0, ($start - 1) + (max(1, $page) - 1) * $num));
        $stmt->execute(array((int) $formId));
        $rows = array();
        foreach ($stmt->fetchAll() as $row) {
            $values = json_decode((string) $row['values_json'], true);
            $item = array();
            foreach (is_array($values) ? $values : array() as $name => $value) {
                $item[(string) $name] = is_array($value) ? implode(',', array_filter($value, 'is_scalar')) : (string) $value;
            }
            $rows[] = $item + array('id' => (string) $row['id'], 'create_time' => date('Y-m-d H:i:s', (int) $row['created_at']));
        }
        return array('rows' => $rows, 'total' => $total);
    }

    /** Pboot parserLink() equivalent for FangdaysCMS routes. */
    public function sortLink(array $sort): string
    {
        if (($sort['outlink'] ?? '') !== '') {
            return (string) $sort['outlink'];
        }
        if ($this->url !== null) {
            return $this->url->sortLink((string) ($sort['type'] ?? '2'), (string) ($sort['urlname'] ?? ''), (string) ($sort['scode'] ?? ''), (string) ($sort['filename'] ?? ''));
        }
        return View::localizedPath('/category/' . ($sort['url_path'] ?? rawurlencode((string) ($sort['filename'] ?? ''))));
    }

    public function contentLink(array $content): string
    {
        if (($content['type'] ?? '2') === '1') {
            return $this->sortLink($content['sort'] ?? $this->sort((string) $content['scode']) ?? array());
        }
        if ($this->url !== null) {
            return $this->url->contentLink((string) ($content['urlname'] ?? ''), (string) $content['scode'], (string) ($content['sortfilename'] ?? ''), (string) $content['id'], (string) ($content['filename'] ?? ''));
        }
        return View::localizedPath('/post/' . rawurlencode((string) ($content['filename'] ?? '')));
    }

    private function baseWhere(): array
    {
        $where = array("p.status = 'published'", self::NOW_SQL . ' <= (? + 0)');
        $params = array(time());
        $area = $this->area();
        if ($this->scoped) {
            $where[] = '(' . ($area === '' ? 'p.category_id IS NULL OR ' : '') . 'p.category_id IN (SELECT id FROM categories WHERE area = ?))';
            $params[] = $area;
        }
        if ($this->member === null) {
            $where[] = "COALESCE(v.visibility, 'public') = 'public'";
        } else {
            $where[] = "(COALESCE(v.visibility, 'public') = 'public' OR NOT EXISTS (SELECT 1 FROM post_group_visibility gv2 WHERE gv2.post_id = p.id) OR EXISTS (SELECT 1 FROM post_group_visibility gv JOIN member_groups g ON g.id = gv.group_id AND g.status = 'active' WHERE gv.post_id = p.id AND gv.group_id = ?))";
            $params[] = (int) ($this->member['group_id'] ?? 0);
        }
        return array($where, $params);
    }

    private function fieldClause(string $field, string $value, bool $fuzzy, array &$params): string
    {
        $operator = $fuzzy ? "LIKE ? ESCAPE '!'" : '= ?';
        $bound = $fuzzy ? '%' . self::likeEscape($value) . '%' : $value;
        if (isset(self::FILTER_COLUMNS[$field])) {
            $params[] = $bound;
            return self::FILTER_COLUMNS[$field] . ' ' . $operator;
        }
        if ($field === 'tags') {
            array_push($params, $bound, $bound);
            return 'EXISTS (SELECT 1 FROM post_tags pt JOIN tags t ON t.id = pt.tag_id WHERE pt.post_id = p.id AND (t.name ' . $operator . ' OR t.name_en ' . $operator . '))';
        }
        if (preg_match('/^ext_[A-Za-z0-9_]{1,60}$/D', $field) === 1) {
            array_push($params, $field, $bound);
            return 'EXISTS (SELECT 1 FROM post_field_values pf JOIN model_fields mf ON mf.id = pf.field_id WHERE pf.post_id = p.id AND mf.name = ? AND pf.value ' . $operator . ')';
        }
        return '';
    }

    private function orderSql(string $order): string
    {
        $tail = self::DEFAULT_ORDER;
        switch ($order) {
            case '':
            case 'istop':
                return $tail;
            case 'id':
                return 'p.id DESC, ' . $tail;
            case 'date':
                return 'COALESCE(pm.is_top, 0) DESC, ' . self::NOW_SQL . ' DESC, ' . $tail;
            case 'sorting':
                return 'COALESCE(pm.sort_order, 255) ASC, ' . $tail;
            case 'isrecommend':
            case 'isheadline':
                return 'COALESCE(pm.is_recommended, 0) DESC, ' . $tail;
            case 'visits':
            case 'likes':
            case 'oppose':
                return self::ORDER_COLUMNS[$order] . ' DESC, ' . $tail;
            case 'random':
                return $this->pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql' ? 'RAND()' : 'RANDOM()';
        }
        $parts = array();
        foreach (explode(',', $order) as $item) {
            if (preg_match('/^\s*([A-Za-z_][A-Za-z0-9_]*)(?:\s+(asc|desc))?\s*$/iD', $item, $match) !== 1) {
                continue;
            }
            $direction = strtoupper($match[2] ?? 'ASC') === 'DESC' ? 'DESC' : 'ASC';
            if (isset(self::ORDER_COLUMNS[$match[1]])) {
                $parts[] = self::ORDER_COLUMNS[$match[1]] . ' ' . $direction;
            } elseif (str_starts_with($match[1], 'ext_')) {
                $parts[] = '(SELECT pf.value FROM post_field_values pf JOIN model_fields mf ON mf.id = pf.field_id WHERE pf.post_id = p.id AND mf.name = ' . $this->pdo->quote($match[1]) . ') ' . $direction;
            }
        }
        return ($parts ? implode(', ', $parts) . ', ' : '') . $tail;
    }

    /** Load posts in the given order with every Pboot content field. */
    private function postsByIds(array $ids, bool $deferBody = false): array
    {
        if (! $ids) {
            return array();
        }
        $markers = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $this->pdo->prepare("SELECT p.id, p.category_id, p.title, p.title_en, p.slug, p.body, p.body_en, p.created_at, p.updated_at, COALESCE(pm.subtitle, '') AS subtitle, COALESCE(pm.subtitle_en, '') AS subtitle_en, COALESCE(pm.author, '') AS author, COALESCE(pm.source, '') AS source, COALESCE(pm.title_color, '') AS title_color, COALESCE(pm.outlink, '') AS outlink, COALESCE(pm.seo_keywords, '') AS seo_keywords, COALESCE(pm.seo_keywords_en, '') AS seo_keywords_en, COALESCE(pm.seo_description, '') AS seo_description, COALESCE(pm.seo_description_en, '') AS seo_description_en, COALESCE(pm.is_top, 0) AS is_top, COALESCE(pm.is_recommended, 0) AS is_recommended, COALESCE(pm.is_headline, 0) AS is_headline, COALESCE(pm.body_format, 'plain') AS body_format, " . self::NOW_SQL . " AS published, COALESCE(pm.sort_order, 255) AS sort_order, COALESCE(pm.visits, 0) AS visits, COALESCE(pm.likes, 0) AS likes, COALESCE(pm.oppose, 0) AS oppose, COALESCE(pm.sub_category_id, 0) AS sub_category_id, COALESCE(pm.gcode, '') AS gcode, COALESCE(pm.gtype, 4) AS gtype, COALESCE(pm.gnote, '') AS gnote, m.path AS cover, a.bytes AS attachment_bytes FROM posts p LEFT JOIN post_meta pm ON pm.post_id = p.id LEFT JOIN post_cover pc ON pc.post_id = p.id LEFT JOIN media m ON m.id = pc.media_id LEFT JOIN post_attachment a ON a.post_id = p.id WHERE p.id IN ($markers)");
        $stmt->execute($ids);
        $rows = array();
        foreach ($stmt->fetchAll() as $row) {
            $rows[(int) $row['id']] = $row;
        }
        $gallery = array();
        $stmt = $this->pdo->prepare("SELECT g.post_id, m.path, g.title FROM post_gallery g JOIN media m ON m.id = g.media_id WHERE g.post_id IN ($markers) ORDER BY g.post_id, g.position");
        $stmt->execute($ids);
        foreach ($stmt->fetchAll() as $item) {
            $gallery[(int) $item['post_id']][] = $item;
        }
        $tags = array();
        $stmt = $this->pdo->prepare("SELECT pt.post_id, t.name, t.name_en FROM post_tags pt JOIN tags t ON t.id = pt.tag_id WHERE pt.post_id IN ($markers) ORDER BY t.id");
        $stmt->execute($ids);
        foreach ($stmt->fetchAll() as $tag) {
            $tags[(int) $tag['post_id']][] = $this->english() && $tag['name_en'] !== '' ? $tag['name_en'] : $tag['name'];
        }
        $fields = (new ContentModelRepository($this->pdo))->publicFieldsForPosts(array_map(static fn (array $row): array => array('id' => $row['id'], 'category_id' => $row['category_id'], 'slug' => $row['slug']), array_values($rows)));
        $sorts = $this->sorts();
        $result = array();
        foreach ($ids as $id) {
            if (! isset($rows[$id])) {
                continue;
            }
            $row = $rows[$id];
            $sort = $row['category_id'] === null ? null : ($sorts[(string) $row['category_id']] ?? null);
            $subSort = $sorts[(string) $row['sub_category_id']] ?? null;
            $pick = fn (string $field): string => $this->english() && ($row[$field . '_en'] ?? '') !== '' ? (string) $row[$field . '_en'] : (string) ($row[$field] ?? '');
            $date = date('Y-m-d H:i:s', (int) $row['published']);
            $data = array(
                'id' => (string) $row['id'], 'acode' => $this->locale, 'scode' => (string) ($row['category_id'] ?? ''), 'subscode' => $subSort === null ? '' : (string) $row['sub_category_id'],
                'title' => $pick('title'), 'titlecolor' => (string) $row['title_color'], 'subtitle' => $pick('subtitle'),
                'filename' => (string) $row['slug'], 'author' => (string) $row['author'], 'source' => (string) $row['source'],
                'outlink' => (string) $row['outlink'], 'date' => $date, 'ico' => (string) ($row['cover'] ?? ''),
                'pics' => implode(',', array_column($gallery[$id] ?? array(), 'path')),
                'picstitle' => implode(',', array_column($gallery[$id] ?? array(), 'title')),
                'content' => $deferBody ? null : RichText::render($pick('body'), (string) $row['body_format']),
                '_body' => $deferBody ? $pick('body') : '', '_body_format' => (string) $row['body_format'],
                'tags' => implode(',', $tags[$id] ?? array()),
                'enclosure' => $row['attachment_bytes'] === null ? '' : View::localizedPath('/post/' . rawurlencode((string) $row['slug']) . '/attachment'),
                'enclosuresize' => (int) ($row['attachment_bytes'] ?? 0),
                'keywords' => $pick('seo_keywords'), 'description' => $pick('seo_description'), 'sorting' => (string) $row['sort_order'],
                'status' => '1', 'istop' => (string) $row['is_top'], 'isrecommend' => (string) $row['is_recommended'], 'isheadline' => (string) $row['is_headline'],
                'visits' => (int) $row['visits'], 'likes' => (int) $row['likes'], 'oppose' => (int) $row['oppose'],
                'create_time' => date('Y-m-d H:i:s', (int) $row['created_at']), 'update_time' => date('Y-m-d H:i:s', (int) $row['updated_at']),
                'sortname' => (string) ($sort['name'] ?? ''), 'sortfilename' => (string) ($sort['filename'] ?? ''), 'sortoutlink' => (string) ($sort['outlink'] ?? ''),
                'subsortname' => (string) ($subSort['name'] ?? ''), 'subfilename' => (string) ($subSort['filename'] ?? ''), 'type' => '2', 'urlname' => (string) ($sort['urlname'] ?? ''), 'modelname' => (string) ($sort['modelname'] ?? ''),
                'gcode' => (string) $row['gcode'], 'gtype' => (int) $row['gtype'], 'gnote' => (string) $row['gnote'],
                '_images' => array(), '_html' => array('content' => true),
            );
            foreach ($fields[$id] ?? array() as $name => $field) {
                $data[(string) $name] = self::fieldValue($field);
                if (($field['type'] ?? '') === 'editor') {
                    $data['_html'][(string) $name] = true;
                }
                if (($field['type'] ?? '') === 'images') {
                    $data['_images'][(string) $name] = $field['items'] ?? array();
                }
            }
            $result[] = $data;
        }
        return $result;
    }

    private static function fieldValue(array $field): string
    {
        $value = (string) ($field['value'] ?? '');
        return ($field['type'] ?? '') === 'editor' ? RichText::render($value, 'html') : $value;
    }

    private static function likeEscape(string $value): string
    {
        return str_replace(array('!', '%', '_'), array('!!', '!%', '!_'), $value);
    }
}
