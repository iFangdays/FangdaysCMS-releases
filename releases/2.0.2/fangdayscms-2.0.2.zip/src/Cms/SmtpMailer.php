<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use RuntimeException;

/** Minimal SMTP transport for the isolated local sink and configured mail relay. */
final class SmtpMailer
{
    public static function configured(): bool
    {
        return (getenv('FANGDAYS_SMTP_HOST') ?: '') !== '';
    }

    public static function send(string $to, string $type, string $token): void
    {
        $host = (string) getenv('FANGDAYS_SMTP_HOST');
        $port = (int) (getenv('FANGDAYS_SMTP_PORT') ?: 2525);
        $from = (string) (getenv('FANGDAYS_SMTP_FROM') ?: 'noreply@localhost.test');
        if ($host === '' || $port < 1 || $port > 65535 || filter_var($to, FILTER_VALIDATE_EMAIL) === false || filter_var($from, FILTER_VALIDATE_EMAIL) === false) {
            throw new RuntimeException('mail transport unavailable');
        }
        if (! function_exists('stream_socket_client')) {
            throw new RuntimeException('mail transport unavailable');
        }
        $socket = @stream_socket_client('tcp://' . $host . ':' . $port, $errno, $error, 3);
        if (! is_resource($socket)) {
            throw new RuntimeException('mail transport unavailable');
        }
        stream_set_timeout($socket, 3);
        try {
            self::expect($socket, 220);
            self::command($socket, 'EHLO localhost', 250);
            self::command($socket, 'MAIL FROM:<' . $from . '>', 250);
            self::command($socket, 'RCPT TO:<' . $to . '>', 250);
            self::command($socket, 'DATA', 354);
            $url = '/member/' . ($type === 'reset' ? 'reset' : 'verify') . '?token=' . rawurlencode($token);
            $body = "Your FangdaysCMS link: " . $url;
            $message = "From: FangdaysCMS <" . $from . ">\r\nTo: <" . $to . ">\r\nSubject: FangdaysCMS account action\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n" . $body;
            $message = preg_replace('/\r?\n/', "\r\n", $message);
            $message = preg_replace('/^\./m', '..', (string) $message);
            fwrite($socket, $message . "\r\n.\r\n");
            self::expect($socket, 250);
            self::command($socket, 'QUIT', 221);
        } finally {
            fclose($socket);
        }
    }

    /**
     * Pboot sendmail(): HTML mail through the SMTP server of 配置参数 → 邮件通知
     * (ssl:// on 465 / smtp_ssl=1, STARTTLS on 587). $to may list several addresses.
     */
    public static function sendMail(array $server, string $to, string $subject, string $html): void
    {
        $host = trim((string) ($server['smtp_server'] ?? ''));
        $port = (int) ($server['smtp_port'] ?? 0);
        $user = trim((string) ($server['smtp_username'] ?? ''));
        // Auth codes are often copied with spaces/newlines; strip them.
        $password = preg_replace('/\s+/u', '', (string) ($server['smtp_password'] ?? '')) ?? '';
        $sslFlag = (string) ($server['smtp_ssl'] ?? '0') === '1';
        if ($port < 1) {
            $port = $sslFlag ? 465 : 25;
        }
        // Port 465 is SMTPS; treat it as SSL even if the radio was left off.
        $useSsl = $sslFlag || $port === 465;
        $useStartTls = ! $useSsl && ($port === 587 || $port === 25);
        $recipients = array_values(array_filter(preg_split('/[,，;\s]+/u', $to) ?: array(), static fn (string $mail): bool => filter_var($mail, FILTER_VALIDATE_EMAIL) !== false));
        $from = filter_var($user, FILTER_VALIDATE_EMAIL) !== false ? $user : 'noreply@' . ($host !== '' ? $host : 'localhost');
        if ($host === '' || $port > 65535 || ! $recipients) {
            throw new RuntimeException('邮件服务器或收件人未配置。');
        }
        if ($user !== '' && $password === '') {
            throw new RuntimeException('邮箱密码/授权码未填写。');
        }
        if (! function_exists('stream_socket_client')) {
            throw new RuntimeException('主机禁用了 stream_socket_client，无法发送邮件。');
        }

        $remote = ($useSsl ? 'ssl://' : 'tcp://') . $host . ':' . $port;
        $context = stream_context_create(array(
            'ssl' => array(
                'verify_peer' => true,
                'verify_peer_name' => true,
                'allow_self_signed' => false,
            ),
        ));
        $socket = @stream_socket_client($remote, $errno, $error, 12, STREAM_CLIENT_CONNECT, $context);
        if (! is_resource($socket) && $useSsl) {
            // Some hosts fail certificate verification; retry once with peer check relaxed.
            $context = stream_context_create(array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true,
                ),
            ));
            $socket = @stream_socket_client($remote, $errno, $error, 12, STREAM_CLIENT_CONNECT, $context);
        }
        if (! is_resource($socket)) {
            $hint = $port === 465 && ! $sslFlag
                ? '（465 端口须开启 SSL，请在配置里把「是否为SSL」选为「是」后重试）'
                : '';
            throw new RuntimeException('无法连接邮件服务器：' . ($error !== '' ? $error : ('#' . $errno)) . $hint);
        }
        stream_set_timeout($socket, 15);
        $ehloHost = preg_replace('/[^a-zA-Z0-9.-]/', '', (string) (gethostname() ?: 'localhost')) ?: 'localhost';
        try {
            self::expect($socket, 220);
            self::command($socket, 'EHLO ' . $ehloHost, 250);
            if ($useStartTls) {
                self::command($socket, 'STARTTLS', 220);
                $crypto = @stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
                if ($crypto !== true) {
                    throw new RuntimeException('STARTTLS 协商失败，请改用 465 端口并开启 SSL。');
                }
                self::command($socket, 'EHLO ' . $ehloHost, 250);
            }
            if ($user !== '') {
                self::command($socket, 'AUTH LOGIN', 334);
                self::command($socket, base64_encode($user), 334);
                self::command($socket, base64_encode($password), 235);
            }
            self::command($socket, 'MAIL FROM:<' . $from . '>', 250);
            foreach ($recipients as $recipient) {
                self::command($socket, 'RCPT TO:<' . $recipient . '>', 250);
            }
            self::command($socket, 'DATA', 354);
            fwrite($socket, self::buildMime($from, $recipients, $subject, $html, (string) ($server['smtp_from_name'] ?? $server['site_name'] ?? '')) . "\r\n.\r\n");
            self::expect($socket, 250);
            self::command($socket, 'QUIT', 221);
        } catch (RuntimeException $exception) {
            $detail = $exception->getMessage();
            if ($detail === '' || $detail === 'mail transport unavailable') {
                $detail = '服务器拒绝了请求';
            }
            if ($port === 465 && ! $sslFlag) {
                $detail .= '。提示：465 端口请将「是否为SSL」设为「是」';
            } elseif (stripos($detail, '535') !== false || stripos($detail, 'Login fail') !== false || stripos($detail, 'auth') !== false) {
                $detail .= '。请到 QQ 邮箱「授权码管理」重新生成授权码，粘贴到「邮箱密码」后再次测试（不要用 QQ 登录密码或独立密码）';
            }
            throw new RuntimeException('邮件发送失败：' . $detail, 0, $exception);
        } finally {
            fclose($socket);
        }
    }

    /** Build a multipart message with the headers filters expect from real mail clients. */
    private static function buildMime(string $from, array $recipients, string $subject, string $html, string $fromName): string
    {
        $fromName = trim($fromName) !== '' ? trim($fromName) : '网站通知';
        $fromName = str_replace(array("\r", "\n"), '', $fromName);
        $subject = str_replace(array("\r", "\n"), '', $subject);
        $domain = substr(strrchr($from, '@') ?: '@localhost', 1) ?: 'localhost';
        $messageId = sprintf('<%s.%s@%s>', bin2hex(random_bytes(8)), dechex(time()), $domain);
        $boundary = 'fd_' . bin2hex(random_bytes(12));
        $plain = html_entity_decode(strip_tags(str_replace(array('<br>', '<br/>', '<br />', '</p>', '</div>'), "\n", $html)), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $plain = trim(preg_replace("/[ \t]+\n/", "\n", preg_replace("/\n{3,}/", "\n\n", $plain) ?? $plain) ?? $plain);
        if ($plain === '') {
            $plain = $subject;
        }
        $toHeader = implode(', ', array_map(static fn (string $mail): string => '<' . $mail . '>', $recipients));
        return 'From: =?UTF-8?B?' . base64_encode($fromName) . '?= <' . $from . ">\r\n"
            . 'Reply-To: <' . $from . ">\r\n"
            . 'To: ' . $toHeader . "\r\n"
            . 'Date: ' . date('r') . "\r\n"
            . 'Message-ID: ' . $messageId . "\r\n"
            . 'Subject: =?UTF-8?B?' . base64_encode($subject) . "?=\r\n"
            . "MIME-Version: 1.0\r\n"
            . 'Content-Type: multipart/alternative; boundary="' . $boundary . "\"\r\n"
            . "\r\n"
            . '--' . $boundary . "\r\n"
            . "Content-Type: text/plain; charset=UTF-8\r\n"
            . "Content-Transfer-Encoding: base64\r\n\r\n"
            . chunk_split(base64_encode($plain))
            . '--' . $boundary . "\r\n"
            . "Content-Type: text/html; charset=UTF-8\r\n"
            . "Content-Transfer-Encoding: base64\r\n\r\n"
            . chunk_split(base64_encode($html))
            . '--' . $boundary . "--\r\n";
    }

    private static function command($socket, string $command, int $expected): void
    {
        fwrite($socket, $command . "\r\n");
        self::expect($socket, $expected);
    }

    private static function expect($socket, int $expected): void
    {
        $line = fgets($socket);
        if (! is_string($line) || $line === '') {
            throw new RuntimeException('邮件服务器无响应或连接已断开');
        }
        $code = (int) substr($line, 0, 3);
        $body = trim($line);
        while (isset($line[3]) && $line[3] === '-') {
            $line = fgets($socket);
            if (! is_string($line)) {
                throw new RuntimeException('邮件服务器响应中断：' . $body);
            }
            $body .= ' ' . trim($line);
        }
        if ($code !== $expected) {
            throw new RuntimeException($body !== '' ? $body : ('期望 ' . $expected . '，实际 ' . $code));
        }
    }
}
