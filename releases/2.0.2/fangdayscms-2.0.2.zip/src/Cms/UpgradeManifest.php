<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;

/** Validates signed, immutable upgrade metadata before any package is downloaded. */
final class UpgradeManifest
{
    public const DEFAULT_FEED_URL = 'https://raw.githubusercontent.com/iFangdays/FangdaysCMS-releases/main/latest.fdu1';
    private const PREFIX = 'FDU1';
    private const MAX_BYTES = 32768;
    private const MAX_REDIRECTS = 5;

    public static function fetch(string $url, int $timeout = 10): string
    {
        $primary = trim($url);
        self::assertHttpsUrl($primary, '升级清单地址必须使用 HTTPS。');
        $timeout = max(1, min(30, $timeout));
        $candidates = self::mirrorUrls($primary);
        $errors = array();
        foreach ($candidates as $candidate) {
            try {
                return self::fetchOnce($candidate, $timeout);
            } catch (InvalidArgumentException $error) {
                $errors[] = $error->getMessage();
            }
        }
        if (count($candidates) > 1) {
            throw new InvalidArgumentException('已尝试 ' . count($candidates) . ' 个官方更新源均失败：' . $errors[0]);
        }
        throw new InvalidArgumentException($errors[0] ?? '升级清单服务器响应失败。');
    }

    /**
     * Expands official GitHub release URLs with jsDelivr CDN mirrors so mainland China hosts
     * still succeed when raw.githubusercontent.com drops or resets connections.
     * Custom/private feed URLs are returned untouched.
     *
     * @return list<string>
     */
    public static function mirrorUrls(string $url): array
    {
        $url = trim($url);
        $urls = array($url);
        if (preg_match('#^https://raw\.githubusercontent\.com/iFangdays/FangdaysCMS-releases/([^/]+)/(.+)$#', $url, $match)) {
            $branch = $match[1];
            $path = $match[2];
            $urls[] = 'https://cdn.jsdelivr.net/gh/iFangdays/FangdaysCMS-releases@' . $branch . '/' . $path;
            $urls[] = 'https://fastly.jsdelivr.net/gh/iFangdays/FangdaysCMS-releases@' . $branch . '/' . $path;
        } elseif (preg_match('#^https://(?:cdn|fastly)\.jsdelivr\.net/gh/iFangdays/FangdaysCMS-releases@([^/]+)/(.+)$#', $url, $match)) {
            $branch = $match[1];
            $path = $match[2];
            $alts = array(
                'https://fastly.jsdelivr.net/gh/iFangdays/FangdaysCMS-releases@' . $branch . '/' . $path,
                'https://cdn.jsdelivr.net/gh/iFangdays/FangdaysCMS-releases@' . $branch . '/' . $path,
                'https://raw.githubusercontent.com/iFangdays/FangdaysCMS-releases/' . $branch . '/' . $path,
            );
            foreach ($alts as $alt) {
                if (! in_array($alt, $urls, true)) {
                    $urls[] = $alt;
                }
            }
        }
        return $urls;
    }

    private static function fetchOnce(string $url, int $timeout): string
    {
        $current = $url;
        for ($hop = 0; $hop <= self::MAX_REDIRECTS; $hop++) {
            self::assertHttpsUrl($current, '升级清单地址必须使用 HTTPS。');
            [$status, $headers, $body, $tooLarge, $transportError] = function_exists('curl_init')
                ? self::httpGetCurl($current, $timeout)
                : self::httpGetStream($current, $timeout);
            if ($status >= 300 && $status < 400) {
                $location = self::headerValue($headers, 'location');
                if ($location === null || $hop === self::MAX_REDIRECTS) {
                    throw new InvalidArgumentException('升级清单重定向无效或次数过多。');
                }
                $current = self::resolveRedirect($current, $location);
                continue;
            }
            if ($tooLarge) {
                throw new InvalidArgumentException('升级清单下载失败或超过大小限制。');
            }
            if ($transportError !== null) {
                throw new InvalidArgumentException('无法连接升级清单服务器（' . self::formatTransportError($transportError) . '）。');
            }
            if ($status < 200 || $status >= 300) {
                throw new InvalidArgumentException($status > 0 ? '升级清单服务器返回 HTTP ' . $status . '。' : '升级清单服务器响应失败。');
            }
            if (! is_string($body) || strlen($body) > self::MAX_BYTES) {
                throw new InvalidArgumentException('升级清单下载失败或超过大小限制。');
            }
            return trim($body);
        }
        throw new InvalidArgumentException('升级清单重定向次数过多。');
    }

    /** @return array{0:int,1:list<string>,2:?string,3:bool,4:?string} */
    private static function httpGetCurl(string $url, int $timeout): array
    {
        $headers = array();
        $body = '';
        $tooLarge = false;
        $handle = curl_init($url);
        if ($handle === false) {
            return array(0, array(), null, false, '无法初始化 cURL');
        }
        curl_setopt_array($handle, array(
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_CONNECTTIMEOUT => min(8, $timeout),
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT => 'FangdaysCMS/' . App::VERSION,
            CURLOPT_HTTPHEADER => array('Accept: text/plain, */*'),
            CURLOPT_HEADERFUNCTION => static function ($ch, string $line) use (&$headers): int {
                $trimmed = trim($line);
                if ($trimmed !== '') {
                    if (preg_match('/^HTTP\/\S+\s+\d{3}\b/', $trimmed)) {
                        $headers = array($trimmed);
                    } else {
                        $headers[] = $trimmed;
                    }
                }
                return strlen($line);
            },
            CURLOPT_WRITEFUNCTION => static function ($ch, string $chunk) use (&$headers, &$body, &$tooLarge): int {
                $code = self::statusCode($headers);
                if ($code < 200 || $code >= 300) {
                    return strlen($chunk);
                }
                if (strlen($body) + strlen($chunk) > self::MAX_BYTES) {
                    $tooLarge = true;
                    return 0;
                }
                $body .= $chunk;
                return strlen($chunk);
            },
        ));
        $ok = curl_exec($handle);
        $status = (int) curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
        $error = $ok === false && ! $tooLarge ? (curl_error($handle) ?: 'cURL error ' . curl_errno($handle)) : null;
        unset($handle);
        if ($status === 0 && $headers !== array()) {
            $status = self::statusCode($headers);
        }
        return array($status, $headers, $ok === false ? null : $body, $tooLarge, $error);
    }

    /** @return array{0:int,1:list<string>,2:?string,3:bool,4:?string} */
    private static function httpGetStream(string $url, int $timeout): array
    {
        $context = stream_context_create(array(
            'http' => array(
                'method' => 'GET',
                'timeout' => $timeout,
                'follow_location' => 0,
                'ignore_errors' => true,
                'header' => 'User-Agent: FangdaysCMS/' . App::VERSION . "\r\nAccept: text/plain, */*\r\n",
            ),
            'ssl' => array('verify_peer' => true, 'verify_peer_name' => true),
        ));
        error_clear_last();
        $stream = @fopen($url, 'rb', false, $context);
        if ($stream === false) {
            $last = error_get_last();
            return array(0, array(), null, false, is_array($last) ? (string) ($last['message'] ?? '连接失败') : '连接失败');
        }
        $meta = stream_get_meta_data($stream);
        $headers = is_array($meta['wrapper_data'] ?? null) ? array_values(array_map('strval', $meta['wrapper_data'])) : array();
        $status = self::statusCode($headers);
        $body = ($status >= 200 && $status < 300) ? @stream_get_contents($stream, self::MAX_BYTES + 1) : '';
        fclose($stream);
        $tooLarge = is_string($body) && strlen($body) > self::MAX_BYTES;
        return array($status, $headers, is_string($body) ? $body : null, $tooLarge, null);
    }

    public static function formatTransportError(string $raw): string
    {
        $clean = trim(preg_replace('/\s+/', ' ', strip_tags($raw)) ?? $raw);
        $clean = preg_replace('/^fopen\([^)]*\):\s*/i', '', $clean) ?? $clean;
        if (stripos($clean, 'timed out') !== false || stripos($clean, 'timeout') !== false) {
            return '连接超时';
        }
        if (stripos($clean, 'reset by peer') !== false || stripos($clean, 'connection reset') !== false || stripos($clean, 'empty reply') !== false) {
            return '连接被远端重置';
        }
        if (stripos($clean, 'could not resolve host') !== false || stripos($clean, 'getaddrinfo') !== false) {
            return '域名解析失败';
        }
        if (stripos($clean, 'ssl') !== false || stripos($clean, 'certificate') !== false || stripos($clean, 'crypto') !== false) {
            return 'SSL/TLS 握手或证书校验失败';
        }
        return strlen($clean) > 120 ? substr($clean, 0, 120) . '...' : ($clean !== '' ? $clean : '网络连接失败');
    }

    /** Signs upgrade metadata with the vendor Ed25519 private key. */
    public static function sign(array $claims, string $secretKey): string
    {
        \FangdaysCMS\Licensing\LicenseCode::requireSodium();
        if (strlen($secretKey) !== SODIUM_CRYPTO_SIGN_SECRETKEYBYTES) {
            throw new InvalidArgumentException('签发私钥无效。');
        }
        $normalized = self::normalizeClaims($claims);
        $payload = json_encode($normalized, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        $message = self::PREFIX . '.' . self::encode($payload);
        $signature = sodium_crypto_sign_detached($message, $secretKey);
        return $message . '.' . self::encode($signature);
    }

    /** Verifies signature and metadata without requiring version > currentVersion. */
    public static function inspect(string $manifest, array $publicKeys): array
    {
        \FangdaysCMS\Licensing\LicenseCode::requireSodium();
        $manifest = trim($manifest);
        if (strlen($manifest) > self::MAX_BYTES || ! preg_match('/^FDU1\.([A-Za-z0-9_-]+)\.([A-Za-z0-9_-]+)$/D', $manifest, $parts)) {
            throw new InvalidArgumentException('升级清单格式无效。');
        }
        $payload = self::decode($parts[1]);
        $signature = self::decode($parts[2]);
        if ($payload === null || $signature === null || strlen($signature) !== SODIUM_CRYPTO_SIGN_BYTES) {
            throw new InvalidArgumentException('升级清单签名无效。');
        }
        $claims = json_decode($payload, true, 16);
        if (! is_array($claims) || ! is_string($claims['key_id'] ?? null)) {
            throw new InvalidArgumentException('升级清单字段无效。');
        }
        $key = $publicKeys[$claims['key_id']] ?? null;
        $publicKey = is_string($key) ? base64_decode($key, true) : false;
        if ($publicKey === false || strlen($publicKey) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES || ! sodium_crypto_sign_verify_detached($signature, self::PREFIX . '.' . $parts[1], $publicKey)) {
            throw new InvalidArgumentException('升级清单签名验证失败。');
        }
        return self::normalizeClaims($claims);
    }

    public static function verify(string $manifest, array $publicKeys, string $currentVersion): array
    {
        $verified = self::inspect($manifest, $publicKeys);
        if (version_compare($verified['version'], $currentVersion, '<=')) {
            throw new InvalidArgumentException('升级清单内容无效。');
        }
        return $verified;
    }

    /** @return array{key_id:string,version:string,sha256:string,size:int,url:string,notes?:string,released_at?:int} */
    private static function normalizeClaims(array $claims): array
    {
        $keyId = (string) ($claims['key_id'] ?? '');
        $version = (string) ($claims['version'] ?? '');
        $sha256 = (string) ($claims['sha256'] ?? '');
        $size = $claims['size'] ?? null;
        $url = (string) ($claims['url'] ?? '');
        if ($keyId === '' || ! preg_match('/^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/D', $version) || ! preg_match('/^[a-f0-9]{64}$/D', $sha256) || ! is_int($size) || $size < 1 || $size > 52428800 || ! filter_var($url, FILTER_VALIDATE_URL) || parse_url($url, PHP_URL_SCHEME) !== 'https') {
            throw new InvalidArgumentException('升级清单内容无效。');
        }
        $result = array('key_id' => $keyId, 'version' => $version, 'sha256' => $sha256, 'size' => $size, 'url' => $url);
        if (array_key_exists('notes', $claims) && $claims['notes'] !== null && $claims['notes'] !== '') {
            if (! is_string($claims['notes']) || strlen($claims['notes']) > 4000) {
                throw new InvalidArgumentException('升级清单更新说明无效。');
            }
            $result['notes'] = $claims['notes'];
        }
        if (array_key_exists('released_at', $claims) && $claims['released_at'] !== null) {
            if (! is_int($claims['released_at']) || $claims['released_at'] < 0) {
                throw new InvalidArgumentException('升级清单发布时间无效。');
            }
            $result['released_at'] = $claims['released_at'];
        }
        return $result;
    }

    public static function assertHttpsUrl(string $url, string $message): void
    {
        if (parse_url($url, PHP_URL_SCHEME) !== 'https' || filter_var($url, FILTER_VALIDATE_URL) === false) {
            throw new InvalidArgumentException($message);
        }
    }

    public static function resolveRedirect(string $baseUrl, string $location): string
    {
        $location = trim($location);
        if ($location === '' || str_contains($location, "\r") || str_contains($location, "\n")) {
            throw new InvalidArgumentException('重定向地址无效。');
        }
        if (preg_match('#^[A-Za-z][A-Za-z0-9+.-]*://#', $location)) {
            self::assertHttpsUrl($location, '重定向目标必须使用 HTTPS。');
            return $location;
        }
        $parts = parse_url($baseUrl);
        if (! is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) {
            throw new InvalidArgumentException('重定向基础地址无效。');
        }
        $origin = $parts['scheme'] . '://' . $parts['host'] . (isset($parts['port']) ? ':' . $parts['port'] : '');
        if (str_starts_with($location, '//')) {
            $resolved = $parts['scheme'] . ':' . $location;
            self::assertHttpsUrl($resolved, '重定向目标必须使用 HTTPS。');
            return $resolved;
        }
        if (str_starts_with($location, '/')) {
            $resolved = $origin . $location;
            self::assertHttpsUrl($resolved, '重定向目标必须使用 HTTPS。');
            return $resolved;
        }
        $dir = dirname((string) ($parts['path'] ?? '/'));
        $resolved = $origin . rtrim($dir, '/') . '/' . $location;
        self::assertHttpsUrl($resolved, '重定向目标必须使用 HTTPS。');
        return $resolved;
    }

    public static function statusCode(array $headers): int
    {
        $statusLine = (string) ($headers[0] ?? '');
        return preg_match('/^HTTP\/\S+\s+(\d{3})\b/', $statusLine, $match) ? (int) $match[1] : 0;
    }

    public static function headerValue(array $headers, string $name): ?string
    {
        $prefix = strtolower($name) . ':';
        foreach (array_slice($headers, 1) as $header) {
            if (is_string($header) && str_starts_with(strtolower($header), $prefix)) {
                return trim(substr($header, strlen($prefix)));
            }
        }
        return null;
    }

    private static function encode(string $bytes): string
    {
        return rtrim(strtr(base64_encode($bytes), '+/', '-_'), '=');
    }

    private static function decode(string $value): ?string
    {
        $decoded = base64_decode(strtr($value, '-_', '+/'), true);
        return $decoded === false ? null : $decoded;
    }
}
