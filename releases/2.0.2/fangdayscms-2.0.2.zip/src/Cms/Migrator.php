<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use PDO;

/** Additive schema upgrade from the original FangdaysCMS installation. */
final class Migrator
{
    public const VERSION = 59;

    public static function ensure(PDO $pdo): void
    {
        $mysql = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql';
        $pdo->exec($mysql
            ? 'CREATE TABLE IF NOT EXISTS cms_schema (id TINYINT UNSIGNED PRIMARY KEY, version INT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
            : 'CREATE TABLE IF NOT EXISTS cms_schema (id INTEGER PRIMARY KEY, version INTEGER NOT NULL)');
        $version = $pdo->query('SELECT version FROM cms_schema WHERE id = 1')->fetchColumn();
        if ($version !== false && (int) $version >= self::VERSION) {
            return;
        }
        if (! $mysql) {
            $pdo->beginTransaction();
        }
        try {
            foreach (self::statements($mysql) as $statement) {
                $pdo->exec($statement);
            }
            if (! self::hasColumn($pdo, $mysql, 'users', 'display_name')) {
                $pdo->exec($mysql ? "ALTER TABLE users ADD COLUMN display_name VARCHAR(100) NOT NULL DEFAULT ''" : "ALTER TABLE users ADD COLUMN display_name TEXT NOT NULL DEFAULT ''");
            }
            if (! self::hasColumn($pdo, $mysql, 'users', 'email')) {
                $pdo->exec($mysql ? "ALTER TABLE users ADD COLUMN email VARCHAR(191) NOT NULL DEFAULT ''" : "ALTER TABLE users ADD COLUMN email TEXT NOT NULL DEFAULT ''");
            }
            if (! self::hasColumn($pdo, $mysql, 'regions', 'legacy_acode')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE regions ADD COLUMN legacy_acode VARCHAR(20) NULL"
                    : "ALTER TABLE regions ADD COLUMN legacy_acode TEXT NULL");
            }
            if (! self::hasColumn($pdo, $mysql, 'regions', 'legacy_pcode')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE regions ADD COLUMN legacy_pcode VARCHAR(20) NULL"
                    : "ALTER TABLE regions ADD COLUMN legacy_pcode TEXT NULL");
            }
            if (! $mysql) {
                $pdo->exec('CREATE UNIQUE INDEX IF NOT EXISTS regions_legacy_acode ON regions (legacy_acode)');
            } else {
                $index = $pdo->query("SHOW INDEX FROM regions WHERE Key_name = 'regions_legacy_acode'")->fetch();
                if ($index === false) {
                    $pdo->exec('CREATE UNIQUE INDEX regions_legacy_acode ON regions (legacy_acode)');
                }
            }
            if (! self::hasColumn($pdo, $mysql, 'category_settings', 'single_title_en')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE category_settings ADD COLUMN single_title_en VARCHAR(191) NOT NULL DEFAULT ''"
                    : "ALTER TABLE category_settings ADD COLUMN single_title_en TEXT NOT NULL DEFAULT ''");
            }
            if (! self::hasColumn($pdo, $mysql, 'category_settings', 'single_body_en')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE category_settings ADD COLUMN single_body_en LONGTEXT NOT NULL"
                    : "ALTER TABLE category_settings ADD COLUMN single_body_en TEXT NOT NULL DEFAULT ''");
            }
            // Pboot ay_member / ay_member_group: account names, avatar, score, login statistics, group score range.
            foreach (array('members' => array('username' => 'text', 'mobile' => 'text', 'headpic' => 'text', 'score' => 'int', 'login_count' => 'int', 'last_login_ip' => 'text', 'last_login_time' => 'int'), 'member_groups' => array('description' => 'text', 'lscore' => 'int', 'uscore' => 'int')) as $table => $columns) {
                foreach ($columns as $column => $type) {
                    if (! self::hasColumn($pdo, $mysql, $table, $column)) {
                        $pdo->exec('ALTER TABLE ' . $table . ' ADD COLUMN ' . $column . ' ' . ($type === 'int' ? ($mysql ? 'BIGINT NOT NULL DEFAULT 0' : 'INTEGER NOT NULL DEFAULT 0') : ($mysql ? "VARCHAR(191) NOT NULL DEFAULT ''" : "TEXT NOT NULL DEFAULT ''")));
                    }
                }
            }
            // Pboot content and category access (gcode, gtype, gnote), sub-category, category descriptions,
            // single-page time and visits, role details, log environment and account status.
            $access = array('gcode' => 'text', 'gtype' => 'level', 'gnote' => 'text');
            foreach (array('post_meta' => array('sub_category_id' => 'int') + $access, 'category_settings' => $access + array('def1' => 'long', 'def2' => 'long', 'def3' => 'long', 'single_updated_at' => 'int', 'single_visits' => 'int'), 'roles' => array('description' => 'text', 'created_at' => 'int', 'updated_at' => 'int'), 'audit_logs' => array('user_os' => 'text', 'user_bs' => 'text'), 'users' => array('status' => 'status')) as $table => $columns) {
                foreach ($columns as $column => $type) {
                    if (! self::hasColumn($pdo, $mysql, $table, $column)) {
                        $pdo->exec('ALTER TABLE ' . $table . ' ADD COLUMN ' . $column . ' ' . match ($type) {
                            'int' => $mysql ? 'BIGINT NOT NULL DEFAULT 0' : 'INTEGER NOT NULL DEFAULT 0',
                            'level' => $mysql ? 'TINYINT NOT NULL DEFAULT 4' : 'INTEGER NOT NULL DEFAULT 4',
                            'status' => $mysql ? "VARCHAR(16) NOT NULL DEFAULT 'active'" : "TEXT NOT NULL DEFAULT 'active'",
                            'long' => $mysql ? "VARCHAR(1000) NOT NULL DEFAULT ''" : "TEXT NOT NULL DEFAULT ''",
                            default => $mysql ? "VARCHAR(191) NOT NULL DEFAULT ''" : "TEXT NOT NULL DEFAULT ''",
                        });
                    }
                }
            }
            // Pboot ay_message / ay_member_comment details: visitor environment, admin reply, comment replies.
            foreach (array('guestbook_messages' => array('user_ip' => 'text', 'user_os' => 'text', 'user_bs' => 'text', 'recontent' => 'long', 'replied_at' => 'int'), 'post_comments' => array('parent_id' => 'int', 'parent_member_id' => 'int', 'user_ip' => 'text', 'user_os' => 'text', 'user_bs' => 'text', 'likes' => 'int', 'oppose' => 'int')) as $table => $columns) {
                foreach ($columns as $column => $type) {
                    if (! self::hasColumn($pdo, $mysql, $table, $column)) {
                        $pdo->exec('ALTER TABLE ' . $table . ' ADD COLUMN ' . $column . ' ' . match ($type) {
                            'int' => $mysql ? 'BIGINT NOT NULL DEFAULT 0' : 'INTEGER NOT NULL DEFAULT 0',
                            'long' => $mysql ? 'TEXT NOT NULL' : "TEXT NOT NULL DEFAULT ''",
                            default => $mysql ? "VARCHAR(64) NOT NULL DEFAULT ''" : "TEXT NOT NULL DEFAULT ''",
                        });
                    }
                }
            }
            foreach (array('visits', 'likes', 'oppose') as $column) {
                if (! self::hasColumn($pdo, $mysql, 'post_meta', $column)) {
                    $pdo->exec('ALTER TABLE post_meta ADD COLUMN ' . $column . ($mysql ? ' INT UNSIGNED' : ' INTEGER') . ' NOT NULL DEFAULT 0');
                }
            }
            // Pboot "文章内链": keywords linked automatically inside content bodies.
            $pdo->exec($mysql
                ? 'CREATE TABLE IF NOT EXISTS content_links (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(50) NOT NULL, link VARCHAR(255) NOT NULL, sort_order INT NOT NULL DEFAULT 255) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
                : 'CREATE TABLE IF NOT EXISTS content_links (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, link TEXT NOT NULL, sort_order INTEGER NOT NULL DEFAULT 255)');
            // Imported Pboot areas: rows of a non-default area carry its locale, the rest are shared (empty).
            foreach (array('categories', 'slides', 'friend_links', 'content_links') as $table) {
                if (! self::hasColumn($pdo, $mysql, $table, 'area')) {
                    $pdo->exec('ALTER TABLE ' . $table . ' ADD COLUMN area ' . ($mysql ? "VARCHAR(32) NOT NULL DEFAULT ''" : "TEXT NOT NULL DEFAULT ''"));
                }
            }
            if (! self::hasColumn($pdo, $mysql, 'category_settings', 'subname')) {
                // Pboot sort subname, shown by themes as [sort:subname] / {sort:subname}.
                $pdo->exec($mysql
                    ? "ALTER TABLE category_settings ADD COLUMN subname VARCHAR(200) NOT NULL DEFAULT ''"
                    : "ALTER TABLE category_settings ADD COLUMN subname TEXT NOT NULL DEFAULT ''");
            }
            if (! self::hasColumn($pdo, $mysql, 'tags', 'name_en')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE tags ADD COLUMN name_en VARCHAR(100) NOT NULL DEFAULT ''"
                    : "ALTER TABLE tags ADD COLUMN name_en TEXT NOT NULL DEFAULT ''");
            }
            if (! self::hasColumn($pdo, $mysql, 'custom_labels', 'type')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE custom_labels ADD COLUMN type VARCHAR(16) NOT NULL DEFAULT 'text'"
                    : "ALTER TABLE custom_labels ADD COLUMN type TEXT NOT NULL DEFAULT 'text'");
            }
            if (! self::hasColumn($pdo, $mysql, 'custom_labels', 'value_en')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE custom_labels ADD COLUMN value_en TEXT NOT NULL"
                    : "ALTER TABLE custom_labels ADD COLUMN value_en TEXT NOT NULL DEFAULT ''");
            }
            foreach (array('name_en', 'address_en', 'contact_en') as $column) {
                if (! self::hasColumn($pdo, $mysql, 'company_profile', $column)) {
                    $pdo->exec($mysql
                        ? "ALTER TABLE company_profile ADD COLUMN $column TEXT NOT NULL"
                        : "ALTER TABLE company_profile ADD COLUMN $column TEXT NOT NULL DEFAULT ''");
                }
            }
            foreach (array(
                'map_provider' => "VARCHAR(16) NOT NULL DEFAULT ''",
                'map_baidu_lng' => "VARCHAR(32) NOT NULL DEFAULT ''",
                'map_baidu_lat' => "VARCHAR(32) NOT NULL DEFAULT ''",
                'map_amap_lng' => "VARCHAR(32) NOT NULL DEFAULT ''",
                'map_amap_lat' => "VARCHAR(32) NOT NULL DEFAULT ''",
                'cs_enabled' => "VARCHAR(8) NOT NULL DEFAULT ''",
                'cs_show_phone' => "VARCHAR(8) NOT NULL DEFAULT ''",
                'cs_show_weixin' => "VARCHAR(8) NOT NULL DEFAULT ''",
                'cs_show_qq' => "VARCHAR(8) NOT NULL DEFAULT ''",
                'cs_weixin_qr' => "VARCHAR(255) NOT NULL DEFAULT ''",
                'cs_show_chat' => "VARCHAR(8) NOT NULL DEFAULT ''",
                'cs_chat_mode' => "VARCHAR(16) NOT NULL DEFAULT ''",
                'cs_chat_label' => "VARCHAR(60) NOT NULL DEFAULT ''",
                'cs_chat_url' => "VARCHAR(500) NOT NULL DEFAULT ''",
                'cs_chat_script' => 'TEXT NOT NULL',
            ) as $column => $mysqlType) {
                if (! self::hasColumn($pdo, $mysql, 'company_profile', $column)) {
                    $pdo->exec($mysql
                        ? "ALTER TABLE company_profile ADD COLUMN $column $mysqlType"
                        : "ALTER TABLE company_profile ADD COLUMN $column TEXT NOT NULL DEFAULT ''");
                }
            }

            if (! self::hasColumn($pdo, $mysql, 'category_settings', 'seo_title_en')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE category_settings ADD COLUMN seo_title_en VARCHAR(191) NOT NULL DEFAULT ''"
                    : "ALTER TABLE category_settings ADD COLUMN seo_title_en TEXT NOT NULL DEFAULT ''");
            }
            if (! self::hasColumn($pdo, $mysql, 'category_settings', 'seo_keywords_en')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE category_settings ADD COLUMN seo_keywords_en VARCHAR(255) NOT NULL DEFAULT ''"
                    : "ALTER TABLE category_settings ADD COLUMN seo_keywords_en TEXT NOT NULL DEFAULT ''");
            }
            if (! self::hasColumn($pdo, $mysql, 'category_settings', 'seo_description_en')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE category_settings ADD COLUMN seo_description_en TEXT NOT NULL"
                    : "ALTER TABLE category_settings ADD COLUMN seo_description_en TEXT NOT NULL DEFAULT ''");
            }
            if (! self::hasColumn($pdo, $mysql, 'pages', 'seo_title')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE pages ADD COLUMN seo_title VARCHAR(191) NOT NULL DEFAULT ''"
                    : "ALTER TABLE pages ADD COLUMN seo_title TEXT NOT NULL DEFAULT ''");
            }
            if (! self::hasColumn($pdo, $mysql, 'pages', 'seo_keywords')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE pages ADD COLUMN seo_keywords VARCHAR(255) NOT NULL DEFAULT ''"
                    : "ALTER TABLE pages ADD COLUMN seo_keywords TEXT NOT NULL DEFAULT ''");
            }
            if (! self::hasColumn($pdo, $mysql, 'pages', 'seo_description')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE pages ADD COLUMN seo_description TEXT NOT NULL"
                    : "ALTER TABLE pages ADD COLUMN seo_description TEXT NOT NULL DEFAULT ''");
            }
            if (! self::hasColumn($pdo, $mysql, 'pages', 'seo_title_en')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE pages ADD COLUMN seo_title_en VARCHAR(191) NOT NULL DEFAULT ''"
                    : "ALTER TABLE pages ADD COLUMN seo_title_en TEXT NOT NULL DEFAULT ''");
            }
            if (! self::hasColumn($pdo, $mysql, 'pages', 'seo_keywords_en')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE pages ADD COLUMN seo_keywords_en VARCHAR(255) NOT NULL DEFAULT ''"
                    : "ALTER TABLE pages ADD COLUMN seo_keywords_en TEXT NOT NULL DEFAULT ''");
            }
            if (! self::hasColumn($pdo, $mysql, 'pages', 'seo_description_en')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE pages ADD COLUMN seo_description_en TEXT NOT NULL"
                    : "ALTER TABLE pages ADD COLUMN seo_description_en TEXT NOT NULL DEFAULT ''");
            }

            if (! self::hasColumn($pdo, $mysql, 'post_meta', 'seo_keywords_en')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE post_meta ADD COLUMN seo_keywords_en VARCHAR(255) NOT NULL DEFAULT ''"
                    : "ALTER TABLE post_meta ADD COLUMN seo_keywords_en TEXT NOT NULL DEFAULT ''");
            }
            if (! self::hasColumn($pdo, $mysql, 'post_meta', 'seo_description_en')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE post_meta ADD COLUMN seo_description_en TEXT NOT NULL"
                    : "ALTER TABLE post_meta ADD COLUMN seo_description_en TEXT NOT NULL DEFAULT ''");
            }

            if (! self::hasColumn($pdo, $mysql, 'pages', 'body_en')) {
                $pdo->exec($mysql
                    ? 'ALTER TABLE pages ADD COLUMN body_en LONGTEXT NOT NULL'
                    : "ALTER TABLE pages ADD COLUMN body_en TEXT NOT NULL DEFAULT ''");
            }

            if (! self::hasColumn($pdo, $mysql, 'posts', 'body_en')) {
                $pdo->exec($mysql
                    ? 'ALTER TABLE posts ADD COLUMN body_en LONGTEXT NOT NULL'
                    : "ALTER TABLE posts ADD COLUMN body_en TEXT NOT NULL DEFAULT ''");
            }
            if (! self::hasColumn($pdo, $mysql, 'post_meta', 'subtitle_en')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE post_meta ADD COLUMN subtitle_en VARCHAR(255) NOT NULL DEFAULT ''"
                    : "ALTER TABLE post_meta ADD COLUMN subtitle_en TEXT NOT NULL DEFAULT ''");
            }
            if (! self::hasColumn($pdo, $mysql, 'posts', 'title_en')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE posts ADD COLUMN title_en VARCHAR(191) NOT NULL DEFAULT ''"
                    : "ALTER TABLE posts ADD COLUMN title_en TEXT NOT NULL DEFAULT ''");
            }
            if (! self::hasColumn($pdo, $mysql, 'pages', 'title_en')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE pages ADD COLUMN title_en VARCHAR(191) NOT NULL DEFAULT ''"
                    : "ALTER TABLE pages ADD COLUMN title_en TEXT NOT NULL DEFAULT ''");
            }
            if (! self::hasColumn($pdo, $mysql, 'categories', 'name_en')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE categories ADD COLUMN name_en VARCHAR(191) NOT NULL DEFAULT ''"
                    : "ALTER TABLE categories ADD COLUMN name_en TEXT NOT NULL DEFAULT ''");
            }

            if (! self::hasColumn($pdo, $mysql, 'categories', 'parent_id')) {
                $pdo->exec($mysql
                    ? 'ALTER TABLE categories ADD COLUMN parent_id BIGINT UNSIGNED NULL, ADD CONSTRAINT fk_categories_parent FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE RESTRICT'
                    : 'ALTER TABLE categories ADD COLUMN parent_id INTEGER NULL REFERENCES categories(id) ON DELETE RESTRICT');
            }
            if (! self::hasColumn($pdo, $mysql, 'post_meta', 'body_format')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE post_meta ADD COLUMN body_format VARCHAR(16) NOT NULL DEFAULT 'plain'"
                    : "ALTER TABLE post_meta ADD COLUMN body_format TEXT NOT NULL DEFAULT 'plain'");
            }
            if (! self::hasColumn($pdo, $mysql, 'pages', 'body_format')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE pages ADD COLUMN body_format VARCHAR(16) NOT NULL DEFAULT 'plain'"
                    : "ALTER TABLE pages ADD COLUMN body_format TEXT NOT NULL DEFAULT 'plain'");
            }
            if (! self::hasColumn($pdo, $mysql, 'category_settings', 'single_body_format')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE category_settings ADD COLUMN single_body_format VARCHAR(16) NOT NULL DEFAULT 'plain'"
                    : "ALTER TABLE category_settings ADD COLUMN single_body_format TEXT NOT NULL DEFAULT 'plain'");
            }
            if (! self::hasColumn($pdo, $mysql, 'category_settings', 'is_visible')) {
                $pdo->exec($mysql
                    ? 'ALTER TABLE category_settings ADD COLUMN is_visible TINYINT NOT NULL DEFAULT 1'
                    : 'ALTER TABLE category_settings ADD COLUMN is_visible INTEGER NOT NULL DEFAULT 1');
            }
            foreach (array('list_template', 'content_template') as $column) {
                if (! self::hasColumn($pdo, $mysql, 'content_models', $column)) {
                    $pdo->exec($mysql
                        ? "ALTER TABLE content_models ADD COLUMN $column VARCHAR(64) NOT NULL DEFAULT ''"
                        : "ALTER TABLE content_models ADD COLUMN $column TEXT NOT NULL DEFAULT ''");
                }
                if (! self::hasColumn($pdo, $mysql, 'category_settings', $column)) {
                    $pdo->exec($mysql
                        ? "ALTER TABLE category_settings ADD COLUMN $column VARCHAR(64) NOT NULL DEFAULT ''"
                        : "ALTER TABLE category_settings ADD COLUMN $column TEXT NOT NULL DEFAULT ''");
                }
            }
            if (! self::hasColumn($pdo, $mysql, 'content_models', 'type')) {
                $pdo->exec($mysql
                    ? "ALTER TABLE content_models ADD COLUMN type VARCHAR(16) NOT NULL DEFAULT 'list'"
                    : "ALTER TABLE content_models ADD COLUMN type TEXT NOT NULL DEFAULT 'list'");
            }
            if (! self::hasColumn($pdo, $mysql, 'post_meta', 'published_at')) {
                $pdo->exec($mysql
                    ? 'ALTER TABLE post_meta ADD COLUMN published_at BIGINT NOT NULL DEFAULT 0'
                    : 'ALTER TABLE post_meta ADD COLUMN published_at INTEGER NOT NULL DEFAULT 0');
            }
            if (! self::hasColumn($pdo, $mysql, 'post_meta', 'sort_order')) {
                $pdo->exec($mysql
                    ? 'ALTER TABLE post_meta ADD COLUMN sort_order INT NOT NULL DEFAULT 255'
                    : 'ALTER TABLE post_meta ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 255');
            }
            $ignore = $mysql ? 'INSERT IGNORE' : 'INSERT OR IGNORE';
            foreach (array(
                array('zh-CN', 'zh', '简体中文', 1, 1),
                array('en-US', 'en', 'English', 0, 1),
            ) as $region) {
                $stmt = $pdo->prepare($ignore . ' INTO regions (locale, prefix, name, parent_locale, domain, is_default, is_enabled, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
                $stmt->execute(array($region[0], $region[1], $region[2], null, '', $region[3], $region[4], $region[0] === 'zh-CN' ? 0 : 1));
            }
            $existingRoles = $pdo->query('SELECT slug FROM roles')->fetchAll(PDO::FETCH_COLUMN);
            foreach (array('owner' => '站点所有者', 'editor' => '编辑', 'viewer' => '只读') as $slug => $name) {
                $stmt = $pdo->prepare($ignore . ' INTO roles (slug, name) VALUES (?, ?)');
                $stmt->execute(array($slug, $name));
            }
            $roleIds = array();
            foreach ($pdo->query('SELECT id, slug FROM roles') as $role) {
                $roleIds[$role['slug']] = (int) $role['id'];
            }
            foreach (array(
                'editor' => array('dashboard.view', 'content.view', 'content.manage', 'taxonomy.manage', 'media.manage', 'operations.manage'),
                'viewer' => array('dashboard.view', 'content.view')
            ) as $role => $permissions) {
                if (in_array($role, $existingRoles, true)) {
                    continue;
                }
                $stmt = $pdo->prepare($ignore . ' INTO role_permissions (role_id, permission) VALUES (?, ?)');
                foreach ($permissions as $permission) {
                    $stmt->execute(array($roleIds[$role], $permission));
                }
            }
            $pdo->exec($ignore . ' INTO user_roles (user_id, role_id) SELECT id, ' . $roleIds['owner'] . ' FROM users');
            $pdo->exec($ignore . " INTO member_groups (code, name, status, created_at) VALUES ('default', '默认会员组', 'active', " . time() . ")");
            $pdo->exec($ignore . ' INTO member_group_members (group_id, member_id) SELECT g.id, m.id FROM member_groups g CROSS JOIN members m WHERE g.code = \'default\'');
            $pdo->exec($ignore . " INTO admin_menus (slug, label, icon, path, permission, sort_order, is_visible, is_quick) VALUES ('dashboard', '管理概览', 'fa-tachometer', '/admin', 'dashboard.view', 10, 1, 1)");
            $pdo->exec($ignore . " INTO admin_menus (slug, label, icon, path, permission, sort_order, is_visible, is_quick) VALUES ('posts', '文章管理', 'fa-file-text-o', '/admin/posts', 'content.view', 20, 1, 1)");
            $pdo->exec($ignore . " INTO admin_menus (slug, label, icon, path, permission, sort_order, is_visible, is_quick) VALUES ('members', '会员管理', 'fa-users', '/admin/members', 'members.manage', 30, 1, 0)");
            $pdo->exec($ignore . " INTO admin_menus (slug, label, icon, path, permission, sort_order, is_visible, is_quick) VALUES ('access', '角色权限', 'fa-shield', '/admin/roles', 'access.manage', 40, 1, 0)");
            $pdo->exec($ignore . " INTO role_locales (role_id, locale) SELECT id, 'zh-CN' FROM roles");
            $pdo->exec($ignore . " INTO role_locales (role_id, locale) SELECT id, 'en-US' FROM roles");
            foreach (array(
                array('pages', '单页管理', '/admin/pages', 'content.view', 21), array('categories', '栏目管理', '/admin/categories', 'taxonomy.manage', 22), array('models', '内容模型', '/admin/models', 'taxonomy.manage', 23), array('tags', '标签管理', '/admin/tags', 'taxonomy.manage', 24), array('media', '媒体图片', '/admin/media', 'media.manage', 25), array('slides', '轮播图', '/admin/slides', 'operations.manage', 31), array('links', '友情链接', '/admin/links', 'operations.manage', 32), array('company', '公司信息', '/admin/company', 'operations.manage', 33), array('labels', '自定义标签', '/admin/labels', 'operations.manage', 34), array('messages', '留言管理', '/admin/messages', 'operations.manage', 35), array('comments', '评论管理', '/admin/comments', 'operations.manage', 36), array('forms', '自定义表单', '/admin/forms', 'operations.manage', 37), array('members', '会员管理', '/admin/members', 'members.manage', 40), array('roles', '角色权限', '/admin/roles', 'access.manage', 41), array('admins', '后台账号', '/admin/admins', 'access.manage', 42), array('config', '配置参数', '/admin/config', 'settings.manage', 49), array('settings', '站点设置', '/admin/settings', 'settings.manage', 50), array('cache', '页面缓存', '/admin/cache', 'settings.manage', 51), array('logs', '系统日志', '/admin/logs', 'settings.manage', 52), array('database', '数据库管理', '/admin/database', 'settings.manage', 53), array('templates', '模板管理', '/admin/templates', 'settings.manage', 54), array('license', '离线授权', '/admin/license', 'license.manage', 55)
            ) as $menu) {
                $stmt = $pdo->prepare($ignore . ' INTO admin_menus (slug, label, path, permission, sort_order, is_visible, is_quick) VALUES (?, ?, ?, ?, ?, 1, 0)');
                $stmt->execute($menu);
            }
            self::pbootMenus($pdo, $ignore);
            $pdo->exec($ignore . " INTO content_models (slug, name) VALUES ('article', '文章模型')");
            $pdo->exec("UPDATE geo_jobs SET type = 'push' WHERE type = 'baidu_push'");
            $pdo->exec("UPDATE content_models SET type = 'mixed' WHERE slug = 'article'");
            $pdo->exec($ignore . " INTO content_models (slug, name, type) VALUES ('__system_single', '单页模型', 'single')");
            $pdo->exec("UPDATE content_models SET type = 'single' WHERE slug = '__system_single'");
            $pdo->exec("UPDATE content_models SET type = CASE
                WHEN EXISTS (SELECT 1 FROM category_models cm JOIN category_settings cs ON cs.category_id = cm.category_id WHERE cm.model_id = content_models.id AND cs.type = 'single')
                 AND EXISTS (SELECT 1 FROM category_models cm LEFT JOIN category_settings cs ON cs.category_id = cm.category_id WHERE cm.model_id = content_models.id AND COALESCE(cs.type, 'list') = 'list') THEN 'mixed'
                WHEN EXISTS (SELECT 1 FROM category_models cm JOIN category_settings cs ON cs.category_id = cm.category_id WHERE cm.model_id = content_models.id AND cs.type = 'single') THEN 'single'
                ELSE type END WHERE slug NOT IN ('article', '__system_single')");
            $pdo->exec($mysql
                ? 'INSERT INTO cms_schema (id, version) VALUES (1, ' . self::VERSION . ') ON DUPLICATE KEY UPDATE version = ' . self::VERSION
                : 'INSERT INTO cms_schema (id, version) VALUES (1, ' . self::VERSION . ') ON CONFLICT(id) DO UPDATE SET version = ' . self::VERSION);
            if (! $mysql) {
                $pdo->commit();
            }
        } catch (\Throwable $error) {
            if (! $mysql && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $error;
        }
    }

    /**
     * Admin menu, grouped by what people do: the site's menus, content, operations, members, site setup, system. The
     * 内容管理 group also lists one entry per content model, added by the layout. Idempotent; it
     * re-labels the built-in items on every schema upgrade.
     */
    private static function pbootMenus(PDO $pdo, string $ignore): void
    {
        $groups = array('grp_menu' => array('菜单管理', 'fa-sitemap', 150), 'grp_content' => array('内容管理', 'fa-file-text-o', 200), 'grp_extend' => array('内容运营', 'fa-bullhorn', 300), 'grp_member' => array('会员中心', 'fa-users', 400), 'grp_global' => array('站点设置', 'fa-globe', 500), 'grp_system' => array('系统管理', 'fa-cogs', 900));
        $insert = $pdo->prepare($ignore . ' INTO admin_menus (slug, label, icon, path, permission, sort_order, is_visible, is_quick) VALUES (?, ?, ?, ?, ?, ?, 1, 0)');
        $relabel = $pdo->prepare('UPDATE admin_menus SET label = ?, icon = ?, sort_order = ? WHERE slug = ?');
        foreach ($groups as $slug => [$label, $icon, $sort]) {
            $insert->execute(array($slug, $label, $icon, '/admin', 'dashboard.view', $sort));
            $relabel->execute(array($label, $icon, $sort, $slug));
        }
        // slug => [group, label, icon, path, permission, sort, quick]
        $items = array(
            'singles' => array('grp_content', '专题内容', 'fa-file-o', '/admin/singles', 'content.view', 201, 0),
            'posts' => array('grp_content', '全部内容', 'fa-file-text-o', '/admin/posts', 'content.view', 249, 0),
            'categories' => array('grp_menu', '菜单管理', 'fa-sitemap', '/admin/categories', 'taxonomy.manage', 151, 1),
            'pages' => array('grp_content', '独立单页', 'fa-file-o', '/admin/pages', 'content.view', 252, 0),
            'tags' => array('grp_content', '内容标签', 'fa-tags', '/admin/tags', 'taxonomy.manage', 253, 0),
            'media' => array('grp_content', '媒体图片', 'fa-picture-o', '/admin/media', 'media.manage', 254, 0),
            'slides' => array('grp_extend', '轮播图片', 'fa-picture-o', '/admin/slides', 'operations.manage', 301, 1),
            'links' => array('grp_extend', '友情链接', 'fa-link', '/admin/links', 'operations.manage', 302, 1),
            'messages' => array('grp_extend', '留言信息', 'fa-question-circle-o', '/admin/messages', 'operations.manage', 303, 1),
            'comments' => array('grp_extend', '文章评论', 'fa-commenting-o', '/admin/comments', 'operations.manage', 304, 0),
            'forms' => array('grp_extend', '自定义表单', 'fa-plus-square-o', '/admin/forms', 'operations.manage', 305, 1),
            'content_links' => array('grp_extend', '文章内链', 'fa-random', '/admin/content-links', 'operations.manage', 306, 0),
            'labels' => array('grp_extend', '定制标签', 'fa-wrench', '/admin/labels', 'operations.manage', 307, 1),
            'geo' => array('grp_extend', 'GEO优化', 'fa-rocket', '/admin/geo', 'geo.view', 308, 1),
            'members' => array('grp_member', '会员管理', 'fa-users', '/admin/members', 'members.manage', 401, 0),
            'member_groups' => array('grp_member', '会员等级', 'fa-signal', '/admin/member-groups', 'members.manage', 402, 0),
            'member_fields' => array('grp_member', '会员字段', 'fa-wpforms', '/admin/members/fields', 'members.manage', 403, 0),
            'submissions' => array('grp_member', '会员投稿', 'fa-pencil-square-o', '/admin/submissions', 'members.manage', 404, 0),
            'settings' => array('grp_global', '站点信息', 'fa-cog', '/admin/settings', 'settings.manage', 501, 1),
            'company' => array('grp_global', '公司信息', 'fa-copyright', '/admin/company', 'operations.manage', 502, 1),
            'config' => array('grp_global', '配置参数', 'fa-sliders', '/admin/config', 'settings.manage', 503, 1),
            'templates' => array('grp_global', '模板管理', 'fa-file-code-o', '/admin/templates', 'settings.manage', 504, 0),
            'models' => array('grp_global', '模型管理', 'fa-codepen', '/admin/models', 'taxonomy.manage', 505, 1),
            'model_fields' => array('grp_global', '模型字段', 'fa-list-ul', '/admin/fields', 'taxonomy.manage', 506, 0),
            'regions' => array('grp_global', '数据区域', 'fa-sitemap', '/admin/regions', 'settings.manage', 507, 1),
            'translations' => array('grp_global', '区域翻译', 'fa-language', '/admin/translations', 'settings.manage', 508, 0),
            'admins' => array('grp_system', '系统用户', 'fa-users', '/admin/admins', 'access.manage', 901, 1),
            'roles' => array('grp_system', '系统角色', 'fa-hand-stop-o', '/admin/roles', 'access.manage', 902, 1),
            'menu' => array('grp_system', '后台菜单', 'fa-bars', '/admin/menu', 'menu.manage', 903, 0),
            'logs' => array('grp_system', '系统日志', 'fa-history', '/admin/logs', 'settings.manage', 904, 1),
            'database' => array('grp_system', '数据库管理', 'fa-database', '/admin/database', 'settings.manage', 905, 1),
            'cache' => array('grp_system', '页面缓存', 'fa-dashboard', '/admin/cache', 'settings.manage', 906, 0),
            'image_clean' => array('grp_system', '图片清理', 'fa-trash', '/admin/image-clean', 'settings.manage', 907, 1),
            'server' => array('grp_system', '服务器信息', 'fa-info-circle', '/admin/server', 'settings.manage', 908, 1),
            'upgrade' => array('grp_system', '在线升级', 'fa-cloud-upload', '/admin/upgrade', 'settings.manage', 909, 0),
            'license' => array('grp_system', '离线授权', 'fa-key', '/admin/license', 'license.manage', 910, 0),
        );
        $parent = $pdo->prepare('SELECT id FROM admin_menus WHERE slug = ?');
        $update = $pdo->prepare('UPDATE admin_menus SET parent_id = ?, label = ?, icon = ?, path = ?, permission = ?, sort_order = ? WHERE slug = ?');
        $add = $pdo->prepare($ignore . ' INTO admin_menus (slug, label, icon, path, permission, sort_order, is_visible, is_quick) VALUES (?, ?, ?, ?, ?, ?, 1, ?)');
        foreach ($items as $slug => [$group, $label, $icon, $path, $permission, $sort, $quick]) {
            $parent->execute(array($group));
            $add->execute(array($slug, $label, $icon, $path, $permission, $sort, $quick));
            $update->execute(array((int) $parent->fetchColumn(), $label, $icon, $path, $permission, $sort, $slug));
        }
        // 基础内容 was split between 内容管理 and 站点设置; a group someone added items to stays.
        $emptyGroup = $pdo->prepare('SELECT COUNT(*) FROM admin_menus child JOIN admin_menus parent ON parent.id = child.parent_id WHERE parent.slug = ?');
        $emptyGroup->execute(array('grp_basic'));
        if ((int) $emptyGroup->fetchColumn() === 0) {
            $pdo->exec("DELETE FROM admin_menus WHERE slug = 'grp_basic'");
        }
        // The layout adds 工作台 itself; 'access' duplicated 系统角色.
        $pdo->exec("UPDATE admin_menus SET is_visible = 0 WHERE slug IN ('dashboard', 'access')");
    }

    private static function hasColumn(PDO $pdo, bool $mysql, string $table, string $name): bool
    {
        if ($mysql) {
            $stmt = $pdo->prepare('SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?');
            $stmt->execute(array($table, $name));
            return (bool) $stmt->fetchColumn();
        }
        foreach ($pdo->query('PRAGMA table_info(' . $table . ')') as $column) {
            if ($column['name'] === $name) {
                return true;
            }
        }
        return false;
    }

    private static function statements(bool $mysql): array
    {
        if ($mysql) {
            return array(
                'CREATE TABLE IF NOT EXISTS regions (locale VARCHAR(32) PRIMARY KEY, prefix VARCHAR(16) NOT NULL UNIQUE, name VARCHAR(100) NOT NULL, parent_locale VARCHAR(32) NULL, domain VARCHAR(255) NOT NULL DEFAULT \'\', is_default TINYINT NOT NULL DEFAULT 0, is_enabled TINYINT NOT NULL DEFAULT 1, sort_order INT NOT NULL DEFAULT 0, CONSTRAINT fk_regions_parent FOREIGN KEY (parent_locale) REFERENCES regions(locale) ON DELETE RESTRICT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                'CREATE TABLE IF NOT EXISTS region_content_records (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, locale VARCHAR(32) NOT NULL, entity_type VARCHAR(16) NOT NULL, source_id BIGINT UNSIGNED NULL, slug VARCHAR(160) NOT NULL, status VARCHAR(16) NOT NULL, payload_json LONGTEXT NOT NULL, created_at BIGINT NOT NULL, updated_at BIGINT NOT NULL, deleted_at BIGINT NULL, created_by BIGINT UNSIGNED NULL, updated_by BIGINT UNSIGNED NULL, UNIQUE KEY region_content_slug (locale, entity_type, slug), INDEX region_content_source (locale, entity_type, source_id), FOREIGN KEY (locale) REFERENCES regions(locale) ON DELETE CASCADE, FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL, FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                'CREATE TABLE IF NOT EXISTS content_translations (entity_type VARCHAR(64) NOT NULL, entity_key VARCHAR(100) NOT NULL, locale VARCHAR(32) NOT NULL, field VARCHAR(100) NOT NULL, value LONGTEXT NOT NULL, PRIMARY KEY (entity_type, entity_key, locale, field), FOREIGN KEY (locale) REFERENCES regions(locale) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                 'CREATE TABLE IF NOT EXISTS roles (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, slug VARCHAR(64) NOT NULL UNIQUE, name VARCHAR(100) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                'CREATE TABLE IF NOT EXISTS role_permissions (role_id BIGINT UNSIGNED NOT NULL, permission VARCHAR(64) NOT NULL, PRIMARY KEY (role_id, permission), FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                'CREATE TABLE IF NOT EXISTS role_locales (role_id BIGINT UNSIGNED NOT NULL, locale VARCHAR(16) NOT NULL, PRIMARY KEY (role_id, locale), FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                'CREATE TABLE IF NOT EXISTS admin_menus (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, parent_id BIGINT UNSIGNED NULL, slug VARCHAR(64) NOT NULL UNIQUE, label VARCHAR(100) NOT NULL, icon VARCHAR(64) NOT NULL DEFAULT \'fa-circle-o\', path VARCHAR(255) NOT NULL, permission VARCHAR(64) NOT NULL, sort_order INT NOT NULL DEFAULT 0, is_visible TINYINT NOT NULL DEFAULT 1, is_quick TINYINT NOT NULL DEFAULT 0, FOREIGN KEY (parent_id) REFERENCES admin_menus(id) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                'CREATE TABLE IF NOT EXISTS user_roles (user_id BIGINT UNSIGNED PRIMARY KEY, role_id BIGINT UNSIGNED NOT NULL, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE, FOREIGN KEY (role_id) REFERENCES roles(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                'CREATE TABLE IF NOT EXISTS tags (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, slug VARCHAR(160) NOT NULL UNIQUE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                'CREATE TABLE IF NOT EXISTS post_tags (post_id BIGINT UNSIGNED NOT NULL, tag_id BIGINT UNSIGNED NOT NULL, PRIMARY KEY (post_id, tag_id), FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE, FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                'CREATE TABLE IF NOT EXISTS members (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, email VARCHAR(191) NOT NULL UNIQUE, display_name VARCHAR(100) NOT NULL, password_hash VARCHAR(255) NOT NULL, status VARCHAR(16) NOT NULL, created_at BIGINT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                'CREATE TABLE IF NOT EXISTS member_groups (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, code VARCHAR(64) NOT NULL UNIQUE, name VARCHAR(100) NOT NULL, status VARCHAR(16) NOT NULL DEFAULT \'active\', created_at BIGINT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                'CREATE TABLE IF NOT EXISTS member_fields (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(64) NOT NULL UNIQUE, length INT NOT NULL DEFAULT 20, required TINYINT NOT NULL DEFAULT 0, description VARCHAR(150) NOT NULL, sorting INT NOT NULL DEFAULT 255, status VARCHAR(16) NOT NULL DEFAULT \'active\') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                 'CREATE TABLE IF NOT EXISTS member_field_values (member_id BIGINT UNSIGNED NOT NULL, field_id BIGINT UNSIGNED NOT NULL, value TEXT NOT NULL, PRIMARY KEY (member_id, field_id), FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE, FOREIGN KEY (field_id) REFERENCES member_fields(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                 'CREATE TABLE IF NOT EXISTS member_submissions (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, member_id BIGINT UNSIGNED NOT NULL, title VARCHAR(191) NOT NULL, slug VARCHAR(191) NOT NULL UNIQUE, body LONGTEXT NOT NULL, status VARCHAR(16) NOT NULL, access_group_id BIGINT UNSIGNED NULL, created_at BIGINT NOT NULL, updated_at BIGINT NOT NULL, INDEX member_submission_status (status, updated_at), FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE, FOREIGN KEY (access_group_id) REFERENCES member_groups(id) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                 'CREATE TABLE IF NOT EXISTS member_tokens (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, member_id BIGINT UNSIGNED NOT NULL, token_hash CHAR(64) NOT NULL UNIQUE, token_type VARCHAR(16) NOT NULL, expires_at BIGINT NOT NULL, used_at BIGINT NULL, created_at BIGINT NOT NULL, INDEX member_token_lookup (member_id, token_type, expires_at), FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                  'CREATE TABLE IF NOT EXISTS member_group_members (group_id BIGINT UNSIGNED NOT NULL, member_id BIGINT UNSIGNED NOT NULL, PRIMARY KEY (group_id, member_id), FOREIGN KEY (group_id) REFERENCES member_groups(id) ON DELETE CASCADE, FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                'CREATE TABLE IF NOT EXISTS post_group_visibility (post_id BIGINT UNSIGNED NOT NULL, group_id BIGINT UNSIGNED NOT NULL, PRIMARY KEY (post_id, group_id), FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE, FOREIGN KEY (group_id) REFERENCES member_groups(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                'CREATE TABLE IF NOT EXISTS post_visibility (post_id BIGINT UNSIGNED PRIMARY KEY, visibility VARCHAR(16) NOT NULL, FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                "CREATE TABLE IF NOT EXISTS pages (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, title VARCHAR(191) NOT NULL, slug VARCHAR(160) NOT NULL UNIQUE, body LONGTEXT NOT NULL, body_format VARCHAR(16) NOT NULL DEFAULT 'plain', status VARCHAR(16) NOT NULL, menu_order INT NOT NULL DEFAULT 0, created_at BIGINT NOT NULL, updated_at BIGINT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                'CREATE TABLE IF NOT EXISTS site_settings (name VARCHAR(64) PRIMARY KEY, value TEXT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                'CREATE TABLE IF NOT EXISTS media (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, path VARCHAR(255) NOT NULL UNIQUE, original_name VARCHAR(255) NOT NULL, mime_type VARCHAR(40) NOT NULL, bytes BIGINT NOT NULL, created_at BIGINT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                'CREATE TABLE IF NOT EXISTS post_cover (post_id BIGINT UNSIGNED PRIMARY KEY, media_id BIGINT UNSIGNED NOT NULL, FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE, FOREIGN KEY (media_id) REFERENCES media(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                'CREATE TABLE IF NOT EXISTS post_gallery (post_id BIGINT UNSIGNED NOT NULL, position INT NOT NULL, media_id BIGINT UNSIGNED NOT NULL, title VARCHAR(150) NOT NULL DEFAULT \'\', PRIMARY KEY (post_id, position), FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE, FOREIGN KEY (media_id) REFERENCES media(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                'CREATE TABLE IF NOT EXISTS post_attachment (post_id BIGINT UNSIGNED PRIMARY KEY, path VARCHAR(255) NOT NULL, original_name VARCHAR(255) NOT NULL, bytes BIGINT NOT NULL, FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                'CREATE TABLE IF NOT EXISTS category_cover (category_id BIGINT UNSIGNED PRIMARY KEY, media_id BIGINT UNSIGNED NOT NULL, FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE, FOREIGN KEY (media_id) REFERENCES media(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                "CREATE TABLE IF NOT EXISTS category_gallery (category_id BIGINT UNSIGNED NOT NULL, position INT NOT NULL, media_id BIGINT UNSIGNED NOT NULL, title VARCHAR(150) NOT NULL DEFAULT '', PRIMARY KEY (category_id, position), FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE, FOREIGN KEY (media_id) REFERENCES media(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                'CREATE TABLE IF NOT EXISTS category_attachment (category_id BIGINT UNSIGNED PRIMARY KEY, path VARCHAR(255) NOT NULL, original_name VARCHAR(255) NOT NULL, bytes BIGINT NOT NULL, FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                'CREATE TABLE IF NOT EXISTS page_cover (page_id BIGINT UNSIGNED PRIMARY KEY, media_id BIGINT UNSIGNED NOT NULL, FOREIGN KEY (page_id) REFERENCES pages(id) ON DELETE CASCADE, FOREIGN KEY (media_id) REFERENCES media(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                "CREATE TABLE IF NOT EXISTS page_gallery (page_id BIGINT UNSIGNED NOT NULL, position INT NOT NULL, media_id BIGINT UNSIGNED NOT NULL, title VARCHAR(150) NOT NULL DEFAULT '', PRIMARY KEY (page_id, position), FOREIGN KEY (page_id) REFERENCES pages(id) ON DELETE CASCADE, FOREIGN KEY (media_id) REFERENCES media(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                'CREATE TABLE IF NOT EXISTS page_attachment (page_id BIGINT UNSIGNED PRIMARY KEY, path VARCHAR(255) NOT NULL, original_name VARCHAR(255) NOT NULL, bytes BIGINT NOT NULL, FOREIGN KEY (page_id) REFERENCES pages(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                'CREATE TABLE IF NOT EXISTS category_images (category_id BIGINT UNSIGNED NOT NULL, kind VARCHAR(16) NOT NULL, media_id BIGINT UNSIGNED NOT NULL, PRIMARY KEY (category_id, kind), FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE, FOREIGN KEY (media_id) REFERENCES media(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                "CREATE TABLE IF NOT EXISTS content_models (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, slug VARCHAR(64) NOT NULL UNIQUE, name VARCHAR(100) NOT NULL, type VARCHAR(16) NOT NULL DEFAULT 'list', list_template VARCHAR(64) NOT NULL DEFAULT '', content_template VARCHAR(64) NOT NULL DEFAULT '') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                'CREATE TABLE IF NOT EXISTS model_fields (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, model_id BIGINT UNSIGNED NOT NULL, name VARCHAR(64) NOT NULL, label VARCHAR(100) NOT NULL, field_type VARCHAR(20) NOT NULL, options_json TEXT NOT NULL, is_required TINYINT NOT NULL DEFAULT 0, sort_order INT NOT NULL DEFAULT 0, UNIQUE KEY model_field_name (model_id, name), FOREIGN KEY (model_id) REFERENCES content_models(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                'CREATE TABLE IF NOT EXISTS category_models (category_id BIGINT UNSIGNED PRIMARY KEY, model_id BIGINT UNSIGNED NOT NULL, FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE, FOREIGN KEY (model_id) REFERENCES content_models(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                "CREATE TABLE IF NOT EXISTS category_settings (category_id BIGINT UNSIGNED PRIMARY KEY, type VARCHAR(16) NOT NULL DEFAULT 'list', is_visible TINYINT NOT NULL DEFAULT 1, list_template VARCHAR(64) NOT NULL DEFAULT '', content_template VARCHAR(64) NOT NULL DEFAULT '', outlink VARCHAR(2048) NOT NULL DEFAULT '', seo_title VARCHAR(255) NOT NULL DEFAULT '', seo_keywords VARCHAR(255) NOT NULL DEFAULT '', seo_description TEXT NOT NULL, single_title VARCHAR(191) NOT NULL DEFAULT '', single_body LONGTEXT NOT NULL, single_body_format VARCHAR(16) NOT NULL DEFAULT 'plain', single_status VARCHAR(16) NOT NULL DEFAULT 'draft', FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                "CREATE TABLE IF NOT EXISTS post_meta (post_id BIGINT UNSIGNED PRIMARY KEY, subtitle VARCHAR(255) NOT NULL DEFAULT '', author VARCHAR(100) NOT NULL DEFAULT '', source VARCHAR(100) NOT NULL DEFAULT '', title_color VARCHAR(7) NOT NULL DEFAULT '', outlink VARCHAR(2048) NOT NULL DEFAULT '', seo_keywords VARCHAR(255) NOT NULL DEFAULT '', seo_description TEXT NOT NULL, is_top TINYINT NOT NULL DEFAULT 0, is_recommended TINYINT NOT NULL DEFAULT 0, is_headline TINYINT NOT NULL DEFAULT 0, body_format VARCHAR(16) NOT NULL DEFAULT 'plain', published_at BIGINT NOT NULL DEFAULT 0, sort_order INT NOT NULL DEFAULT 255, FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                'CREATE TABLE IF NOT EXISTS post_field_values (post_id BIGINT UNSIGNED NOT NULL, field_id BIGINT UNSIGNED NOT NULL, value TEXT NOT NULL, PRIMARY KEY (post_id, field_id), FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE, FOREIGN KEY (field_id) REFERENCES model_fields(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                'CREATE TABLE IF NOT EXISTS category_field_values (category_id BIGINT UNSIGNED NOT NULL, field_id BIGINT UNSIGNED NOT NULL, value TEXT NOT NULL, PRIMARY KEY (category_id, field_id), FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE, FOREIGN KEY (field_id) REFERENCES model_fields(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                'CREATE TABLE IF NOT EXISTS post_field_attachments (post_id BIGINT UNSIGNED NOT NULL, field_id BIGINT UNSIGNED NOT NULL, path VARCHAR(255) NOT NULL, original_name VARCHAR(255) NOT NULL, bytes BIGINT NOT NULL, PRIMARY KEY (post_id, field_id), FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE, FOREIGN KEY (field_id) REFERENCES model_fields(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                'CREATE TABLE IF NOT EXISTS category_field_attachments (category_id BIGINT UNSIGNED NOT NULL, field_id BIGINT UNSIGNED NOT NULL, path VARCHAR(255) NOT NULL, original_name VARCHAR(255) NOT NULL, bytes BIGINT NOT NULL, PRIMARY KEY (category_id, field_id), FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE, FOREIGN KEY (field_id) REFERENCES model_fields(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
                "CREATE TABLE IF NOT EXISTS slides (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, group_id INT NOT NULL DEFAULT 1, media_id BIGINT UNSIGNED NOT NULL, title VARCHAR(150) NOT NULL DEFAULT '', subtitle VARCHAR(255) NOT NULL DEFAULT '', link VARCHAR(2048) NOT NULL DEFAULT '', sort_order INT NOT NULL DEFAULT 255, FOREIGN KEY (media_id) REFERENCES media(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                "CREATE TABLE IF NOT EXISTS friend_links (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, group_id INT NOT NULL DEFAULT 1, name VARCHAR(150) NOT NULL, link VARCHAR(2048) NOT NULL, media_id BIGINT UNSIGNED NULL, sort_order INT NOT NULL DEFAULT 255, FOREIGN KEY (media_id) REFERENCES media(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                "CREATE TABLE IF NOT EXISTS custom_labels (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(64) NOT NULL UNIQUE, description VARCHAR(150) NOT NULL DEFAULT '', type VARCHAR(16) NOT NULL DEFAULT 'text', value TEXT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                "CREATE TABLE IF NOT EXISTS company_profile (id TINYINT UNSIGNED PRIMARY KEY, name VARCHAR(150) NOT NULL DEFAULT '', address VARCHAR(255) NOT NULL DEFAULT '', postcode VARCHAR(30) NOT NULL DEFAULT '', contact VARCHAR(100) NOT NULL DEFAULT '', mobile VARCHAR(50) NOT NULL DEFAULT '', phone VARCHAR(50) NOT NULL DEFAULT '', fax VARCHAR(50) NOT NULL DEFAULT '', email VARCHAR(191) NOT NULL DEFAULT '', qq VARCHAR(50) NOT NULL DEFAULT '', weixin VARCHAR(255) NOT NULL DEFAULT '', blicense VARCHAR(255) NOT NULL DEFAULT '', other TEXT NOT NULL, map_provider VARCHAR(16) NOT NULL DEFAULT '', map_baidu_lng VARCHAR(32) NOT NULL DEFAULT '', map_baidu_lat VARCHAR(32) NOT NULL DEFAULT '', map_amap_lng VARCHAR(32) NOT NULL DEFAULT '', map_amap_lat VARCHAR(32) NOT NULL DEFAULT '', cs_enabled VARCHAR(8) NOT NULL DEFAULT '', cs_show_phone VARCHAR(8) NOT NULL DEFAULT '', cs_show_weixin VARCHAR(8) NOT NULL DEFAULT '', cs_show_qq VARCHAR(8) NOT NULL DEFAULT '', cs_weixin_qr VARCHAR(255) NOT NULL DEFAULT '', cs_show_chat VARCHAR(8) NOT NULL DEFAULT '', cs_chat_mode VARCHAR(16) NOT NULL DEFAULT '', cs_chat_label VARCHAR(60) NOT NULL DEFAULT '', cs_chat_url VARCHAR(500) NOT NULL DEFAULT '', cs_chat_script TEXT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                 "CREATE TABLE IF NOT EXISTS guestbook_messages (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, member_id BIGINT UNSIGNED NULL, name VARCHAR(100) NOT NULL, email VARCHAR(191) NOT NULL DEFAULT '', phone VARCHAR(50) NOT NULL DEFAULT '', content TEXT NOT NULL, status VARCHAR(16) NOT NULL, created_at BIGINT NOT NULL, updated_at BIGINT NOT NULL, INDEX guestbook_status_created (status, created_at), FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE SET NULL)",
                 "CREATE TABLE IF NOT EXISTS post_comments (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, post_id BIGINT UNSIGNED NOT NULL, member_id BIGINT UNSIGNED NULL, name VARCHAR(100) NOT NULL, email VARCHAR(191) NOT NULL DEFAULT '', content TEXT NOT NULL, status VARCHAR(16) NOT NULL, created_at BIGINT NOT NULL, updated_at BIGINT NOT NULL, INDEX comments_post_status (post_id, status, created_at), FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE, FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE SET NULL)",
                 "CREATE TABLE IF NOT EXISTS custom_forms (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, slug VARCHAR(64) NOT NULL UNIQUE, intro VARCHAR(500) NOT NULL DEFAULT '', status VARCHAR(16) NOT NULL, fields_json TEXT NOT NULL, created_at BIGINT NOT NULL, updated_at BIGINT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                 "CREATE TABLE IF NOT EXISTS form_submissions (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, form_id BIGINT UNSIGNED NOT NULL, member_id BIGINT UNSIGNED NULL, values_json TEXT NOT NULL, created_at BIGINT NOT NULL, INDEX submissions_form_created (form_id, created_at), FOREIGN KEY (form_id) REFERENCES custom_forms(id) ON DELETE CASCADE, FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                 "CREATE TABLE IF NOT EXISTS upgrade_history (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, version VARCHAR(32) NOT NULL, status VARCHAR(16) NOT NULL, backup_path VARCHAR(255) NOT NULL, manifest_hash CHAR(64) NOT NULL, created_at BIGINT NOT NULL, INDEX upgrade_created (created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",                 "CREATE TABLE IF NOT EXISTS audit_logs (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NULL, username VARCHAR(100) NOT NULL, method VARCHAR(10) NOT NULL, path VARCHAR(255) NOT NULL, ip_address VARCHAR(64) NOT NULL, created_at BIGINT NOT NULL, INDEX audit_created (created_at), INDEX audit_user (user_id), FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                 "CREATE TABLE IF NOT EXISTS geo_entity_meta (entity_type VARCHAR(16) NOT NULL, entity_id BIGINT NOT NULL, locale VARCHAR(32) NOT NULL, summary VARCHAR(1000) NOT NULL DEFAULT '', faq_json MEDIUMTEXT NOT NULL, schema_type VARCHAR(32) NOT NULL DEFAULT '', reviewed_by VARCHAR(100) NOT NULL DEFAULT '', reviewed_at BIGINT NOT NULL DEFAULT 0, updated_at BIGINT NOT NULL, PRIMARY KEY (entity_type, entity_id, locale)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                 "CREATE TABLE IF NOT EXISTS geo_facts (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, locale VARCHAR(32) NOT NULL, category VARCHAR(16) NOT NULL, label VARCHAR(191) NOT NULL, value TEXT NOT NULL, source_url VARCHAR(500) NOT NULL DEFAULT '', status VARCHAR(16) NOT NULL DEFAULT 'draft', confirmed_by BIGINT NOT NULL DEFAULT 0, confirmed_at BIGINT NOT NULL DEFAULT 0, updated_at BIGINT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                 "CREATE TABLE IF NOT EXISTS geo_jobs (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, type VARCHAR(32) NOT NULL, payload TEXT NOT NULL, dedupe_key VARCHAR(160) NOT NULL UNIQUE, status VARCHAR(16) NOT NULL DEFAULT 'pending', attempts INT NOT NULL DEFAULT 0, run_after BIGINT NOT NULL DEFAULT 0, last_error VARCHAR(255) NOT NULL DEFAULT '', created_at BIGINT NOT NULL, updated_at BIGINT NOT NULL, KEY geo_jobs_due (status, run_after)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                 "CREATE TABLE IF NOT EXISTS geo_push_log (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, job_id BIGINT NOT NULL DEFAULT 0, source VARCHAR(8) NOT NULL DEFAULT 'job', engine VARCHAR(16) NOT NULL, kind VARCHAR(16) NOT NULL, target_id BIGINT NOT NULL DEFAULT 0, url VARCHAR(500) NOT NULL DEFAULT '', outcome VARCHAR(12) NOT NULL, http_status INT NOT NULL DEFAULT 0, message VARCHAR(255) NOT NULL DEFAULT '', detail TEXT NOT NULL, attempt INT NOT NULL DEFAULT 1, created_at BIGINT NOT NULL, KEY geo_push_log_time (created_at), KEY geo_push_log_filter (engine, outcome, id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                 "CREATE TABLE IF NOT EXISTS geo_bot_daily (day CHAR(10) NOT NULL, bot VARCHAR(60) NOT NULL, path_group VARCHAR(64) NOT NULL, hits BIGINT NOT NULL DEFAULT 0, PRIMARY KEY (day, bot, path_group)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                 "CREATE TABLE IF NOT EXISTS geo_scores (entity_type VARCHAR(16) NOT NULL, entity_id BIGINT NOT NULL, score INT NOT NULL, issues_json TEXT NOT NULL, content_hash CHAR(64) NOT NULL, created_at BIGINT NOT NULL, PRIMARY KEY (entity_type, entity_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                 "CREATE TABLE IF NOT EXISTS geo_pack_records (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, post_id BIGINT NOT NULL, platform VARCHAR(16) NOT NULL, url VARCHAR(500) NOT NULL, content MEDIUMTEXT NOT NULL, created_by BIGINT NOT NULL DEFAULT 0, created_at BIGINT NOT NULL, KEY geo_pack_post (post_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                 "CREATE TABLE IF NOT EXISTS geo_questions (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, question VARCHAR(1000) NOT NULL, brand_terms VARCHAR(1000) NOT NULL, competitor_terms VARCHAR(1000) NOT NULL DEFAULT '', status VARCHAR(16) NOT NULL DEFAULT 'active', created_at BIGINT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                 "CREATE TABLE IF NOT EXISTS geo_samples (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, question_id BIGINT NOT NULL, platform VARCHAR(16) NOT NULL, channel VARCHAR(8) NOT NULL, answer MEDIUMTEXT NOT NULL, mentioned TINYINT NOT NULL DEFAULT 0, position INT NOT NULL DEFAULT 0, competitors_json TEXT NOT NULL, cited_urls_json TEXT NOT NULL, sampled_at BIGINT NOT NULL, recorded_by BIGINT NOT NULL DEFAULT 0, KEY geo_samples_time (sampled_at), KEY geo_samples_question (question_id, channel, sampled_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                 "CREATE TABLE IF NOT EXISTS geo_ai_usage (day CHAR(10) PRIMARY KEY, calls INT NOT NULL DEFAULT 0) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );
        }
        return array(
            "CREATE TABLE IF NOT EXISTS regions (locale TEXT PRIMARY KEY, prefix TEXT NOT NULL UNIQUE, name TEXT NOT NULL, parent_locale TEXT NULL REFERENCES regions(locale) ON DELETE RESTRICT, domain TEXT NOT NULL DEFAULT '', is_default INTEGER NOT NULL DEFAULT 0, is_enabled INTEGER NOT NULL DEFAULT 1, sort_order INTEGER NOT NULL DEFAULT 0)",
             'CREATE TABLE IF NOT EXISTS content_translations (entity_type TEXT NOT NULL, entity_key TEXT NOT NULL, locale TEXT NOT NULL, field TEXT NOT NULL, value TEXT NOT NULL, PRIMARY KEY (entity_type, entity_key, locale, field), FOREIGN KEY (locale) REFERENCES regions(locale) ON DELETE CASCADE)',
             'CREATE TABLE IF NOT EXISTS region_content_records (id INTEGER PRIMARY KEY AUTOINCREMENT, locale TEXT NOT NULL REFERENCES regions(locale) ON DELETE CASCADE, entity_type TEXT NOT NULL, source_id INTEGER NULL, slug TEXT NOT NULL, status TEXT NOT NULL, payload_json TEXT NOT NULL, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, deleted_at INTEGER NULL, created_by INTEGER NULL REFERENCES users(id) ON DELETE SET NULL, updated_by INTEGER NULL REFERENCES users(id) ON DELETE SET NULL, UNIQUE (locale, entity_type, slug))',
'CREATE TABLE IF NOT EXISTS roles (id INTEGER PRIMARY KEY AUTOINCREMENT, slug TEXT NOT NULL UNIQUE, name TEXT NOT NULL)',
            'CREATE TABLE IF NOT EXISTS role_permissions (role_id INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE, permission TEXT NOT NULL, PRIMARY KEY (role_id, permission))',
            'CREATE TABLE IF NOT EXISTS role_locales (role_id INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE, locale TEXT NOT NULL, PRIMARY KEY (role_id, locale))',
            'CREATE TABLE IF NOT EXISTS admin_menus (id INTEGER PRIMARY KEY AUTOINCREMENT, parent_id INTEGER NULL REFERENCES admin_menus(id) ON DELETE SET NULL, slug TEXT NOT NULL UNIQUE, label TEXT NOT NULL, icon TEXT NOT NULL DEFAULT \'fa-circle-o\', path TEXT NOT NULL, permission TEXT NOT NULL, sort_order INTEGER NOT NULL DEFAULT 0, is_visible INTEGER NOT NULL DEFAULT 1, is_quick INTEGER NOT NULL DEFAULT 0)',
            'CREATE TABLE IF NOT EXISTS user_roles (user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, role_id INTEGER NOT NULL REFERENCES roles(id))',
            'CREATE TABLE IF NOT EXISTS tags (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, slug TEXT NOT NULL UNIQUE)',
            'CREATE TABLE IF NOT EXISTS post_tags (post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE, tag_id INTEGER NOT NULL REFERENCES tags(id) ON DELETE CASCADE, PRIMARY KEY (post_id, tag_id))',
                         'CREATE TABLE IF NOT EXISTS members (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT NOT NULL COLLATE NOCASE UNIQUE, display_name TEXT NOT NULL, password_hash TEXT NOT NULL, status TEXT NOT NULL, created_at INTEGER NOT NULL)',
             "CREATE TABLE IF NOT EXISTS member_groups (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active', created_at INTEGER NOT NULL)",
             'CREATE TABLE IF NOT EXISTS member_fields (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, length INTEGER NOT NULL DEFAULT 20, required INTEGER NOT NULL DEFAULT 0, description TEXT NOT NULL, sorting INTEGER NOT NULL DEFAULT 255, status TEXT NOT NULL DEFAULT \'active\')',
             'CREATE TABLE IF NOT EXISTS member_field_values (member_id INTEGER NOT NULL REFERENCES members(id) ON DELETE CASCADE, field_id INTEGER NOT NULL REFERENCES member_fields(id) ON DELETE CASCADE, value TEXT NOT NULL, PRIMARY KEY (member_id, field_id))',
             'CREATE TABLE IF NOT EXISTS member_submissions (id INTEGER PRIMARY KEY AUTOINCREMENT, member_id INTEGER NOT NULL REFERENCES members(id) ON DELETE CASCADE, title TEXT NOT NULL, slug TEXT NOT NULL UNIQUE, body TEXT NOT NULL, status TEXT NOT NULL, access_group_id INTEGER NULL REFERENCES member_groups(id) ON DELETE SET NULL, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)',
             'CREATE TABLE IF NOT EXISTS member_tokens (id INTEGER PRIMARY KEY AUTOINCREMENT, member_id INTEGER NOT NULL REFERENCES members(id) ON DELETE CASCADE, token_hash TEXT NOT NULL UNIQUE, token_type TEXT NOT NULL, expires_at INTEGER NOT NULL, used_at INTEGER NULL, created_at INTEGER NOT NULL)',
             'CREATE TABLE IF NOT EXISTS member_group_members (group_id INTEGER NOT NULL REFERENCES member_groups(id) ON DELETE CASCADE, member_id INTEGER NOT NULL REFERENCES members(id) ON DELETE CASCADE, PRIMARY KEY (group_id, member_id))',
             'CREATE TABLE IF NOT EXISTS post_group_visibility (post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE, group_id INTEGER NOT NULL REFERENCES member_groups(id) ON DELETE CASCADE, PRIMARY KEY (post_id, group_id))',
            'CREATE TABLE IF NOT EXISTS post_visibility (post_id INTEGER PRIMARY KEY REFERENCES posts(id) ON DELETE CASCADE, visibility TEXT NOT NULL)',
            "CREATE TABLE IF NOT EXISTS pages (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, slug TEXT NOT NULL UNIQUE, body TEXT NOT NULL, body_format TEXT NOT NULL DEFAULT 'plain', status TEXT NOT NULL, menu_order INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)",
            'CREATE TABLE IF NOT EXISTS site_settings (name TEXT PRIMARY KEY, value TEXT NOT NULL)',
            'CREATE TABLE IF NOT EXISTS media (id INTEGER PRIMARY KEY AUTOINCREMENT, path TEXT NOT NULL UNIQUE, original_name TEXT NOT NULL, mime_type TEXT NOT NULL, bytes INTEGER NOT NULL, created_at INTEGER NOT NULL)',
            'CREATE TABLE IF NOT EXISTS post_cover (post_id INTEGER PRIMARY KEY REFERENCES posts(id) ON DELETE CASCADE, media_id INTEGER NOT NULL REFERENCES media(id))',
            "CREATE TABLE IF NOT EXISTS post_gallery (post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE, position INTEGER NOT NULL, media_id INTEGER NOT NULL REFERENCES media(id), title TEXT NOT NULL DEFAULT '', PRIMARY KEY (post_id, position))",
            'CREATE TABLE IF NOT EXISTS post_attachment (post_id INTEGER PRIMARY KEY REFERENCES posts(id) ON DELETE CASCADE, path TEXT NOT NULL, original_name TEXT NOT NULL, bytes INTEGER NOT NULL)',
            'CREATE TABLE IF NOT EXISTS category_cover (category_id INTEGER PRIMARY KEY REFERENCES categories(id) ON DELETE CASCADE, media_id INTEGER NOT NULL REFERENCES media(id))',
            "CREATE TABLE IF NOT EXISTS category_gallery (category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE CASCADE, position INTEGER NOT NULL, media_id INTEGER NOT NULL REFERENCES media(id), title TEXT NOT NULL DEFAULT '', PRIMARY KEY (category_id, position))",
            'CREATE TABLE IF NOT EXISTS category_attachment (category_id INTEGER PRIMARY KEY REFERENCES categories(id) ON DELETE CASCADE, path TEXT NOT NULL, original_name TEXT NOT NULL, bytes INTEGER NOT NULL)',
            'CREATE TABLE IF NOT EXISTS page_cover (page_id INTEGER PRIMARY KEY REFERENCES pages(id) ON DELETE CASCADE, media_id INTEGER NOT NULL REFERENCES media(id))',
            "CREATE TABLE IF NOT EXISTS page_gallery (page_id INTEGER NOT NULL REFERENCES pages(id) ON DELETE CASCADE, position INTEGER NOT NULL, media_id INTEGER NOT NULL REFERENCES media(id), title TEXT NOT NULL DEFAULT '', PRIMARY KEY (page_id, position))",
            'CREATE TABLE IF NOT EXISTS page_attachment (page_id INTEGER PRIMARY KEY REFERENCES pages(id) ON DELETE CASCADE, path TEXT NOT NULL, original_name TEXT NOT NULL, bytes INTEGER NOT NULL)',
            "CREATE TABLE IF NOT EXISTS category_images (category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE CASCADE, kind TEXT NOT NULL CHECK (kind IN ('thumbnail', 'banner')), media_id INTEGER NOT NULL REFERENCES media(id), PRIMARY KEY (category_id, kind))",
            "CREATE TABLE IF NOT EXISTS content_models (id INTEGER PRIMARY KEY AUTOINCREMENT, slug TEXT NOT NULL UNIQUE, name TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'list', list_template TEXT NOT NULL DEFAULT '', content_template TEXT NOT NULL DEFAULT '')",
            'CREATE TABLE IF NOT EXISTS model_fields (id INTEGER PRIMARY KEY AUTOINCREMENT, model_id INTEGER NOT NULL REFERENCES content_models(id) ON DELETE CASCADE, name TEXT NOT NULL, label TEXT NOT NULL, field_type TEXT NOT NULL, options_json TEXT NOT NULL, is_required INTEGER NOT NULL DEFAULT 0, sort_order INTEGER NOT NULL DEFAULT 0, UNIQUE (model_id, name))',
            'CREATE TABLE IF NOT EXISTS category_models (category_id INTEGER PRIMARY KEY REFERENCES categories(id) ON DELETE CASCADE, model_id INTEGER NOT NULL REFERENCES content_models(id))',
            "CREATE TABLE IF NOT EXISTS category_settings (category_id INTEGER PRIMARY KEY REFERENCES categories(id) ON DELETE CASCADE, type TEXT NOT NULL DEFAULT 'list', is_visible INTEGER NOT NULL DEFAULT 1, list_template TEXT NOT NULL DEFAULT '', content_template TEXT NOT NULL DEFAULT '', outlink TEXT NOT NULL DEFAULT '', seo_title TEXT NOT NULL DEFAULT '', seo_keywords TEXT NOT NULL DEFAULT '', seo_description TEXT NOT NULL DEFAULT '', single_title TEXT NOT NULL DEFAULT '', single_body TEXT NOT NULL DEFAULT '', single_body_format TEXT NOT NULL DEFAULT 'plain', single_status TEXT NOT NULL DEFAULT 'draft')",
            "CREATE TABLE IF NOT EXISTS post_meta (post_id INTEGER PRIMARY KEY REFERENCES posts(id) ON DELETE CASCADE, subtitle TEXT NOT NULL DEFAULT '', author TEXT NOT NULL DEFAULT '', source TEXT NOT NULL DEFAULT '', title_color TEXT NOT NULL DEFAULT '', outlink TEXT NOT NULL DEFAULT '', seo_keywords TEXT NOT NULL DEFAULT '', seo_description TEXT NOT NULL DEFAULT '', is_top INTEGER NOT NULL DEFAULT 0, is_recommended INTEGER NOT NULL DEFAULT 0, is_headline INTEGER NOT NULL DEFAULT 0, body_format TEXT NOT NULL DEFAULT 'plain', published_at INTEGER NOT NULL DEFAULT 0, sort_order INTEGER NOT NULL DEFAULT 255)",
            'CREATE TABLE IF NOT EXISTS post_field_values (post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE, field_id INTEGER NOT NULL REFERENCES model_fields(id) ON DELETE CASCADE, value TEXT NOT NULL, PRIMARY KEY (post_id, field_id))',
            'CREATE TABLE IF NOT EXISTS category_field_values (category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE CASCADE, field_id INTEGER NOT NULL REFERENCES model_fields(id) ON DELETE CASCADE, value TEXT NOT NULL, PRIMARY KEY (category_id, field_id))',
            'CREATE TABLE IF NOT EXISTS post_field_attachments (post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE, field_id INTEGER NOT NULL REFERENCES model_fields(id) ON DELETE CASCADE, path TEXT NOT NULL, original_name TEXT NOT NULL, bytes INTEGER NOT NULL, PRIMARY KEY (post_id, field_id))',
            'CREATE TABLE IF NOT EXISTS category_field_attachments (category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE CASCADE, field_id INTEGER NOT NULL REFERENCES model_fields(id) ON DELETE CASCADE, path TEXT NOT NULL, original_name TEXT NOT NULL, bytes INTEGER NOT NULL, PRIMARY KEY (category_id, field_id))',
            "CREATE TABLE IF NOT EXISTS slides (id INTEGER PRIMARY KEY AUTOINCREMENT, group_id INTEGER NOT NULL DEFAULT 1, media_id INTEGER NOT NULL REFERENCES media(id), title TEXT NOT NULL DEFAULT '', subtitle TEXT NOT NULL DEFAULT '', link TEXT NOT NULL DEFAULT '', sort_order INTEGER NOT NULL DEFAULT 255)",
            "CREATE TABLE IF NOT EXISTS friend_links (id INTEGER PRIMARY KEY AUTOINCREMENT, group_id INTEGER NOT NULL DEFAULT 1, name TEXT NOT NULL, link TEXT NOT NULL, media_id INTEGER NULL REFERENCES media(id), sort_order INTEGER NOT NULL DEFAULT 255)",
            "CREATE TABLE IF NOT EXISTS custom_labels (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, description TEXT NOT NULL DEFAULT '', type TEXT NOT NULL DEFAULT 'text', value TEXT NOT NULL)",
            "CREATE TABLE IF NOT EXISTS company_profile (id INTEGER PRIMARY KEY, name TEXT NOT NULL DEFAULT '', address TEXT NOT NULL DEFAULT '', postcode TEXT NOT NULL DEFAULT '', contact TEXT NOT NULL DEFAULT '', mobile TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '', fax TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '', qq TEXT NOT NULL DEFAULT '', weixin TEXT NOT NULL DEFAULT '', blicense TEXT NOT NULL DEFAULT '', other TEXT NOT NULL DEFAULT '', map_provider TEXT NOT NULL DEFAULT '', map_baidu_lng TEXT NOT NULL DEFAULT '', map_baidu_lat TEXT NOT NULL DEFAULT '', map_amap_lng TEXT NOT NULL DEFAULT '', map_amap_lat TEXT NOT NULL DEFAULT '', cs_enabled TEXT NOT NULL DEFAULT '', cs_show_phone TEXT NOT NULL DEFAULT '', cs_show_weixin TEXT NOT NULL DEFAULT '', cs_show_qq TEXT NOT NULL DEFAULT '', cs_weixin_qr TEXT NOT NULL DEFAULT '', cs_show_chat TEXT NOT NULL DEFAULT '', cs_chat_mode TEXT NOT NULL DEFAULT '', cs_chat_label TEXT NOT NULL DEFAULT '', cs_chat_url TEXT NOT NULL DEFAULT '', cs_chat_script TEXT NOT NULL DEFAULT '')",
             "CREATE TABLE IF NOT EXISTS guestbook_messages (id INTEGER PRIMARY KEY AUTOINCREMENT, member_id INTEGER NULL REFERENCES members(id) ON DELETE SET NULL, name TEXT NOT NULL, email TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '', content TEXT NOT NULL, status TEXT NOT NULL, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)",
             "CREATE TABLE IF NOT EXISTS post_comments (id INTEGER PRIMARY KEY AUTOINCREMENT, post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE, member_id INTEGER NULL REFERENCES members(id) ON DELETE SET NULL, name TEXT NOT NULL, email TEXT NOT NULL DEFAULT '', content TEXT NOT NULL, status TEXT NOT NULL, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)",
             "CREATE TABLE IF NOT EXISTS custom_forms (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, slug TEXT NOT NULL UNIQUE, intro TEXT NOT NULL DEFAULT '', status TEXT NOT NULL, fields_json TEXT NOT NULL, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)",
             "CREATE TABLE IF NOT EXISTS form_submissions (id INTEGER PRIMARY KEY AUTOINCREMENT, form_id INTEGER NOT NULL REFERENCES custom_forms(id) ON DELETE CASCADE, member_id INTEGER NULL REFERENCES members(id) ON DELETE SET NULL, values_json TEXT NOT NULL, created_at INTEGER NOT NULL)",
              "CREATE TABLE IF NOT EXISTS upgrade_history (id INTEGER PRIMARY KEY AUTOINCREMENT, version TEXT NOT NULL, status TEXT NOT NULL, backup_path TEXT NOT NULL, manifest_hash TEXT NOT NULL, created_at INTEGER NOT NULL)",
              "CREATE TABLE IF NOT EXISTS geo_entity_meta (entity_type TEXT NOT NULL, entity_id INTEGER NOT NULL, locale TEXT NOT NULL, summary TEXT NOT NULL DEFAULT '', faq_json TEXT NOT NULL DEFAULT '[]', schema_type TEXT NOT NULL DEFAULT '', reviewed_by TEXT NOT NULL DEFAULT '', reviewed_at INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL, PRIMARY KEY (entity_type, entity_id, locale))",
              "CREATE TABLE IF NOT EXISTS geo_facts (id INTEGER PRIMARY KEY AUTOINCREMENT, locale TEXT NOT NULL, category TEXT NOT NULL, label TEXT NOT NULL, value TEXT NOT NULL, source_url TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'draft', confirmed_by INTEGER NOT NULL DEFAULT 0, confirmed_at INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL)",
              "CREATE TABLE IF NOT EXISTS geo_jobs (id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL, payload TEXT NOT NULL, dedupe_key TEXT NOT NULL UNIQUE, status TEXT NOT NULL DEFAULT 'pending', attempts INTEGER NOT NULL DEFAULT 0, run_after INTEGER NOT NULL DEFAULT 0, last_error TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)",
              "CREATE INDEX IF NOT EXISTS geo_jobs_due ON geo_jobs (status, run_after)",
              "CREATE TABLE IF NOT EXISTS geo_push_log (id INTEGER PRIMARY KEY AUTOINCREMENT, job_id INTEGER NOT NULL DEFAULT 0, source TEXT NOT NULL DEFAULT 'job', engine TEXT NOT NULL, kind TEXT NOT NULL, target_id INTEGER NOT NULL DEFAULT 0, url TEXT NOT NULL DEFAULT '', outcome TEXT NOT NULL, http_status INTEGER NOT NULL DEFAULT 0, message TEXT NOT NULL DEFAULT '', detail TEXT NOT NULL DEFAULT '', attempt INTEGER NOT NULL DEFAULT 1, created_at INTEGER NOT NULL)",
              "CREATE INDEX IF NOT EXISTS geo_push_log_time ON geo_push_log (created_at)",
              "CREATE INDEX IF NOT EXISTS geo_push_log_filter ON geo_push_log (engine, outcome, id)",
              "CREATE TABLE IF NOT EXISTS geo_bot_daily (day TEXT NOT NULL, bot TEXT NOT NULL, path_group TEXT NOT NULL, hits INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (day, bot, path_group))",
              "CREATE TABLE IF NOT EXISTS geo_scores (entity_type TEXT NOT NULL, entity_id INTEGER NOT NULL, score INTEGER NOT NULL, issues_json TEXT NOT NULL, content_hash TEXT NOT NULL, created_at INTEGER NOT NULL, PRIMARY KEY (entity_type, entity_id))",
              "CREATE TABLE IF NOT EXISTS geo_pack_records (id INTEGER PRIMARY KEY AUTOINCREMENT, post_id INTEGER NOT NULL, platform TEXT NOT NULL, url TEXT NOT NULL, content TEXT NOT NULL DEFAULT '', created_by INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL)",
              "CREATE INDEX IF NOT EXISTS geo_pack_post ON geo_pack_records (post_id)",
              "CREATE TABLE IF NOT EXISTS geo_questions (id INTEGER PRIMARY KEY AUTOINCREMENT, question TEXT NOT NULL, brand_terms TEXT NOT NULL, competitor_terms TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'active', created_at INTEGER NOT NULL)",
              "CREATE TABLE IF NOT EXISTS geo_samples (id INTEGER PRIMARY KEY AUTOINCREMENT, question_id INTEGER NOT NULL, platform TEXT NOT NULL, channel TEXT NOT NULL, answer TEXT NOT NULL, mentioned INTEGER NOT NULL DEFAULT 0, position INTEGER NOT NULL DEFAULT 0, competitors_json TEXT NOT NULL DEFAULT '[]', cited_urls_json TEXT NOT NULL DEFAULT '[]', sampled_at INTEGER NOT NULL, recorded_by INTEGER NOT NULL DEFAULT 0)",
              "CREATE INDEX IF NOT EXISTS geo_samples_time ON geo_samples (sampled_at)",
              "CREATE INDEX IF NOT EXISTS geo_samples_question ON geo_samples (question_id, channel, sampled_at)",
              "CREATE TABLE IF NOT EXISTS geo_ai_usage (day TEXT PRIMARY KEY, calls INTEGER NOT NULL DEFAULT 0)",
             "CREATE TABLE IF NOT EXISTS audit_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NULL REFERENCES users(id) ON DELETE SET NULL, username TEXT NOT NULL, method TEXT NOT NULL, path TEXT NOT NULL, ip_address TEXT NOT NULL, created_at INTEGER NOT NULL)"
        );
    }
}
