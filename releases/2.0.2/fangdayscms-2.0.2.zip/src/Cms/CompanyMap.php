<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

/** Company location pins for Baidu Map (BD-09) and Amap (GCJ-02). */
final class CompanyMap
{
    public const PROVIDERS = array('baidu' => '百度地图', 'amap' => '高德地图');

    /** @var array{baidu?: string, amap?: string} */
    private static array $keys = array();

    /** @param array{baidu?: string, amap?: string} $keys */
    public static function configure(array $keys): void
    {
        self::$keys = array(
            'baidu' => trim((string) ($keys['baidu'] ?? '')),
            'amap' => trim((string) ($keys['amap'] ?? '')),
        );
    }

    /** @param array<string, string> $company */
    public static function embed(array $company, int $height = 320, string $title = ''): string
    {
        $provider = (string) ($company['map_provider'] ?? '');
        if (! isset(self::PROVIDERS[$provider])) {
            return '';
        }
        [$lng, $lat] = self::coords($company, $provider);
        if ($lng === '' || $lat === '') {
            return '';
        }
        $height = max(160, min(800, $height));
        $label = $title !== '' ? $title : (string) ($company['name'] ?? '');
        $address = (string) ($company['address'] ?? '');
        $id = 'fd-company-map-' . substr(sha1($provider . '|' . $lng . '|' . $lat . '|' . $height), 0, 12);
        $openUrl = self::externalUrl($provider, $lng, $lat, $label, $address);
        $ak = $provider === 'baidu' ? (string) (self::$keys['baidu'] ?? '') : (string) (self::$keys['amap'] ?? '');
        $attrs = array(
            'id' => $id,
            'class' => 'fd-company-map',
            'data-provider' => $provider,
            'data-lng' => $lng,
            'data-lat' => $lat,
            'data-title' => $label,
            'data-address' => $address,
            'data-height' => (string) $height,
            'data-open' => $openUrl,
            'data-ak' => $ak,
        );
        $attrHtml = '';
        foreach ($attrs as $name => $value) {
            $attrHtml .= ' ' . $name . '="' . View::e($value) . '"';
        }
        $script = View::asset('/assets/company-map-front.js');
        return '<div' . $attrHtml . ' style="width:100%;height:' . $height . 'px;overflow:hidden;position:relative">'
            . '<div class="fd-company-map-canvas" style="width:100%;height:100%"></div>'
            . '</div>'
            . '<script src="' . View::e($script) . '" defer></script>';
    }

    /** @param array<string, string> $company @return array{0: string, 1: string} */
    public static function coords(array $company, string $provider): array
    {
        if ($provider === 'baidu') {
            return array((string) ($company['map_baidu_lng'] ?? ''), (string) ($company['map_baidu_lat'] ?? ''));
        }
        if ($provider === 'amap') {
            return array((string) ($company['map_amap_lng'] ?? ''), (string) ($company['map_amap_lat'] ?? ''));
        }
        return array('', '');
    }

    public static function externalUrl(string $provider, string $lng, string $lat, string $label, string $address): string
    {
        if ($provider === 'baidu') {
            return 'https://api.map.baidu.com/marker?location=' . rawurlencode($lat . ',' . $lng)
                . '&title=' . rawurlencode($label)
                . '&content=' . rawurlencode($address)
                . '&output=html&src=webapp.fangdayscms.site';
        }
        return 'https://uri.amap.com/marker?position=' . rawurlencode($lng . ',' . $lat)
            . '&name=' . rawurlencode($label)
            . '&src=fangdayscms';
    }

    public static function normalizeProvider(mixed $value): string
    {
        $value = is_string($value) ? trim($value) : '';
        return isset(self::PROVIDERS[$value]) ? $value : '';
    }

    public static function normalizeCoord(mixed $value, string $label, float $min, float $max): string
    {
        if (! is_string($value) && ! is_int($value) && ! is_float($value)) {
            throw new \InvalidArgumentException($label . '无效。');
        }
        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }
        if (! is_numeric($value)) {
            throw new \InvalidArgumentException($label . '须为数字。');
        }
        $number = (float) $value;
        if ($number < $min || $number > $max) {
            throw new \InvalidArgumentException($label . '超出有效范围。');
        }
        $formatted = rtrim(rtrim(sprintf('%.8F', $number), '0'), '.');
        return $formatted === '-0' ? '0' : $formatted;
    }
}
