<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;
use RuntimeException;

/** Streams a verified upgrade package into an atomic staging file. */
final class UpgradePackageDownloader
{
    private const MAX_BYTES = 52428800;
    private const MAX_REDIRECTS = 5;

    /** @param callable(int,int):void|null $progress */
    public static function download(string $url, array $manifest, string $destination, ?callable $progress = null): array
    {
        $primary = trim($url);
        UpgradeManifest::assertHttpsUrl($primary, '升级包地址必须使用 HTTPS。');
        self::assertManifestAndTarget($manifest, $destination);
        $candidates = UpgradeManifest::mirrorUrls($primary);
        $errors = array();
        foreach ($candidates as $candidate) {
            try {
                return self::downloadOnce($candidate, $manifest, $destination, $progress);
            } catch (RuntimeException $error) {
                $errors[] = $error->getMessage();
            }
        }
        if (count($candidates) > 1) {
            throw new RuntimeException('已尝试 ' . count($candidates) . ' 个官方下载源均失败：' . $errors[0]);
        }
        throw new RuntimeException($errors[0] ?? '升级包服务器响应失败。');
    }

    /** @param callable(int,int):void|null $progress */
    private static function downloadOnce(string $url, array $manifest, string $destination, ?callable $progress = null): array
    {
        return function_exists('curl_init')
            ? self::downloadCurl($url, $manifest, $destination, $progress)
            : self::downloadStream($url, $manifest, $destination, $progress);
    }

    /** @param callable(int,int):void|null $progress */
    private static function downloadCurl(string $url, array $manifest, string $destination, ?callable $progress = null): array
    {
        $current = $url;
        for ($hop = 0; $hop <= self::MAX_REDIRECTS; $hop++) {
            UpgradeManifest::assertHttpsUrl($current, '升级包地址必须使用 HTTPS。');
            $headers = array();
            $temp = $destination . '.part-' . bin2hex(random_bytes(8));
            $output = null;
            $hash = hash_init('sha256');
            $bytes = 0;
            $writeError = null;
            try {
                $handle = curl_init($current);
                if ($handle === false) {
                    throw new RuntimeException('无法初始化 cURL 下载升级包。');
                }
                curl_setopt_array($handle, array(
                    CURLOPT_RETURNTRANSFER => false,
                    CURLOPT_FOLLOWLOCATION => false,
                    CURLOPT_CONNECTTIMEOUT => 15,
                    CURLOPT_TIMEOUT => 120,
                    CURLOPT_SSL_VERIFYPEER => true,
                    CURLOPT_SSL_VERIFYHOST => 2,
                    CURLOPT_USERAGENT => 'FangdaysCMS/' . App::VERSION,
                    CURLOPT_HTTPHEADER => array('Accept: application/zip, application/octet-stream, */*'),
                    CURLOPT_HEADERFUNCTION => static function ($ch, string $line) use (&$headers): int {
                        $trimmed = trim($line);
                        if ($trimmed !== '') {
                            if (preg_match('/^HTTP\/\S+\s+\d{3}\b/', $trimmed)) {
                                $headers = array($trimmed);
                            } else {
                                $headers[] = $trimmed;
                            }
                        }
                        return strlen($line);
                    },
                    CURLOPT_WRITEFUNCTION => static function ($ch, string $chunk) use (&$headers, &$output, $temp, &$hash, &$bytes, $manifest, $progress, &$writeError): int {
                        $code = UpgradeManifest::statusCode($headers);
                        if ($code < 200 || $code >= 300) {
                            return strlen($chunk);
                        }
                        if ($chunk === '') {
                            return 0;
                        }
                        if ($output === null) {
                            $output = @fopen($temp, 'xb');
                            if ($output === false) {
                                $output = null;
                                $writeError = '无法创建升级包临时文件。';
                                return 0;
                            }
                        }
                        $len = strlen($chunk);
                        $bytes += $len;
                        if ($bytes > self::MAX_BYTES || $bytes > $manifest['size']) {
                            $writeError = '升级包超过声明大小限制。';
                            return 0;
                        }
                        if (fwrite($output, $chunk) !== $len) {
                            $writeError = '写入升级包失败。';
                            return 0;
                        }
                        hash_update($hash, $chunk);
                        if ($progress !== null) {
                            $progress($bytes, $manifest['size']);
                        }
                        return $len;
                    },
                ));
                $ok = curl_exec($handle);
                $status = (int) curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
                $curlError = $ok === false ? (curl_error($handle) ?: 'cURL error ' . curl_errno($handle)) : null;
                unset($handle);
                if ($status === 0 && $headers !== array()) {
                    $status = UpgradeManifest::statusCode($headers);
                }
                if ($writeError !== null) {
                    throw new RuntimeException($writeError);
                }
                if ($status >= 300 && $status < 400) {
                    $location = UpgradeManifest::headerValue($headers, 'location');
                    if ($location === null || $hop === self::MAX_REDIRECTS) {
                        throw new RuntimeException('升级包重定向无效或次数过多。');
                    }
                    $current = UpgradeManifest::resolveRedirect($current, $location);
                    continue;
                }
                if ($ok === false) {
                    throw new RuntimeException('无法下载升级包（' . UpgradeManifest::formatTransportError((string) $curlError) . '）。');
                }
                if ($status < 200 || $status >= 300) {
                    throw new RuntimeException($status > 0 ? '升级包服务器返回 HTTP ' . $status . '。' : '升级包服务器响应失败。');
                }
                if (! is_resource($output) || $bytes !== $manifest['size'] || hash_final($hash) !== $manifest['sha256']) {
                    throw new RuntimeException('升级包大小或 SHA-256 校验失败。');
                }
                if (! fflush($output) || ! fclose($output)) {
                    $output = null;
                    throw new RuntimeException('升级包落盘失败。');
                }
                $output = null;
                if (! @rename($temp, $destination)) {
                    throw new RuntimeException('升级包原子替换失败。');
                }
                return array('path' => $destination, 'bytes' => $bytes, 'sha256' => $manifest['sha256']);
            } finally {
                if (is_resource($output)) {
                    fclose($output);
                }
                if (is_file($temp)) {
                    @unlink($temp);
                }
            }
        }
        throw new RuntimeException('升级包重定向次数过多。');
    }

    /** @param callable(int,int):void|null $progress */
    private static function downloadStream(string $url, array $manifest, string $destination, ?callable $progress = null): array
    {
        $current = $url;
        for ($hop = 0; $hop <= self::MAX_REDIRECTS; $hop++) {
            UpgradeManifest::assertHttpsUrl($current, '升级包地址必须使用 HTTPS。');
            error_clear_last();
            $stream = @fopen($current, 'rb', false, stream_context_create(array(
                'http' => array(
                    'method' => 'GET',
                    'timeout' => 60,
                    'follow_location' => 0,
                    'ignore_errors' => true,
                    'header' => 'User-Agent: FangdaysCMS/' . App::VERSION . "\r\nAccept: application/zip, application/octet-stream, */*\r\n",
                ),
                'ssl' => array('verify_peer' => true, 'verify_peer_name' => true),
            )));
            if ($stream === false) {
                $last = error_get_last();
                $reason = is_array($last) ? (string) ($last['message'] ?? '连接失败') : '连接失败';
                throw new RuntimeException('无法下载升级包（' . UpgradeManifest::formatTransportError($reason) . '）。');
            }
            $meta = stream_get_meta_data($stream);
            $headers = is_array($meta['wrapper_data'] ?? null) ? array_values(array_map('strval', $meta['wrapper_data'])) : array();
            $status = UpgradeManifest::statusCode($headers);
            if ($status >= 300 && $status < 400) {
                fclose($stream);
                $location = UpgradeManifest::headerValue($headers, 'location');
                if ($location === null || $hop === self::MAX_REDIRECTS) {
                    throw new RuntimeException('升级包重定向无效或次数过多。');
                }
                $current = UpgradeManifest::resolveRedirect($current, $location);
                continue;
            }
            if ($status < 200 || $status >= 300) {
                fclose($stream);
                throw new RuntimeException($status > 0 ? '升级包服务器返回 HTTP ' . $status . '。' : '升级包服务器响应失败。');
            }
            try {
                return self::stage($stream, $manifest, $destination, $progress);
            } finally {
                fclose($stream);
            }
        }
        throw new RuntimeException('升级包重定向次数过多。');
    }

    private static function assertManifestAndTarget(array $manifest, string $destination): void
    {
        if (! is_int($manifest['size'] ?? null) || $manifest['size'] < 1 || $manifest['size'] > self::MAX_BYTES || ! is_string($manifest['sha256'] ?? null) || ! preg_match('/^[a-f0-9]{64}$/D', $manifest['sha256'])) {
            throw new InvalidArgumentException('升级包元数据无效。');
        }
        $parent = dirname($destination);
        if (is_link($parent)) {
            throw new RuntimeException('升级包目录不能是符号链接。');
        }
        if (! is_dir($parent) && ! mkdir($parent, 0700, true) && ! is_dir($parent)) {
            throw new RuntimeException('无法创建升级包目录。');
        }
        if (is_link($destination)) {
            throw new RuntimeException('升级包目标不能是符号链接。');
        }
    }

    /** @param resource $stream @param callable(int,int):void|null $progress */
    public static function stage($stream, array $manifest, string $destination, ?callable $progress = null): array
    {
        if (! is_resource($stream) || ! is_int($manifest['size'] ?? null) || $manifest['size'] < 1 || $manifest['size'] > self::MAX_BYTES || ! is_string($manifest['sha256'] ?? null) || ! preg_match('/^[a-f0-9]{64}$/D', $manifest['sha256'])) {
            throw new InvalidArgumentException('升级包元数据无效。');
        }
        $parent = dirname($destination);
        if (is_link($parent)) {
            throw new RuntimeException('升级包目录不能是符号链接。');
        }
        if (! is_dir($parent) && ! mkdir($parent, 0700, true) && ! is_dir($parent)) {
            throw new RuntimeException('无法创建升级包目录。');
        }
        if (is_link($destination)) {
            throw new RuntimeException('升级包目标不能是符号链接。');
        }
        $temp = $destination . '.part-' . bin2hex(random_bytes(8));
        $output = @fopen($temp, 'xb');
        if ($output === false) {
            throw new RuntimeException('无法创建升级包临时文件。');
        }
        $hash = hash_init('sha256');
        $bytes = 0;
        try {
            while (! feof($stream)) {
                $chunk = fread($stream, 8192);
                if ($chunk === false) {
                    throw new RuntimeException('读取升级包失败。');
                }
                if ($chunk === '') {
                    continue;
                }
                $bytes += strlen($chunk);
                if ($bytes > self::MAX_BYTES || $bytes > $manifest['size']) {
                    throw new RuntimeException('升级包超过声明大小限制。');
                }
                if (fwrite($output, $chunk) !== strlen($chunk)) {
                    throw new RuntimeException('写入升级包失败。');
                }
                hash_update($hash, $chunk);
                if ($progress !== null) {
                    $progress($bytes, $manifest['size']);
                }
            }
            if ($bytes !== $manifest['size'] || hash_final($hash) !== $manifest['sha256']) {
                throw new RuntimeException('升级包大小或 SHA-256 校验失败。');
            }
            if (! fflush($output) || ! fclose($output)) {
                $output = null;
                throw new RuntimeException('升级包落盘失败。');
            }
            $output = null;
            if (! @rename($temp, $destination)) {
                throw new RuntimeException('升级包原子替换失败。');
            }
            return array('path' => $destination, 'bytes' => $bytes, 'sha256' => $manifest['sha256']);
        } finally {
            if (is_resource($output)) {
                fclose($output);
            }
            if (is_file($temp)) {
                @unlink($temp);
            }
        }
    }
}
