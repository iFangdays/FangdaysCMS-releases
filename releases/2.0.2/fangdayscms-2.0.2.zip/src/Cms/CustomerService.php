<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

/** Floating contact rail: phone, WeChat, QQ, and a hook for third-party live chat. */
final class CustomerService
{
    public const CHAT_MODES = array(
        '' => '未启用',
        'link' => '打开链接 / 会话页',
        'script' => '嵌入第三方脚本',
    );

    /** @param array<string, string> $company */
    public static function embed(array $company): string
    {
        if (! self::enabled($company)) {
            return '';
        }

        $items = self::items($company);
        $chat = self::chatConfig($company);
        if ($items === array() && $chat === null) {
            return '';
        }

        $script = View::asset('/assets/customer-service.js');
        $html = '<aside class="fd-cs" id="fd-customer-service" data-fd-cs aria-label="侧边客服"';
        if ($chat !== null) {
            $html .= ' data-fd-cs-chat-mode="' . View::e($chat['mode']) . '"';
            if ($chat['url'] !== '') {
                $html .= ' data-fd-cs-chat-url="' . View::e($chat['url']) . '"';
            }
        }
        $html .= '>';
        $html .= '<div class="fd-cs-rail" role="list">';

        foreach ($items as $item) {
            $html .= self::channelHtml($item);
        }
        if ($chat !== null) {
            $html .= self::chatButtonHtml($chat);
        }

        $html .= '</div>';
        if ($chat !== null && $chat['mode'] === 'script' && $chat['script'] !== '') {
            // Trusted admin snippet for vendors such as MeiQia / Crisp / 53KF.
            $html .= '<div class="fd-cs-vendor" data-fd-cs-vendor>' . $chat['script'] . '</div>';
        }
        $html .= '</aside>';
        $html .= '<script src="' . View::e($script) . '" defer></script>';
        return $html;
    }

    /**
     * @param array<string, string> $company
     * @return list<array{kind: string, label: string, value?: string, href?: string, qr?: string}>
     */
    public static function items(array $company): array
    {
        $items = array();
        if (self::flag($company, 'cs_show_phone')) {
            $phone = trim((string) ($company['phone'] ?? ''));
            $mobile = trim((string) ($company['mobile'] ?? ''));
            $number = $phone !== '' ? $phone : $mobile;
            if ($number !== '') {
                $items[] = array(
                    'kind' => 'phone',
                    'label' => '电话',
                    'value' => $number,
                    'href' => 'tel:' . preg_replace('/[^\d+]/', '', $number),
                );
            }
        }
        if (self::flag($company, 'cs_show_weixin')) {
            $qr = trim((string) ($company['cs_weixin_qr'] ?? ''));
            $weixin = trim((string) ($company['weixin'] ?? ''));
            if ($qr !== '' || $weixin !== '') {
                $items[] = array(
                    'kind' => 'weixin',
                    'label' => '微信',
                    'value' => $weixin,
                    'qr' => $qr,
                );
            }
        }
        if (self::flag($company, 'cs_show_qq')) {
            $qq = trim((string) ($company['qq'] ?? ''));
            if ($qq !== '') {
                $items[] = array(
                    'kind' => 'qq',
                    'label' => 'QQ',
                    'value' => $qq,
                    'href' => 'https://wpa.qq.com/msgrd?v=3&uin=' . rawurlencode($qq) . '&site=qq&menu=yes',
                );
            }
        }
        return $items;
    }

    /**
     * @param array<string, string> $company
     * @return array{mode: string, label: string, url: string, script: string}|null
     */
    public static function chatConfig(array $company): ?array
    {
        if (! self::flag($company, 'cs_show_chat')) {
            return null;
        }
        $mode = self::normalizeChatMode($company['cs_chat_mode'] ?? '');
        if ($mode === '') {
            return null;
        }
        $label = trim((string) ($company['cs_chat_label'] ?? ''));
        if ($label === '') {
            $label = '在线客服';
        }
        $url = trim((string) ($company['cs_chat_url'] ?? ''));
        $script = (string) ($company['cs_chat_script'] ?? '');
        if ($mode === 'link' && $url === '') {
            return null;
        }
        if ($mode === 'script' && trim($script) === '') {
            return null;
        }
        return array(
            'mode' => $mode,
            'label' => $label,
            'url' => $url,
            'script' => $script,
        );
    }

    /** @param array<string, string> $company */
    public static function enabled(array $company): bool
    {
        return self::flag($company, 'cs_enabled');
    }

    /** @param array<string, string> $company */
    public static function flag(array $company, string $key): bool
    {
        $value = strtolower(trim((string) ($company[$key] ?? '')));
        return $value === '1' || $value === 'true' || $value === 'yes' || $value === 'on';
    }

    public static function normalizeFlag(mixed $value): string
    {
        if (is_bool($value)) {
            return $value ? '1' : '';
        }
        if (is_int($value) || is_float($value)) {
            return ((int) $value) === 1 ? '1' : '';
        }
        if (! is_string($value)) {
            return '';
        }
        $value = strtolower(trim($value));
        return in_array($value, array('1', 'true', 'yes', 'on'), true) ? '1' : '';
    }

    public static function normalizeChatMode(mixed $value): string
    {
        $value = is_string($value) ? trim($value) : '';
        return isset(self::CHAT_MODES[$value]) ? $value : '';
    }

    public static function normalizeChatUrl(mixed $value): string
    {
        if (! is_string($value)) {
            return '';
        }
        $value = trim($value);
        if ($value === '') {
            return '';
        }
        if (filter_var($value, FILTER_VALIDATE_URL) === false || ! preg_match('#^https?://#i', $value)) {
            throw new \InvalidArgumentException('在线客服链接须为 http(s) 地址。');
        }
        if (strlen($value) > 500) {
            throw new \InvalidArgumentException('在线客服链接过长。');
        }
        return $value;
    }

    public static function normalizeChatLabel(mixed $value): string
    {
        if (! is_string($value) && ! is_int($value) && ! is_float($value)) {
            return '';
        }
        $value = trim((string) $value);
        if (mb_strlen($value) > 30) {
            throw new \InvalidArgumentException('在线客服按钮文案最多 30 字。');
        }
        return $value;
    }

    public static function normalizeChatScript(mixed $value): string
    {
        if (! is_string($value)) {
            return '';
        }
        $value = trim($value);
        if ($value === '') {
            return '';
        }
        if (strlen($value) > 12000) {
            throw new \InvalidArgumentException('第三方客服脚本过长。');
        }
        return $value;
    }

    public static function normalizeQrPath(mixed $value): string
    {
        if (! is_string($value)) {
            return '';
        }
        $value = trim($value);
        if ($value === '') {
            return '';
        }
        if (! preg_match('#^/uploads/[0-9]{4}/[0-9]{2}/[a-f0-9]{32}\.(jpg|jpeg|png|webp|gif)$#Di', $value)) {
            throw new \InvalidArgumentException('微信二维码图片路径无效，请从媒体库选择。');
        }
        return $value;
    }

    /** @param array{kind: string, label: string, value?: string, href?: string, qr?: string} $item */
    private static function channelHtml(array $item): string
    {
        $kind = $item['kind'];
        $label = View::e($item['label']);
        $value = View::e((string) ($item['value'] ?? ''));
        $cardId = 'fd-cs-card-' . $kind;
        $html = '<div class="fd-cs-channel fd-cs-channel-' . View::e($kind) . '" role="listitem">';
        $html .= '<button type="button" class="fd-cs-btn" data-fd-cs-open="' . View::e($kind) . '" aria-expanded="false" aria-controls="' . $cardId . '" title="' . $label . '">';
        $html .= self::iconSvg($kind);
        $html .= '<span class="fd-cs-btn-text">' . $label . '</span>';
        $html .= '</button>';
        $html .= '<div class="fd-cs-card" id="' . $cardId . '" data-fd-cs-card="' . View::e($kind) . '" hidden>';
        $html .= '<p class="fd-cs-card-title">' . $label . '</p>';
        if ($kind === 'weixin') {
            $qr = (string) ($item['qr'] ?? '');
            if ($qr !== '') {
                $html .= '<img class="fd-cs-qr" src="' . View::e($qr) . '" alt="微信二维码" loading="lazy" width="132" height="132">';
            }
            if ($value !== '') {
                $html .= '<p class="fd-cs-card-value">微信号 ' . $value . '</p>';
            }
            if ($qr !== '') {
                $html .= '<p class="fd-cs-card-hint">扫码添加客服</p>';
            }
        } elseif (isset($item['href']) && $item['href'] !== '') {
            $extra = $kind === 'qq' ? ' target="_blank" rel="noopener"' : '';
            $action = $kind === 'phone' ? '立即拨打' : '打开会话';
            $html .= '<p class="fd-cs-card-value">' . $value . '</p>';
            $html .= '<a class="fd-cs-card-action" href="' . View::e($item['href']) . '"' . $extra . '>' . $action . '</a>';
        }
        $html .= '</div></div>';
        return $html;
    }

    /** @param array{mode: string, label: string, url: string, script: string} $chat */
    private static function chatButtonHtml(array $chat): string
    {
        $label = View::e($chat['label']);
        $html = '<div class="fd-cs-channel fd-cs-channel-chat" role="listitem">';
        $html .= '<button type="button" class="fd-cs-btn fd-cs-btn-chat" data-fd-cs-chat title="' . $label . '">';
        $html .= self::iconSvg('chat');
        $html .= '<span class="fd-cs-btn-text">' . $label . '</span>';
        $html .= '</button>';
        $html .= '</div>';
        return $html;
    }

    private static function iconSvg(string $kind): string
    {
        $common = ' class="fd-cs-ico" width="20" height="20" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"';
        return match ($kind) {
            'phone' => '<svg' . $common . '><path d="M6.5 4.5h3l1.2 3.2-1.8 1.2a12 12 0 0 0 5.2 5.2l1.2-1.8 3.2 1.2v3a2 2 0 0 1-2.2 2A15.5 15.5 0 0 1 4.5 6.7 2 2 0 0 1 6.5 4.5z"/></svg>',
            'weixin' => '<svg' . $common . '><path d="M8.8 9.2a.8.8 0 1 1-1.6 0 .8.8 0 0 1 1.6 0zm4.4 0a.8.8 0 1 1-1.6 0 .8.8 0 0 1 1.6 0z"/><path d="M9.2 5.2c-3.6 0-6.5 2.4-6.5 5.4 0 1.8 1 3.3 2.6 4.3l-.5 2 2.3-1.2c.7.2 1.4.3 2.1.3.3 0 .6 0 .9-.1A4.8 4.8 0 0 1 9.2 14c0-3 2.9-5.4 6.5-5.4.2 0 .5 0 .7.1C15.5 6.7 12.6 5.2 9.2 5.2z"/><path d="M15.7 10.2c-3.2 0-5.8 2.1-5.8 4.7 0 1.5.9 2.9 2.3 3.8l-.4 1.7 2-1c.6.2 1.2.3 1.9.3 3.2 0 5.8-2.1 5.8-4.7s-2.6-4.8-5.8-4.8z"/></svg>',
            'qq' => '<svg' . $common . '><path d="M12 4.5c-2.2 0-3.8 1.7-3.8 4.1 0 .4 0 .8.1 1.1C6.5 11 5.5 13 5.8 14.8c.2 1 .9 1.2 1.5.6.3 1.2 1 2.2 2 2.8-.4.3-.8.8-.5 1.2.3.4 1.6.3 2.7-.3.3 0 .5.1.8.1s.5 0 .8-.1c1.1.6 2.4.7 2.7.3.3-.4-.1-.9-.5-1.2 1-.6 1.7-1.6 2-2.8.6.6 1.3.4 1.5-.6.3-1.8-.7-3.8-2.5-5.1.1-.3.1-.7.1-1.1 0-2.4-1.6-4.1-3.8-4.1z"/></svg>',
            default => '<svg' . $common . '><path d="M5 11c0-3.6 3.1-6.5 7-6.5s7 2.9 7 6.5-3.1 6.5-7 6.5c-.7 0-1.4-.1-2-.3L6.5 19l.8-3.1C6.1 14.8 5 13 5 11z"/></svg>',
        };
    }
}
