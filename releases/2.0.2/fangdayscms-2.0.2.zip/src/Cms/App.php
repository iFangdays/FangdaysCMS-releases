<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use FangdaysCMS\Cms\Geo\BaiduPusher;
use FangdaysCMS\Cms\Geo\GeoAudit;
use FangdaysCMS\Cms\Geo\GeoBots;
use FangdaysCMS\Cms\Geo\GeoHead;
use FangdaysCMS\Cms\Geo\GeoAi;
use FangdaysCMS\Cms\Geo\GeoJobs;
use FangdaysCMS\Cms\Geo\GeoMonitor;
use FangdaysCMS\Cms\Geo\GeoOverview;
use FangdaysCMS\Cms\Geo\GeoPack;
use FangdaysCMS\Cms\Geo\GeoPusher;
use FangdaysCMS\Cms\Geo\GeoPushLog;
use FangdaysCMS\Cms\Geo\GeoRepository;
use FangdaysCMS\Cms\Geo\GeoScore;
use FangdaysCMS\Cms\Geo\GeoUrl;
use FangdaysCMS\Cms\Pboot\Api as PbootApi;
use FangdaysCMS\Cms\Pboot\PbootConfig;
use FangdaysCMS\Cms\Pboot\PbootData;
use FangdaysCMS\Cms\Pboot\PbootRoute;
use FangdaysCMS\Cms\Pboot\PbootSite;
use FangdaysCMS\Cms\Pboot\PbootUrl;
use FangdaysCMS\Cms\Pboot\Theme;
use FangdaysCMS\Licensing\LicenseStore;
use InvalidArgumentException;
use PDO;
use PDOException;
use Throwable;

final class App
{
    public const VERSION = '2.0.2';
    private const RESERVED_ROOTS = array('api', 'admin', 'member', 'category', 'post', 'page', 'tag', 'search', 'rss', 'sitemap', 'message', 'form', 'login', 'logout', 'install', 'qrcode', 'comment', 'do');
    private ?string $routePrefix = null;

    public function __construct(private readonly string $root)
    {
    }

    public function run(): void
    {
        Auth::start();
        $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
        if ($path === '/core/code.php') {
            // PbootCMS captcha address, used by the front-end forms.
            Captcha::render();
            return;
        }
        $requestPath = $path;
        $routePrefix = null;
        if (preg_match('#^/([A-Za-z][A-Za-z0-9-]*)(/.*)?$#D', $path, $localeMatch) && ! in_array(strtolower($localeMatch[1]), self::RESERVED_ROOTS, true)) {
            $routePrefix = strtolower($localeMatch[1]);
            $this->routePrefix = $routePrefix;
            $path = ($localeMatch[2] ?? '') !== '' ? $localeMatch[2] : '/';
        }
        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        $configFile = $this->root . '/config/app.php';
        if (! is_file($configFile)) {
            $this->installRoute($path, $method);
            return;
        }
        $config = require $configFile;
        $hostHeader = $_SERVER['HTTP_HOST'] ?? '';
        $requestHost = is_string($hostHeader) ? preg_replace('/:[0-9]+$/D', '', $hostHeader) : '';
        $requestHost = is_string($requestHost) ? $requestHost : '';
        $pdo = Database::connect($config['database']);
        Migrator::ensure($pdo);
        $pbootConfigBoot = new PbootConfig($pdo);
        Captcha::configure($pbootConfigBoot);
        CompanyMap::configure(array('baidu' => $pbootConfigBoot->get('baidu_map_ak'), 'amap' => $pbootConfigBoot->get('amap_map_key')));
        $repo = new ContentRepository($pdo);
        $operations = new OperationsRepository($pdo);
        $settings = (new SettingsRepository($pdo))->all($config['site_name']);
        $regions = new RegionRepository($pdo);
        $translations = new TranslationRepository($pdo);
        $hostLocale = $regions->localeForDomain((string) $requestHost);
        $requestDomain = \FangdaysCMS\Licensing\LicenseCode::normalizeDomain($requestHost);
        $siteDomains = array_merge(array($config['site_domain']), $config['site_aliases'] ?? array());
        if (($requestDomain === null || ! \FangdaysCMS\Licensing\LicenseCode::coversDomain($siteDomains, $requestDomain)) && $hostLocale === null) {
            View::render('host-mismatch', array('bare' => true, 'page_title' => '当前域名未绑定本站', 'detail' => '请使用站点的正式地址访问。如果这是新绑定的域名，请联系建站负责人添加。', 'domain' => $requestDomain), 421);
            return;
        }
        $store = new LicenseStore($config['license_file'], (string) $requestHost);
        $routeLocale = $routePrefix !== null ? $regions->localeForPrefix($routePrefix) : null;
        if ($routePrefix !== null && $routeLocale === null) {
            // With a Pboot URL mode, /article/ etc. are Pboot addresses rather than region prefixes.
            if (PbootUrl::fromSettings(PbootSite::settings($pdo)) === null) {
                $this->notFound();
                return;
            }
            $routePrefix = null;
            $this->routePrefix = null;
            $path = $requestPath;
        }
        if ($hostLocale !== null && $routeLocale !== null && $hostLocale !== $routeLocale) {
            http_response_code(421);
            View::render('host-mismatch', array('bare' => true, 'page_title' => '区域域名不匹配', 'detail' => '这个域名绑定的区域与当前地址不一致，请从对应区域的地址访问。', 'domain' => $requestDomain), 421);
            return;
        }
        $activeLocale = $routeLocale ?? $hostLocale ?? $settings['locale'];
        foreach ($translations->forEntity('site', '1', $activeLocale) as $field => $value) {
            if ((string) $value !== '') {
                $settings[$field] = $value;
            }
        }
        // Pboot URL modes also apply without a Pboot theme, except on translated regions, which keep their prefix routes.
        $pbootSettings = PbootSite::settings($pdo);
        $pbootUrl = PbootUrl::fromSettings($pbootSettings);
        if ($pbootUrl !== null && $routePrefix === null && $activeLocale === 'zh-CN') {
            View::setAddresses(new GeoUrl($pdo, $activeLocale));
            if (in_array($method, array('GET', 'HEAD'), true) && PbootSite::themeName($pbootSettings, $this->root) === null) {
                $path = (new PbootRoute(new PbootData($pdo, $activeLocale, null, $pbootUrl), $pbootUrl))->builtinPath($path, (string) ($_SERVER['QUERY_STRING'] ?? ''), self::RESERVED_ROOTS) ?? $path;
            }
        }
        $activeRegion = $regions->find($activeLocale) ?? array('locale' => $activeLocale, 'prefix' => $activeLocale === 'en-US' ? 'en' : 'zh');
        $siteName = $activeLocale === 'en-US' && $settings['site_name_en'] !== '' ? $settings['site_name_en'] : $settings['site_name'];
        $siteDescription = $activeLocale === 'en-US' && $settings['description_en'] !== '' ? $settings['description_en'] : $settings['description'];
        $siteSeoTitle = $activeLocale === 'en-US' && ($settings['seo_title_en'] ?? '') !== '' ? $settings['seo_title_en'] : (string) ($settings['seo_title'] ?? '');
        $siteSeoKeywords = $activeLocale === 'en-US' && ($settings['seo_keywords_en'] ?? '') !== '' ? $settings['seo_keywords_en'] : (string) ($settings['seo_keywords'] ?? '');
        $siteSeoDescription = $activeLocale === 'en-US' && ($settings['seo_description_en'] ?? '') !== '' ? $settings['seo_description_en'] : (string) ($settings['seo_description'] ?? '');
        $site = array('site_name' => $siteName, 'site_description' => $siteDescription, 'site_seo_title' => $siteSeoTitle, 'site_seo_keywords' => $siteSeoKeywords, 'site_seo_description' => $siteSeoDescription, 'footer_text' => ($activeLocale === 'en-US' && ($settings['footer_text_en'] ?? '') !== '') ? $settings['footer_text_en'] : $settings['footer_text'], 'desktop_template' => ($activeLocale === 'en-US' && ($settings['desktop_template_en'] ?? '') !== '') ? $settings['desktop_template_en'] : $settings['desktop_template'], 'mobile_template' => ($activeLocale === 'en-US' && ($settings['mobile_template_en'] ?? '') !== '') ? $settings['mobile_template_en'] : $settings['mobile_template'], 'search_template' => ($activeLocale === 'en-US' && ($settings['search_template_en'] ?? '') !== '') ? $settings['search_template_en'] : $settings['search_template'], 'locale' => $activeLocale, 'locale_prefix' => $routePrefix !== null ? '/' . $activeRegion['prefix'] : '', 'locale_path' => $path);
        header('Content-Language: ' . $activeLocale);

        if ($path === '/login') {
            $this->loginRoute($method, $pdo, $site);
            return;
        }
        if ($path === '/login/slider' && $method === 'POST') {
            $this->requireCsrf();
            $pass = SliderCaptcha::issue();
            http_response_code($pass === null ? 422 : 200);
            header('Content-Type: application/json; charset=utf-8');
            header('Cache-Control: private, no-store');
            echo json_encode($pass === null ? array('ok' => false) : array('ok' => true, 'pass' => $pass, 'expires_in' => SliderCaptcha::PASS_SECONDS));
            return;
        }
        if ($path === '/logout' && $method === 'POST') {
            header('Cache-Control: private, no-store');
            header('Vary: Accept-Encoding, Cookie');
            $this->requireCsrf();
            Auth::logout();
            $this->redirect('/login');
        }
        if (str_starts_with($path, '/admin')) {
            $user = Auth::user($pdo);
            if ($user === null) {
                // The activation link on the license notice lands back on activation after login.
                if ($path === '/admin/license') {
                    $_SESSION['after_login'] = $path;
                }
                $this->redirect('/login');
            }
            header('Cache-Control: private, no-store');
            header('Vary: Accept-Encoding, Cookie');
            $can = array();
            foreach (Permissions::CATALOG as $permission => $label) {
                $can[$permission] = Permissions::can($pdo, $user, $permission);
            }
            $access = new AccessRepository($pdo);
            if (! $access->canLocale($user, $activeLocale)) {
                View::render('forbidden', array('admin' => true, 'user' => $user, 'can' => $can, 'site_name' => $siteName, 'page_title' => '无权访问', 'flash' => null), 403);
                return;
            }
            // Legacy content tables mix canonical and *_en columns. Until every field is
            // physically locale-scoped, non-owner regional roles may only edit overlays.
            if ($method !== 'GET' && ($user['role_slug'] ?? '') !== 'owner' && $activeLocale !== 'zh-CN') {
                $overlayWrite = $path === '/admin/translations'
                    || str_starts_with($path, '/admin/region-content')
                    || preg_match('#^/admin/translations/[^/]+/[^/]+/[^/]+/[^/]+/delete$#D', $path) === 1;
                if (! $overlayWrite) {
                    View::render('forbidden', array('admin' => true, 'user' => $user, 'can' => $can, 'site_name' => $siteName, 'page_title' => '区域写入受限', 'flash' => null), 403);
                    return;
                }
            }
            $menuRepository = new MenuRepository($pdo);
            $menuItems = $menuRepository->visibleFor($can);
            $quickLinks = $menuRepository->quickLinks($can);
            if ($path === '/admin' && ! $can['dashboard.view']) {
                $landing = self::firstAdminPath($can);
                if ($landing !== '/admin') {
                    $this->redirect($landing);
                }
            }
            // Without a valid license only the activation page works, for those allowed to use it.
            if ($path !== '/admin/license' && ! $store->status()['valid']) {
                View::render('license-required', $site + array('page_title' => '站点授权', 'bare' => true, 'license' => $store->status(), 'domain' => $store->domain(), 'can_activate' => $can['license.manage'], 'signed_in' => true), 503);
                return;
            }
            if ($method === 'POST' && $path !== '/admin/upgrade/check') {
                PageCache::bump($this->root);
            }
            $availableUpdate = $can['settings.manage'] ? UpgradeChecker::availableUpdate($this->root, self::VERSION) : null;
            $upgradeShouldCheck = $can['settings.manage'] && UpgradeChecker::shouldAutoCheck($this->root, $pdo, self::VERSION);
            $this->adminRoute($path, $method, $pdo, $repo, $store, $site + array('admin' => true, 'user' => $user, 'can' => $can, 'menu_items' => $menuItems, 'quick_links' => $quickLinks, 'license_days_left' => $can['license.manage'] ? $store->daysUntilExpiry() : null, 'license_expires_at' => $store->status()['claims']['expires_at'] ?? null, 'available_update' => $availableUpdate, 'upgrade_should_check' => $upgradeShouldCheck, 'app_version' => self::VERSION, 'content_menu' => $can['content.view'] ? self::contentMenu($pdo) : array(), 'english_enabled' => (int) ($regions->find('en-US')['is_enabled'] ?? 0) === 1));
            return;
        }

        $license = $store->status();
        if (! $license['valid']) {
            View::render('license-required', $site + array('page_title' => '站点授权', 'bare' => true, 'license' => $license, 'domain' => $store->domain(), 'can_activate' => true, 'signed_in' => false), 503);
            return;
        }
        if ($path === '/api.php' || str_starts_with($path, '/api.php/')) {
            (new PbootApi($pdo, $this->root, $activeLocale))->handle($path);
            return;
        }
        View::setLocalePrefix($routePrefix !== null ? '/' . $activeRegion['prefix'] : '');
        ob_start();
        $apiHandled = $this->apiRoute($path, $method, $repo, new TagRepository($pdo), new FormRepository($pdo), new CommentRepository($pdo), new GuestbookRepository($pdo), $operations, $site, Auth::member($pdo), $regions, $translations, new MemberSubmissionRepository($pdo), new ContentModelRepository($pdo), new PageRepository($pdo), $pdo);
        $apiBody = ob_get_clean();
        if ($apiHandled) {
            if (http_response_code() === 200 && is_string($apiBody)) {
                $apiEtag = PageCache::etag($apiBody);
                header('ETag: ' . $apiEtag);
                if (PageCache::matches((string) ($_SERVER['HTTP_IF_NONE_MATCH'] ?? ''), $apiEtag)) {
                    http_response_code(304);
                    return;
                }
            }
            echo $apiBody;
            return;
        }
        // PbootCMS HomeController checks: closed site, HTTPS/main-domain redirects, IP lists, wap domain.
        if (PbootSite::gate($pdo)) {
            return;
        }
        // Pboot Gzip页面压缩 for front-end responses; ob_gzhandler honours Accept-Encoding.
        if ((new PbootConfig($pdo))->on('gzip') && extension_loaded('zlib') && ! headers_sent() && ! ini_get('zlib.output_compression')) {
            ob_start('ob_gzhandler');
        }
        $member = Auth::member($pdo);
        $translations = new TranslationRepository($pdo);
        $company = $operations->company($activeLocale);
        foreach ($translations->forEntity('company', '1', $activeLocale) as $field => $value) {
            if ((string) $value !== '') {
                $company[$field] = $value;
            }
        }
        $site += array('member' => $member, 'company' => $company, 'custom_labels' => $operations->labelValues($activeLocale), 'custom_label_defs' => $operations->labelDefinitions($activeLocale), 'operations' => $operations, 'friend_links' => $operations->links(1, 30), 'all_tags' => (new TagRepository($pdo))->all());
        // With a Pboot theme, its member pages (member/login.html, ...) answer /member/{action}.
        if (str_starts_with($path, '/member/') && ($pbootMembers = PbootSite::forSite($pdo, $this->root, $site)) !== null) {
            header('Cache-Control: private, no-store');
            header('Vary: Accept-Encoding, Cookie');
            if ($pbootMembers->handle($path)) {
                return;
            }
        }
        // Pboot member addresses (伪静态/普通 mode), e.g. /member/ucenter/, lead to the member pages.
        if (preg_match('#^/member/([A-Za-z]+)/$#D', $path, $memberMatch) && ($memberPage = PbootSite::memberPage($memberMatch[1])) !== null && PbootUrl::fromSettings(PbootSite::settings($pdo)) !== null) {
            $this->redirect($memberPage);
        }
        if (str_starts_with($path, '/member/')) {
            header('Cache-Control: private, no-store');
            header('Vary: Accept-Encoding, Cookie');
            $this->memberRoute($path, $method, $pdo, $site);
            return;
        }
        $sessionFormPage = $path === '/message' || str_starts_with($path, '/form/') || str_starts_with($path, '/post/');
        if ($member !== null) {
            header('Cache-Control: private, no-store');
            header('Vary: Accept-Encoding, Cookie');
        } elseif ($method === 'GET' && $sessionFormPage) {
            header('Cache-Control: private, no-store');
            header('Vary: Accept-Encoding, Cookie');
        }
        // Pboot 静态缓存 switch and 缓存有效期.
        $pbootConfig = new PbootConfig($pdo);
        $cacheTtl = max(1, (int) $pbootConfig->get('tpl_html_cache_time'));
        $cacheable = $method === 'GET' && $member === null && ! str_starts_with($path, '/member') && ! isset($_SESSION['flash'])
            // These public pages embed the session CSRF token in a form.
            && ! $sessionFormPage && $pbootConfig->on('tpl_html_cache');
        $pbootSiteSettings = PbootSite::settings($pdo);
        $cacheQuery = $_GET + (PbootSite::wantsWap($pbootSiteSettings) ? array("\0wap" => '1') : array()) + (! empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? array("\0https" => '1') : array());
        // With a phone theme the same address differs by device.
        $cacheVary = ($pbootSiteSettings['pboot_open_wap'] ?? '') === '1' ? 'Vary: Accept-Encoding, User-Agent' : 'Vary: Accept-Encoding';
        $cacheFile = $cacheable ? PageCache::key($this->root, $activeLocale, ($routePrefix === null ? '' : '/' . $activeRegion['prefix']) . $path, $cacheQuery) : null;
        if ($cacheFile !== null) {
            $cached = PageCache::read($cacheFile, $cacheTtl);
            if ($cached !== null) {
                header('Content-Type: text/html; charset=utf-8');
                header('X-Content-Type-Options: nosniff');
                header('Referrer-Policy: same-origin');
                header('X-Frame-Options: DENY');
                header('Content-Language: ' . $activeLocale);
                header('Cache-Control: public, max-age=' . $cacheTtl . ', must-revalidate');
                header($cacheVary);
                header('ETag: ' . PageCache::etag($cached));
                header('X-Fangdays-Cache: HIT');
                if (PageCache::matches((string) ($_SERVER['HTTP_IF_NONE_MATCH'] ?? ''), PageCache::etag($cached))) {
                    http_response_code(304);
                    return;
                }
                echo $cached;
                return;
            }
        }
        if ($cacheable) {
            ob_start();
        }
        $this->siteRoute($path, $method, $pdo, $repo, new TagRepository($pdo), new PageRepository($pdo), $site);
        if ($cacheable) {
            $html = ob_get_clean();
            $isHtml = is_string($html) && preg_match('/^\s*(?:<!doctype\s+html|<html\b)/i', $html) === 1;
            if (! $isHtml) {
                echo $html;
                return;
            }
            if (http_response_code() !== 200) {
                echo $html;
                return;
            }
            if ($cacheFile !== null) {
                PageCache::write($cacheFile, $html);
            }
            header('Cache-Control: public, max-age=' . $cacheTtl . ', must-revalidate');
            header($cacheVary);
            if (is_string($html)) {
                header('ETag: ' . PageCache::etag($html));
            }
            header('X-Fangdays-Cache: MISS');
            echo $html;
        }
    }

    private function installRoute(string $path, string $method): void
    {
        header('Cache-Control: private, no-store');
        header('Vary: Accept-Encoding, Cookie');
        if ($path !== '/install') {
            $this->redirect('/install');
        }
        $hostHeader = $_SERVER['HTTP_HOST'] ?? '';
        $suggestedHost = is_string($hostHeader) ? preg_replace('/:[0-9]+$/D', '', $hostHeader) : '';
        $suggestedHost = \FangdaysCMS\Licensing\LicenseCode::normalizeDomain($suggestedHost) ?? 'localhost';
        $data = array('page_title' => '安装 FangdaysCMS', 'error' => null, 'input' => array('database_driver' => 'sqlite', 'site_domain' => $suggestedHost));
        if ($method === 'POST') {
            $this->requireCsrf();
            $data['input'] = $_POST;
            try {
                Installer::install($_POST, $this->root);
                $_SESSION['flash'] = '安装完成，请登录后台并激活授权码。';
                $this->redirect('/login');
            } catch (InvalidArgumentException $error) {
                $data['error'] = $error->getMessage();
            } catch (Throwable $error) {
                error_log('FangdaysCMS install: ' . $error->getMessage());
                $data['error'] = '安装失败，请核对数据库连接和目录权限。';
            }
        } elseif ($method !== 'GET') {
            $this->notFound();
        }
        View::render('install', $data);
    }

    private function loginRoute(string $method, PDO $pdo, array $site): void
    {
        header('Cache-Control: private, no-store');
        header('Vary: Accept-Encoding, Cookie');
        if (Auth::user($pdo) !== null) {
            $this->redirect('/admin');
        }
        $error = null;
        if ($method === 'POST') {
            $this->requireCsrf();
            $username = self::postString('username');
            $identity = (string) ($_SERVER['REMOTE_ADDR'] ?? '') . '|' . strtolower($username);
            // Pboot 后台登录阀值 / 失败锁定时间.
            $pbootConfig = new PbootConfig($pdo);
            $limited = ! (new RateLimiter($this->root . '/var/rate-limits'))->configuredAllow('admin-login', $identity, max(1, (int) $pbootConfig->get('lock_count')), max(1, (int) $pbootConfig->get('lock_time')));
            $captchaError = SliderCaptcha::error(self::postString('slider_pass'));
            if ($captchaError !== null) {
                SliderCaptcha::begin();
                View::render('login', $site + array('page_title' => '后台登录', 'error' => $captchaError), 422);
                return;
            }
            if (! $limited && Auth::login($pdo, $username, self::postString('password'))) {
                $user = Auth::user($pdo);
                try {
                    (new AuditLogRepository($pdo))->record($user['id'] ?? null, $username, 'LOGIN_OK', '/login', (string) ($_SERVER['REMOTE_ADDR'] ?? ''));
                } catch (\Throwable $auditError) {
                    error_log('FangdaysCMS login audit: ' . $auditError->getMessage());
                }
                if ($user === null) {
                    $this->redirect('/login');
                }
                $can = array();
                foreach (Permissions::CATALOG as $permission => $label) {
                    $can[$permission] = Permissions::can($pdo, $user, $permission);
                }
                $target = $_SESSION['after_login'] ?? self::firstAdminPath($can);
                unset($_SESSION['after_login']);
                $this->redirect($target);
            }
            try {
                (new AuditLogRepository($pdo))->record(null, $username, 'LOGIN_FAIL', '/login', (string) ($_SERVER['REMOTE_ADDR'] ?? ''));
            } catch (\Throwable $auditError) {
                error_log('FangdaysCMS login audit: ' . $auditError->getMessage());
            }
            $error = '用户名或密码错误，或尝试次数过多。';
        } elseif ($method !== 'GET') {
            $this->notFound();
        }
        SliderCaptcha::begin();
        View::render('login', $site + array('page_title' => '后台登录', 'error' => $error));
    }

    private function adminRoute(string $path, string $method, PDO $pdo, ContentRepository $repo, LicenseStore $store, array $base): void
    {
        // Image fields live on content, category and operations forms, so this list is not limited to media.manage.
        if ($path === '/admin/media/library' && $method === 'GET') {
            $this->mediaLibrary(new MediaRepository($pdo, $this->root . '/public'), $base['can']);
            return;
        }
        $permission = match (true) {
            $path === '/admin' => 'dashboard.view',
            str_starts_with($path, '/admin/license') => 'license.manage',
            str_starts_with($path, '/admin/categories'), str_starts_with($path, '/admin/tags'), str_starts_with($path, '/admin/models'), str_starts_with($path, '/admin/fields') => 'taxonomy.manage',
            ($path === '/admin/posts' || $path === '/admin/pages') && $method === 'GET' => 'content.view',
            str_starts_with($path, '/admin/region-content') => 'content.manage',
            str_starts_with($path, '/admin/posts') => 'content.manage',
            str_starts_with($path, '/admin/pages') => 'content.manage',
            str_starts_with($path, '/admin/media') => 'media.manage',
            str_starts_with($path, '/admin/slides'), str_starts_with($path, '/admin/links'), str_starts_with($path, '/admin/labels'), $path === '/admin/company' => 'operations.manage',
             str_starts_with($path, '/admin/messages') => 'operations.manage',
             str_starts_with($path, '/admin/comments') => 'operations.manage',
             str_starts_with($path, '/admin/forms') => 'operations.manage',
            str_starts_with($path, '/admin/members'), str_starts_with($path, '/admin/submissions') => 'members.manage',
            $path === '/admin/translations', str_starts_with($path, '/admin/translations/'), $path === '/admin/settings', $path === '/admin/regions', str_starts_with($path, '/admin/regions/'), $path === '/admin/upgrade', $path === '/admin/upgrade/check', $path === '/admin/cache', str_starts_with($path, '/admin/logs'), str_starts_with($path, '/admin/database'), str_starts_with($path, '/admin/templates') => 'settings.manage',
            $path === '/admin/config', $path === '/admin/config/testmail', $path === '/admin/server', $path === '/admin/server/check', $path === '/admin/image-clean' => 'settings.manage',
            $path === '/admin/singles' && $method === 'GET' => 'content.view',
            str_starts_with($path, '/admin/singles/') => 'taxonomy.manage',
            str_starts_with($path, '/admin/member-groups') => 'members.manage',
            str_starts_with($path, '/admin/content-links') => 'operations.manage',
            str_starts_with($path, '/admin/roles'), str_starts_with($path, '/admin/admins') => 'access.manage',
            str_starts_with($path, '/admin/menu') => 'menu.manage',
            str_starts_with($path, '/admin/region') => 'region.manage',
            $path === '/admin/profile' => 'dashboard.view',
            str_starts_with($path, '/admin/geo/ai'), $path === '/admin/geo/push' && $method === 'POST' => 'settings.manage',
            str_starts_with($path, '/admin/geo') && $method === 'GET' => 'geo.view',
            str_starts_with($path, '/admin/geo') => 'geo.manage',
            default => null
        };
        if ($permission === null) {
            $this->notFound();
        }
        if (! $base['can'][$permission]) {
            View::render('forbidden', $base + array('page_title' => '无权访问'), 403);
            return;
        }
        if ($path !== '/admin/logs' && $path !== '/admin/upgrade/check') {
            try {
                (new AuditLogRepository($pdo))->record((int) $base['user']['id'], (string) $base['user']['username'], $method, $path, (string) ($_SERVER['REMOTE_ADDR'] ?? ''));
            } catch (\Throwable $error) {
                error_log('FangdaysCMS audit log: ' . $error->getMessage());
            }
        }
        if (str_starts_with($path, '/admin/tags')) {
            $this->tagAdminRoute($path, $method, new TagRepository($pdo), $base);
            return;
        }
        if (str_starts_with($path, '/admin/models') || $path === '/admin/fields' || $path === '/admin/fields/new') {
            $this->modelAdminRoute($path, $method, $pdo, new ContentModelRepository($pdo), $base);
            return;
        }
        if (str_starts_with($path, '/admin/members') || str_starts_with($path, '/admin/submissions')) {
            $this->memberAdminRoute($path, $method, $pdo, new MemberRepository($pdo), $base);
            return;
        }
        if (str_starts_with($path, '/admin/roles') || str_starts_with($path, '/admin/admins') || str_starts_with($path, '/admin/menu') || $path === '/admin/region' || str_starts_with($path, '/admin/region/') || $path === '/admin/profile') {
            $this->accessAdminRoute($path, $method, new AccessRepository($pdo), $base);
            return;
        }
        if (str_starts_with($path, '/admin/region-content')) {
             $this->regionContentAdminRoute($path, $method, new RegionContentRepository($pdo), $base);
             return;
         }
         if (str_starts_with($path, '/admin/pages')) {
            $this->pageAdminRoute($path, $method, $pdo, new PageRepository($pdo), new MediaRepository($pdo, $this->root . '/public'), $base);
            return;
        }
        if (str_starts_with($path, '/admin/media')) {
            $this->mediaAdminRoute($path, $method, new MediaRepository($pdo, $this->root . '/public'), $base);
            return;
        }
        if (str_starts_with($path, '/admin/messages')) {
            $this->messageAdminRoute($path, $method, new GuestbookRepository($pdo), $base);
            return;
        }
        if (str_starts_with($path, '/admin/comments')) {
            $this->commentAdminRoute($path, $method, new CommentRepository($pdo), $base);
            return;
        }
        if (str_starts_with($path, '/admin/forms')) {
            $this->formAdminRoute($path, $method, $pdo, new FormRepository($pdo), $base);
            return;
        }
        if (str_starts_with($path, '/admin/logs')) {
            $this->logAdminRoute($path, $method, new AuditLogRepository($pdo), $base);
            return;
        }
        if (str_starts_with($path, '/admin/database')) {
            $this->databaseAdminRoute($path, $method, $pdo, $base);
            return;
        }
        if (str_starts_with($path, '/admin/templates')) {
            $this->templateAdminRoute($path, $method, $pdo, $base);
            return;
        }
        if (str_starts_with($path, '/admin/slides') || str_starts_with($path, '/admin/links') || str_starts_with($path, '/admin/labels') || $path === '/admin/company') {
            $this->operationsAdminRoute($path, $method, $pdo, new OperationsRepository($pdo), new MediaRepository($pdo, $this->root . '/public'), $base);
            return;
        }
        if (str_starts_with($path, '/admin/geo')) {
            $this->geoAdminRoute($path, $method, $pdo, $base);
            return;
        }
        if ($path === '/admin/cache') {
            if ($method === 'POST') {
                $this->requireCsrf();
                PageCache::clear($this->root);
                $_SESSION['flash'] = '页面缓存已清理。';
                $this->redirect('/admin/cache');
            }
            if ($method !== 'GET') {
                $this->notFound();
            }
            View::render('admin/cache', $base + array('page_title' => '页面缓存', 'cache_stats' => PageCache::stats($this->root)));
            return;
        }
        if ($path === '/admin/upgrade/check') {
            if ($method !== 'POST') {
                $this->notFound();
            }
            $this->requireCsrf();
            $check = UpgradeChecker::check($this->root, $pdo, self::VERSION, \FangdaysCMS\Licensing\TrustedKeys::KEYS, false, 8);
            header('Content-Type: application/json; charset=UTF-8');
            header('Cache-Control: private, no-store');
            echo json_encode(array(
                'status' => $check['status'],
                'has_update' => $check['has_update'],
                'current_version' => self::VERSION,
                'version' => $check['manifest']['version'] ?? null,
                'released_at' => $check['manifest']['released_at'] ?? null,
                'notes' => $check['manifest']['notes'] ?? null,
                'checked_at' => $check['checked_at'],
                'error' => $check['error'],
            ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            return;
        }
        if ($path === '/admin/upgrade') {
            $upgradeError = null;
            $upgradeManifest = is_array($_SESSION['upgrade_manifest'] ?? null) ? $_SESSION['upgrade_manifest'] : null;
            $manifestInput = '';
            $currentVersionInput = self::VERSION;
            if ($method === 'POST') {
                $this->requireCsrf();
                $action = self::postString('action');
                try {
                    if ($action === 'check') {
                        $check = UpgradeChecker::check($this->root, $pdo, self::VERSION, \FangdaysCMS\Licensing\TrustedKeys::KEYS, true, 12);
                        if ($check['status'] === 'error') {
                            throw new InvalidArgumentException('检查远程更新失败：' . ($check['error'] ?? '未知错误'));
                        }
                        if ($check['has_update'] && is_array($check['manifest'])) {
                            $_SESSION['upgrade_manifest'] = $check['manifest'];
                            unset($_SESSION['upgrade_package']);
                            $_SESSION['flash'] = '检测到新版本 ' . $check['manifest']['version'] . '，签名校验通过，可直接下载并安装。';
                        } else {
                            $_SESSION['flash'] = '当前已是最新版本（' . self::VERSION . '）。';
                        }
                        $this->redirect('/admin/upgrade');
                    }
                    if ($action === 'feed') {
                        UpgradeChecker::saveSettings($pdo, self::postString('feed_url'), self::postString('auto_check') === '1');
                        UpgradeChecker::clearCache($this->root);
                        $_SESSION['flash'] = '远程更新源设置已保存。';
                        $this->redirect('/admin/upgrade');
                    }
                    if ($action === 'stage' || $action === 'stage_remote') {
                        $storedManifest = $action === 'stage_remote'
                            ? (UpgradeChecker::availableUpdate($this->root, self::VERSION) ?? $_SESSION['upgrade_manifest'] ?? null)
                            : ($_SESSION['upgrade_manifest'] ?? null);
                        if (! is_array($storedManifest) || ! isset($storedManifest['version'], $storedManifest['url'], $storedManifest['size'], $storedManifest['sha256'])) {
                            throw new InvalidArgumentException('请先校验升级清单。');
                        }
                        if (version_compare((string) $storedManifest['version'], self::VERSION, '<=')) {
                            throw new InvalidArgumentException('目标版本不高于当前运行版本。');
                        }
                        $_SESSION['upgrade_manifest'] = $storedManifest;
                        $upgradeDir = $this->root . '/var/upgrades';
                        $destination = $upgradeDir . '/' . $storedManifest['version'] . '.zip';
                        $staged = UpgradePackageDownloader::download($storedManifest['url'], $storedManifest, $destination);
                        $_SESSION['upgrade_package'] = $staged['path'];
                        $_SESSION['flash'] = '升级包已完成校验并暂存，可继续安装。';
                        $this->redirect('/admin/upgrade');
                    }
                    if ($action === 'install') {
                        $storedManifest = $_SESSION['upgrade_manifest'] ?? null;
                        $package = $_SESSION['upgrade_package'] ?? null;
                        if (! is_array($storedManifest) || ! is_string($package) || $package === '') {
                            throw new InvalidArgumentException('请先校验并暂存升级包。');
                        }
                        $result = UpgradeInstaller::install($package, $storedManifest, $this->root, $this->root . '/var/upgrades/backups');
                        $manifestHash = hash('sha256', json_encode($storedManifest, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
                        (new UpgradeHistory($pdo))->record((string) $result['version'], 'success', (string) $result['backup'], $manifestHash);
                        UpgradeChecker::clearCache($this->root);
                        unset($_SESSION['upgrade_manifest'], $_SESSION['upgrade_package']);
                        $_SESSION['flash'] = '升级安装完成，已备份 ' . (int) $result['files'] . ' 个文件。';
                        $this->redirect('/admin/upgrade');
                    }
                    if ($action === 'rollback' || $action === 'rollback_templates') {
                        $backupInput = trim(self::postString('backup'));
                        $backupName = basename($backupInput);
                        if ($backupName === '' || $backupName === '.' || $backupName === '..') {
                            throw new InvalidArgumentException('请选择有效的升级备份记录。');
                        }
                        $scope = $action === 'rollback_templates' ? 'templates' : 'all';
                        $backupRoot = $this->root . '/var/upgrades/backups';
                        $result = UpgradeInstaller::rollback($backupRoot . '/' . $backupName, $this->root, $backupRoot, $scope);
                        $manifestHash = hash('sha256', 'rollback:' . $scope . ':' . $result['backup']);
                        (new UpgradeHistory($pdo))->record(self::VERSION, 'rolled_back', (string) $result['backup'], $manifestHash);
                        $_SESSION['flash'] = $scope === 'templates'
                            ? '已从备份 ' . $backupName . ' 恢复 ' . (int) $result['files'] . ' 个前台模板与静态资源文件（后端 CMS 保持当前版本）。'
                            : '已从备份 ' . $backupName . ' 回退 ' . (int) $result['files'] . ' 个站点文件。';
                        $this->redirect('/admin/upgrade');
                    }
                    $manifestInput = self::postString('manifest');
                    $currentVersionInput = self::postString('current_version') ?: self::VERSION;
                    // Upgrade manifests are vendor-signed like licenses; site config cannot add keys.
                    $upgradeManifest = UpgradeManifest::verify($manifestInput, \FangdaysCMS\Licensing\TrustedKeys::KEYS, $currentVersionInput);
                    $_SESSION['upgrade_manifest'] = $upgradeManifest;
                    unset($_SESSION['upgrade_package']);
                    $_SESSION['flash'] = '升级清单签名和版本校验通过，可继续下载并安装。';
                } catch (Throwable $exception) {
                    if ($action === 'install' && is_array($_SESSION['upgrade_manifest'] ?? null)) {
                        try {
                            $failedManifest = $_SESSION['upgrade_manifest'];
                            $failedHash = hash('sha256', json_encode($failedManifest, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
                            (new UpgradeHistory($pdo))->record((string) ($failedManifest['version'] ?? '0.0.0'), 'failed', '(install-failed)', $failedHash);
                        } catch (Throwable) {
                            // Preserve the original installation error if audit persistence fails.
                        }
                    }
                    $upgradeError = $exception->getMessage();
                }
            } elseif ($method !== 'GET') {
                $this->notFound();
            }
            $upgradeCheck = UpgradeChecker::cached($this->root, self::VERSION);
            $backupRoot = $this->root . '/var/upgrades/backups';
            $historyRows = (new UpgradeHistory($pdo))->recent(20);
            foreach ($historyRows as &$historyRow) {
                $backupName = basename((string) ($historyRow['backup_path'] ?? ''));
                $historyRow['backup_info'] = ($historyRow['status'] ?? '') === 'success' && $backupName !== '' && $backupName !== '.' && $backupName !== '..'
                    ? UpgradeInstaller::inspectBackup($backupRoot . '/' . $backupName, $backupRoot)
                    : null;
            }
            unset($historyRow);
            View::render('admin/upgrade', $base + array(
                'page_title' => '在线升级',
                'upgrade_history' => $historyRows,
                'upgrade_error' => $upgradeError,
                'upgrade_manifest' => $upgradeManifest,
                'manifest_input' => $manifestInput,
                'current_version' => $currentVersionInput,
                'upgrade_package' => $_SESSION['upgrade_package'] ?? null,
                'upgrade_check' => $upgradeCheck,
                'upgrade_feed_url' => UpgradeChecker::feedUrl($pdo),
                'upgrade_auto_check' => UpgradeChecker::autoCheckEnabled($pdo),
            ));
            return;
        }
        if (str_starts_with($path, '/admin/regions')) {
            $this->regionAdminRoute($path, $method, new RegionRepository($pdo), $base);
            return;
        }
        if (str_starts_with($path, '/admin/translations')) {
            $this->translationAdminRoute($path, $method, new TranslationRepository($pdo), new RegionRepository($pdo), $base);
            return;
        }
        if (($path === '/admin/server' && $method === 'GET') || ($path === '/admin/server/check' && $method === 'POST')) {
            $check = null;
            if ($path === '/admin/server/check') {
                $this->requireCsrf();
                $scheme = ! empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http';
                // The single-threaded development server cannot answer requests to itself.
                $check = PHP_SAPI === 'cli-server' ? '开发服务器无法自检，请在命令行运行：php bin/check.php ' . $scheme . '://' . (string) ($_SERVER['HTTP_HOST'] ?? 'localhost') : DeployCheck::run($scheme . '://' . (string) ($_SERVER['HTTP_HOST'] ?? 'localhost'), $this->root);
            }
            View::render('admin/server', $base + array('page_title' => '服务器信息', 'check' => $check, 'php_advisories' => DeployCheck::phpAdvisories(), 'rows' => self::serverInfo($pdo) + array('部署模式' => DeployCheck::mode($this->root), '最大执行时间' => ini_get('max_execution_time') . ' 秒', '内存限制' => ini_get('memory_limit'), 'GD 图像库' => extension_loaded('gd') ? (gd_info()['GD Version'] ?? '已安装') : '未安装', 'Zlib 压缩' => extension_loaded('zlib') ? '已安装' : '未安装', '磁盘剩余空间' => is_float($free = function_exists('disk_free_space') ? @disk_free_space($this->root) : null) ? number_format($free / 1073741824, 2) . ' GB' : '未知', '服务器时间' => date('Y-m-d H:i:s'), '时区' => date_default_timezone_get(), '运行目录' => $this->root)));
            return;
        }
        if ($path === '/admin/singles' && $method === 'GET') {
            $keyword = is_string($_GET['q'] ?? null) ? mb_substr(trim($_GET['q']), 0, 100) : '';
            $singles = $repo->singles();
            if ($keyword !== '') {
                $singles = array_values(array_filter($singles, static fn (array $single): bool => mb_stripos($single['name'] . ' ' . $single['single_title'], $keyword) !== false));
            }
            View::render('admin/singles', $base + array('page_title' => '专题内容', 'singles' => $singles, 'keyword' => $keyword));
            return;
        }
        if (preg_match('#^/admin/singles/([1-9][0-9]*)/toggle$#D', $path, $match) && $method === 'POST') {
            $this->requireCsrf();
            [$field, $value] = explode(':', self::postString('switch'), 2) + array('', '');
            $stmt = $pdo->prepare("UPDATE category_settings SET single_status = ? WHERE category_id = ? AND type = 'single'");
            $stmt->execute(array($value === '1' ? 'published' : 'draft', (int) $match[1]));
            $_SESSION['flash'] = $field === 'status' && $stmt->rowCount() > 0 ? '修改成功！' : '操作失败：单页不存在。';
            $this->redirect('/admin/singles');
        }
        if (str_starts_with($path, '/admin/member-groups')) {
            $this->memberGroupAdminRoute($path, $method, $pdo, $base);
            return;
        }
        if (str_starts_with($path, '/admin/content-links')) {
            $this->contentLinkAdminRoute($path, $method, $pdo, $base);
            return;
        }
        if ($path === '/admin/image-clean') {
            $media = new MediaRepository($pdo, $this->root . '/public');
            if ($method === 'POST') {
                $this->requireCsrf();
                $deleted = 0;
                $kept = array();
                foreach (is_array($_POST['media_ids'] ?? null) ? $_POST['media_ids'] : array() as $rawId) {
                    if (is_string($rawId) && ctype_digit($rawId)) {
                        try {
                            $media->delete((int) $rawId);
                            $deleted++;
                        } catch (InvalidArgumentException $error) {
                            $kept[] = $error->getMessage();
                        }
                    }
                }
                $_SESSION['flash'] = '已删除 ' . $deleted . ' 张图片。' . ($kept ? '未删除：' . implode('；', array_unique($kept)) : '');
                $this->redirect('/admin/image-clean');
            } elseif ($method !== 'GET') {
                $this->notFound();
            }
            $unused = array_values(array_filter($media->all(), static fn (array $item): bool => $media->usage((int) $item['id']) === null));
            View::render('admin/image-clean', $base + array('page_title' => '图片清理', 'unused' => $unused));
            return;
        }
        if ($path === '/admin/config' || $path === '/admin/config/testmail') {
            $this->configAdminRoute($path, $method, $pdo, $base);
            return;
        }
        if ($path === '/admin/settings') {
            $settings = new SettingsRepository($pdo);
            $values = $settings->all($base['site_name']);
            $error = null;
            if ($method === 'POST') {
                $this->requireCsrf();
                $values = array('site_name' => self::postString('site_name'), 'description' => self::postString('description'), 'footer_text' => self::postString('footer_text'), 'footer_text_en' => self::postString('footer_text_en'), 'desktop_template' => self::postString('desktop_template'), 'mobile_template' => self::postString('mobile_template'), 'search_template' => self::postString('search_template'), 'desktop_template_en' => self::postString('desktop_template_en'), 'mobile_template_en' => self::postString('mobile_template_en'), 'search_template_en' => self::postString('search_template_en'), 'locale' => array_key_exists('locale', $_POST) ? self::postString('locale') : 'zh-CN', 'site_name_en' => self::postString('site_name_en'), 'description_en' => self::postString('description_en'), 'seo_title_en' => self::postString('seo_title_en'), 'seo_keywords_en' => self::postString('seo_keywords_en'), 'seo_description_en' => self::postString('seo_description_en'));
                try {
                    $settings->save($values['site_name'], $values['description'], $values['footer_text'], $values['desktop_template'], $values['mobile_template'], $values['locale'], $values['site_name_en'], $values['description_en'], $values['seo_title_en'], $values['seo_keywords_en'], $values['seo_description_en'], $values['search_template'], $values['desktop_template_en'], $values['mobile_template_en'], $values['search_template_en'], $values['footer_text_en']);
                    $settings->saveTheme(self::postString('pboot_theme'), $this->root);
                    $_SESSION['flash'] = '站点设置已保存。';
                    $this->redirect('/admin/settings');
                } catch (InvalidArgumentException $exception) {
                    $error = $exception->getMessage();
                }
            } elseif ($method !== 'GET') {
                $this->notFound();
            }
            View::render('admin/settings', $base + array('page_title' => '站点设置', 'settings' => $values + array('pboot_theme' => self::postString('pboot_theme')), 'themes' => Theme::names($this->root), 'regions' => (new RegionRepository($pdo))->all(true), 'templates' => SiteTemplate::names(), 'error' => $error), $error ? 422 : 200);
            return;
        }
        if ($path === '/admin' && $method === 'GET') {
            // PbootCMS system/home.html.
            $logins = $pdo->prepare("SELECT created_at, ip_address FROM audit_logs WHERE user_id = ? AND method = 'LOGIN_OK' ORDER BY id DESC");
            $logins->execute(array((int) $base['user']['id']));
            $loginRows = $logins->fetchAll();
            $shortcuts = array();
            if ($base['can']['content.view']) {
                foreach (self::contentMenu($pdo) as [$href, $label]) {
                    $shortcuts[] = array($label, $href, 'fa-file-text-o');
                }
            }
            View::render('admin/home', $base + array(
                'page_title' => '工作台',
                'login' => array('time' => isset($loginRows[0]) ? date('Y-m-d H:i', (int) $loginRows[0]['created_at']) : '', 'ip' => (string) ($loginRows[0]['ip_address'] ?? ''), 'count' => count($loginRows)),
                'shortcuts' => $shortcuts,
                'overview' => (new Workbench($pdo))->overview($base['can']),
                'push_board' => $base['can']['geo.view'] ? (new GeoJobs($pdo))->pushBoard() : null,
                'warnings' => $base['can']['settings.manage'] ? DeployCheck::phpAdvisories() : array(),
            ));
            return;
        }
        if ($path === '/admin/license') {
            if ($method === 'POST') {
                $this->requireCsrf();
                $result = $store->activate(self::postString('code'));
                $_SESSION['flash'] = $result['valid'] ? '授权码已激活。' : '授权码无效：' . LicenseStore::reasonText((string) $result['reason']);
                $this->redirect('/admin/license');
            }
            if ($method === 'GET') {
                View::render('admin/license', $base + array('page_title' => '离线授权', 'license' => $store->status(), 'domain' => $store->domain()));
                return;
            }
        }
        if ($path === '/admin/categories' && $method === 'GET') {
            View::render('admin/categories', $base + array('page_title' => '菜单管理', 'categories' => $repo->categoriesWithPostCounts()));
            return;
        }
        if ($path === '/admin/categories/bulk' && $method === 'POST') {
            // Pboot ContentSort/mod (保存排序) and ContentSort/del (批量删除).
            $this->requireCsrf();
            try {
                if (self::postString('action') === 'sorting') {
                    $orders = $_POST['sort_order'] ?? null;
                    $_SESSION['flash'] = '已保存 ' . $repo->saveCategorySortOrders(is_array($orders) ? $orders : array()) . ' 个栏目的排序。';
                } elseif (self::postString('action') === 'delete') {
                    $ids = array_values(array_unique(array_map('intval', array_filter(is_array($_POST['category_ids'] ?? null) ? $_POST['category_ids'] : array(), static fn ($id): bool => is_string($id) && ctype_digit($id) && (int) $id > 0))));
                    if ($ids === array()) {
                        throw new InvalidArgumentException('请选择要删除的栏目。');
                    }
                    // Children before parents, so a selected subtree can go in one request.
                    $depths = array_column($repo->categories(), 'depth', 'id');
                    usort($ids, static fn (int $a, int $b): int => ($depths[$b] ?? 0) <=> ($depths[$a] ?? 0));
                    foreach ($ids as $id) {
                        $this->deleteCategoryWithFiles($pdo, $repo, $id);
                    }
                    $_SESSION['flash'] = '已删除 ' . count($ids) . ' 个栏目，原文章保留。';
                } else {
                    throw new InvalidArgumentException('请选择有效操作。');
                }
            } catch (InvalidArgumentException $error) {
                $_SESSION['flash'] = '操作失败：' . $error->getMessage();
            }
            $this->redirect('/admin/categories');
        }
        if (preg_match('#^/admin/categories/([1-9][0-9]*)/toggle$#D', $path, $match) && $method === 'POST') {
            $this->requireCsrf();
            try {
                [$field, $value] = explode(':', self::postString('switch'), 2) + array('', '');
                if ($field !== 'status') {
                    throw new InvalidArgumentException('开关字段无效。');
                }
                $repo->setCategoryVisible((int) $match[1], $value === '1');
                $_SESSION['flash'] = '修改成功！';
            } catch (InvalidArgumentException $error) {
                $_SESSION['flash'] = '操作失败：' . $error->getMessage();
            }
            $this->redirect('/admin/categories');
        }
        if ($path === '/admin/categories/batch') {
            $this->categoryBatchRoute($method, $pdo, $repo, $base);
            return;
        }
        if ($path === '/admin/categories/new' && $method === 'GET') {
            // 添加子菜单 from the list: start under that menu, with its content model.
            $under = ctype_digit((string) ($_GET['parent_id'] ?? '')) ? $repo->category((int) $_GET['parent_id']) : null;
            View::render('admin/category-form', $base + self::accessChoices($pdo) + array('page_title' => '新增菜单', 'category' => $under === null ? null : array('parent_id' => $under['id'], 'model_id' => $under['model_id'] ?? null), 'parents' => $repo->parentChoices(null), 'models' => (new ContentModelRepository($pdo))->all(), 'templates' => SiteTemplate::choices(), 'media' => (new MediaRepository($pdo, $this->root . '/public'))->all(), 'error' => null));
            return;
        }
        if ($path === '/admin/categories' && $method === 'POST') {
            $this->saveCategory($pdo, $repo, null, $base);
            return;
        }
        if (preg_match('#^/admin/categories/([1-9][0-9]*)/single$#D', $path, $match)) {
            $id = (int) $match[1];
            $category = $repo->category($id);
            if ($category === null || $category['type'] !== 'single') {
                $this->notFound();
            }
            $models = new ContentModelRepository($pdo);
            $model = $models->modelForCategory($id);
            $fields = $models->fields((int) $model['id']);
            $extraValues = $models->valuesForSingleCategory($id);
            $media = new MediaRepository($pdo, $this->root . '/public');
            $attachments = new AttachmentRepository($pdo, $this->root . '/var');
            $cover = $media->coverForCategory($id);
            $gallery = $media->galleryForCategory($id);
            $attachment = $attachments->forCategory($id);
            if ($method === 'POST') {
                $this->requireCsrf();
                $category['single_title'] = self::postString('title');
                $category['single_body'] = self::postString('body');
                $category['single_title_en'] = self::postString('title_en');
                $category['single_body_en'] = self::postString('body_en');
                $category['single_body_format'] = self::postString('body_format') ?: $category['single_body_format'];
                $category['single_status'] = self::postString('status');
                $extraValues = $_POST['extra'] ?? array();
                $category['cover_media_id'] = self::postString('cover_media_id');
                $rawGalleryIds = $_POST['gallery_media_ids'] ?? array();
                $rawGalleryTitles = $_POST['gallery_titles'] ?? array();
                $uploadFile = is_array($_FILES['attachment'] ?? null) ? $_FILES['attachment'] : array();
                $newModelFiles = array();
                try {
                    if (! is_array($extraValues)) {
                        throw new InvalidArgumentException('扩展字段内容无效。');
                    }
                    $coverId = $category['cover_media_id'] === '' ? null : filter_var($category['cover_media_id'], FILTER_VALIDATE_INT, array('options' => array('min_range' => 1)));
                    if ($coverId === false) {
                        throw new InvalidArgumentException('封面图片无效。');
                    }
                    if (! is_array($rawGalleryIds) || ! is_array($rawGalleryTitles) || count($rawGalleryIds) !== count($rawGalleryTitles) || count($rawGalleryIds) > 30) {
                        throw new InvalidArgumentException('多图数据无效。');
                    }
                    $galleryIds = array();
                    $galleryTitles = array();
                    $gallery = array();
                    foreach ($rawGalleryIds as $position => $galleryId) {
                        if (! is_string($galleryId) || ! isset($rawGalleryTitles[$position]) || ! is_string($rawGalleryTitles[$position])) {
                            throw new InvalidArgumentException('多图数据无效。');
                        }
                        if ($galleryId === '' && $rawGalleryTitles[$position] === '') {
                            continue;
                        }
                        $galleryIds[] = $galleryId;
                        $galleryTitles[] = $rawGalleryTitles[$position];
                        $image = ctype_digit($galleryId) ? $media->byId((int) $galleryId) : null;
                        $gallery[] = array('media_id' => $galleryId, 'title' => $rawGalleryTitles[$position], 'path' => $image['path'] ?? '');
                    }
                    $hasUpload = $uploadFile !== array() && ($uploadFile['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;
                    if ($hasUpload) {
                        $attachments->validateUpload($uploadFile);
                    }
                    $modelUploads = self::modelUploadFiles();
                    $pdo->beginTransaction();
                    $repo->saveSingle($id, $category['single_title'], $category['single_body'], $category['single_status'], $category['single_body_format'], $category['single_title_en'], $category['single_body_en']);
                    $oldModelFiles = self::syncModelFiles($attachments, true, $id, $fields, $modelUploads, $_POST['remove_extra_file'] ?? array(), $newModelFiles);
                    $models->setValuesForSingleCategory($id, $extraValues);
                    $media->setCoverForCategory($id, $coverId);
                    $media->setGalleryForCategory($id, $galleryIds, $galleryTitles);
                    $oldFile = null;
                    if ($hasUpload) {
                        $oldFile = $attachments->replaceForCategory($id, $uploadFile);
                    } elseif (self::postString('remove_attachment') === '1') {
                        $oldFile = $attachments->removeForCategory($id);
                    }
                    $pdo->commit();
                    $attachments->deleteFile($oldFile);
                    foreach ($oldModelFiles as $path) {
                        $attachments->deleteFile($path);
                    }
                    $_SESSION['flash'] = '单页栏目内容已保存。';
                    $this->redirect('/admin/categories/' . $id . '/single');
                } catch (Throwable $error) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    foreach ($newModelFiles as $path) {
                        $attachments->deleteFile($path);
                    }
                    $message = $error instanceof InvalidArgumentException || $error instanceof \RuntimeException ? $error->getMessage() : '保存失败，请稍后重试。';
                    View::render('admin/category-single', $base + array('page_title' => '编辑单页栏目', 'category' => $category, 'media' => self::mediaOptionsForSelection($media, array_merge(array($category['cover_media_id']), array_column($gallery, 'media_id'))), 'gallery' => $gallery, 'attachment' => $attachment, 'model' => $model, 'fields' => $fields, 'extra_values' => is_array($extraValues) ? $extraValues : array(), 'extra_files' => $attachments->modelFilesForCategory($id), 'error' => $message), 422);
                }
            } elseif ($method === 'GET') {
                $category['cover_media_id'] = $cover['id'] ?? '';
                View::render('admin/category-single', $base + array('page_title' => '编辑单页栏目', 'category' => $category, 'media' => self::mediaOptionsForSelection($media, array_merge(array($category['cover_media_id']), array_column($gallery, 'media_id'))), 'gallery' => $gallery, 'attachment' => $attachment, 'model' => $model, 'fields' => $fields, 'extra_values' => $extraValues, 'extra_files' => $attachments->modelFilesForCategory($id), 'error' => null));
            } else {
                $this->notFound();
            }
            return;
        }
        if (preg_match('#^/admin/categories/([1-9][0-9]*)/edit$#D', $path, $match)) {
            $id = (int) $match[1];
            $category = $repo->category($id);
            if ($category === null) {
                $this->notFound();
            }
            if ($method === 'POST') {
                $this->saveCategory($pdo, $repo, $id, $base);
            } elseif ($method === 'GET') {
                $media = new MediaRepository($pdo, $this->root . '/public');
                $category['thumbnail_media_id'] = $media->categoryImage($id, 'thumbnail')['id'] ?? '';
                $category['banner_media_id'] = $media->categoryImage($id, 'banner')['id'] ?? '';
                $category += $repo->categoryAccess($id);
                View::render('admin/category-form', $base + self::accessChoices($pdo) + array('page_title' => '修改菜单', 'category' => $category, 'parents' => $repo->parentChoices($id), 'models' => (new ContentModelRepository($pdo))->all(), 'templates' => SiteTemplate::choices(), 'media' => self::mediaOptionsForSelection($media, array($category['thumbnail_media_id'], $category['banner_media_id'])), 'error' => null));
            } else {
                $this->notFound();
            }
            return;
        }
        if (preg_match('#^/admin/categories/([1-9][0-9]*)/delete$#D', $path, $match) && $method === 'POST') {
            $this->requireCsrf();
            try {
                $this->deleteCategoryWithFiles($pdo, $repo, (int) $match[1]);
                $_SESSION['flash'] = '栏目已删除，原文章保留。';
            } catch (InvalidArgumentException $error) {
                $_SESSION['flash'] = '操作失败：' . $error->getMessage();
            }
            $this->redirect('/admin/categories');
        }
        if ($path === '/admin/posts' && $method === 'GET') {
            $keyword = $_GET['q'] ?? '';
            $keyword = is_string($keyword) ? mb_substr(trim($keyword), 0, 100) : '';
            $status = $_GET['status'] ?? '';
            $status = is_string($status) && in_array($status, array('draft', 'published'), true) ? $status : '';
            $feature = $_GET['feature'] ?? '';
            $feature = is_string($feature) && in_array($feature, array('top', 'recommended', 'headline'), true) ? $feature : '';
            $category = $_GET['category_id'] ?? '';
            $categoryId = is_string($category) && ctype_digit($category) && (int) $category > 0 ? (int) $category : null;
            // 文章内容 → {模型}内容: the categories bound to that model (the default model also covers unbound ones).
            $modelId = is_string($_GET['model_id'] ?? null) && ctype_digit($_GET['model_id']) ? (int) $_GET['model_id'] : null;
            $search = array();
            $pageTitle = '全部内容';
            $categories = $repo->categories();
            if ($modelId !== null) {
                $pageTitle = null;
                foreach (self::contentMenu($pdo) as [$href, $label]) {
                    $pageTitle = $href === '/admin/posts?model_id=' . $modelId ? $label : $pageTitle;
                }
                if ($pageTitle === null) {
                    $this->notFound();
                }
                $models = new ContentModelRepository($pdo);
                $categories = array_values(array_filter($categories, static fn (array $row): bool => (int) $models->modelForCategory((int) $row['id'])['id'] === $modelId));
                $search = array('category_ids' => array_map(static fn (array $row): int => (int) $row['id'], $categories));
            }
            // Pboot 每页显示数量 (pagesize 20-200).
            $pageSize = is_string($_GET['pagesize'] ?? null) && in_array($_GET['pagesize'], array('20', '30', '50', '60', '100', '150', '200'), true) ? (int) $_GET['pagesize'] : 20;
            $filters = array('model_id' => $modelId ?? '', 'category_id' => $categoryId ?? '', 'q' => $keyword, 'status' => $status, 'feature' => $feature, 'pagesize' => $pageSize === 20 ? '' : (string) $pageSize);
            $empty = $search === array('category_ids' => array());
            $total = $empty ? 0 : $repo->countPosts($status ?: null, $categoryId, true, null, $keyword ?: null, $feature ?: null, true, search: $search);
            $page = self::boundedPage((int) ceil($total / $pageSize));
            $config = new PbootConfig($pdo);
            View::render('admin/posts', $base + array(
                'page_title' => $pageTitle,
                'model_name' => preg_replace('/内容$/u', '', $pageTitle) ?: $pageTitle,
                'posts' => $empty ? array() : $repo->posts($status ?: null, $categoryId, true, null, $keyword ?: null, $page, $feature ?: null, true, search: $search, num: $pageSize),
                'categories' => $categories,
                'filters' => $filters,
                'total' => $total,
                'page' => $page,
                'page_size' => $pageSize,
                'back' => '/admin/posts' . (($query = http_build_query(array_filter($filters + array('page' => $page > 1 ? $page : ''), static fn ($value): bool => $value !== ''))) !== '' ? '?' . $query : ''),
                'baidu' => array('baiduzz' => $config->get('baidu_zz_token') !== '', 'baiduks' => $config->get('baidu_ks_token') !== ''),
            ));
            return;
        }
        if (preg_match('#^/admin/posts/([1-9][0-9]*)/toggle$#D', $path, $match) && $method === 'POST') {
            // Pboot Content/mod/field/status|istop|isrecommend/value/0|1.
            $this->requireCsrf();
            try {
                [$field, $value] = explode(':', self::postString('switch'), 2) + array('', '');
                $repo->setPostSwitch((int) $match[1], $field, $value === '1');
                $_SESSION['flash'] = '修改成功！';
            } catch (InvalidArgumentException $error) {
                $_SESSION['flash'] = '操作失败：' . $error->getMessage();
            }
            $this->redirect(self::adminBack('/admin/posts'));
        }
        if ($path === '/admin/posts/bulk' && $method === 'POST') {
            $this->requireCsrf();
            try {
                $rawIds = $_POST['post_ids'] ?? array();
                if (! is_array($rawIds)) {
                    throw new InvalidArgumentException('所选文章无效。');
                }
                $action = self::postString('action');
                if ($action === 'sorting') {
                    $orders = $_POST['sort_order'] ?? array();
                    if (! is_array($orders)) {
                        throw new InvalidArgumentException('排序值无效。');
                    }
                    $affected = $repo->savePostSortOrders($orders);
                    $_SESSION['flash'] = '已保存 ' . $affected . ' 篇文章的排序。';
                } elseif (in_array($action, array('baiduzz', 'baiduks'), true)) {
                    $_SESSION['flash'] = $this->baiduPush($pdo, $rawIds, $action === 'baiduks');
                } elseif (in_array($action, array('copy', 'move'), true)) {
                    $categoryId = filter_var(self::postString('target_category_id'), FILTER_VALIDATE_INT, array('options' => array('min_range' => 1)));
                    if ($categoryId === false) {
                        throw new InvalidArgumentException('请选择目标列表栏目。');
                    }
                    $affected = $repo->transferPosts($rawIds, $action, $categoryId);
                    $_SESSION['flash'] = '已' . ($action === 'copy' ? '复制' : '移动') . ' ' . $affected . ' 篇文章。';
                } else {
                    $oldFiles = array();
                    if ($action === 'delete') {
                        $attachments = new AttachmentRepository($pdo, $this->root . '/var');
                        foreach ($rawIds as $rawId) {
                            if (is_string($rawId) && ctype_digit($rawId) && (int) $rawId > 0) {
                                $oldFiles[] = $attachments->forPost((int) $rawId)['path'] ?? null;
                                foreach ($attachments->modelFilesForPost((int) $rawId) as $file) {
                                    $oldFiles[] = $file['path'];
                                }
                            }
                        }
                    }
                    $affected = $repo->bulkPosts($rawIds, $action);
                    foreach ($oldFiles as $file) {
                        $attachments->deleteFile($file);
                    }
                    $_SESSION['flash'] = '已处理 ' . $affected . ' 篇文章。';
                }
            } catch (InvalidArgumentException $error) {
                $_SESSION['flash'] = '操作失败：' . $error->getMessage();
            } catch (PDOException $error) {
                $_SESSION['flash'] = '操作失败：数据库写入未完成，请重试。';
            }
            $this->redirect(self::adminBack('/admin/posts'));
            return;
        }
        if ($path === '/admin/posts/new' && $method === 'GET') {
            $models = new ContentModelRepository($pdo);
            $tab = self::postModelTab($pdo, is_string($_GET['model_id'] ?? null) && ctype_digit($_GET['model_id']) ? (int) $_GET['model_id'] : null, null);
            View::render('admin/post-form', $base + self::accessChoices($pdo) + array('all_categories' => $repo->categories()) + $tab + array('page_title' => $tab['model_name'] . '新增', 'post' => null, 'categories' => $tab['categories'] ?? $repo->categories(), 'tags' => (new TagRepository($pdo))->all(), 'media' => (new MediaRepository($pdo, $this->root . '/public'))->all(), 'gallery' => array(), 'attachment' => null, 'selected_tags' => array(), 'extra_values' => array(), 'extra_files' => array(), 'model_form' => self::postModelForm($models, $repo, null), 'error' => null));
            return;
        }
        if ($path === '/admin/posts' && $method === 'POST') {
            $this->savePost($pdo, $repo, null, $base);
            return;
        }
        if (preg_match('#^/admin/posts/([1-9][0-9]*)/edit$#D', $path, $match)) {
            $id = (int) $match[1];
            $post = $repo->post($id);
            if ($post === null) {
                $this->notFound();
            }
            if ($method === 'POST') {
                $this->savePost($pdo, $repo, $id, $base);
            } elseif ($method === 'GET') {
                $models = new ContentModelRepository($pdo);
                $attachments = new AttachmentRepository($pdo, $this->root . '/var');
                View::render('admin/post-form', $base + array('geo_meta' => (new GeoRepository($pdo))->meta('post', (int) $post['id'])) + self::accessChoices($pdo) + array('all_categories' => $repo->categories()) + self::postModelTab($pdo, null, $post['category_id'] === null ? null : (int) $post['category_id']) + array('page_title' => '编辑文章', 'post' => $post, 'categories' => $repo->categories(), 'tags' => (new TagRepository($pdo))->all(), 'media' => (new MediaRepository($pdo, $this->root . '/public'))->all(), 'gallery' => (new MediaRepository($pdo, $this->root . '/public'))->galleryForPost($id), 'attachment' => $attachments->forPost($id), 'selected_tags' => array_column((new TagRepository($pdo))->forPost($id), 'id'), 'extra_values' => $models->valuesForPost($id), 'extra_files' => $attachments->modelFilesForPost($id), 'model_form' => self::postModelForm($models, $repo, $post), 'error' => null));
            } else {
                $this->notFound();
            }
            return;
        }
        if (preg_match('#^/admin/posts/([1-9][0-9]*)/delete$#D', $path, $match) && $method === 'POST') {
            $postId = (int) $match[1];
            if ($repo->post($postId) === null) {
                $this->notFound();
            }
            $this->requireCsrf();
            $attachments = new AttachmentRepository($pdo, $this->root . '/var');
            $oldAttachment = $attachments->forPost($postId);
            $modelFiles = array_column($attachments->modelFilesForPost($postId), 'path');
            $repo->deletePost($postId);
            $attachments->deleteFile($oldAttachment['path'] ?? null);
            foreach ($modelFiles as $file) {
                $attachments->deleteFile($file);
            }
            $_SESSION['flash'] = '文章已删除。';
            $this->redirect('/admin/posts');
        }
        $this->notFound();
    }

    /**
     * Pboot ContentController baiduzz/baiduks: push the public addresses of the selected posts to
     * Baidu (普通收录 or 快速收录 with type=daily) and report its answer.
     */
    private function baiduPush(PDO $pdo, array $rawIds, bool $daily): string
    {
        $label = $daily ? '百度快速收录推送' : '百度普通收录推送';
        $token = (new PbootConfig($pdo))->get($daily ? 'baidu_ks_token' : 'baidu_zz_token');
        if ($token === '') {
            throw new InvalidArgumentException('请先到配置参数中填写' . $label . 'token值！');
        }
        $data = new PbootData($pdo, 'zh-CN', null, PbootUrl::fromSettings(PbootSite::settings($pdo)));
        $origin = self::siteOrigin();
        $urls = array();
        foreach (array_slice($rawIds, 0, 100) as $rawId) {
            if (is_string($rawId) && ctype_digit($rawId) && ($post = $data->content($rawId)) !== null) {
                $urls[] = $origin . $data->contentLink($post);
            }
        }
        if (! $urls) {
            throw new InvalidArgumentException('请选择要推送的已发布内容！');
        }
        $result = BaiduPusher::send((new GeoPusher($pdo))->baiduSite($origin), $token, $urls, $daily);
        $logs = new AuditLogRepository($pdo);
        foreach ($urls as $url) {
            $logs->record(null, $label, 'POST', substr($url, 0, 255), (string) ($_SERVER['REMOTE_ADDR'] ?? ''));
        }
        if ($result === null) {
            return $label . '发生未知错误！';
        }
        if (isset($result['error'])) {
            return $label . '发生错误：' . (string) ($result['message'] ?? $result['error']);
        }
        $success = $result[$daily ? 'success_daily' : 'success'] ?? null;
        return $success === null ? $label . '发生未知错误！' : '成功推送' . (int) $success . '条，今天剩余可推送' . (int) ($result[$daily ? 'remain_daily' : 'remain'] ?? 0) . '条数!';
    }

    /** Pboot 留言/表单/评论 switches, login requirement and captcha; throws with Pboot's message. */
    private static function assertInteraction(PbootConfig $config, string $kind, ?array $member): void
    {
        $names = array('message' => '留言', 'form' => '表单', 'comment' => '评论');
        if (! $config->on($kind . '_status')) {
            throw new InvalidArgumentException('系统已经关闭' . $names[$kind] . '功能，请到后台开启再试！');
        }
        if ($member === null && (($kind === 'message' && $config->on('message_rqlogin')) || ($kind === 'comment' && ! $config->on('comment_anonymous')))) {
            throw new InvalidArgumentException('请先登录后再提交' . $names[$kind] . '！');
        }
        if (($error = Captcha::error($kind, self::postString('checkcode'))) !== null) {
            throw new InvalidArgumentException($error);
        }
    }

    /** Pboot sendmail() after a submission, when 发送邮件 is on; failures are logged, not shown. */
    private static function notifyInteraction(PbootConfig $config, string $kind, array $fields, array $vars = array()): void
    {
        if (! $config->on($kind . '_send_mail') || $config->get('message_send_to') === '') {
            return;
        }
        $vars = array_merge(array(
            'site_name' => (string) ($vars['site_name'] ?? 'FangdaysCMS'),
            'site_url' => self::siteOrigin(),
            'datetime' => date('Y-m-d H:i:s'),
        ), $vars);
        $mail = EmailTemplate::render($config->all(), $kind, $fields, $vars);
        try {
            SmtpMailer::sendMail($config->all() + array('smtp_from_name' => (string) $vars['site_name']), $config->get('message_send_to'), $mail['subject'], $mail['body']);
        } catch (\RuntimeException $exception) {
            error_log('FangdaysCMS notification mail: ' . $exception->getMessage());
        }
    }

    /** 文章内容 menu entries: one per list content model, with its post count. @return list<array{0: string, 1: string, 2: int}> */
    private static function contentMenu(PDO $pdo): array
    {
        $entries = array();
        foreach ($pdo->query("SELECT m.id, m.name, m.slug, (SELECT COUNT(*) FROM posts p LEFT JOIN category_models cm ON cm.category_id = p.category_id WHERE COALESCE(cm.model_id, (SELECT id FROM content_models WHERE slug = 'article')) = m.id) AS posts FROM content_models m WHERE m.type IN ('list', 'mixed') ORDER BY m.id") as $model) {
            $name = preg_replace('/模型$/u', '', (string) $model['name']) ?: (string) $model['name'];
            $entries[] = array('/admin/posts?model_id=' . (int) $model['id'], str_ends_with($name, '内容') ? $name : $name . '内容', (int) $model['posts']);
        }
        return $entries;
    }

    /** The value of a list switch button (switch=field:0|1). */
    private static function switchValue(): bool
    {
        return str_ends_with(self::postString('switch'), ':1');
    }

    /** The choices of Pboot's 浏览权限 and 内容副栏目 fields. */
    private static function accessChoices(PDO $pdo): array
    {
        return array('member_groups' => $pdo->query('SELECT code, name FROM member_groups ORDER BY code, id')->fetchAll());
    }

    /** Pboot checkPageLevel() for a post and/or category: the note to show when this visitor may not open it. */
    private static function levelNote(PDO $pdo, ContentRepository $repo, ?array $post, ?int $categoryId, ?array $member): ?string
    {
        $categoryId ??= (int) ($post['category_id'] ?? 0);
        $rules = $categoryId > 0 ? array($repo->categoryAccess($categoryId)) : array();
        return (new PageLevel($pdo))->firstDenied($post === null ? $rules : array_merge($rules, array($post)), $member);
    }

    /** The list address a form posted back from (field "back"); only addresses under $prefix are followed. */
    private static function adminBack(string $prefix): string
    {
        $back = self::postString('back');
        return preg_match('#^' . preg_quote($prefix, '#') . '(?:\?[A-Za-z0-9_=&%.\-\[\]]*)?$#D', $back) === 1 ? $back : $prefix;
    }

    /**
     * The 文章内容 model an editor page belongs to (from ?model_id or the post's category): its name for the
     * {模型}新增 / {模型}内容修改 tabs, the list address, and for a new post the categories of that model.
     */
    private static function postModelTab(PDO $pdo, ?int $modelId, ?int $categoryId): array
    {
        $models = new ContentModelRepository($pdo);
        $modelId ??= $categoryId === null ? null : (int) $models->modelForCategory($categoryId)['id'];
        foreach (self::contentMenu($pdo) as [$href, $label]) {
            if ($modelId !== null && $href === '/admin/posts?model_id=' . $modelId) {
                $tab = array('model_name' => preg_replace('/内容$/u', '', $label) ?: $label, 'list_href' => $href);
                if ($categoryId === null) {
                    $tab['categories'] = array_values(array_filter((new ContentRepository($pdo))->categories(), static fn (array $row): bool => (int) $models->modelForCategory((int) $row['id'])['id'] === $modelId));
                }
                return $tab;
            }
        }
        return array('model_name' => '文章', 'list_href' => '/admin/posts');
    }

    /** Pboot 系统信息 rows shared by the home and 服务器信息 pages. */
    private static function serverInfo(PDO $pdo): array
    {
        return array(
            '应用版本' => 'FangdaysCMS ' . self::VERSION,
            '主机系统' => PHP_OS,
            '主机地址' => (string) ($_SERVER['HTTP_HOST'] ?? ''),
            'WEB软件' => (string) ($_SERVER['SERVER_SOFTWARE'] ?? ''),
            'PHP版本' => PHP_VERSION,
            '数据库驱动' => (string) $pdo->getAttribute(PDO::ATTR_DRIVER_NAME),
            '文件上传限制' => (string) ini_get('upload_max_filesize'),
            '表单提交限制' => (string) ini_get('post_max_size'),
        );
    }

    /** PbootCMS member/group.html: 会员等级. */
    private function memberGroupAdminRoute(string $path, string $method, PDO $pdo, array $base): void
    {
        $error = null;
        $editId = is_string($_GET['edit'] ?? null) && ctype_digit($_GET['edit']) ? (int) $_GET['edit'] : null;
        if ($method === 'POST') {
            $this->requireCsrf();
            if (preg_match('#^/admin/member-groups/([1-9][0-9]*)/toggle$#D', $path, $match)) {
                $pdo->prepare('UPDATE member_groups SET status = ? WHERE id = ?')->execute(array(self::switchValue() ? 'active' : 'disabled', (int) $match[1]));
                $_SESSION['flash'] = '修改成功！';
                $this->redirect('/admin/member-groups');
            }
            if (preg_match('#^/admin/member-groups/([1-9][0-9]*)/delete$#D', $path, $match)) {
                $stmt = $pdo->prepare('DELETE FROM member_groups WHERE id = ? AND NOT EXISTS (SELECT 1 FROM member_group_members WHERE group_id = ?)');
                $stmt->execute(array((int) $match[1], (int) $match[1]));
                $_SESSION['flash'] = $stmt->rowCount() > 0 ? '会员等级已删除。' : '操作失败：该等级下还有会员，不能删除。';
                $this->redirect('/admin/member-groups');
            }
            $id = preg_match('#^/admin/member-groups/([1-9][0-9]*)/edit$#D', $path, $match) ? (int) $match[1] : ($path === '/admin/member-groups' ? null : -1);
            if ($id === -1) {
                $this->notFound();
            }
            $code = trim(self::postString('code'));
            $name = trim(self::postString('name'));
            $lscore = self::postString('lscore');
            $uscore = self::postString('uscore');
            $status = self::postString('status') === 'disabled' ? 'disabled' : 'active';
            if (preg_match('/^[A-Za-z0-9_-]{1,64}$/D', $code) !== 1 || $name === '' || mb_strlen($name) > 100 || mb_strlen(self::postString('description')) > 200 || ! ctype_digit($lscore !== '' ? $lscore : '0') || ! ctype_digit($uscore !== '' ? $uscore : '0')) {
                $error = '等级编号（字母、数字、下划线）、名称或积分无效。';
            } else {
                try {
                    if ($id === null) {
                        $pdo->prepare('INSERT INTO member_groups (code, name, status, created_at, description, lscore, uscore) VALUES (?, ?, ?, ?, ?, ?, ?)')->execute(array($code, $name, $status, time(), trim(self::postString('description')), (int) $lscore, (int) $uscore));
                    } else {
                        $pdo->prepare('UPDATE member_groups SET code = ?, name = ?, status = ?, description = ?, lscore = ?, uscore = ? WHERE id = ?')->execute(array($code, $name, $status, trim(self::postString('description')), (int) $lscore, (int) $uscore, $id));
                    }
                    $_SESSION['flash'] = '会员等级已保存。';
                    $this->redirect('/admin/member-groups');
                } catch (PDOException $exception) {
                    $error = '等级编号已经存在。';
                }
            }
            $editId = $id;
        } elseif ($method !== 'GET' || $path !== '/admin/member-groups') {
            $this->notFound();
        }
        $groups = $pdo->query('SELECT g.*, (SELECT COUNT(*) FROM member_group_members gm WHERE gm.group_id = g.id) AS members FROM member_groups g ORDER BY g.code, g.id')->fetchAll();
        $editing = $editId === null ? null : (array_values(array_filter($groups, static fn (array $group): bool => (int) $group['id'] === $editId))[0] ?? null);
        if ($error !== null) {
            $editing = array('id' => $editId ?? 0, 'code' => self::postString('code'), 'name' => self::postString('name'), 'description' => self::postString('description'), 'lscore' => (int) self::postString('lscore'), 'uscore' => (int) self::postString('uscore'), 'status' => self::postString('status'));
            $editing = $editId === null ? array_merge($editing, array('id' => 0)) : $editing;
        }
        View::render('admin/member-groups', $base + array('page_title' => '会员等级', 'groups' => $groups, 'editing' => $editId === null && $error === null ? null : $editing, 'error' => $error), $error ? 422 : 200);
    }

    /** PbootCMS content/tags.html: 文章内链. */
    private function contentLinkAdminRoute(string $path, string $method, PDO $pdo, array $base): void
    {
        $error = null;
        $editId = is_string($_GET['edit'] ?? null) && ctype_digit($_GET['edit']) ? (int) $_GET['edit'] : null;
        if ($method === 'POST') {
            $this->requireCsrf();
            if (preg_match('#^/admin/content-links/([1-9][0-9]*)/delete$#D', $path, $match)) {
                $pdo->prepare('DELETE FROM content_links WHERE id = ?')->execute(array((int) $match[1]));
                $_SESSION['flash'] = '内链已删除。';
                $this->redirect('/admin/content-links');
            }
            $id = preg_match('#^/admin/content-links/([1-9][0-9]*)/edit$#D', $path, $match) ? (int) $match[1] : ($path === '/admin/content-links' ? null : -1);
            if ($id === -1) {
                $this->notFound();
            }
            $name = trim(self::postString('name'));
            $link = trim(self::postString('link'));
            $sort = self::postString('sort_order');
            if ($name === '' || mb_strlen($name) > 50 || ! preg_match('#^(?:https?://[^\s"<>]+|/[^\s"<>]*)$#D', $link) || strlen($link) > 255 || ! ctype_digit($sort !== '' ? $sort : '0')) {
                $error = '关键词、链接（http(s) 地址或站内地址）或排序无效。';
                $editId = $id;
            } else {
                if ($id === null) {
                    $pdo->prepare('INSERT INTO content_links (name, link, sort_order) VALUES (?, ?, ?)')->execute(array($name, $link, (int) $sort));
                } else {
                    $pdo->prepare('UPDATE content_links SET name = ?, link = ?, sort_order = ? WHERE id = ?')->execute(array($name, $link, (int) $sort, $id));
                }
                $_SESSION['flash'] = '内链已保存。';
                $this->redirect('/admin/content-links');
            }
        } elseif ($method !== 'GET' || $path !== '/admin/content-links') {
            $this->notFound();
        }
        $links = $pdo->query('SELECT * FROM content_links ORDER BY sort_order, id')->fetchAll();
        $editing = $error !== null ? array('id' => $editId ?? 0, 'name' => self::postString('name'), 'link' => self::postString('link'), 'sort_order' => (int) self::postString('sort_order')) : ($editId === null ? null : (array_values(array_filter($links, static fn (array $link): bool => (int) $link['id'] === $editId))[0] ?? null));
        View::render('admin/content-links', $base + array('page_title' => '文章内链', 'links' => $links, 'editing' => $editing !== null && (int) $editing['id'] === 0 && $error === null ? null : $editing, 'error' => $error), $error ? 422 : 200);
    }

    /** PbootCMS 配置参数 (system/config.html): one form per tab, plus the test mail action. */
    private function configAdminRoute(string $path, string $method, PDO $pdo, array $base): void
    {
        $config = new PbootConfig($pdo);
        $tab = is_string($_GET['tab'] ?? null) ? $_GET['tab'] : 't1';
        $error = null;
        $values = $config->all();
        if ($method === 'POST') {
            $this->requireCsrf();
            if ($path === '/admin/config/testmail') {
                try {
                    // Apply the form values first so a freshly pasted auth code is used.
                    $config->saveTab('t2', $_POST);
                    $to = $config->get('smtp_username_test');
                    if ($to === '') {
                        throw new \RuntimeException('请先填写测试账号。');
                    }
                    $mail = EmailTemplate::render($config->all(), 'test', array(), array(
                        'site_name' => (string) $base['site_name'],
                        'site_url' => self::siteOrigin(),
                        'datetime' => date('Y-m-d H:i:s'),
                    ));
                    SmtpMailer::sendMail($config->all() + array('smtp_from_name' => (string) $base['site_name']), $to, $mail['subject'], $mail['body']);
                    $_SESSION['flash'] = '测试邮件已发送到 ' . $to . '。';
                } catch (InvalidArgumentException | \RuntimeException $exception) {
                    $_SESSION['flash'] = '测试邮件发送失败：' . $exception->getMessage();
                }
                $this->redirect('/admin/config?tab=t2');
            }
            $tab = (string) array_search(self::postString('submit'), array_map(static fn (array $definition): string => $definition[1], PbootConfig::TABS), true);
            try {
                $config->saveTab($tab, $_POST);
                $_SESSION['flash'] = '修改成功！';
                $this->redirect('/admin/config?tab=' . $tab);
            } catch (InvalidArgumentException $exception) {
                $error = $exception->getMessage();
                $values = array_merge($values, array_map(static fn ($value): string => is_string($value) ? $value : '', array_intersect_key($_POST, PbootConfig::FIELDS)));
            }
        } elseif ($method !== 'GET') {
            $this->notFound();
        }
        $groups = $pdo->query("SELECT id, name FROM member_groups WHERE status = 'active' ORDER BY id")->fetchAll();
        View::render('admin/config', $base + array('page_title' => '配置参数', 'values' => $values, 'tab' => $tab, 'groups' => $groups, 'error' => $error), $error ? 422 : 200);
    }

    private function messageAdminRoute(string $path, string $method, GuestbookRepository $messages, array $base): void
    {
        if ($path === '/admin/messages' && $method === 'GET') {
            $status = isset($_GET['status']) && is_string($_GET['status']) ? $_GET['status'] : null;
            View::render('admin/messages', $base + array('page_title' => '留言管理', 'messages' => $messages->all($status), 'filter_status' => $status, 'message_count' => $messages->count()));
            return;
        }
        if (preg_match('#^/admin/messages/([1-9][0-9]*)/status$#D', $path, $match) && $method === 'POST') {
            $this->requireCsrf();
            try {
                $messages->updateStatus((int) $match[1], self::postString('status'));
                $_SESSION['flash'] = '留言状态已更新。';
            } catch (InvalidArgumentException $error) {
                $_SESSION['flash'] = '操作失败：' . $error->getMessage();
            }
            $this->redirect('/admin/messages');
        }
        if (preg_match('#^/admin/messages/([1-9][0-9]*)/reply$#D', $path, $match) && $method === 'POST') {
            $this->requireCsrf();
            try {
                $messages->reply((int) $match[1], self::postString('recontent'));
                $_SESSION['flash'] = '留言回复已保存。';
            } catch (InvalidArgumentException $error) {
                $_SESSION['flash'] = '操作失败：' . $error->getMessage();
            }
            $this->redirect('/admin/messages');
        }
        if (preg_match('#^/admin/messages/([1-9][0-9]*)/delete$#D', $path, $match) && $method === 'POST') {
            $this->requireCsrf();
            try {
                $messages->delete((int) $match[1]);
                $_SESSION['flash'] = '留言已删除。';
            } catch (InvalidArgumentException $error) {
                $_SESSION['flash'] = '操作失败：' . $error->getMessage();
            }
            $this->redirect('/admin/messages');
        }
        $this->notFound();
    }

    private function commentAdminRoute(string $path, string $method, CommentRepository $comments, array $base): void
    {
        if ($path === '/admin/comments' && $method === 'GET') {
            $status = isset($_GET['status']) && is_string($_GET['status']) ? $_GET['status'] : null;
            View::render('admin/comments', $base + array('page_title' => '评论管理', 'comments' => $comments->all($status), 'filter_status' => $status));
            return;
        }
        if (preg_match('#^/admin/comments/([1-9][0-9]*)/status$#D', $path, $match) && $method === 'POST') {
            $this->requireCsrf();
            try {
                $comments->updateStatus((int) $match[1], self::postString('status'));
                $_SESSION['flash'] = '评论状态已更新。';
            } catch (InvalidArgumentException $error) {
                $_SESSION['flash'] = '操作失败：' . $error->getMessage();
            }
            $this->redirect('/admin/comments');
        }
        if (preg_match('#^/admin/comments/([1-9][0-9]*)/delete$#D', $path, $match) && $method === 'POST') {
            $this->requireCsrf();
            try {
                $comments->delete((int) $match[1]);
                $_SESSION['flash'] = '评论已删除。';
            } catch (InvalidArgumentException $error) {
                $_SESSION['flash'] = '操作失败：' . $error->getMessage();
            }
            $this->redirect('/admin/comments');
        }
        $this->notFound();
    }

    private function formAdminRoute(string $path, string $method, PDO $pdo, FormRepository $forms, array $base): void
    {
        if ($path === '/admin/forms' && $method === 'GET') {
            View::render('admin/forms', $base + array('page_title' => '自定义表单', 'forms' => $forms->all()));
            return;
        }
        if ($path === '/admin/forms/new' && $method === 'GET') {
            View::render('admin/form-form', $base + array('page_title' => '新建表单', 'form' => null, 'fields_text' => '', 'error' => null));
            return;
        }
        if ($path === '/admin/forms' && $method === 'POST') {
            $this->saveForm($forms, null, $base);
            return;
        }
        if (preg_match('#^/admin/forms/([1-9][0-9]*)/edit$#D', $path, $match)) {
            $id = (int) $match[1];
            $form = $forms->byId($id);
            if ($form === null) {
                $this->notFound();
            }
            if ($method === 'POST') {
                $this->saveForm($forms, $id, $base);
                return;
            }
            View::render('admin/form-form', $base + array('page_title' => '编辑表单', 'form' => $form, 'fields_text' => self::fieldsText($forms->fields($form)), 'error' => null));
            return;
        }
        if (preg_match('#^/admin/forms/([1-9][0-9]*)/toggle$#D', $path, $match) && $method === 'POST') {
            $this->requireCsrf();
            $forms->setStatus((int) $match[1], self::switchValue());
            $_SESSION['flash'] = '修改成功！';
            $this->redirect('/admin/forms');
        }
        if (preg_match('#^/admin/forms/([1-9][0-9]*)/menu$#D', $path, $match) && $method === 'POST') {
            // Pboot 添加到菜单: the form's data page under 扩展内容.
            $this->requireCsrf();
            $form = $forms->byId((int) $match[1]);
            if ($form === null) {
                $this->notFound();
            }
            $menus = new MenuRepository($pdo);
            $slug = 'form_' . (int) $form['id'];
            if (in_array($slug, array_column($menus->all(), 'slug'), true)) {
                $_SESSION['flash'] = '该表单已在菜单中。';
            } else {
                $group = $pdo->query("SELECT id FROM admin_menus WHERE slug = 'grp_extend'")->fetchColumn();
                $menus->save(null, array('parent_id' => $group === false ? '' : (string) $group, 'slug' => $slug, 'label' => mb_substr((string) $form['name'], 0, 100), 'icon' => 'fa-list-alt', 'path' => '/admin/forms/' . (int) $form['id'] . '/submissions', 'permission' => 'operations.manage', 'sort_order' => 510, 'is_visible' => '1'));
                $_SESSION['flash'] = '已添加到菜单。';
            }
            $this->redirect('/admin/forms');
        }
        if (preg_match('#^/admin/forms/([1-9][0-9]*)/fields(?:/([a-z][a-z0-9_]{0,58})/(edit|delete))?$#D', $path, $match)) {
            $form = $forms->byId((int) $match[1]);
            if ($form === null) {
                $this->notFound();
            }
            $id = (int) $form['id'];
            $name = $match[2] ?? null;
            $error = null;
            if ($method === 'POST') {
                $this->requireCsrf();
                try {
                    if (($match[3] ?? '') === 'delete') {
                        $forms->deleteField($id, (string) $name);
                    } else {
                        $forms->saveField($id, $name, $_POST);
                    }
                    $_SESSION['flash'] = '表单字段已保存。';
                    $this->redirect('/admin/forms/' . $id . '/fields');
                } catch (InvalidArgumentException $exception) {
                    $error = $exception->getMessage();
                }
            } elseif ($method !== 'GET' || $name !== null) {
                $this->notFound();
            }
            $fields = $forms->fields($form);
            $editName = $name ?? (is_string($_GET['edit'] ?? null) ? $_GET['edit'] : null);
            $editing = $editName === null ? null : (array_values(array_filter($fields, static fn (array $field): bool => $field['name'] === $editName))[0] ?? null);
            View::render('admin/form-fields', $base + array('page_title' => '表单字段', 'form' => $form, 'fields' => $fields, 'editing' => $editing, 'error' => $error), $error === null ? 200 : 422);
            return;
        }
        if (preg_match('#^/admin/forms/([1-9][0-9]*)/submissions$#D', $path, $match) && $method === 'GET') {
            $form = $forms->byId((int) $match[1]);
            if ($form === null) {
                $this->notFound();
            }
            View::render('admin/form-submissions', $base + array('page_title' => '表单记录', 'form' => $form, 'fields' => $forms->fields($form), 'submissions' => $forms->submissions((int) $match[1])));
            return;
        }
        if (preg_match('#^/admin/forms/([1-9][0-9]*)/delete$#D', $path, $match) && $method === 'POST') {
            $this->requireCsrf();
            try {
                $forms->delete((int) $match[1]);
                $_SESSION['flash'] = '表单已删除。';
            } catch (InvalidArgumentException $error) {
                $_SESSION['flash'] = '操作失败：' . $error->getMessage();
            }
            $this->redirect('/admin/forms');
        }
        $this->notFound();
    }

    private function saveForm(FormRepository $forms, ?int $id, array $base): void
    {
        $this->requireCsrf();
        $input = array('name' => self::postString('name'), 'slug' => self::postString('slug'), 'intro' => self::postString('intro'), 'status' => self::postString('status'), 'fields_text' => array_key_exists('fields_text', $_POST) ? self::postString('fields_text') : null);
        try {
            $forms->save($id, $input['name'], $input['slug'], $input['intro'], $input['status'], $input['fields_text']);
            $_SESSION['flash'] = '表单已保存。';
            $this->redirect('/admin/forms');
        } catch (InvalidArgumentException $error) {
            View::render('admin/form-form', $base + array('page_title' => $id === null ? '新建表单' : '编辑表单', 'form' => $input + array('id' => $id), 'fields_text' => $input['fields_text'], 'error' => $error->getMessage()), 422);
        }
    }

    private static function fieldsText(array $fields): string
    {
        return implode("\n", array_map(static fn (array $field): string => implode('|', array((string) $field['name'], (string) $field['label'], (string) $field['type'], ! empty($field['required']) ? '1' : '0', implode(',', $field['options'] ?? array()))), $fields));
    }

    private function logAdminRoute(string $path, string $method, AuditLogRepository $logs, array $base): void
    {
        if ($path === '/admin/logs' && $method === 'GET') {
            $keyword = isset($_GET['q']) && is_string($_GET['q']) ? $_GET['q'] : '';
            $page = isset($_GET['page']) && is_string($_GET['page']) ? max(1, (int) $_GET['page']) : 1;
            $total = $logs->count($keyword);
            View::render('admin/logs', $base + array('page_title' => '系统日志', 'logs' => $logs->all($keyword, $page), 'keyword' => $keyword, 'page' => $page, 'total' => $total, 'total_pages' => max(1, (int) ceil($total / 50))));
            return;
        }
        if ($path === '/admin/logs/export' && $method === 'GET') {
            $keyword = isset($_GET['q']) && is_string($_GET['q']) ? $_GET['q'] : '';
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="audit-logs.csv"');
            echo "\xEF\xBB\xBF" . $logs->csv($keyword);
            return;
        }
        if ($path === '/admin/logs/clear' && $method === 'POST') {
            $this->requireCsrf();
            $logs->clear();
            $_SESSION['flash'] = '系统日志已清空。';
            $this->redirect('/admin/logs');
        }
        $this->notFound();
    }

    private function templateAdminRoute(string $path, string $method, PDO $pdo, array $base): void
    {
        $listing = function (?string $error = null) use ($pdo, $base): void {
            $active = PbootSite::themeName(PbootSite::settings($pdo), $this->root);
            $themes = array();
            foreach (Theme::names($this->root) as $name) {
                $themes[$name] = array('pc' => (new Theme($this->root, $name))->files(), 'wap' => Theme::hasWap($this->root, $name) ? (new Theme($this->root, $name, true))->files() : array());
            }
            uksort($themes, static fn (string $a, string $b): int => array($b === $active, $a) <=> array($a === $active, $b));
            View::render('admin/templates', $base + array('page_title' => '模板管理', 'templates' => SiteTemplate::names(), 'themes' => $themes, 'active_theme' => $active, 'error' => $error), $error === null ? 200 : 422);
        };
        if ($path === '/admin/templates' && $method === 'GET') {
            $listing();
            return;
        }
        if (preg_match('#^/admin/templates/theme/([a-z0-9][a-z0-9_-]{0,31})/(pc|wap)/([A-Za-z0-9_./-]+\.html)/edit$#D', $path, $match)) {
            [, $themeName, $device, $file] = $match;
            $action = $path;
            $title = $themeName . ' · ' . ($device === 'wap' ? '手机' : '电脑') . ' · ' . $file;
            try {
                $theme = new Theme($this->root, $themeName, $device === 'wap');
                if ($method === 'GET') {
                    View::render('admin/template-form', $base + array('page_title' => '编辑模板', 'name' => $title, 'action' => $action, 'limit' => '1 MB', 'source' => $theme->source($file), 'error' => null));
                    return;
                }
                if ($method === 'POST') {
                    $this->requireCsrf();
                    $theme->save($file, self::postString('source'));
                    $_SESSION['flash'] = '模板已保存。';
                    $this->redirect('/admin/templates');
                }
            } catch (InvalidArgumentException $error) {
                if ($method === 'POST' && isset($theme) && $theme->has($file)) {
                    View::render('admin/template-form', $base + array('page_title' => '编辑模板', 'name' => $title, 'action' => $action, 'limit' => '1 MB', 'source' => self::postString('source'), 'error' => $error->getMessage()), 422);
                    return;
                }
            }
            $this->notFound();
            return;
        }
        if ($path === '/admin/templates/export' && $method === 'GET') {
            try {
                SiteTemplate::exportArchive($this->root);
            } catch (InvalidArgumentException $error) {
                $listing($error->getMessage());
            }
        }
        if ($path === '/admin/templates/import' && $method === 'POST') {
            $this->requireCsrf();
            $upload = $_FILES['archive'] ?? null;
            try {
                if (! is_array($upload) || (int) ($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
                    throw new InvalidArgumentException('请选择有效的 ZIP 模板包。');
                }
                $count = SiteTemplate::importArchive($this->root, (string) $upload['tmp_name']);
                $_SESSION['flash'] = '已导入 ' . $count . ' 个模板文件。';
                $this->redirect('/admin/templates');
            } catch (InvalidArgumentException $error) {
                $listing($error->getMessage());
            }
            return;
        }
        if (preg_match('#^/admin/templates/([a-z0-9-]+\.html)/preview$#D', $path, $match) && $method === 'GET') {
            try {
                $name = $match[1];
                $sampleCategory = array('id' => 1, 'parent_id' => null, 'name' => '预览栏目', 'slug' => 'preview', 'type' => 'list', 'is_visible' => 1, 'outlink' => '', 'seo_title' => '模板预览', 'seo_keywords' => '', 'seo_description' => '模板预览栏目');
                $samplePost = array('id' => 1, 'category_id' => 1, 'category_name' => '预览栏目', 'category_slug' => 'preview', 'title' => '模板预览文章', 'slug' => 'preview-post', 'body' => '这是用于模板预览的示例正文。', 'body_format' => 'plain', 'status' => 'published', 'created_at' => time(), 'updated_at' => time(), 'published_at' => time(), 'sort_order' => 1, 'is_top' => 0, 'is_recommended' => 0, 'is_headline' => 0, 'title_color' => '', 'subtitle' => '', 'author' => 'FangdaysCMS', 'source' => '预览数据', 'outlink' => '', 'cover_path' => '', 'seo_keywords' => '', 'seo_description' => '模板预览示例文章');
                $data = $base + array('site_name' => $base['site_name'] ?? 'FangdaysCMS', 'page_title' => '模板预览', 'categories' => array($sampleCategory), 'all_categories' => array($sampleCategory), 'category' => $sampleCategory, 'post' => $samplePost, 'posts' => array($samplePost), 'page' => 1, 'total_pages' => 1, 'list_extra_fields' => array(), 'list_galleries' => array(), 'list_tags' => array(), 'gallery' => array(), 'tags' => array(), 'extra_fields' => array());
                View::renderSiteHtml(SiteTemplate::render($name, $data), $data);
            } catch (InvalidArgumentException $error) {
                $this->notFound();
            }
            return;
        }
        if (preg_match('#^/admin/templates/([a-z0-9-]+\.html)/edit$#D', $path, $match)) {
            $name = $match[1];
            if ($method === 'GET') {
                try {
                    View::render('admin/template-form', $base + array('page_title' => '编辑模板', 'name' => $name, 'source' => SiteTemplate::source($name), 'error' => null));
                } catch (InvalidArgumentException $error) {
                    $this->notFound();
                }
                return;
            }
            if ($method === 'POST') {
                $this->requireCsrf();
                try {
                    SiteTemplate::save($name, self::postString('source'));
                    $_SESSION['flash'] = '模板已保存。';
                    $this->redirect('/admin/templates');
                } catch (InvalidArgumentException $error) {
                    View::render('admin/template-form', $base + array('page_title' => '编辑模板', 'name' => $name, 'source' => self::postString('source'), 'error' => $error->getMessage()), 422);
                }
                return;
            }
        }
        $this->notFound();
    }

    private function databaseAdminRoute(string $path, string $method, PDO $pdo, array $base): void
    {
        $config = require $this->root . '/config/app.php';
        $maintenance = new DatabaseMaintenance($pdo, $config['database'], $this->root);
        if ($path === '/admin/database' && $method === 'GET') {
            View::render('admin/database', $base + array('page_title' => '数据库管理', 'backups' => $maintenance->backups()));
            return;
        }
        if ($path === '/admin/database/backup' && $method === 'POST') {
            $this->requireCsrf();
            try {
                $name = $maintenance->backup();
                $_SESSION['flash'] = '数据库备份已生成：' . $name;
            } catch (\Throwable $error) {
                $_SESSION['flash'] = '备份失败：' . $error->getMessage();
            }
            $this->redirect('/admin/database');
        }
        if ($path === '/admin/database/optimize' && $method === 'POST') {
            $this->requireCsrf();
            try {
                $maintenance->optimize();
                $_SESSION['flash'] = '数据库优化已完成。';
            } catch (\Throwable $error) {
                $_SESSION['flash'] = '优化失败：' . $error->getMessage();
            }
            $this->redirect('/admin/database');
        }
        if ($path === '/admin/database/restore' && $method === 'POST') {
            $this->requireCsrf();
            try {
                $maintenance->restore(self::postString('backup_name'));
                $_SESSION['flash'] = '数据库已从备份恢复，恢复前版本已另存。';
            } catch (\Throwable $error) {
                $_SESSION['flash'] = '恢复失败：' . $error->getMessage();
            }
            $this->redirect('/admin/database');
        }
        if (preg_match('#^/admin/database/download/(content-[0-9]{8}-[0-9]{6}\.(?:sqlite|sql))$#D', $path, $match) && $method === 'GET') {
            try {
                $maintenance->send($match[1]);
            } catch (\Throwable $error) {
                $this->notFound();
            }
        }
        $this->notFound();
    }

    private function regionContentAdminRoute(string $path, string $method, RegionContentRepository $records, array $base): void
    {
        if (preg_match('#^/admin/region-content/(post|page|category)$#D', $path, $match) && $method === 'GET') {
            View::render('admin/region-content-list', $base + array('page_title' => '区域内容', 'type' => $match[1], 'locale' => $base['locale'], 'records' => $records->all((string) $base['locale'], $match[1])));
            return;
        }
        if (preg_match('#^/admin/region-content/(post|page|category)/new$#D', $path, $match) && $method === 'GET') {
            View::render('admin/region-content-form', $base + array('page_title' => '新建区域记录', 'type' => $match[1], 'record' => null, 'error' => null));
            return;
        }
        if (preg_match('#^/admin/region-content/(post|page|category)/([1-9][0-9]*)/edit$#D', $path, $match) && $method === 'GET') {
            $record = $records->byId((string) $base['locale'], (int) $match[2]);
            if ($record === null) $this->notFound();
            View::render('admin/region-content-form', $base + array('page_title' => '编辑区域记录', 'type' => $match[1], 'record' => $record, 'error' => null));
            return;
        }
        if ($method !== 'POST') $this->notFound();
        $this->requireCsrf();
        if (preg_match('#^/admin/region-content/(post|page|category)$#D', $path, $match)) {
            $type = $match[1]; $id = null;
        } elseif (preg_match('#^/admin/region-content/(post|page|category)/([1-9][0-9]*)$#D', $path, $match)) {
            $type = $match[1];
            $id = (int) $match[2];
        } elseif (preg_match('#^/admin/region-content/(post|page|category)/([1-9][0-9]*)/edit$#D', $path, $match)) {
            $type = $match[1]; $id = (int) $match[2];
            if ($records->byId((string) $base['locale'], $id) === null) $this->notFound();
        } elseif (preg_match('#^/admin/region-content/(post|page|category)/([1-9][0-9]*)/delete$#D', $path, $match)) {
            $records->tombstone((string) $base['locale'], (int) $match[2], (int) $base['user']['id']);
            $this->redirect('/admin/region-content/' . $match[1]);
        } else {
            $this->notFound();
        }
        $payload = array('title' => self::postString('title'), 'body' => self::postString('body'), 'seo_title' => self::postString('seo_title'), 'seo_keywords' => self::postString('seo_keywords'), 'seo_description' => self::postString('seo_description'));
        if (self::postString('payload') !== '') {
            $legacyPayload = json_decode(self::postString('payload'), true);
            if (!is_array($legacyPayload)) throw new InvalidArgumentException('payload 必须是 JSON 对象。');
            $payload = $legacyPayload;
        }
        if (self::postString('category_id') !== '') $payload['category_id'] = (int) self::postString('category_id');
        try {
            $sourceRaw = self::postString('source_id');
            $sourceId = $sourceRaw === '' ? null : filter_var($sourceRaw, FILTER_VALIDATE_INT, array('options' => array('min_range' => 1)));
            if ($sourceId === false) throw new InvalidArgumentException('canonical ID 无效。');
            $status = self::postString('status') ?: 'draft';
            $recordId = $records->save((string) $base['locale'], $type, $id, $sourceId, self::postString('slug'), $payload, $status, (int) $base['user']['id']);
            if (self::postString('payload') !== '' || str_contains((string) ($_SERVER['HTTP_ACCEPT'] ?? ''), 'application/json')) { header('Content-Type: application/json; charset=utf-8'); echo json_encode(array('id' => $recordId, 'locale' => $base['locale'], 'entity_type' => $type, 'status' => $status), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR); return; }
            $this->redirect('/admin/region-content/' . $type);
        } catch (Throwable $error) {
            View::render('admin/region-content-form', $base + array('page_title' => '区域记录写入失败', 'type' => $type, 'record' => $payload + array('id' => $id, 'source_id' => self::postString('source_id'), 'slug' => self::postString('slug'), 'status' => self::postString('status')), 'error' => $error->getMessage()), 422);
        }
    }


    private function pageAdminRoute(string $path, string $method, PDO $pdo, PageRepository $pages, MediaRepository $media, array $base): void
    {
        if ($path === '/admin/pages' && $method === 'GET') {
            View::render('admin/pages', $base + array('page_title' => '单页管理', 'pages' => $pages->all()));
            return;
        }
        if ($path === '/admin/pages/new' && $method === 'GET') {
            View::render('admin/page-form', $base + array('page_title' => '新建单页', 'page' => null, 'media' => $media->all(), 'gallery' => array(), 'attachment' => null, 'error' => null));
            return;
        }
        if ($path === '/admin/pages' && $method === 'POST') {
            $this->savePage($pdo, $pages, $media, null, $base);
            return;
        }
        if (preg_match('#^/admin/pages/([1-9][0-9]*)/edit$#D', $path, $match)) {
            $id = (int) $match[1];
            $page = $pages->byId($id);
            if ($page === null) {
                $this->notFound();
            }
            if ($method === 'POST') {
                $this->savePage($pdo, $pages, $media, $id, $base);
            } elseif ($method === 'GET') {
                $cover = $media->coverForPage($id);
                $page['cover_media_id'] = $cover['id'] ?? '';
                $gallery = $media->galleryForPage($id);
                View::render('admin/page-form', $base + array('geo_meta' => (new GeoRepository($pdo))->meta('page', (int) $page['id'])) + array('page_title' => '编辑单页', 'page' => $page, 'media' => self::mediaOptionsForSelection($media, array_merge(array($page['cover_media_id']), array_column($gallery, 'media_id'))), 'gallery' => $gallery, 'attachment' => (new AttachmentRepository($pdo, $this->root . '/var'))->forPage($id), 'error' => null));
            } else {
                $this->notFound();
            }
            return;
        }
        if (preg_match('#^/admin/pages/([1-9][0-9]*)/delete$#D', $path, $match) && $method === 'POST') {
            $this->requireCsrf();
            $attachments = new AttachmentRepository($pdo, $this->root . '/var');
            $oldFile = $attachments->forPage((int) $match[1])['path'] ?? null;
            $pages->delete((int) $match[1]);
            $attachments->deleteFile($oldFile);
            $_SESSION['flash'] = '单页已删除。';
            $this->redirect('/admin/pages');
        }
        $this->notFound();
    }

    private function operationsAdminRoute(string $path, string $method, PDO $pdo, OperationsRepository $operations, MediaRepository $media, array $base): void
    {
        if ($path === '/admin/company') {
            $company = $operations->company();
            $error = null;
            if ($method === 'POST') {
                $this->requireCsrf();
                $company = $_POST;
                try {
                    $operations->saveCompany($company);
                    $_SESSION['flash'] = '公司信息已保存。';
                    $this->redirect('/admin/company');
                } catch (InvalidArgumentException $exception) {
                    $error = $exception->getMessage();
                }
            } elseif ($method !== 'GET') {
                $this->notFound();
            }
            $config = new PbootConfig($pdo);
            View::render('admin/company', $base + array(
                'page_title' => '公司信息',
                'company' => $company,
                'map_keys' => array('baidu' => $config->get('baidu_map_ak'), 'amap' => $config->get('amap_map_key')),
                'media' => self::mediaOptionsForSelection($media, array()),
                'error' => $error,
            ), $error ? 422 : 200);
            return;
        }
        if (str_starts_with($path, '/admin/labels')) {
            if ($path === '/admin/labels' && $method === 'GET') {
                View::render('admin/labels', $base + array('page_title' => '定制标签', 'labels' => $operations->labels(), 'media' => $media->all()));
                return;
            }
            if ($path === '/admin/labels/new' && $method === 'GET') {
                View::render('admin/label-form', $base + array('page_title' => '新建自定义标签', 'label' => null, 'media' => $media->all(), 'error' => null));
                return;
            }
            if ($path === '/admin/labels' && $method === 'POST') {
                $this->saveOperationLabel($operations, $media, null, $base);
                return;
            }
            if (preg_match('#^/admin/labels/([1-9][0-9]*)/edit$#D', $path, $match)) {
                $id = (int) $match[1];
                $label = $operations->label($id);
                if ($label === null) {
                    $this->notFound();
                }
                if ($method === 'POST') {
                    $this->saveOperationLabel($operations, $media, $id, $base);
                } elseif ($method === 'GET') {
                    View::render('admin/label-form', $base + array('page_title' => '编辑自定义标签', 'label' => $label, 'media' => self::mediaOptionsForSelection($media, array()), 'error' => null));
                } else {
                    $this->notFound();
                }
                return;
            }
            if ($path === '/admin/labels/values' && $method === 'POST') {
                $this->requireCsrf();
                try {
                    $values = $_POST['values'] ?? null;
                    $valuesEn = $_POST['values_en'] ?? null;
                    $_SESSION['flash'] = '已更新 ' . $operations->saveLabelValues(is_array($values) ? $values : array(), is_array($valuesEn) ? $valuesEn : array()) . ' 个标签。';
                } catch (InvalidArgumentException $exception) {
                    $_SESSION['flash'] = '操作失败：' . $exception->getMessage();
                }
                $this->redirect('/admin/labels');
            }
            if (preg_match('#^/admin/labels/([1-9][0-9]*)/delete$#D', $path, $match) && $method === 'POST') {
                $this->requireCsrf();
                $operations->deleteLabel((int) $match[1]);
                $_SESSION['flash'] = '自定义标签已删除。';
                $this->redirect('/admin/labels');
            }
            $this->notFound();
        }
        $slides = str_starts_with($path, '/admin/slides');
        $prefix = $slides ? '/admin/slides' : '/admin/links';
        $title = $slides ? '轮播图片' : '友情链接';
        if ($path === $prefix && $method === 'GET') {
            View::render('admin/operation-list', $base + array('page_title' => $title, 'kind' => $slides ? 'slide' : 'link', 'items' => $slides ? $operations->slides() : $operations->links()));
            return;
        }
        if ($path === $prefix . '/sort' && $method === 'POST') {
            $this->requireCsrf();
            try {
                $orders = $_POST['sort_order'] ?? null;
                $_SESSION['flash'] = '已保存 ' . $operations->saveSortOrders($slides, is_array($orders) ? $orders : array()) . ' 条排序。';
            } catch (InvalidArgumentException $exception) {
                $_SESSION['flash'] = '操作失败：' . $exception->getMessage();
            }
            $this->redirect($prefix);
        }
        if ($path === $prefix . '/new' && $method === 'GET') {
            View::render('admin/operation-form', $base + array('page_title' => '新建' . $title, 'kind' => $slides ? 'slide' : 'link', 'item' => null, 'media' => $media->all(), 'error' => null));
            return;
        }
        if ($path === $prefix && $method === 'POST') {
            $this->saveOperationItem($operations, $media, $slides, null, $base);
            return;
        }
        if (preg_match('#^' . preg_quote($prefix, '#') . '/([1-9][0-9]*)/edit$#D', $path, $match)) {
            $id = (int) $match[1];
            $item = $slides ? $operations->slide($id) : $operations->friendLink($id);
            if ($item === null) {
                $this->notFound();
            }
            if ($method === 'POST') {
                $this->saveOperationItem($operations, $media, $slides, $id, $base);
            } elseif ($method === 'GET') {
                View::render('admin/operation-form', $base + array('page_title' => '编辑' . $title, 'kind' => $slides ? 'slide' : 'link', 'item' => $item, 'media' => self::operationMediaOptions($media, $item['media_id']), 'error' => null));
            } else {
                $this->notFound();
            }
            return;
        }
        if (preg_match('#^' . preg_quote($prefix, '#') . '/([1-9][0-9]*)/delete$#D', $path, $match) && $method === 'POST') {
            $this->requireCsrf();
            if ($slides) {
                $operations->deleteSlide((int) $match[1]);
            } else {
                $operations->deleteLink((int) $match[1]);
            }
            $_SESSION['flash'] = $title . '已删除。';
            $this->redirect($prefix);
        }
        $this->notFound();
    }

    private function saveOperationItem(OperationsRepository $operations, MediaRepository $media, bool $slides, ?int $id, array $base): void
    {
        $this->requireCsrf();
        $input = array('id' => $id, 'group_id' => self::postString('group_id'), 'media_id' => self::postString('media_id'), 'name' => self::postString('name'), 'title' => self::postString('title'), 'subtitle' => self::postString('subtitle'), 'link' => self::postString('link'), 'sort_order' => self::postString('sort_order'));
        $prefix = $slides ? '/admin/slides' : '/admin/links';
        $title = $slides ? '轮播图' : '友情链接';
        try {
            if ($slides) {
                $operations->saveSlide($id, $input);
            } else {
                $operations->saveLink($id, $input);
            }
            $_SESSION['flash'] = $title . '已保存。';
            $this->redirect($prefix);
        } catch (InvalidArgumentException $exception) {
            $error = $exception->getMessage();
        }
        View::render('admin/operation-form', $base + array('page_title' => ($id === null ? '新建' : '编辑') . $title, 'kind' => $slides ? 'slide' : 'link', 'item' => $input, 'media' => self::operationMediaOptions($media, $input['media_id']), 'error' => $error), 422);
    }

    private static function operationMediaOptions(MediaRepository $media, mixed $selected): array
    {
        return self::mediaOptionsForSelection($media, array($selected));
    }

    /** JSON for the admin image picker: a page of the library, or the images named by ?ids=1,2. */
    private function mediaLibrary(MediaRepository $media, array $can): void
    {
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        if (! ($can['media.manage'] || $can['content.manage'] || $can['taxonomy.manage'] || $can['operations.manage'] || $can['settings.manage'])) {
            http_response_code(403);
            echo json_encode(array('error' => '无权访问媒体库。'), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            return;
        }
        $perPage = 40;
        if (isset($_GET['ids']) && is_string($_GET['ids'])) {
            $ids = array_slice(array_filter(array_map('intval', explode(',', $_GET['ids']))), 0, 60);
            $result = array('total' => 0, 'items' => array_values(array_filter(array_map(static fn (int $id): ?array => $media->byId($id), $ids))));
        } else {
            $result = $media->search(is_string($_GET['q'] ?? null) ? mb_substr($_GET['q'], 0, 100) : '', max(1, (int) ($_GET['page'] ?? 1)), $perPage);
        }
        echo json_encode(array(
            'total' => $result['total'],
            'per_page' => $perPage,
            'items' => array_map(static fn (array $item): array => array('id' => (int) $item['id'], 'path' => (string) $item['path'], 'name' => (string) $item['original_name']), $result['items']),
        ), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    }

    private static function mediaOptionsForSelection(MediaRepository $media, array $selected): array
    {
        $items = $media->all();
        $known = array_fill_keys(array_map('intval', array_column($items, 'id')), true);
        foreach ($selected as $value) {
            if (! is_string($value) && ! is_int($value)) {
                continue;
            }
            $id = filter_var($value, FILTER_VALIDATE_INT, array('options' => array('min_range' => 1)));
            if ($id !== false && ! isset($known[$id])) {
                $older = $media->byId($id);
                if ($older !== null) {
                    array_unshift($items, $older);
                    $known[$id] = true;
                }
            }
        }
        return $items;
    }

    private function saveOperationLabel(OperationsRepository $operations, MediaRepository $media, ?int $id, array $base): void
    {
        $this->requireCsrf();
        $input = array('id' => $id, 'name' => self::postString('name'), 'description' => self::postString('description'), 'type' => self::postString('type') ?: 'text', 'value' => self::postString('value'), 'value_en' => self::postString('value_en'));
        try {
            $operations->saveLabel($id, $input);
            $_SESSION['flash'] = '自定义标签已保存。';
            $this->redirect('/admin/labels');
        } catch (InvalidArgumentException $exception) {
            $error = $exception->getMessage();
        } catch (PDOException $exception) {
            $error = '标签标识已存在。';
        }
        View::render('admin/label-form', $base + array('page_title' => ($id === null ? '新建' : '编辑') . '自定义标签', 'label' => $input, 'media' => self::mediaOptionsForSelection($media, array()), 'error' => $error), 422);
    }

    private function translationAdminRoute(string $path, string $method, TranslationRepository $translations, RegionRepository $regions, array $base): void
    {
        if ($path === '/admin/translations' && $method === 'GET') {
            View::render('admin/translations', $base + array('page_title' => '区域译文', 'items' => $translations->all(), 'regions' => $regions->all(true)));
            return;
        }
        if ($path === '/admin/translations' && $method === 'POST') {
            $this->requireCsrf();
            try {
                $locale = self::postString('locale');
                if (($base['user']['role_slug'] ?? '') !== 'owner') {
                    $translations->saveForLocale(self::postString('entity_type'), self::postString('entity_key'), (string) ($base['locale'] ?? ''), self::postString('field'), self::postString('value'));
                } else {
                    $translations->save(self::postString('entity_type'), self::postString('entity_key'), $locale, self::postString('field'), self::postString('value'));
                }
                $_SESSION['flash'] = '译文已保存。';
                $this->redirect('/admin/translations');
            } catch (Throwable $error) {
                View::render('admin/translations', $base + array('page_title' => '区域译文', 'items' => $translations->all(), 'regions' => $regions->all(true), 'error' => $error->getMessage()), 422);
            }
            return;
        }
        if (preg_match('#^/admin/translations/([^/]+)/([^/]+)/([^/]+)/([^/]+)/delete$#D', $path, $match) && $method === 'POST') {
            $this->requireCsrf();
            if (($base['user']['role_slug'] ?? '') !== 'owner') {
                $translations->deleteForLocale(rawurldecode($match[1]), rawurldecode($match[2]), (string) ($base['locale'] ?? ''), rawurldecode($match[4]));
            } else {
                $translations->delete(rawurldecode($match[1]), rawurldecode($match[2]), rawurldecode($match[3]), rawurldecode($match[4]));
            }
            $_SESSION['flash'] = '译文已删除。';
            $this->redirect('/admin/translations');
            return;
        }
        $this->notFound();
    }

    private function regionAdminRoute(string $path, string $method, RegionRepository $regions, array $base): void
    {
        if ($path === '/admin/regions' && $method === 'GET') {
            View::render('admin/regions', $base + array('page_title' => '数据区域', 'regions' => $regions->all(), 'error' => null));
            return;
        }
        if (preg_match('#^/admin/regions/([^/]+)/toggle$#D', $path, $match) && $method === 'POST') {
            $this->requireCsrf();
            try {
                $regions->setEnabled(rawurldecode($match[1]), self::switchValue());
                $_SESSION['flash'] = '修改成功！';
            } catch (InvalidArgumentException $exception) {
                $_SESSION['flash'] = '操作失败：' . $exception->getMessage();
            }
            $this->redirect('/admin/regions');
        }
        $editing = null;
        if (preg_match('#^/admin/regions/([^/]+)/edit$#D', $path, $match)) {
            $editing = $regions->find(rawurldecode($match[1]));
            if ($editing === null) {
                $this->notFound();
            }
            if ($method === 'GET') {
                View::render('admin/region-form', $base + array('page_title' => '编辑区域', 'region' => $editing, 'regions' => $regions->all(), 'error' => null));
                return;
            }
            if ($method === 'POST') {
                $this->saveRegion($regions, (string) $editing['locale'], $base);
                return;
            }
        }
        if ($path === '/admin/regions/new' && $method === 'GET') {
            View::render('admin/region-form', $base + array('page_title' => '新建区域', 'region' => null, 'regions' => $regions->all(), 'error' => null));
            return;
        }
        if ($path === '/admin/regions' && $method === 'POST') {
            $this->saveRegion($regions, null, $base);
            return;
        }
        if (preg_match('#^/admin/regions/([^/]+)/delete$#D', $path, $match) && $method === 'POST') {
            $this->requireCsrf();
            try {
                $regions->delete(rawurldecode($match[1]));
                $_SESSION['flash'] = '区域已删除。';
            } catch (Throwable $error) {
                $_SESSION['flash'] = '区域删除失败：' . $error->getMessage();
            }
            $this->redirect('/admin/regions');
        }
        $this->notFound();
    }

    private function saveRegion(RegionRepository $regions, ?string $originalLocale, array $base): void
    {
        $this->requireCsrf();
        try {
            $regions->save($originalLocale, self::postString('locale'), self::postString('prefix'), self::postString('name'), self::postString('parent_locale'), self::postString('domain'), self::postString('is_default') === '1', self::postString('is_enabled') !== '0', (int) self::postString('sort_order'));
            $_SESSION['flash'] = '区域已保存。';
            $this->redirect('/admin/regions');
        } catch (Throwable $error) {
            View::render('admin/region-form', $base + array('page_title' => $originalLocale === null ? '新建区域' : '编辑区域', 'region' => $_POST, 'regions' => $regions->all(), 'error' => $error->getMessage()), 422);
        }
    }

    private function apiRoute(string $path, string $method, ContentRepository $repo, TagRepository $tags, FormRepository $forms, CommentRepository $comments, GuestbookRepository $guestbook, OperationsRepository $operations, array $site, ?array $member = null, ?RegionRepository $regions = null, ?TranslationRepository $translations = null, ?MemberSubmissionRepository $submissions = null, ?ContentModelRepository $models = null, ?PageRepository $pages = null, ?PDO $database = null): bool
    {
        if ($method !== 'GET' || (! in_array($path, array('/api/posts', '/api/search', '/api/categories', '/api/pages', '/api/tags', '/api/settings', '/api/labels', '/api/slides', '/api/links', '/api/forms', '/api/messages', '/api/member', '/api/member/comments', '/api/regions', '/api/submissions'), true) && ! preg_match('#^/api/pages/[a-z0-9-]+$#D', $path) && ! preg_match('#^/api/posts/[a-z0-9-]+$#D', $path) && ! preg_match('#^/api/categories/[a-z0-9-]+(?:/[a-z0-9-]+)*$#D', $path) && ! preg_match('#^/api/tags/[a-z0-9-]+$#D', $path) && ! preg_match('#^/api/forms/[a-z0-9-]+$#D', $path) && ! preg_match('#^/api/submissions/[a-z0-9-]+$#D', $path) && ! preg_match('#^/api/posts/[a-z0-9-]+/comments$#D', $path) && ! preg_match('#^/api/region-content/(post|page|category)/[a-z0-9-]+$#D', $path))) {
            return false;
        }
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Content-Language: ' . ($site['locale'] ?? 'zh-CN'));
        header('Cache-Control: public, max-age=60, must-revalidate');
        header('Vary: Accept-Encoding');
        $localizedPost = static function (array $post) use ($translations, $site): array {
            return $translations instanceof TranslationRepository ? $translations->apply('post', $post, (string) ($site['locale'] ?? 'zh-CN')) : $post;
        };
        if (preg_match('#^/api/region-content/(post|page|category)/([a-z0-9-]+)$#D', $path, $match)) {
            $record = (new RegionContentRepository($database ?? throw new \RuntimeException('数据库连接未初始化')))->publishedBySlug((string) ($site['locale'] ?? 'zh-CN'), $match[1], $match[2]);
            if ($record === null) {
                http_response_code(404);
                echo json_encode(array('error' => '区域内容不存在'), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
                return true;
            }
            echo json_encode(array('data' => $record, 'locale' => $site['locale'] ?? 'zh-CN'), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            return true;
        }
        $regionalApi = $database instanceof PDO ? new RegionContentRepository($database) : null;

            if ($path === '/api/regions') {
             $items = $regions instanceof RegionRepository ? $regions->all(true) : array();
            $items = array_map(static fn (array $region): array => array('locale' => (string) $region['locale'], 'prefix' => (string) $region['prefix'], 'name' => (string) $region['name'], 'parent_locale' => (string) ($region['parent_locale'] ?? ''), 'domain' => (string) ($region['domain'] ?? ''), 'is_default' => (int) $region['is_default'], 'sort_order' => (int) $region['sort_order'], 'link' => '/' . rawurlencode((string) $region['prefix']) . '/'), $items);
            echo json_encode(array('data' => $items, 'locale' => $site['locale'] ?? 'zh-CN', 'locale_prefix' => $site['locale_prefix'] ?? '', 'total' => count($items)), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            return true;
        }


        if ($path === '/api/member') {
            header('Cache-Control: private, no-store');
            header('Vary: Accept-Encoding, Cookie');
            if ($member === null) {
                http_response_code(401);
                echo json_encode(array('error' => '需要登录', 'code' => 'member_auth_required'), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
                return true;
            }
            echo json_encode(array('data' => array('id' => (int) $member['id'], 'memberid' => (int) $member['id'], 'email' => (string) $member['email'], 'memberemail' => (string) $member['email'], 'display_name' => (string) $member['display_name'], 'membername' => (string) $member['display_name'], 'memberlogged' => 1, 'status' => (string) $member['status'], 'memberstatus' => (string) $member['status'], 'group_id' => (int) ($member['group_id'] ?? 0), 'membergroupid' => (int) ($member['group_id'] ?? 0), 'created_at' => (string) $member['created_at'])), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            return true;
        }

        if ($path === '/api/submissions' || preg_match('#^/api/submissions/[a-z0-9-]+$#D', $path)) {
            header('Cache-Control: private, no-store');
            header('Vary: Accept-Encoding, Cookie');
            $submissionRepo = $submissions;
            if ($submissionRepo === null) { throw new \RuntimeException('投稿仓储未初始化。'); }
            $groupId = $member['group_id'] ?? null;
            if (preg_match('#^/api/submissions/([a-z0-9-]+)$#D', $path, $sm)) { $row=$submissionRepo->bySlug($sm[1],$member['id']??null,$groupId); if($row===null){http_response_code(404);echo json_encode(array('error'=>'投稿不存在'),JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);return true;} echo json_encode(array('data'=>$row),JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);return true; }
            $rows=$submissionRepo->publicList($member['id']??null,$groupId); echo json_encode(array('data'=>$rows,'total'=>count($rows)),JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR); return true;
        }

        if ($path === '/api/member/comments') {
            header('Cache-Control: private, no-store');
            header('Vary: Accept-Encoding, Cookie');
            if ($member === null) {
                http_response_code(401);
                echo json_encode(array('error' => '需要登录', 'code' => 'member_auth_required'), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
                return true;
            }
            $limit = max(1, min(100, (int) ($_GET['num'] ?? 100)));
            $memberId = (int) $member['id'];
            $items = array_map(static fn (array $comment): array => array('id' => (int) $comment['id'], 'post_id' => (int) $comment['post_id'], 'post_title' => (string) $comment['post_title'], 'post_slug' => (string) $comment['post_slug'], 'content' => (string) $comment['content'], 'status' => (string) $comment['status'], 'created_at' => (int) $comment['created_at']), $comments->forMember($memberId, $limit));
            $total = $comments->countForMember($memberId);
            echo json_encode(array('data' => $items, 'num' => $limit, 'total' => $total, 'total_pages' => (int) ceil($total / $limit)), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            return true;
        }

        if (preg_match('#^/api/posts/([a-z0-9-]+)/comments$#D', $path, $commentMatch)) {
            $post = $repo->publishedPostBySlug($commentMatch[1]);
            if ($post !== null && $post['visibility'] === 'members') {
                header('Cache-Control: private, no-store');
                header('Vary: Accept-Encoding, Cookie');
            }
            if ($post === null || ($database instanceof PDO && self::levelNote($database, $repo, $post, null, $member) !== null) || ($post['visibility'] === 'members' && ($member === null || ! $repo->memberCanAccess((int) $post['id'], (int) ($member['group_id'] ?? 0))))) {
                http_response_code(404);
                echo json_encode(array('error' => '文章不存在'), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
                return true;
            }
            $limit = max(1, min(100, (int) ($_GET['num'] ?? 20)));
            $page = max(1, (int) ($_GET['page'] ?? 1));
            $total = $comments->countApprovedForPost((int) $post['id']);
            echo json_encode(array('data' => $comments->approvedForPost((int) $post['id'], $limit, ($page - 1) * $limit), 'num' => $limit, 'page' => $page, 'total' => $total, 'total_pages' => (int) ceil($total / $limit)), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            return true;
        }

        if (preg_match('#^/api/forms/([a-z0-9-]+)$#D', $path, $formMatch)) {
            $form = $forms->publishedBySlug($formMatch[1]);
            if ($form === null) {
                http_response_code(404);
                echo json_encode(array('error' => '表单不存在'), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
                return true;
            }
            echo json_encode(array('data' => array('id' => (int) $form['id'], 'name' => $form['name'], 'slug' => $form['slug'], 'intro' => $form['intro'], 'fields' => $forms->fields($form), 'link' => View::localizedPath('/form/' . rawurlencode($form['slug'])))), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            return true;
        }
        if ($path === '/api/forms') {
            $publishedForms = array_values(array_filter($forms->all(), static fn (array $form): bool => ($form['status'] ?? '') === 'published'));
            $items = array_map(static fn (array $form): array => array('id' => (int) $form['id'], 'name' => $form['name'], 'slug' => $form['slug'], 'intro' => $form['intro'], 'link' => View::localizedPath('/form/' . rawurlencode($form['slug']))), $publishedForms);
            echo json_encode(array('data' => $items, 'total' => count($publishedForms)), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            return true;
        }

        if ($path === '/api/slides') {
            $slideItems = $operations->slides(1, 200);
            echo json_encode(array('data' => $slideItems, 'total' => count($slideItems)), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            return true;
        }
        if ($path === '/api/links') {
            $linkItems = $operations->links(1, 200);
            echo json_encode(array('data' => $linkItems, 'total' => count($linkItems)), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            return true;
        }

        if ($path === '/api/messages') {
            $limit = max(1, min(100, (int) ($_GET['num'] ?? 20)));
            $totalMessages = $guestbook->count('approved');
            echo json_encode(array('data' => $guestbook->approved($limit), 'num' => $limit, 'total' => $totalMessages, 'total_pages' => (int) ceil($totalMessages / $limit)), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            return true;
        }

        if ($path === '/api/labels') {
            $labelItems = $operations->labelValues((string) ($site['locale'] ?? 'zh-CN'));
            echo json_encode(array('data' => $labelItems, 'items' => $operations->labelApiItems((string) ($site['locale'] ?? 'zh-CN')), 'total' => count($labelItems)), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            return true;
        }

        if ($path === '/api/settings') {
            $apiCompany = $operations->company((string) ($site['locale'] ?? 'zh-CN'));
            if ($translations instanceof TranslationRepository) {
                $apiCompany = $translations->apply('company', array_merge(array('id' => 1), $apiCompany), (string) ($site['locale'] ?? 'zh-CN'));
                unset($apiCompany['id']);
            }
            echo json_encode(array('data' => array('site_name' => $site['site_name'], 'site_description' => $site['site_description'], 'seo_title' => $site['site_seo_title'], 'seo_keywords' => $site['site_seo_keywords'], 'seo_description' => $site['site_seo_description'], 'footer_text' => $site['footer_text'], 'locale' => $site['locale'], 'locale_prefix' => $site['locale_prefix'], 'company' => $site['company'] ?? $apiCompany)), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            return true;
        }

        if ($path === '/api/pages') {
            $items = $pages instanceof PageRepository ? $pages->published() : array();
            if ($regionalApi !== null) $items = $regionalApi->mergePages((string) ($site['locale'] ?? 'zh-CN'), $items);
            $items = array_map(static function (array $page) use ($translations, $site): array {
                if ($translations instanceof TranslationRepository) {
                    $page = $translations->apply('page', $page, (string) ($site['locale'] ?? 'zh-CN'));
                }
                return array('id' => (int) $page['id'], 'title' => (string) $page['title'], 'slug' => (string) $page['slug'], 'link' => View::localizedPath('/page/' . rawurlencode((string) $page['slug'])), 'menu_order' => (int) $page['menu_order']);
            }, $items);
            echo json_encode(array('data' => $items, 'total' => count($items)), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            return true;
        }

        if (preg_match('#^/api/pages/([a-z0-9-]+)$#D', $path, $pageMatch)) {
            $page = $regionalApi?->publishedBySlug((string) ($site['locale'] ?? 'zh-CN'), 'page', $pageMatch[1]);
            if ($page === null) $page = $pages instanceof PageRepository ? $pages->publishedBySlug($pageMatch[1]) : null;
            if ($page === null) {
                http_response_code(404);
                echo json_encode(array('error' => '单页不存在'), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
                return true;
            }
            if ($translations instanceof TranslationRepository) {
                $page = $translations->apply('page', $page, (string) ($site['locale'] ?? 'zh-CN'));
            }
            echo json_encode(array('data' => array('id' => (int) $page['id'], 'title' => (string) $page['title'], 'slug' => (string) $page['slug'], 'body' => (string) $page['body'], 'body_format' => (string) $page['body_format'], 'seo_title' => (string) ($page['seo_title'] ?? ''), 'seo_keywords' => (string) ($page['seo_keywords'] ?? ''), 'seo_description' => (string) ($page['seo_description'] ?? ''), 'menu_order' => (int) $page['menu_order'], 'link' => View::localizedPath('/page/' . rawurlencode((string) $page['slug'])))), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            return true;
        }

        if (preg_match('#^/api/posts/([a-z0-9-]+)$#D', $path, $detailMatch)) {
            $post = $regionalApi?->publishedBySlug((string) ($site['locale'] ?? 'zh-CN'), 'post', $detailMatch[1]);
            if ($post !== null) $post = $regionalApi->asPost($post);
            else $post = $repo->publishedPostBySlug($detailMatch[1]);
            if ($post !== null && $post['visibility'] === 'members') {
                header('Cache-Control: private, no-store');
                header('Vary: Accept-Encoding, Cookie');
            }
            if ($post === null || ($database instanceof PDO && self::levelNote($database, $repo, $post, null, $member) !== null) || ($post['visibility'] === 'members' && ($member === null || ! $repo->memberCanAccess((int) $post['id'], (int) ($member['group_id'] ?? 0))))) {
                http_response_code(404);
                echo json_encode(array('error' => '文章不存在'), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
                return true;
            }
            if ($translations instanceof TranslationRepository) {
                $post = $translations->apply('post', $post, (string) ($site['locale'] ?? 'zh-CN'));
            }
            $english = ($site['locale'] ?? '') === 'en-US';
            $seoKeywords = $english && ($post['seo_keywords_en'] ?? '') !== '' ? $post['seo_keywords_en'] : ($post['seo_keywords'] ?? '');
            $seoDescription = $english && ($post['seo_description_en'] ?? '') !== '' ? $post['seo_description_en'] : ($post['seo_description'] ?? '');
            $postTags = array_map(static function (array $tag) use ($english): array {
                return array('id' => (int) $tag['id'], 'name' => $english && ($tag['name_en'] ?? '') !== '' ? $tag['name_en'] : $tag['name'], 'name_en' => $tag['name_en'] ?? '', 'slug' => $tag['slug'], 'link' => View::localizedPath('/tag/' . rawurlencode($tag['slug'])));
            }, $tags->forPost((int) $post['id']));
            $extraFields = $models instanceof ContentModelRepository ? $models->publicFieldsForPost((int) $post['id'], isset($post['category_id']) ? (int) $post['category_id'] : null) : array();
            echo json_encode(array('data' => array('id' => (int) $post['id'], 'title' => $english && ($post['title_en'] ?? '') !== '' ? $post['title_en'] : $post['title'], 'subtitle' => $english && ($post['subtitle_en'] ?? '') !== '' ? $post['subtitle_en'] : ($post['subtitle'] ?? ''), 'slug' => $post['slug'], 'body' => $english && ($post['body_en'] ?? '') !== '' ? $post['body_en'] : $post['body'], 'body_format' => $post['body_format'] ?? 'plain', 'extra_fields' => $extraFields, 'category' => $english && ($post['category_name_en'] ?? '') !== '' ? $post['category_name_en'] : $post['category_name'], 'category_slug' => $post['category_slug'] ?? '', 'category_link' => View::localizedPath('/category/' . (($post['category_path'] ?? '') !== '' ? $post['category_path'] : rawurlencode((string) ($post['category_slug'] ?? '')))), 'is_link' => trim((string) ($post['outlink'] ?? '')) !== '' ? 1 : 0, 'outlink' => $post['outlink'] ?? '', 'author' => $post['author'] ?? '', 'source' => $post['source'] ?? '', 'seo_keywords' => $seoKeywords, 'seo_description' => $seoDescription, 'tags' => $postTags, 'link' => View::postLink($post), 'published_at' => (int) $post['published_at'], 'created_at' => (int) ($post['created_at'] ?? 0), 'updated_at' => (int) ($post['updated_at'] ?? 0), 'sorting' => (int) ($post['sort_order'] ?? 255), 'cover' => $post['cover_path'] ?? '')), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            return true;
        }

        if (preg_match('#^/api/categories/([a-z0-9-]+(?:/[a-z0-9-]+)*)$#D', $path, $categoryMatch)) {
            $category = $repo->categoryByPath($categoryMatch[1]);
            if ($category === null || (int) ($category['is_visible'] ?? 1) !== 1) {
                http_response_code(404);
                echo json_encode(array('error' => '栏目不存在'), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
                return true;
            }
            if ($translations instanceof TranslationRepository) {
                $category = $translations->apply('category', $category, (string) ($site['locale'] ?? 'zh-CN'));
            }
            $english = ($site['locale'] ?? '') === 'en-US';
            $seoTitle = $english && ($category['seo_title_en'] ?? '') !== '' ? $category['seo_title_en'] : ($category['seo_title'] ?? '');
            $seoKeywords = $english && ($category['seo_keywords_en'] ?? '') !== '' ? $category['seo_keywords_en'] : ($category['seo_keywords'] ?? '');
            $seoDescription = $english && ($category['seo_description_en'] ?? '') !== '' ? $category['seo_description_en'] : ($category['seo_description'] ?? '');
            $postCount = $repo->countPosts('published', (int) $category['id'], false);
            $page = max(1, min(10000, (int) ($_GET['page'] ?? 1)));
            $num = max(1, min(100, (int) ($_GET['num'] ?? 20)));
            $englishPosts = ($site['locale'] ?? '') === 'en-US';
            $categoryPosts = $repo->posts('published', (int) $category['id'], false, null, null, $page, num: $num);
            $categoryTags = $tags->forPosts($categoryPosts);
            $postItems = array_map(static function (array $post) use ($englishPosts, $categoryTags): array {
                $postTags = array_map(static fn (array $tag): array => array('id' => (int) $tag['id'], 'name' => $englishPosts && ($tag['name_en'] ?? '') !== '' ? $tag['name_en'] : $tag['name'], 'slug' => $tag['slug'], 'link' => View::localizedPath('/tag/' . rawurlencode($tag['slug']))), $categoryTags[(int) $post['id']] ?? array());
                return array('id' => (int) $post['id'], 'title' => $englishPosts && ($post['title_en'] ?? '') !== '' ? $post['title_en'] : $post['title'], 'subtitle' => $englishPosts && ($post['subtitle_en'] ?? '') !== '' ? $post['subtitle_en'] : ($post['subtitle'] ?? ''), 'slug' => $post['slug'], 'author' => $post['author'] ?? '', 'source' => $post['source'] ?? '', 'is_link' => trim((string) ($post['outlink'] ?? '')) !== '' ? 1 : 0, 'outlink' => $post['outlink'] ?? '', 'is_top' => (int) ($post['is_top'] ?? 0), 'is_recommended' => (int) ($post['is_recommended'] ?? 0), 'is_headline' => (int) ($post['is_headline'] ?? 0), 'seo_description' => $englishPosts && ($post['seo_description_en'] ?? '') !== '' ? $post['seo_description_en'] : ($post['seo_description'] ?? ''), 'published_at' => (int) $post['published_at'], 'created_at' => (int) ($post['created_at'] ?? 0), 'updated_at' => (int) ($post['updated_at'] ?? 0), 'sorting' => (int) ($post['sort_order'] ?? 255), 'cover' => $post['cover_path'] ?? '', 'tags' => $postTags, 'link' => View::postLink($post));
            }, $categoryPosts);
            $children = array_map(static function (array $child) use ($english, $repo): array {
                return array('id' => (int) $child['id'], 'parent_id' => (int) ($child['parent_id'] ?? 0), 'name' => $english && ($child['name_en'] ?? '') !== '' ? $child['name_en'] : $child['name'], 'slug' => $child['slug'], 'type' => $child['type'], 'seo_title' => $english && ($child['seo_title_en'] ?? '') !== '' ? $child['seo_title_en'] : ($child['seo_title'] ?? ''), 'seo_keywords' => $english && ($child['seo_keywords_en'] ?? '') !== '' ? $child['seo_keywords_en'] : ($child['seo_keywords'] ?? ''), 'seo_description' => $english && ($child['seo_description_en'] ?? '') !== '' ? $child['seo_description_en'] : ($child['seo_description'] ?? ''), 'sorting' => (int) ($child['sort_order'] ?? 0), 'is_link' => trim((string) ($child['outlink'] ?? '')) !== '' ? 1 : 0, 'outlink' => $child['outlink'] ?? '', 'is_parent' => count($repo->childCategories((int) $child['id'])) > 0 ? 1 : 0, 'post_count' => $repo->countPosts('published', (int) $child['id'], false), 'link' => View::categoryLink($child));
            }, array_values(array_filter($repo->childCategories((int) $category['id']), static fn (array $child): bool => (int) ($child['is_visible'] ?? 1) === 1)));
            $ancestors = array_map(static function (array $ancestor) use ($english, $repo): array {
                return array('id' => (int) $ancestor['id'], 'parent_id' => (int) ($ancestor['parent_id'] ?? 0), 'sorting' => (int) ($ancestor['sort_order'] ?? 0), 'is_parent' => count($repo->childCategories((int) $ancestor['id'])) > 0 ? 1 : 0, 'post_count' => $repo->countPosts('published', (int) $ancestor['id'], false), 'name' => $english && ($ancestor['name_en'] ?? '') !== '' ? $ancestor['name_en'] : $ancestor['name'], 'slug' => $ancestor['slug'], 'is_link' => trim((string) ($ancestor['outlink'] ?? '')) !== '' ? 1 : 0, 'outlink' => $ancestor['outlink'] ?? '', 'seo_title' => $english && ($ancestor['seo_title_en'] ?? '') !== '' ? $ancestor['seo_title_en'] : ($ancestor['seo_title'] ?? ''), 'seo_keywords' => $english && ($ancestor['seo_keywords_en'] ?? '') !== '' ? $ancestor['seo_keywords_en'] : ($ancestor['seo_keywords'] ?? ''), 'seo_description' => $english && ($ancestor['seo_description_en'] ?? '') !== '' ? $ancestor['seo_description_en'] : ($ancestor['seo_description'] ?? ''), 'link' => View::categoryLink($ancestor));
            }, $repo->categoryAncestors((int) $category['id']));
            echo json_encode(array('data' => array('id' => (int) $category['id'], 'parent_id' => (int) ($category['parent_id'] ?? 0), 'name' => $english && ($category['name_en'] ?? '') !== '' ? $category['name_en'] : $category['name'], 'slug' => $category['slug'], 'type' => $category['type'], 'sorting' => (int) ($category['sort_order'] ?? 0), 'is_link' => trim((string) ($category['outlink'] ?? '')) !== '' ? 1 : 0, 'outlink' => $category['outlink'] ?? '', 'is_parent' => count($children) > 0 ? 1 : 0, 'post_count' => $postCount, 'ancestors' => $ancestors, 'children' => $children, 'posts' => $postItems, 'seo_title' => $seoTitle, 'seo_keywords' => $seoKeywords, 'seo_description' => $seoDescription, 'link' => View::categoryLink($category)), 'page' => $page, 'num' => $num, 'total' => $postCount, 'total_pages' => (int) ceil($postCount / $num)), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            return true;
        }

        if (preg_match('#^/api/tags/([a-z0-9-]+)$#D', $path, $tagMatch)) {
            $tag = $tags->bySlug($tagMatch[1]);
            if ($tag === null) {
                http_response_code(404);
                echo json_encode(array('error' => '标签不存在'), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
                return true;
            }
            $english = ($site['locale'] ?? '') === 'en-US';
            $page = max(1, min(10000, (int) ($_GET['page'] ?? 1)));
            $num = max(1, min(100, (int) ($_GET['num'] ?? 20)));
            $total = $repo->countPosts('published', null, false, (int) $tag['id']);
            $tagPosts = $repo->posts('published', null, false, (int) $tag['id'], null, $page, num: $num);
            $items = array_map(static function (array $post) use ($english): array {
                return array('id' => (int) $post['id'], 'title' => $english && ($post['title_en'] ?? '') !== '' ? $post['title_en'] : $post['title'], 'slug' => $post['slug'], 'link' => View::postLink($post));
            }, $tagPosts);
            echo json_encode(array('data' => array('id' => (int) $tag['id'], 'name' => $english && ($tag['name_en'] ?? '') !== '' ? $tag['name_en'] : $tag['name'], 'name_en' => $tag['name_en'] ?? '', 'slug' => $tag['slug'], 'post_count' => $total, 'link' => View::localizedPath('/tag/' . rawurlencode($tag['slug'])), 'posts' => $items), 'page' => $page, 'num' => $num, 'total' => $total, 'total_pages' => (int) ceil($total / $num)), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            return true;
        }

        if ($path === '/api/tags') {
            $english = ($site['locale'] ?? '') === 'en-US';
            $allTags = $tags->all();
            $items = array_map(static function (array $tag) use ($english, $repo): array {
                return array('id' => (int) $tag['id'], 'name' => $english && ($tag['name_en'] ?? '') !== '' ? $tag['name_en'] : $tag['name'], 'name_en' => $tag['name_en'] ?? '', 'slug' => $tag['slug'], 'post_count' => $repo->countPosts('published', null, false, (int) $tag['id']), 'link' => View::localizedPath('/tag/' . rawurlencode($tag['slug'])));
            }, $allTags);
            echo json_encode(array('data' => $items, 'total' => count($allTags)), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            return true;
        }

        if ($path === '/api/categories') {
            $rootCategories = $repo->rootCategories();
            if ($regionalApi !== null) $rootCategories = array_values(array_filter($regionalApi->mergeCategories((string) ($site['locale'] ?? 'zh-CN'), $rootCategories), static fn (array $row): bool => ($row['parent_id'] ?? null) === null));
            $items = array_map(static function (array $category) use ($repo, $site): array {
            $children = array_map(static function (array $child) use ($site, $repo): array {
                return array('id' => (int) $child['id'], 'parent_id' => (int) ($child['parent_id'] ?? 0), 'name' => ($site['locale'] ?? '') === 'en-US' && ($child['name_en'] ?? '') !== '' ? $child['name_en'] : $child['name'], 'slug' => $child['slug'], 'type' => $child['type'], 'seo_title' => ($site['locale'] ?? '') === 'en-US' && ($child['seo_title_en'] ?? '') !== '' ? $child['seo_title_en'] : ($child['seo_title'] ?? ''), 'seo_keywords' => ($site['locale'] ?? '') === 'en-US' && ($child['seo_keywords_en'] ?? '') !== '' ? $child['seo_keywords_en'] : ($child['seo_keywords'] ?? ''), 'seo_description' => ($site['locale'] ?? '') === 'en-US' && ($child['seo_description_en'] ?? '') !== '' ? $child['seo_description_en'] : ($child['seo_description'] ?? ''), 'sorting' => (int) ($child['sort_order'] ?? 0), 'is_link' => trim((string) ($child['outlink'] ?? '')) !== '' ? 1 : 0, 'outlink' => $child['outlink'] ?? '', 'is_parent' => count($repo->childCategories((int) $child['id'])) > 0 ? 1 : 0, 'post_count' => $repo->countPosts('published', (int) $child['id'], false), 'link' => View::categoryLink($child));
            }, array_values(array_filter($repo->childCategories((int) $category['id']), static fn (array $child): bool => (int) ($child['is_visible'] ?? 1) === 1)));
                return array('id' => (int) $category['id'], 'parent_id' => (int) ($category['parent_id'] ?? 0), 'name' => ($site['locale'] ?? '') === 'en-US' && ($category['name_en'] ?? '') !== '' ? $category['name_en'] : $category['name'], 'slug' => $category['slug'], 'type' => $category['type'], 'sorting' => (int) ($category['sort_order'] ?? 0), 'is_link' => trim((string) ($category['outlink'] ?? '')) !== '' ? 1 : 0, 'outlink' => $category['outlink'] ?? '', 'is_parent' => count($children) > 0 ? 1 : 0, 'post_count' => $repo->countPosts('published', (int) $category['id'], false), 'children' => $children, 'seo_title' => ($site['locale'] ?? '') === 'en-US' && ($category['seo_title_en'] ?? '') !== '' ? $category['seo_title_en'] : ($category['seo_title'] ?? ''), 'seo_keywords' => ($site['locale'] ?? '') === 'en-US' && ($category['seo_keywords_en'] ?? '') !== '' ? $category['seo_keywords_en'] : ($category['seo_keywords'] ?? ''), 'seo_description' => ($site['locale'] ?? '') === 'en-US' && ($category['seo_description_en'] ?? '') !== '' ? $category['seo_description_en'] : ($category['seo_description'] ?? ''), 'link' => View::categoryLink($category));
            }, $rootCategories);
            echo json_encode(array('data' => $items, 'total' => count($rootCategories)), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            return true;
        }
        $page = max(1, min(10000, (int) ($_GET['page'] ?? 1)));
        $num = max(1, min(100, (int) ($_GET['num'] ?? 20)));
        $categoryId = null;
        $categorySlug = trim((string) ($_GET['category'] ?? ''));
        if ($categorySlug !== '') {
            $category = $repo->categoryByPath($categorySlug);
            if ($category === null || (int) ($category['is_visible'] ?? 1) !== 1) {
                http_response_code(404);
                echo json_encode(array('error' => '栏目不存在'), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
                return true;
            }
            $categoryId = (int) $category['id'];
        }
        $tagId = null;
        $tagSlug = trim((string) ($_GET['tag'] ?? ''));
        if ($tagSlug !== '') {
            $filterTag = $tags->bySlug($tagSlug);
            if ($filterTag === null) {
                http_response_code(404);
                echo json_encode(array('error' => '标签不存在'), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
                return true;
            }
            $tagId = (int) $filterTag['id'];
        }
        $query = $path === '/api/search' ? trim((string) ($_GET['keyword'] ?? $_GET['q'] ?? '')) : null;
        $feature = trim((string) ($_GET['feature'] ?? ''));
        if (! in_array($feature, array('top', 'recommended', 'headline'), true)) {
            $feature = null;
        }
        $total = $repo->countPosts('published', $categoryId, false, $tagId, $query, $feature);
        $rows = $repo->posts('published', $categoryId, false, $tagId, $query, $page, feature: $feature, num: $num);
        if ($regionalApi !== null && ($site['locale'] ?? 'zh-CN') !== 'zh-CN') {
            $allRows = $regionalApi->mergePosts((string) $site['locale'], $repo->posts('published', $categoryId, false, $tagId, $query, 1, feature: $feature, num: 10000));
            $total = count($allRows); $rows = array_slice($allRows, ($page - 1) * $num, $num);
        }
        $bulkTags = $tags->forPosts($rows);
        $bulkFields = $models instanceof ContentModelRepository ? $models->publicFieldsForPosts($rows) : array();
        $items = array_map(static function (array $post) use ($site, $bulkTags, $bulkFields, $localizedPost): array {
            $post = $localizedPost($post);
            $english = ($site['locale'] ?? '') === 'en-US';
            $postTags = array_map(static fn (array $tag): array => array('id' => (int) $tag['id'], 'name' => $english && ($tag['name_en'] ?? '') !== '' ? $tag['name_en'] : $tag['name'], 'name_en' => $tag['name_en'] ?? '', 'slug' => $tag['slug'], 'link' => View::localizedPath('/tag/' . rawurlencode($tag['slug']))), $bulkTags[(int) $post['id']] ?? array());
            return array('id' => (int) $post['id'], 'title' => $english && ($post['title_en'] ?? '') !== '' ? $post['title_en'] : $post['title'], 'subtitle' => $english && ($post['subtitle_en'] ?? '') !== '' ? $post['subtitle_en'] : ($post['subtitle'] ?? ''), 'slug' => $post['slug'], 'category' => $english && ($post['category_name_en'] ?? '') !== '' ? $post['category_name_en'] : $post['category_name'], 'category_slug' => $post['category_slug'] ?? '', 'category_link' => View::localizedPath('/category/' . (($post['category_path'] ?? '') !== '' ? $post['category_path'] : rawurlencode((string) ($post['category_slug'] ?? '')))), 'is_link' => trim((string) ($post['outlink'] ?? '')) !== '' ? 1 : 0, 'outlink' => $post['outlink'] ?? '', 'author' => $post['author'] ?? '', 'source' => $post['source'] ?? '', 'is_link' => trim((string) ($post['outlink'] ?? '')) !== '' ? 1 : 0, 'outlink' => $post['outlink'] ?? '', 'is_top' => (int) ($post['is_top'] ?? 0), 'is_recommended' => (int) ($post['is_recommended'] ?? 0), 'is_headline' => (int) ($post['is_headline'] ?? 0), 'seo_description' => $english && ($post['seo_description_en'] ?? '') !== '' ? $post['seo_description_en'] : ($post['seo_description'] ?? ''), 'seo_keywords' => $english && ($post['seo_keywords_en'] ?? '') !== '' ? $post['seo_keywords_en'] : ($post['seo_keywords'] ?? ''), 'tags' => $postTags, 'link' => View::postLink($post), 'published_at' => (int) $post['published_at'], 'created_at' => (int) ($post['created_at'] ?? 0), 'updated_at' => (int) ($post['updated_at'] ?? 0), 'sorting' => (int) ($post['sort_order'] ?? 255), 'cover' => $post['cover_path'] ?? '', 'extra_fields' => $bulkFields[(int) $post['id']] ?? array());
        }, $rows);
        echo json_encode(array('data' => $items, 'page' => $page, 'num' => $num, 'total' => $total, 'total_pages' => (int) ceil($total / $num), 'keyword' => $query ?? '', 'category' => $categorySlug, 'tag' => $tagSlug, 'feature' => $feature ?? ''), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
        return true;
    }

    private function mediaAdminRoute(string $path, string $method, MediaRepository $media, array $base): void
    {
        if ($path === '/admin/media/editor-upload' && $method === 'POST') {
            $this->requireCsrf();
            header('Content-Type: application/json; charset=utf-8');
            header('X-Content-Type-Options: nosniff');
            try {
                $id = $media->upload(is_array($_FILES['image'] ?? null) ? $_FILES['image'] : array());
                $image = $media->byId($id);
                echo json_encode(array('id' => $id, 'path' => $image['path'], 'name' => $image['original_name']), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            } catch (InvalidArgumentException | \RuntimeException $error) {
                http_response_code(422);
                echo json_encode(array('error' => $error->getMessage()), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            }
            return;
        }
        if ($path === '/admin/media') {
            $error = null;
            if ($method === 'POST') {
                $this->requireCsrf();
                try {
                    $media->upload(is_array($_FILES['image'] ?? null) ? $_FILES['image'] : array());
                    $_SESSION['flash'] = '图片已上传。';
                    $this->redirect('/admin/media');
                } catch (InvalidArgumentException | \RuntimeException $exception) {
                    $error = $exception->getMessage();
                }
            } elseif ($method !== 'GET') {
                $this->notFound();
            }
            View::render('admin/media', $base + array('page_title' => '媒体图片', 'media' => $media->all(), 'error' => $error), $error ? 422 : 200);
            return;
        }
        if (preg_match('#^/admin/media/([1-9][0-9]*)/delete$#D', $path, $match) && $method === 'POST') {
            $this->requireCsrf();
            try {
                $media->delete((int) $match[1]);
                $_SESSION['flash'] = '图片已删除。';
            } catch (InvalidArgumentException $exception) {
                $_SESSION['flash'] = $exception->getMessage();
            }
            $this->redirect('/admin/media');
        }
        $this->notFound();
    }

    private function savePage(PDO $pdo, PageRepository $pages, MediaRepository $media, ?int $id, array $base): void
    {
        $this->requireCsrf();
        $input = array('id' => $id, 'title' => self::postString('title'), 'title_en' => self::postString('title_en'), 'seo_title' => self::postString('seo_title'), 'seo_keywords' => self::postString('seo_keywords'), 'seo_description' => self::postString('seo_description'), 'seo_title_en' => self::postString('seo_title_en'), 'seo_keywords_en' => self::postString('seo_keywords_en'), 'seo_description_en' => self::postString('seo_description_en'), 'slug' => self::postString('slug'), 'body' => self::postString('body'), 'body_en' => self::postString('body_en'), 'body_format' => self::postString('body_format') ?: ($id === null ? 'plain' : ($pages->byId($id)['body_format'] ?? 'plain')), 'status' => self::postString('status'), 'menu_order' => self::postString('menu_order'), 'cover_media_id' => self::postString('cover_media_id'));
        $rawGalleryIds = $_POST['gallery_media_ids'] ?? array();
        $rawGalleryTitles = $_POST['gallery_titles'] ?? array();
        $gallery = array();
        $galleryIds = array();
        $galleryTitles = array();
        $attachments = new AttachmentRepository($pdo, $this->root . '/var');
        $attachment = $id === null ? null : $attachments->forPage($id);
        $uploadFile = is_array($_FILES['attachment'] ?? null) ? $_FILES['attachment'] : array();
        try {
            $order = filter_var($input['menu_order'], FILTER_VALIDATE_INT);
            if ($order === false) {
                throw new InvalidArgumentException('单页排序必须是整数。');
            }
            $coverId = $input['cover_media_id'] === '' ? null : filter_var($input['cover_media_id'], FILTER_VALIDATE_INT, array('options' => array('min_range' => 1)));
            if ($coverId === false) {
                throw new InvalidArgumentException('封面图片无效。');
            }
            if (! is_array($rawGalleryIds) || ! is_array($rawGalleryTitles) || count($rawGalleryIds) !== count($rawGalleryTitles) || count($rawGalleryIds) > 30) {
                throw new InvalidArgumentException('多图数据无效。');
            }
            foreach ($rawGalleryIds as $position => $galleryId) {
                if (! is_string($galleryId) || ! isset($rawGalleryTitles[$position]) || ! is_string($rawGalleryTitles[$position])) {
                    throw new InvalidArgumentException('多图数据无效。');
                }
                if ($galleryId === '' && $rawGalleryTitles[$position] === '') {
                    continue;
                }
                $galleryIds[] = $galleryId;
                $galleryTitles[] = $rawGalleryTitles[$position];
                $image = ctype_digit($galleryId) ? $media->byId((int) $galleryId) : null;
                $gallery[] = array('media_id' => $galleryId, 'title' => $rawGalleryTitles[$position], 'path' => $image['path'] ?? '');
            }
            $hasUpload = $uploadFile !== array() && ($uploadFile['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;
            if ($hasUpload) {
                $attachments->validateUpload($uploadFile);
            }
            $pdo->beginTransaction();
            try {
                $pageId = $pages->save($id, $input['title'], $input['slug'], $input['body'], $input['status'], $order, $input['body_format'], $input['title_en'], $input['body_en'], $input['seo_title'], $input['seo_keywords'], $input['seo_description'], $input['seo_title_en'], $input['seo_keywords_en'], $input['seo_description_en']);
                if (array_key_exists('geo_summary', $_POST)) {
                    (new GeoRepository($pdo))->saveMeta('page', $pageId, self::postString('geo_summary'), self::postString('geo_faq'), self::postString('geo_schema_type'), self::postString('geo_reviewed_by'));
                }
                $media->setCoverForPage($pageId, $coverId);
                $media->setGalleryForPage($pageId, $galleryIds, $galleryTitles);
                $oldFile = null;
                if ($hasUpload) {
                    $oldFile = $attachments->replaceForPage($pageId, $uploadFile);
                } elseif (self::postString('remove_attachment') === '1') {
                    $oldFile = $attachments->removeForPage($pageId);
                }
                $pdo->commit();
            } catch (Throwable $error) {
                $pdo->rollBack();
                throw $error;
            }
            $attachments->deleteFile($oldFile);
            if ($input['status'] === 'published') {
                (new GeoJobs($pdo))->queueUrl('page', $pageId, self::siteOrigin());
            }
            $_SESSION['flash'] = '单页已保存。';
            $this->redirect('/admin/pages');
        } catch (InvalidArgumentException $error) {
            $message = $error->getMessage();
        } catch (PDOException $error) {
            $message = '保存失败，请检查单页别名是否重复。';
        } catch (\RuntimeException $error) {
            $message = $error->getMessage();
        }
        View::render('admin/page-form', $base + array('geo_meta' => self::geoFormInput()) + array('page_title' => $id === null ? '新建单页' : '编辑单页', 'page' => $input, 'media' => self::mediaOptionsForSelection($media, array_merge(array($input['cover_media_id']), array_column($gallery, 'media_id'))), 'gallery' => $gallery, 'attachment' => $attachment, 'error' => $message), 422);
    }

    private function siteRoute(string $path, string $method, PDO $pdo, ContentRepository $repo, TagRepository $tags, PageRepository $pages, array $base): void
    {
        $memberSubmissions = new MemberSubmissionRepository($pdo);
        if ($path === '/submissions' && $method === 'GET') { View::render('site/submissions',$base+array('page_title'=>'会员投稿','submissions'=>$memberSubmissions->publicList($base['member']['id']??null,$base['member']['group_id']??null))); return; }
        if (preg_match('#^/submission/([a-z0-9-]+)$#D',$path,$sm) && $method==='GET') { $row=$memberSubmissions->bySlug($sm[1],$base['member']['id']??null,$base['member']['group_id']??null); if($row===null){$this->notFound();} View::render('site/submission',$base+array('page_title'=>$row['title'],'submission'=>$row)); return; }

        $base['all_categories'] = array_values(array_filter($repo->categories(), static fn (array $row): bool => (int) ($row['is_visible'] ?? 1) === 1 && (($row['type'] ?? 'list') !== 'single' || ($row['single_status'] ?? 'draft') === 'published')));
        $base['categories'] = $base['all_categories'];
        $base['tags'] = $tags->all();
        $base['pages'] = $pages->published();
        $regionalRecords = new RegionContentRepository($pdo);
        $base['all_categories'] = $regionalRecords->mergeCategories((string) ($base['locale'] ?? 'zh-CN'), $base['all_categories']);
        $base['categories'] = $base['all_categories'];
        $base['pages'] = $regionalRecords->mergePages((string) ($base['locale'] ?? 'zh-CN'), $base['pages']);
        $translations = new TranslationRepository($pdo);
        $locale = (string) ($base['locale'] ?? 'zh-CN');
        $base['translation_repository'] = $translations;
        $base['categories'] = array_map(fn (array $row): array => $translations->apply('category', $row, $locale), $base['categories']);
        $base['all_categories'] = array_map(fn (array $row): array => $translations->apply('category', $row, $locale), $base['all_categories']);
        $base['tags'] = array_map(fn (array $row): array => $translations->apply('tag', $row, $locale), $base['tags']);
        $base['pages'] = array_map(fn (array $row): array => $translations->apply('page', $row, $locale), $base['pages']);
        GeoHead::boot($pdo, $locale, self::siteOrigin());
        if ($method === 'GET' && preg_match('#^/([a-f0-9]{32})\.txt$#D', $path, $match) === 1 && $match[1] === (new PbootConfig($pdo))->get('geo_indexnow_key')) {
            header('Content-Type: text/plain; charset=utf-8');
            echo $match[1];
            return;
        }
        if ($method === 'GET' && preg_match('#^/post/([a-z0-9-]+)\.md$#D', $path, $match) === 1) {
            $this->postMarkdown($pdo, $match[1]);
            return;
        }
        if (in_array($method, array('GET', 'POST'), true) && ($pbootSite = PbootSite::forSite($pdo, $this->root, $base)) !== null && $pbootSite->handle($path)) {
            return;
        }
        if ($path === '/message') {
            $guestbook = new GuestbookRepository($pdo);
            $error = null;
            $input = array('name' => $base['member']['display_name'] ?? '', 'email' => $base['member']['email'] ?? '', 'phone' => '', 'content' => '');
            if ($method === 'POST') {
                $this->requireCsrf();
                if (self::postString('website') !== '') {
                    $error = '提交内容无效。';
                } else {
                    $identity = (string) ($_SERVER['REMOTE_ADDR'] ?? '') . '|' . (string) ($base['member']['id'] ?? 'guest');
                    if (! (new RateLimiter($this->root . '/var/rate-limits'))->configuredAllow('guestbook', $identity, 5, 600)) {
                    $error = '提交过于频繁，请稍后再试。';
                } else {
                    $input = array('name' => self::postString('name'), 'email' => self::postString('email'), 'phone' => self::postString('phone'), 'content' => self::postString('content'));
                    try {
                        $pbootConfig = new PbootConfig($pdo);
                        self::assertInteraction($pbootConfig, 'message', $base['member']);
                        $id = $guestbook->create($input['name'], $input['email'], $input['phone'], $input['content'], $base['member']['id'] ?? null);
                        $approved = ! $pbootConfig->on('message_verify');
                        if ($approved) {
                            $guestbook->updateStatus($id, 'approved');
                        }
                        self::notifyInteraction($pbootConfig, 'message', array('联系人' => $input['name'], '邮箱' => $input['email'], '电话' => $input['phone'], '留言内容' => $input['content']), array('site_name' => (string) $base['site_name']));
                        $_SESSION['flash'] = $approved ? '留言已提交。' : '留言已提交，审核通过后显示。';
                        $this->redirect('/message');
                    } catch (InvalidArgumentException $exception) {
                        $error = $exception->getMessage();
                    }
                }
                }
            } elseif ($method !== 'GET') {
                $this->notFound();
            }
            View::render('site/message', $base + array('page_title' => '在线留言', 'messages' => $guestbook->approved(), 'input' => $input, 'error' => $error), $error ? 422 : 200);
            return;
        }
        if (preg_match('#^/form/([a-z0-9-]+)$#D', $path, $match)) {
            $forms = new FormRepository($pdo);
            $form = $forms->publishedBySlug($match[1]);
            if ($form === null) {
                $this->notFound();
            }
            $error = null;
            $input = array();
            if ($method === 'POST') {
                $this->requireCsrf();
                if (self::postString('website') !== '') {
                    $error = '提交内容无效。';
                } else {
                    $identity = (string) ($_SERVER['REMOTE_ADDR'] ?? '') . '|' . (string) ($base['member']['id'] ?? 'guest');
                    if (! (new RateLimiter($this->root . '/var/rate-limits'))->configuredAllow('form-' . $match[1], $identity, 5, 600)) {
                    $error = '提交过于频繁，请稍后再试。';
                } else {
                    $input = $_POST;
                    try {
                        $pbootConfig = new PbootConfig($pdo);
                        self::assertInteraction($pbootConfig, 'form', $base['member']);
                        $forms->submit((int) $form['id'], $_POST, $base['member']['id'] ?? null);
                        $mailFields = array();
                        foreach ($forms->fields($form) as $formField) {
                            $submitted = $_POST[$formField['name'] ?? ''] ?? '';
                            $mailFields[(string) ($formField['label'] ?? $formField['name'] ?? '')] = is_array($submitted) ? implode(',', array_filter($submitted, 'is_string')) : (string) $submitted;
                        }
                        self::notifyInteraction($pbootConfig, 'form', $mailFields, array('site_name' => (string) $base['site_name'], 'form_name' => (string) $form['name']));
                        $_SESSION['flash'] = '表单提交成功，感谢你的反馈。';
                        $this->redirect('/form/' . rawurlencode($form['slug']));
                    } catch (InvalidArgumentException $exception) {
                        $error = $exception->getMessage();
                    }
                }
                }
            } elseif ($method !== 'GET') {
                $this->notFound();
            }
            View::render('site/form', $base + array('page_title' => $form['name'], 'form' => $form, 'fields' => $forms->fields($form), 'input' => $input, 'error' => $error), $error ? 422 : 200);
            return;
        }
        if (preg_match('#^/post/([a-z0-9-]+)/comment$#D', $path, $match)) {
            if ($method !== 'POST') {
                $this->notFound();
            }
            $post = $repo->publishedPostBySlug($match[1]);
            if ($post === null || self::levelNote($pdo, $repo, $post, null, $base['member']) !== null || ($post['visibility'] === 'members' && ($base['member'] === null || ! $repo->memberCanAccess((int) $post['id'], (int) ($base['member']['group_id'] ?? 0))))) {
                $this->notFound();
            }
            $this->requireCsrf();
            $name = self::postString('name') ?: (string) ($base['member']['display_name'] ?? '');
            $email = self::postString('email') ?: (string) ($base['member']['email'] ?? '');
            if (self::postString('website') !== '') {
                $_SESSION['flash'] = '评论内容无效。';
                $this->redirect('/post/' . rawurlencode($post['slug']));
            }
            $identity = (string) ($_SERVER['REMOTE_ADDR'] ?? '') . '|' . (string) ($base['member']['id'] ?? 'guest');
            if (! (new RateLimiter($this->root . '/var/rate-limits'))->configuredAllow('comment-' . $match[1], $identity, 5, 600)) {
                $_SESSION['flash'] = '评论提交过于频繁，请稍后再试。';
                $this->redirect('/post/' . rawurlencode($post['slug']));
            }
            try {
                $pbootConfig = new PbootConfig($pdo);
                self::assertInteraction($pbootConfig, 'comment', $base['member']);
                $comments = new CommentRepository($pdo);
                $commentId = $comments->create((int) $post['id'], $name, $email, self::postString('content'), $base['member']['id'] ?? null);
                $approved = ! $pbootConfig->on('comment_verify');
                if ($approved) {
                    $comments->updateStatus($commentId, 'approved');
                }
                self::notifyInteraction($pbootConfig, 'comment', array('评论内容' => self::postString('content')), array('site_name' => (string) $base['site_name']));
                $_SESSION['flash'] = $approved ? '评论已提交。' : '评论已提交，审核通过后显示。';
            } catch (InvalidArgumentException $error) {
                $_SESSION['flash'] = '操作失败：' . $error->getMessage();
            }
            $this->redirect('/post/' . rawurlencode($post['slug']));
        }
        if ($path === '/rss.xml' && $method === 'GET') {
            $this->rssRoute($pdo, $repo, $tags, $base);
            return;
        }
        if ($path === '/sitemap.xml' && $method === 'GET') {
            $this->sitemapRoute($pdo, $repo, $pages, ($base['member'] ?? null) !== null, (string) ($base['locale'] ?? 'zh-CN'));
            return;
        }
        if ($path === '/llms.txt' && $method === 'GET' && (new PbootConfig($pdo))->on('geo_llms_enabled')) {
            $this->llmsRoute($pdo, $base);
            return;
        }
        if ($path === '/robots.txt' && $method === 'GET') {
            $body = "User-agent: *\nAllow: /\nSitemap: " . self::siteOrigin() . View::localizedPath('/sitemap.xml') . "\n";
            $extraRules = trim((new PbootConfig($pdo))->get('geo_robots_extra'));
            if ($extraRules !== '') {
                $body .= "\n" . str_replace("\r\n", "\n", $extraRules) . "\n";
            }
            header('Content-Type: text/plain; charset=utf-8');
            header('Cache-Control: public, max-age=300');
            header('Vary: Accept-Encoding');
            header('ETag: ' . PageCache::etag($body));
            if (PageCache::matches((string) ($_SERVER['HTTP_IF_NONE_MATCH'] ?? ''), PageCache::etag($body))) {
                http_response_code(304);
                return;
            }
            echo $body;
            return;
        }
        if ($method !== 'GET') {
            $this->notFound();
        }
        if (preg_match('#^/page/([a-z0-9-]+)/attachment$#D', $path, $match)) {
            $page = $pages->publishedBySlug($match[1]);
            if ($page === null) {
                $this->notFound();
            }
            $attachments = new AttachmentRepository($pdo, $this->root . '/var');
            $attachment = $attachments->forPage((int) $page['id']);
            if ($attachment === null) {
                $this->notFound();
            }
            try {
                $attachments->send($attachment);
            } catch (\RuntimeException $error) {
                $this->notFound();
            }
            return;
        }
        if (preg_match('#^/page/([a-z0-9-]+)$#D', $path, $match) && ($base['locale'] ?? 'zh-CN') !== 'zh-CN') {
            $regional = (new RegionContentRepository($pdo))->publishedBySlug((string) $base['locale'], 'page', $match[1]);
            if ($regional !== null) {
                View::render('site/page', $base + array('page_title' => (string) $regional['title'], 'seo_title' => (string) ($regional['seo_title'] ?? ''), 'seo_keywords' => (string) ($regional['seo_keywords'] ?? ''), 'seo_description' => (string) ($regional['seo_description'] ?? ''), 'page' => $regional, 'cover' => null, 'gallery' => array(), 'attachment' => null));
                return;
            }
        }


        if (preg_match('#^/page/([a-z0-9-]+)$#D', $path, $match)) {
            $page = $pages->publishedBySlug($match[1]);
            if ($page === null) {
                $this->notFound();
            }
            $translations = new TranslationRepository($pdo);
            $page = $translations->apply('page', $page, (string) ($base['locale'] ?? 'zh-CN'));
            $media = new MediaRepository($pdo, $this->root . '/public');
            $pageTitle = ($base['locale'] ?? '') === 'en-US' && ($page['title_en'] ?? '') !== '' ? $page['title_en'] : $page['title'];
            $page['title'] = $pageTitle;
            if (($base['locale'] ?? '') === 'en-US' && ($page['body_en'] ?? '') !== '') {
                $page['body'] = $page['body_en'];
            }
            $pageSeoTitle = ($base['locale'] ?? '') === 'en-US' && ($page['seo_title_en'] ?? '') !== '' ? $page['seo_title_en'] : ($page['seo_title'] ?? '');
            $pageSeoKeywords = ($base['locale'] ?? '') === 'en-US' && ($page['seo_keywords_en'] ?? '') !== '' ? $page['seo_keywords_en'] : ($page['seo_keywords'] ?? '');
            $pageSeoDescription = ($base['locale'] ?? '') === 'en-US' && ($page['seo_description_en'] ?? '') !== '' ? $page['seo_description_en'] : ($page['seo_description'] ?? '');
            View::render('site/page', $base + array('page_title' => $pageTitle, 'seo_title' => $pageSeoTitle, 'seo_keywords' => $pageSeoKeywords, 'seo_description' => $pageSeoDescription, 'page' => $page, 'cover' => $media->coverForPage((int) $page['id']), 'gallery' => $media->galleryForPage((int) $page['id']), 'attachment' => (new AttachmentRepository($pdo, $this->root . '/var'))->forPage((int) $page['id'])));
            return;
        }
        if ($path === '/') {
            $members = $base['member'] !== null;
            $allHomePosts = $regionalRecords->mergePosts($locale, $repo->posts('published', null, $members, null, null, 1, num: 10000));
            $totalPages = (int) ceil(count($allHomePosts) / 20);
            $page = self::boundedPage($totalPages);
            $homePosts = array_map(fn (array $row): array => $translations->apply('post', $row, $locale), array_slice($allHomePosts, ($page - 1) * 20, 20));
            $homeCategories = array_map(fn (array $row): array => $translations->apply('category', $row, $locale), array_values(array_filter($base['categories'], static fn (array $row): bool => ($row['parent_id'] ?? null) === null)));
            View::render('site/home', $base + array('page_title' => '首页', 'slides' => (new OperationsRepository($pdo))->slides(1, 20), 'categories' => $homeCategories, 'tags' => $base['tags'], 'posts' => $homePosts, 'page' => $page, 'total_pages' => $totalPages));
            return;
        }
        if (preg_match('#^/category/([a-z0-9-]+(?:/[a-z0-9-]+)*)/files/(ext_[A-Za-z][A-Za-z0-9_]*)$#D', $path, $match)) {
            $category = $repo->categoryByPath($match[1]);
            if ($category === null || $category['type'] !== 'single' || $category['single_status'] !== 'published' || self::levelNote($pdo, $repo, null, (int) $category['id'], $base['member']) !== null) {
                $this->notFound();
            }
            $models = new ContentModelRepository($pdo);
            $field = self::activeFileField($models, (int) $category['id'], $match[2]);
            $attachments = new AttachmentRepository($pdo, $this->root . '/var');
            $file = $field === null ? null : ($attachments->modelFilesForCategory((int) $category['id'])[(int) $field['id']] ?? null);
            if ($file === null) {
                $this->notFound();
            }
            try {
                $attachments->send($file);
            } catch (\RuntimeException $error) {
                $this->notFound();
            }
            return;
        }
        if (preg_match('#^/category/([a-z0-9-]+(?:/[a-z0-9-]+)*)/attachment$#D', $path, $match)) {
            $category = $repo->categoryByPath($match[1]);
            if ($category === null || $category['type'] !== 'single' || $category['single_status'] !== 'published' || self::levelNote($pdo, $repo, null, (int) $category['id'], $base['member']) !== null) {
                $this->notFound();
            }
            $attachments = new AttachmentRepository($pdo, $this->root . '/var');
            $attachment = $attachments->forCategory((int) $category['id']);
            if ($attachment === null) {
                $this->notFound();
            }
            try {
                $attachments->send($attachment);
            } catch (\RuntimeException $error) {
                $this->notFound();
            }
            return;
        }
        if (preg_match('#^/category/([a-z0-9-]+(?:/[a-z0-9-]+)*)$#D', $path, $match)) {
            if ($locale !== 'zh-CN') {
                $regionalCategory = $regionalRecords->publishedBySlug($locale, 'category', basename($match[1]));
                if ($regionalCategory !== null) {
                    $regionalCategory['type'] = $regionalCategory['type'] ?? 'list';
                    $regionalCategory['is_visible'] = 1;
                    $regionalPosts = array_map(fn (array $row): array => $regionalRecords->asPost($row), $regionalRecords->publishedForCategory($locale, (int) ($regionalCategory['source_id'] ?? 0)));
                    $totalPages = (int) ceil(count($regionalPosts) / 20);
                    $page = self::boundedPage($totalPages);
                    View::render('site/category', $base + array('page_title' => $regionalCategory['title'], 'seo_title' => $regionalCategory['seo_title'] ?? '', 'seo_keywords' => $regionalCategory['seo_keywords'] ?? '', 'seo_description' => $regionalCategory['seo_description'] ?? '', 'category' => $regionalCategory, 'breadcrumb' => array(), 'child_categories' => array(), 'filter_fields' => array(), 'filter_params' => array(), 'filter_invalid' => false, 'posts' => array_slice($regionalPosts, ($page - 1) * 20, 20), 'page' => $page, 'total_pages' => $totalPages, 'page_path' => View::localizedPath('/category/' . rawurlencode($match[1])), 'list_template' => '', 'content_template' => ''));
                    return;
                }
            }
            $category = $repo->categoryByPath($match[1]);
            if ($category === null) {
                $this->notFound();
            }
            if (($levelNote = self::levelNote($pdo, $repo, null, (int) $category['id'], $base['member'])) !== null) {
                View::render('member-required', $base + array('page_title' => '会员内容', 'level_note' => $levelNote), 403);
                return;
            }
            $category = $translations->apply('category', $category, $locale);
            if ($category['type'] === 'link') {
                header('Location: ' . $category['outlink'], true, 302);
                exit;
            }
            $media = new MediaRepository($pdo, $this->root . '/public');
            $category['thumbnail_path'] = $media->categoryImage((int) $category['id'], 'thumbnail')['path'] ?? '';
            $category['banner_path'] = $media->categoryImage((int) $category['id'], 'banner')['path'] ?? '';
            if (($base['locale'] ?? '') === 'en-US') {
                if (($category['name_en'] ?? '') !== '') {
                    $category['name'] = $category['name_en'];
                }
                if (($category['seo_title_en'] ?? '') !== '') {
                    $category['seo_title'] = $category['seo_title_en'];
                }
                if (($category['seo_keywords_en'] ?? '') !== '') {
                    $category['seo_keywords'] = $category['seo_keywords_en'];
                }
                if (($category['seo_description_en'] ?? '') !== '') {
                    $category['seo_description'] = $category['seo_description_en'];
                }
            }
            if ($category['type'] === 'single') {
                if ($category['single_status'] !== 'published') {
                    $this->notFound();
                }
                $models = new ContentModelRepository($pdo);
                if (($base['locale'] ?? '') === 'en-US') {
                    if (($category['single_title_en'] ?? '') !== '') {
                        $category['single_title'] = $category['single_title_en'];
                    }
                    if (($category['single_body_en'] ?? '') !== '') {
                        $category['single_body'] = $category['single_body_en'];
                    }
                }
                $data = $base + array('page_title' => $category['single_title'], 'seo_title' => $category['seo_title'], 'seo_keywords' => $category['seo_keywords'], 'seo_description' => $category['seo_description'], 'category' => $category, 'breadcrumb' => $this->localizedBreadcrumb($repo->categoryAncestors((int) $category['id']), (string) ($base['locale'] ?? '')), 'cover' => $media->coverForCategory((int) $category['id']), 'gallery' => $media->galleryForCategory((int) $category['id']), 'attachment' => (new AttachmentRepository($pdo, $this->root . '/var'))->forCategory((int) $category['id']), 'extra_fields' => $models->publicFieldsForSingleCategory((int) $category['id']), 'list_template' => $models->templateForCategory((int) $category['id'], 'list'), 'content_template' => $models->templateForCategory((int) $category['id'], 'content'));
                $pdo->prepare('UPDATE category_settings SET single_visits = single_visits + 1 WHERE category_id = ?')->execute(array((int) $category['id']));
                self::renderPublicTemplate($data['content_template'], 'site/category-single', $data);
                return;
            }
            $members = $base['member'] !== null;
            $filterState = (new ContentModelRepository($pdo))->categoryFilters((int) $category['id'], $_GET);
            $totalPages = $filterState['invalid'] ? 0 : (int) ceil($repo->countPosts('published', (int) $category['id'], $members, fieldFilters: $filterState['filters']) / 20);
            $page = self::boundedPage($totalPages);
            $children = $repo->childCategories((int) $category['id']);
            foreach ($children as &$child) {
                $child['thumbnail_path'] = $media->categoryImage((int) $child['id'], 'thumbnail')['path'] ?? '';
            }
            unset($child);
            $models = new ContentModelRepository($pdo);
            $data = $base + array('page_title' => $category['name'], 'seo_title' => $category['seo_title'], 'seo_keywords' => $category['seo_keywords'], 'seo_description' => $category['seo_description'], 'category' => $category, 'breadcrumb' => $this->localizedBreadcrumb($repo->categoryAncestors((int) $category['id']), (string) ($base['locale'] ?? '')), 'child_categories' => $children, 'filter_fields' => $filterState['fields'], 'filter_params' => $filterState['params'], 'filter_invalid' => $filterState['invalid'], 'posts' => $filterState['invalid'] ? array() : array_map(fn (array $row): array => $translations->apply('post', $row, $locale), $repo->posts('published', (int) $category['id'], $members, null, null, $page, fieldFilters: $filterState['filters'])), 'page' => $page, 'total_pages' => $totalPages, 'page_path' => View::categoryLink($category), 'list_template' => $models->templateForCategory((int) $category['id'], 'list'), 'content_template' => $models->templateForCategory((int) $category['id'], 'content'));
            if ($data['list_template'] !== '') {
                $data['list_extra_fields'] = $models->publicFieldsForPosts($data['posts']);
                $data['list_galleries'] = $media->galleriesForPosts($data['posts']);
                $data['list_tags'] = $tags->forPosts($data['posts']);
            }
            self::renderPublicTemplate($data['list_template'], 'site/category', $data);
            return;
        }
        if (preg_match('#^/tag/([a-z0-9-]+)$#D', $path, $match)) {
            $tag = $translations->apply('tag', $tags->bySlug($match[1]) ?? array(), $locale);
            if ($tag === array()) {
                $this->notFound();
            }
            if (($base['locale'] ?? '') === 'en-US' && ($tag['name_en'] ?? '') !== '') {
                $tag['name'] = $tag['name_en'];
            }
            $members = $base['member'] !== null;
            $totalPages = (int) ceil($repo->countPosts('published', null, $members, (int) $tag['id']) / 20);
            $page = self::boundedPage($totalPages);
            View::render('site/tag', $base + array('page_title' => $tag['name'], 'tag' => $tag, 'posts' => array_map(fn (array $row): array => $translations->apply('post', $row, $locale), $repo->posts('published', null, $members, (int) $tag['id'], null, $page)), 'page' => $page, 'total_pages' => $totalPages));
            return;
        }
        if ($path === '/search') {
            $search = ContentSearch::parse($pdo, $repo, $_GET);
            $members = $base['member'] !== null;
            $canSearch = $search['active'] && ! $search['invalid'];
            $searchPosts = $canSearch ? $regionalRecords->mergePosts($locale, $repo->posts('published', null, $members, null, $search['legacy_query'], 1, search: $search['criteria'], num: 10000)) : array();
            if ($canSearch && $locale !== 'zh-CN' && $search['legacy_query'] !== '') $searchPosts = array_values(array_filter($searchPosts, static fn (array $row): bool => stripos((string) ($row['title'] ?? '') . ' ' . (string) ($row['body'] ?? ''), (string) $search['legacy_query']) !== false));
            $totalPages = $canSearch ? (int) ceil(count($searchPosts) / 20) : 0;
            $page = self::boundedPage($totalPages);
            $this->renderPublicTemplate((string) ($base['search_template'] ?? ''), 'site/search', $base + array('page_title' => '搜索', 'search' => $search, 'search_categories' => $base['categories'], 'posts' => array_map(fn (array $row): array => $translations->apply('post', $row, $locale), array_slice($searchPosts, ($page - 1) * 20, 20)), 'page' => $page, 'total_pages' => $totalPages));
            return;
        }
        if (preg_match('#^/post/([a-z0-9-]+)/files/(ext_[A-Za-z][A-Za-z0-9_]*)$#D', $path, $match)) {
            $post = $repo->publishedPostBySlug($match[1]);
            if ($post === null || self::levelNote($pdo, $repo, $post, null, $base['member']) !== null || ($post['visibility'] === 'members' && ($base['member'] === null || ! $repo->memberCanAccess((int) $post['id'], (int) ($base['member']['group_id'] ?? 0))))) {
                $this->notFound();
            }
            $models = new ContentModelRepository($pdo);
            $field = self::activeFileField($models, $post['category_id'] === null ? null : (int) $post['category_id'], $match[2]);
            $attachments = new AttachmentRepository($pdo, $this->root . '/var');
            $file = $field === null ? null : ($attachments->modelFilesForPost((int) $post['id'])[(int) $field['id']] ?? null);
            if ($file === null) {
                $this->notFound();
            }
            try {
                $attachments->send($file);
            } catch (\RuntimeException $error) {
                $this->notFound();
            }
            return;
        }
        if (preg_match('#^/post/([a-z0-9-]+)/attachment$#D', $path, $match)) {
            $post = $repo->publishedPostBySlug($match[1]);
            if ($post === null || self::levelNote($pdo, $repo, $post, null, $base['member']) !== null || ($post['visibility'] === 'members' && ($base['member'] === null || ! $repo->memberCanAccess((int) $post['id'], (int) ($base['member']['group_id'] ?? 0))))) {
                $this->notFound();
            }
            $attachments = new AttachmentRepository($pdo, $this->root . '/var');
            $attachment = $attachments->forPost((int) $post['id']);
            if ($attachment === null) {
                $this->notFound();
            }
            try {
                $attachments->send($attachment);
            } catch (\RuntimeException $error) {
                $this->notFound();
            }
            return;
        }
        if (preg_match('#^/post/([a-z0-9-]+)$#D', $path, $match) && ($base['locale'] ?? 'zh-CN') !== 'zh-CN') {
            $regional = (new RegionContentRepository($pdo))->publishedBySlug((string) $base['locale'], 'post', $match[1]);
            if ($regional !== null) {
                $regional['body_format'] = 'plain';
                View::render('site/post', $base + array('page_title' => (string) $regional['title'], 'seo_keywords' => (string) ($regional['seo_keywords'] ?? ''), 'seo_description' => (string) ($regional['seo_description'] ?? ''), 'post' => $regional, 'category' => array(), 'gallery' => array(), 'attachment' => null, 'breadcrumb' => array(), 'tags' => array(), 'comments' => array(), 'extra_fields' => array(), 'list_template' => '', 'content_template' => ''));
                return;
            }
        }

        if (preg_match('#^/post/([a-z0-9-]+)$#D', $path, $match)) {
            $post = $repo->publishedPostBySlug($match[1]);
            if ($post === null) {
                $this->notFound();
            }
            $post = $translations->apply('post', $post, $locale);
            if ($post['visibility'] === 'members' && ($base['member'] === null || ! $repo->memberCanAccess((int) $post['id'], (int) ($base['member']['group_id'] ?? 0)))) {
                View::render('member-required', $base + array('page_title' => '会员内容'), 403);
                return;
            }
            if (($levelNote = self::levelNote($pdo, $repo, $post, null, $base['member'])) !== null) {
                View::render('member-required', $base + array('page_title' => '会员内容', 'level_note' => $levelNote), 403);
                return;
            }
            $attachments = new AttachmentRepository($pdo, $this->root . '/var');
            $attachment = $attachments->forPost((int) $post['id']);
            if ($post['outlink'] !== '') {
                header('Location: ' . $post['outlink'], true, 302);
                exit;
            }
            $categoryId = $post['category_id'] === null ? null : (int) $post['category_id'];
            $models = new ContentModelRepository($pdo);
            $category = $categoryId === null ? array() : ($repo->category($categoryId) ?? array());
            if (($base['locale'] ?? '') === 'en-US' && ($category['name_en'] ?? '') !== '') {
                $category['name'] = $category['name_en'];
            }
            $postTitle = ($base['locale'] ?? '') === 'en-US' && ($post['title_en'] ?? '') !== '' ? $post['title_en'] : $post['title'];
            $post['title'] = $postTitle;
            if (($base['locale'] ?? '') === 'en-US' && ($post['subtitle_en'] ?? '') !== '') {
                $post['subtitle'] = $post['subtitle_en'];
            }
            if (($base['locale'] ?? '') === 'en-US' && ($post['body_en'] ?? '') !== '') {
                $post['body'] = $post['body_en'];
            }
            $postSeoKeywords = ($base['locale'] ?? '') === 'en-US' && ($post['seo_keywords_en'] ?? '') !== '' ? $post['seo_keywords_en'] : $post['seo_keywords'];
            $postSeoDescription = ($base['locale'] ?? '') === 'en-US' && ($post['seo_description_en'] ?? '') !== '' ? $post['seo_description_en'] : $post['seo_description'];
            $postTags = array_map(static function (array $tag): array {
                return array('id' => (int) $tag['id'], 'name' => (string) $tag['name'], 'name_en' => (string) ($tag['name_en'] ?? ''), 'slug' => (string) $tag['slug'], 'link' => View::localizedPath('/tag/' . rawurlencode((string) $tag['slug'])));
            }, $tags->forPost((int) $post['id']));

            if (($base['locale'] ?? '') === 'en-US') {
                foreach ($postTags as &$postTag) {
                    if (($postTag['name_en'] ?? '') !== '') {
                        $postTag['name'] = $postTag['name_en'];
                    }
                }
                unset($postTag);
            }
            $data = $base + array('page_title' => $postTitle, 'seo_keywords' => $postSeoKeywords, 'seo_description' => $postSeoDescription, 'post' => $post, 'category' => $category, 'gallery' => (new MediaRepository($pdo, $this->root . '/public'))->galleryForPost((int) $post['id']), 'attachment' => $attachment, 'breadcrumb' => $categoryId === null ? array() : $this->localizedBreadcrumb($repo->categoryAncestors($categoryId), (string) ($base['locale'] ?? '')), 'tags' => $postTags, 'comments' => (new CommentRepository($pdo))->approvedForPost((int) $post['id']), 'extra_fields' => $models->publicFieldsForPost((int) $post['id'], $categoryId), 'list_template' => $models->templateForCategory($categoryId, 'list'), 'content_template' => $models->templateForCategory($categoryId, 'content'));
            self::renderPublicTemplate($data['content_template'], 'site/post', $data);
            return;
        }
        $this->notFound();
    }

    private function rssRoute(PDO $pdo, ContentRepository $repo, TagRepository $tags, array $base): void
    {
        $origin = self::siteOrigin();
        $categoryId = null;
        $categorySlug = isset($_GET['category']) && is_string($_GET['category']) ? trim($_GET['category']) : '';
        if ($categorySlug !== '') {
            $category = $repo->categoryBySlug($categorySlug);
            $categoryId = $category === null ? -1 : (int) $category['id'];
        }
        $tagId = null;
        $tagSlug = isset($_GET['tag']) && is_string($_GET['tag']) ? trim($_GET['tag']) : '';
        if ($tagSlug !== '') {
            $tag = $tags->bySlug($tagSlug);
            $tagId = $tag === null ? -1 : (int) $tag['id'];
        }
        $page = isset($_GET['page']) && is_string($_GET['page']) && ctype_digit($_GET['page']) ? max(1, min(100, (int) $_GET['page'])) : 1;
        $posts = $repo->posts('published', $categoryId, $base['member'] !== null, $tagId, null, 1, num: 10000);
        if (($base['locale'] ?? 'zh-CN') !== 'zh-CN') $posts = (new RegionContentRepository($pdo))->mergePosts((string) $base['locale'], $posts);
        $posts = array_slice($posts, ($page - 1) * 20, 20);
        $privateFeed = ($base['member'] ?? null) !== null;
        header('Cache-Control: ' . ($privateFeed ? 'private, no-store' : 'public, max-age=300'));
        header('Vary: Accept-Encoding' . ($privateFeed ? ', Cookie' : ''));
        header('Content-Type: application/rss+xml; charset=utf-8');
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<rss version="2.0"><channel><title>' . self::xml($base['site_name']) . '</title><link>' . self::xml($origin . View::localizedPath('/')) . '</link><description>' . self::xml($base['site_description']) . '</description>';
        $level = new PageLevel($pdo);
        $categoryRules = array();
        foreach (array_slice($posts, 0, 20) as $post) {
            // Same rule as the post page: the feed carries the full body.
            $ruleKey = (int) ($post['category_id'] ?? 0);
            $categoryRules[$ruleKey] ??= $ruleKey > 0 ? $repo->categoryAccess($ruleKey) : array();
            if ($level->firstDenied(array($categoryRules[$ruleKey], $post), $base['member']) !== null) {
                continue;
            }
            if (isset($base['translation_repository']) && $base['translation_repository'] instanceof TranslationRepository) {
                $post = $base['translation_repository']->apply('post', $post, (string) ($base['locale'] ?? 'zh-CN'));
            }
            $rssTitle = ($base['locale'] ?? '') === 'en-US' && ($post['title_en'] ?? '') !== '' ? $post['title_en'] : $post['title'];
            $rssBody = ($base['locale'] ?? '') === 'en-US' && ($post['body_en'] ?? '') !== '' ? $post['body_en'] : $post['body'];
            $rssCategory = ($base['locale'] ?? '') === 'en-US' && ($post['category_name_en'] ?? '') !== '' ? $post['category_name_en'] : ($post['category_name'] ?? '');
            $url = $origin . View::postLink(array('outlink' => '') + $post);
            $rssDescription = ($base['locale'] ?? '') === 'en-US' && ($post['seo_description_en'] ?? '') !== '' ? $post['seo_description_en'] : ($post['seo_description'] ?? '');
            $xml .= '<item><title>' . self::xml((string) $rssTitle) . '</title><link>' . self::xml($url) . '</link><guid>' . self::xml($url) . '</guid><category>' . self::xml((string) $rssCategory) . '</category><description>' . self::xml((string) ($rssDescription ?: strip_tags((string) $rssBody))) . '</description><pubDate>' . gmdate(DATE_RSS, (int) ($post['published_at'] ?: $post['created_at'])) . '</pubDate></item>';
        }
        $body = $xml . '</channel></rss>';
        header('ETag: ' . PageCache::etag($body));
        if (PageCache::matches((string) ($_SERVER['HTTP_IF_NONE_MATCH'] ?? ''), PageCache::etag($body))) {
            http_response_code(304);
            return;
        }
        echo $body;
    }

    /** Redisplay after a failed save; a malformed FAQ is dropped because the error names the fault. */
    private static function geoFormInput(): array
    {
        $faq = array();
        try {
            $faq = GeoRepository::parseFaq(self::postString('geo_faq'));
        } catch (InvalidArgumentException) {
        }
        return array('summary' => self::postString('geo_summary'), 'faq' => $faq, 'schema_type' => self::postString('geo_schema_type'), 'reviewed_by' => self::postString('geo_reviewed_by'));
    }

    private function geoAdminRoute(string $path, string $method, PDO $pdo, array $base): void
    {
        $repository = new GeoRepository($pdo);
        $jobs = new GeoJobs($pdo);
        if ($method === 'GET' && $path === '/admin/geo') {
            $repository->seedFacts((new OperationsRepository($pdo))->company());
            (new GeoScore($pdo))->refresh();
            $overview = new GeoOverview($pdo, (string) parse_url(self::siteOrigin(), PHP_URL_HOST));
            if (($_GET['audit'] ?? '') === '1') {
                $overview->saveAudit((new GeoAudit($pdo, self::siteOrigin()))->run());
            } else {
                $jobs->run(3, 'push');
            }
            View::render('admin/geo', $base + array('page_title' => 'GEO优化', 'steps' => $overview->steps(), 'audit' => $overview->lastAudit(), 'scores' => (new GeoScore($pdo))->summary(), 'headline' => $overview->headline(), 'facts' => $repository->facts(), 'job_failures' => $jobs->failures()));
            return;
        }
        if ($path === '/admin/geo/facts' && $method === 'GET') {
            $repository->seedFacts((new OperationsRepository($pdo))->company());
            View::render('admin/geo-facts', $base + array('page_title' => 'GEO品牌事实', 'facts' => $repository->facts()));
            return;
        }
        if ($path === '/admin/geo/push' && $method === 'GET') {
            $config = new PbootConfig($pdo);
            View::render('admin/geo-push', $base + array('page_title' => 'GEO收录推送', 'job_stats' => $jobs->stats(), 'job_failures' => $jobs->failures(), 'bots' => GeoBots::summary($pdo), 'queued' => $jobs->queued(), 'overdue' => $jobs->overdue(), 'push_recent' => (new GeoPushLog($pdo))->summary(), 'pusher' => new GeoPusher($pdo), 'config' => $config, 'values' => $config->all(), 'site_origin' => self::siteOrigin()));
            return;
        }
        if ($path === '/admin/geo/push-log' && $method === 'GET') {
            $log = new GeoPushLog($pdo);
            $engine = (string) ($_GET['engine'] ?? '');
            $outcome = (string) ($_GET['outcome'] ?? '');
            $engine = isset(GeoPusher::URL_ENGINES[$engine]) || $engine === 'google' ? $engine : '';
            $outcome = isset(GeoPushLog::OUTCOMES[$outcome]) ? $outcome : '';
            $page = max(1, (int) ($_GET['page'] ?? 1));
            $entries = $log->page($page, 20, $engine, $outcome);
            View::render('admin/geo-push-log', $base + array('page_title' => 'GEO推送记录', 'push_log' => $entries['rows'], 'push_total' => $entries['total'], 'push_page' => $page, 'push_engine' => $engine, 'push_outcome' => $outcome, 'push_recent' => $log->summary(), 'pusher' => new GeoPusher($pdo)));
            return;
        }
        if ($path === '/admin/geo/ai' && $method === 'GET') {
            $config = new PbootConfig($pdo);
            View::render('admin/geo-ai', $base + array('page_title' => 'GEO AI 接口', 'config' => $config, 'ai' => new GeoAi($pdo)));
            return;
        }
        if ($path === '/admin/geo/content' && $method === 'GET') {
            $score = new GeoScore($pdo);
            $score->refresh();
            View::render('admin/geo-content', $base + array('page_title' => 'GEO内容评分', 'rows' => $score->ranking(), 'summary' => $score->summary()));
            return;
        }
        if ($path === '/admin/geo/monitor' && $method === 'GET') {
            $monitor = new GeoMonitor($pdo);
            $ai = new GeoAi($pdo);
            View::render('admin/geo-monitor', $base + array('page_title' => 'GEO效果监控', 'questions' => $monitor->questions(), 'manual_due' => $monitor->manualDue(), 'report' => $monitor->report((string) parse_url(self::siteOrigin(), PHP_URL_HOST)), 'providers' => $ai->configured(), 'ai_used' => $ai->usedToday(), 'ai_limit' => $ai->dailyLimit(), 'samples' => $monitor->recentSamples(), 'brand_hint' => (string) ($base['site_name'] ?? '')));
            return;
        }
        if (preg_match('#^/admin/geo/posts/(\d+)$#D', $path, $match) && $method === 'GET') {
            $this->geoPostPage($pdo, (int) $match[1], $base);
            return;
        }
        if ($method !== 'POST') {
            $this->notFound();
        }
        $this->requireCsrf();
        if ($path === '/admin/geo/ai/models' || $path === '/admin/geo/ai/test') {
            $this->geoAiProbe($path, new GeoAi($pdo));
            return;
        }
        $back = '/admin/geo';
        try {
            if ($path === '/admin/geo/ai') {
                $back = '/admin/geo/ai';
                (new PbootConfig($pdo))->saveTab('t11', $_POST);
                $_SESSION['flash'] = 'AI 接口配置已保存。';
            } elseif ($path === '/admin/geo/push') {
                $back = '/admin/geo/push';
                $config = new PbootConfig($pdo);
                foreach (PbootConfig::GEO_TABS as $tab) {
                    $config->saveTab($tab, $_POST);
                }
                $_SESSION['flash'] = '推送配置已保存。';
            } elseif ($path === '/admin/geo/push-test') {
                $back = '/admin/geo/push-log';
                $_SESSION['flash'] = $this->geoPushTest($pdo, self::postString('engine'));
            } elseif ($path === '/admin/geo/push-all') {
                $back = '/admin/geo/push';
                $_SESSION['flash'] = '已加入 ' . $jobs->queueAll(self::siteOrigin()) . ' 个推送任务，由定时任务或“立即运行任务”执行。';
            } elseif (preg_match('#^/admin/geo/posts/(\\d+)/adopt$#D', $path, $match)) {
                $back = '/admin/geo/posts/' . $match[1];
                $current = $repository->meta('post', (int) $match[1]);
                $repository->saveMeta('post', (int) $match[1], self::postString('geo_summary'), self::postString('geo_faq'), $current['schema_type'], $current['reviewed_by']);
                PageCache::bump($this->root);
                $_SESSION['flash'] = '摘要和 FAQ 已写入内容。';
            } elseif ($path === '/admin/geo/content/score') {
                $_SESSION['flash'] = '已更新 ' . (new GeoScore($pdo))->refresh() . ' 篇内容的评分。';
                $back = '/admin/geo/content';
            } elseif (preg_match('#^/admin/geo/posts/(\d+)/ai$#D', $path, $match)) {
                $this->geoPostPage($pdo, (int) $match[1], $base, true);
                return;
            } elseif (preg_match('#^/admin/geo/posts/(\d+)/record$#D', $path, $match)) {
                $back = '/admin/geo/posts/' . $match[1];
                $near = (new GeoPack($pdo))->record((int) $match[1], self::postString('platform'), self::postString('url'), self::postString('content'), (int) $base['user']['id']);
                $_SESSION['flash'] = $near ? '已记录。注意：内容与 ' . implode('、', $near) . ' 的版本高度相似，建议改写后再发布。' : '发布记录已保存。';
            } elseif ($path === '/admin/geo/questions') {
                $back = '/admin/geo/monitor';
                (new GeoMonitor($pdo))->saveQuestion(self::postString('question'), self::postString('brand_terms'), self::postString('competitor_terms'));
                $_SESSION['flash'] = '问题已保存。';
            } elseif (preg_match('#^/admin/geo/questions/(\d+)/archive$#D', $path, $match)) {
                $back = '/admin/geo/monitor';
                (new GeoMonitor($pdo))->archiveQuestion((int) $match[1]);
                $_SESSION['flash'] = '问题已归档。';
            } elseif ($path === '/admin/geo/samples') {
                $back = '/admin/geo/monitor';
                $monitor = new GeoMonitor($pdo);
                $question = $monitor->question((int) self::postString('question_id'));
                if ($question === null) {
                    throw new InvalidArgumentException('问题不存在。');
                }
                $monitor->record($question, self::postString('platform'), 'manual', self::postString('answer'), array_values(array_filter(array_map('trim', preg_split('/\R/u', self::postString('cited_urls')) ?: array()))), (int) $base['user']['id']);
                $_SESSION['flash'] = 'App 回答已记录。';
            } elseif ($path === '/admin/geo/samples/queue') {
                $back = '/admin/geo/monitor';
                $_SESSION['flash'] = '已加入 ' . (new GeoMonitor($pdo))->queueSamples() . ' 个抽样任务，由定时任务或“立即运行任务”执行。';
            } elseif ($path === '/admin/geo/run') {
                $back = self::postString('back') === '/admin' ? '/admin' : '/admin/geo/push';
                // From the workbench one-click: also wake quota-deferred jobs and try them now.
                $result = self::postString('wake_quota') === '1' ? $jobs->pushDaily(50) : $jobs->run();
                $_SESSION['flash'] = '任务已运行：完成 ' . $result['done'] . '，失败 ' . $result['failed'] . '，待重试 ' . $result['retry'] . '。';
            } elseif ($path === '/admin/geo/facts') {
                $back = '/admin/geo/facts';
                $repository->saveFact(null, self::postString('category'), self::postString('label'), self::postString('value'), self::postString('source_url'));
                $_SESSION['flash'] = '事实已保存，确认后才会对外输出。';
            } elseif (preg_match('#^/admin/geo/facts/(\d+)/(confirm|archive)$#D', $path, $match)) {
                $back = '/admin/geo/facts';
                $match[2] === 'confirm' ? $repository->confirmFact((int) $match[1], (int) $base['user']['id']) : $repository->archiveFact((int) $match[1]);
                PageCache::bump($this->root);
                $_SESSION['flash'] = $match[2] === 'confirm' ? '事实已确认。' : '事实已归档。';
            } else {
                $this->notFound();
            }
        } catch (InvalidArgumentException $error) {
            $_SESSION['flash'] = '操作失败：' . $error->getMessage();
        }
        $this->redirect($back);
    }

    /** Pushes the home page (or the sitemap for Google) right now and says what the engine answered, so a setup can be checked without waiting for the queue. */
    private function geoPushTest(PDO $pdo, string $engine): string
    {
        $pusher = new GeoPusher($pdo);
        $origin = self::siteOrigin();
        if ($engine === 'google' && $pusher->googleReady()) {
            $kind = 'sitemap';
            $url = $origin . '/sitemap.xml';
            $result = $pusher->submitSitemap($origin);
        } elseif (in_array($engine, $pusher->urlEngines(), true)) {
            $kind = 'home';
            $url = $origin . ((new GeoUrl($pdo))->publicPath('home', 0) ?? '/');
            $result = $pusher->send($engine, $origin, $url);
        } else {
            throw new InvalidArgumentException('该渠道还没有配置，请先保存推送配置。');
        }
        (new GeoPushLog($pdo))->record('test', 0, $engine, $kind, 0, $url, $result['ok'] ? 'ok' : ($result['quota'] ? 'quota' : 'failed'), $result['http'], $result['message'], $result['detail'], 1);
        $label = GeoPusher::URL_ENGINES[$engine] ?? 'Google';
        return $label . ($result['ok'] ? '测试推送成功：' : '测试推送失败：') . $result['message'] . '（详情见本页推送记录）';
    }

    private function geoAiProbe(string $path, GeoAi $ai): void
    {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        $provider = self::postString('provider');
        try {
            $data = $path === '/admin/geo/ai/models'
                ? array('models' => $ai->models($provider, self::postString('key'), self::postString('url')))
                : $ai->test($provider, self::postString('model'), self::postString('key'), self::postString('url'));
            echo json_encode(array('ok' => true) + $data, JSON_UNESCAPED_UNICODE);
        } catch (\RuntimeException $error) {
            echo json_encode(array('ok' => false, 'message' => $error->getMessage()), JSON_UNESCAPED_UNICODE);
        }
    }

    private function geoPostPage(PDO $pdo, int $id, array $base, bool $askAi = false): void
    {
        $row = (new ContentRepository($pdo))->post($id);
        if ($row === null) {
            $this->notFound();
        }
        // Drafts can be scored and rewritten; only public posts have an address to share.
        $public = (new GeoUrl($pdo))->publicPosts($id)[0] ?? null;
        $repository = new GeoRepository($pdo);
        $meta = $repository->meta('post', $id);
        $ai = new GeoAi($pdo);
        $provider = $ai->assistant();
        $mode = self::postString('mode');
        $suggestion = null;
        $proposal = null;
        $unverified = array();
        $aiError = null;
        if ($askAi && $provider !== null) {
            $facts = array_map(static fn (array $fact): string => $fact['label'] . '：' . $fact['value'], $repository->facts(null, 'confirmed'));
            try {
                $answer = $ai->chat($provider, GeoPack::prompt($mode, (string) $row['title'], (string) $row['body'], $facts), '你是严谨的内容编辑，只整理已有事实。')['answer'];
                $unverified = GeoPack::unverified($answer, $row['title'] . "\n" . strip_tags((string) $row['body']) . "\n" . implode("\n", $facts));
                if ($mode === 'meta') {
                    $proposal = GeoPack::parseMeta($answer);
                    if ($proposal === null) {
                        $aiError = '模型没有返回可用的摘要和 FAQ，请重试。';
                    }
                } else {
                    $suggestion = $answer;
                }
            } catch (\RuntimeException $error) {
                $aiError = $error->getMessage();
            }
        }
        View::render('admin/geo-post', $base + array('page_title' => 'GEO内容优化', 'post' => $row, 'public' => $public !== null, 'result' => (new GeoScore($pdo))->post($id), 'site_scores' => (new GeoScore($pdo))->summary(), 'meta' => $meta, 'drafts' => $public === null ? array() : GeoPack::drafts((string) $row['title'], (string) $row['body'], $meta, self::siteOrigin() . $public['path']), 'records' => (new GeoPack($pdo))->records($id), 'provider' => $provider === null ? null : GeoAi::PROVIDERS[$provider][0], 'provider_host' => $provider === null ? '' : $ai->endpointHost($provider), 'mode' => $mode, 'suggestion' => $suggestion, 'proposal' => $proposal, 'unverified' => $unverified, 'ai_error' => $aiError));
    }

    private function postMarkdown(PDO $pdo, string $slug): void
    {
        foreach ((new GeoUrl($pdo))->publicPosts() as $post) {
            if ($post['slug'] === $slug) {
                $row = (new ContentRepository($pdo))->post((int) $post['id']);
                $url = self::siteOrigin() . $post['path'];
                header('Content-Type: text/markdown; charset=utf-8');
                header('Link: <' . $url . '>; rel="canonical"');
                header('X-Robots-Tag: noindex');
                echo GeoPack::markdown((string) $row['title'], (string) $row['body'], (new GeoRepository($pdo))->meta('post', (int) $post['id']), $url, (int) $post['lastmod']);
                return;
            }
        }
        $this->notFound();
    }

    private function llmsRoute(PDO $pdo, array $base): void
    {
        $origin = self::siteOrigin();
        $body = '# ' . $base['site_name'] . "\n";
        if (($base['site_description'] ?? '') !== '') {
            $body .= "\n> " . str_replace("\n", ' ', (string) $base['site_description']) . "\n";
        }
        $body .= "\n## 内容\n\n";
        foreach (array_slice((new GeoUrl($pdo, (string) ($base['locale'] ?? 'zh-CN')))->publicPosts(), 0, 100) as $post) {
            $body .= '- [' . str_replace(array('[', ']', "\n"), ' ', (string) $post['title']) . '](' . $origin . $post['path'] . ")\n";
        }
        header('Content-Type: text/plain; charset=utf-8');
        header('Cache-Control: public, max-age=300');
        echo $body;
    }

    private function sitemapRoute(PDO $pdo, ContentRepository $repo, PageRepository $pages, bool $privateFeed = false, string $locale = 'zh-CN'): void
    {
        $origin = self::siteOrigin();
        $index = new GeoUrl($pdo, $locale);
        $posts = $index->publicPosts();
        $urls = array(array('loc' => $origin . View::localizedPath('/'), 'lastmod' => $posts ? max(array_column($posts, 'lastmod')) : null));
        $categoryLastmod = array();
        foreach ($posts as $post) {
            $categoryLastmod[(int) $post['category_id']] = max($categoryLastmod[(int) $post['category_id']] ?? 0, (int) $post['lastmod']);
        }
        foreach ($repo->categories() as $category) {
            if ((int) $category['is_visible'] !== 1 || ($category['type'] ?? 'list') === 'link' || (($category['type'] ?? '') === 'single' && ($category['single_status'] ?? '') !== 'published') || ! $index->categoryIsPublic((int) $category['id'])) {
                continue;
            }
            $urls[] = array('loc' => $origin . $index->categoryPath($category), 'lastmod' => $categoryLastmod[(int) $category['id']] ?? null);
        }
        $regional = new RegionContentRepository($pdo);
        if ($locale !== 'zh-CN') foreach ($regional->published($locale, 'category') as $category) {
            if ((int) ($category['is_visible'] ?? 1) === 1 && ($category['type'] ?? 'list') !== 'link') $urls[] = array('loc' => $origin . View::localizedPath('/category/' . rawurlencode((string) $category['slug'])), 'lastmod' => (int) $category['updated_at']);
        }
        foreach ($regional->mergePages($locale, $pages->published()) as $page) {
            $urls[] = array('loc' => $origin . View::localizedPath('/page/' . rawurlencode((string) $page['slug'])), 'lastmod' => isset($page['updated_at']) ? (int) $page['updated_at'] : null);
        }
        foreach ($posts as $post) {
            $urls[] = array('loc' => $origin . $post['path'], 'lastmod' => (int) $post['lastmod']);
        }
        if ($locale !== 'zh-CN') foreach ($regional->published($locale, 'post') as $post) $urls[] = array('loc' => $origin . View::localizedPath('/post/' . rawurlencode((string) $post['slug'])), 'lastmod' => (int) $post['updated_at']);
        $unique = array();
        foreach ($urls as $url) {
            $known = $unique[(string) $url['loc']] ?? null;
            if ($known === null || (int) $url['lastmod'] > (int) $known['lastmod']) $unique[(string) $url['loc']] = $url;
        }
        $urls = array_values($unique);
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n";
        foreach ($urls as $url) {
            $xml .= '  <url><loc>' . self::xml($url['loc']) . '</loc>';
            if ($url['lastmod'] !== null) {
                $xml .= '<lastmod>' . date('c', (int) $url['lastmod']) . '</lastmod>';
            }
            $xml .= "</url>\n";
        }
        $body = $xml . "</urlset>\n";
        header('Content-Type: application/xml; charset=utf-8');
        header('Cache-Control: ' . ($privateFeed ? 'private, no-store' : 'public, max-age=300'));
        header('Vary: Accept-Encoding' . ($privateFeed ? ', Cookie' : ''));
        header('ETag: ' . PageCache::etag($body));
        if (PageCache::matches((string) ($_SERVER['HTTP_IF_NONE_MATCH'] ?? ''), PageCache::etag($body))) {
            http_response_code(304);
            return;
        }
        echo $body;
    }

    private static function localizedBreadcrumb(array $items, string $locale): array
    {
        if ($locale !== 'en-US') {
            return $items;
        }
        foreach ($items as &$item) {
            if (($item['name_en'] ?? '') !== '') {
                $item['name'] = $item['name_en'];
            }
        }
        unset($item);
        return $items;
    }

    private static function siteOrigin(): string
    {
        $scheme = (! empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = (string) ($_SERVER['HTTP_HOST'] ?? 'localhost');
        return $scheme . '://' . preg_replace('/[^A-Za-z0-9.:-]/', '', $host);
    }

    private static function xml(string $value): string
    {
        return htmlspecialchars($value, ENT_XML1 | ENT_QUOTES, 'UTF-8');
    }

    private static function renderPublicTemplate(string $name, string $fallback, array $data): void
    {
        $forcedDevice = isset($_GET['device']) && is_string($_GET['device']) ? strtolower($_GET['device']) : '';
        $mobile = in_array($forcedDevice, array('mobile', 'tablet'), true) || ($forcedDevice !== 'desktop' && preg_match('/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i', (string) ($_SERVER['HTTP_USER_AGENT'] ?? '')) === 1);
        if ($mobile && ($data['mobile_template'] ?? '') !== '') {
            $name = (string) $data['mobile_template'];
        } elseif ($name === '' && ($data['desktop_template'] ?? '') !== '') {
            $name = (string) $data['desktop_template'];
        }
        if ($name !== '') {
            try {
                View::renderSiteHtml(SiteTemplate::render($name, $data), $data);
                return;
            } catch (InvalidArgumentException $error) {
                error_log('FangdaysCMS site template: ' . $error->getMessage());
            }
        }
        View::render($fallback, $data);
    }

    private function deleteCategoryWithFiles(PDO $pdo, ContentRepository $repo, int $id): void
    {
        $attachments = new AttachmentRepository($pdo, $this->root . '/var');
        $oldFile = $attachments->forCategory($id)['path'] ?? null;
        $modelFiles = array_column($attachments->modelFilesForCategory($id), 'path');
        $repo->deleteCategory($id);
        $attachments->deleteFile($oldFile);
        foreach ($modelFiles as $file) {
            $attachments->deleteFile($file);
        }
    }

    /** PbootCMS ContentSort 批量新增: names separated by commas, one model, templates and status. */
    private function categoryBatchRoute(string $method, PDO $pdo, ContentRepository $repo, array $base): void
    {
        $models = new ContentModelRepository($pdo);
        $error = null;
        if ($method === 'POST') {
            $this->requireCsrf();
            $outline = ContentRepository::parseMenuOutline(self::postString('names'));
            $parentId = self::postString('parent_id') === '' ? null : filter_var(self::postString('parent_id'), FILTER_VALIDATE_INT, array('options' => array('min_range' => 1)));
            $model = ctype_digit(self::postString('model_id')) ? $models->model((int) self::postString('model_id')) : null;
            $templates = SiteTemplate::choices();
            $listTemplate = self::postString('list_template');
            $contentTemplate = self::postString('content_template');
            $modelNames = array_column($models->all(), null, 'name');
            $unknown = array_values(array_unique(array_filter(array_column($outline, 'model'), static fn (string $name): bool => $name !== '' && ! isset($modelNames[$name]))));
            if ($outline === array() || count($outline) > 100) {
                $error = '请输入菜单名称，一行一个（最多 100 个）。';
            } elseif ($unknown !== array()) {
                $error = '没有这个内容模型：' . implode('、', $unknown) . '。';
            } elseif ($parentId === false || ($parentId !== null && $repo->category($parentId) === null)) {
                $error = '请选择有效的父栏目。';
            } elseif ($model === null) {
                $error = '栏目模型必须选择！';
            } elseif (($listTemplate !== '' && ! in_array($listTemplate, $templates, true)) || ($contentTemplate !== '' && ! in_array($contentTemplate, $templates, true))) {
                $error = '请选择现有的 HTML 模板文件。';
            } else {
                $next = (int) $pdo->query('SELECT COALESCE(MAX(id), 0) FROM categories')->fetchColumn() + 1;
                $slugExists = $pdo->prepare('SELECT 1 FROM categories WHERE slug = ?');
                $levels = array($parentId ?: null);
                $pdo->beginTransaction();
                try {
                    foreach ($outline as $node) {
                        // Pboot leaves the URL name empty and addresses the category by its code; FangdaysCMS needs a slug.
                        do {
                            $slug = 'sort' . $next++;
                            $slugExists->execute(array($slug));
                        } while ($slugExists->fetchColumn() !== false);
                        $chosen = $node['model'] === '' ? $model : $modelNames[$node['model']];
                        $categoryId = $repo->saveCategory(null, $node['name'], $slug, 255, $levels[$node['depth']]);
                        $levels[$node['depth'] + 1] = $categoryId;
                        $models->bindCategory($categoryId, (int) $chosen['id']);
                        $repo->saveCategorySettings($categoryId, $chosen['type'] === 'single' ? 'single' : 'list', '', '', '', '', self::postString('status') !== '0', $listTemplate, $contentTemplate);
                    }
                    $pdo->commit();
                    $_SESSION['flash'] = '已新增 ' . count($outline) . ' 个菜单。';
                    $this->redirect('/admin/categories');
                } catch (InvalidArgumentException $exception) {
                    $pdo->rollBack();
                    $error = $exception->getMessage();
                }
            }
        } elseif ($method !== 'GET') {
            $this->notFound();
        }
        View::render('admin/category-batch', $base + array('page_title' => '批量新增菜单', 'parents' => $repo->parentChoices(null), 'models' => $models->all(), 'templates' => SiteTemplate::choices(), 'error' => $error), $error === null ? 200 : 422);
    }

    private function saveCategory(PDO $pdo, ContentRepository $repo, ?int $id, array $base): void
    {
        $this->requireCsrf();
        $current = $id === null ? null : $repo->category($id) + $repo->categoryAccess($id);
        $media = new MediaRepository($pdo, $this->root . '/public');
        $thumbnailId = $id === null ? '' : (string) ($media->categoryImage($id, 'thumbnail')['id'] ?? '');
        $bannerId = $id === null ? '' : (string) ($media->categoryImage($id, 'banner')['id'] ?? '');
        $input = array('name' => self::postString('name'), 'subname' => self::postString('subname'), 'name_en' => self::postString('name_en'), 'slug' => self::postString('slug'), 'sort_order' => self::postString('sort_order'), 'model_id' => self::postString('model_id'), 'parent_id' => self::postString('parent_id'), 'type' => array_key_exists('type', $_POST) ? self::postString('type') : ($current['type'] ?? 'list'), 'is_visible' => array_key_exists('is_visible', $_POST) ? self::postString('is_visible') : (string) ($current['is_visible'] ?? '1'), 'list_template' => array_key_exists('list_template', $_POST) ? self::postString('list_template') : ($current['list_template'] ?? ''), 'content_template' => array_key_exists('content_template', $_POST) ? self::postString('content_template') : ($current['content_template'] ?? ''), 'outlink' => array_key_exists('outlink', $_POST) ? self::postString('outlink') : ($current['outlink'] ?? ''), 'seo_title' => array_key_exists('seo_title', $_POST) ? self::postString('seo_title') : ($current['seo_title'] ?? ''), 'seo_title_en' => array_key_exists('seo_title_en', $_POST) ? self::postString('seo_title_en') : ($current['seo_title_en'] ?? ''), 'seo_keywords_en' => array_key_exists('seo_keywords_en', $_POST) ? self::postString('seo_keywords_en') : ($current['seo_keywords_en'] ?? ''), 'seo_description_en' => array_key_exists('seo_description_en', $_POST) ? self::postString('seo_description_en') : ($current['seo_description_en'] ?? ''), 'seo_keywords' => array_key_exists('seo_keywords', $_POST) ? self::postString('seo_keywords') : ($current['seo_keywords'] ?? ''), 'seo_description' => array_key_exists('seo_description', $_POST) ? self::postString('seo_description') : ($current['seo_description'] ?? ''), 'thumbnail_media_id' => array_key_exists('thumbnail_media_id', $_POST) ? self::postString('thumbnail_media_id') : $thumbnailId, 'banner_media_id' => array_key_exists('banner_media_id', $_POST) ? self::postString('banner_media_id') : $bannerId);
        foreach (array('gcode' => '', 'gtype' => '4', 'gnote' => '', 'def1' => '', 'def2' => '', 'def3' => '') as $name => $default) {
            $input[$name] = array_key_exists($name, $_POST) ? self::postString($name) : (string) ($current[$name] ?? $default);
        }
        try {
            $sortOrder = filter_var($input['sort_order'], FILTER_VALIDATE_INT);
            if ($sortOrder === false) {
                throw new InvalidArgumentException('栏目排序必须是整数。');
            }
            $parentId = $input['parent_id'] === '' ? null : filter_var($input['parent_id'], FILTER_VALIDATE_INT, array('options' => array('min_range' => 1)));
            if ($parentId === false) {
                throw new InvalidArgumentException('请选择有效的上级栏目。');
            }
            $models = new ContentModelRepository($pdo);
            $modelId = $input['model_id'] === '' ? (int) ($input['type'] === 'single' ? $models->defaultSingleModel()['id'] : $models->defaultModel()['id']) : filter_var($input['model_id'], FILTER_VALIDATE_INT, array('options' => array('min_range' => 1)));
            if ($modelId === false) {
                throw new InvalidArgumentException('请选择有效的内容模型。');
            }
            $chosenModel = $models->model($modelId);
            if ($chosenModel === null) {
                throw new InvalidArgumentException('所选内容模型不存在。');
            }
            $sameLegacyBinding = $current !== null && (int) $current['model_id'] === $modelId && $current['type'] === $input['type'];
            if (! $sameLegacyBinding && $input['type'] !== 'link' && $chosenModel['type'] !== 'mixed' && $chosenModel['type'] !== $input['type']) {
                throw new InvalidArgumentException('栏目类型与内容模型类型不匹配。');
            }
            if (! in_array($input['is_visible'], array('0', '1'), true)) {
                throw new InvalidArgumentException('请选择有效的栏目显示状态。');
            }
            $imageIds = array();
            foreach (array('thumbnail_media_id', 'banner_media_id') as $name) {
                $imageIds[$name] = $input[$name] === '' ? null : filter_var($input[$name], FILTER_VALIDATE_INT, array('options' => array('min_range' => 1)));
                if ($imageIds[$name] === false) {
                    throw new InvalidArgumentException('栏目图片无效。');
                }
            }
            $pdo->beginTransaction();
            try {
                $categoryId = $repo->saveCategory($id, $input['name'], $input['slug'], $sortOrder, $parentId, $input['name_en']);
                $models->bindCategory($categoryId, $modelId);
                $repo->saveCategorySettings($categoryId, $input['type'], $input['outlink'], $input['seo_title'], $input['seo_keywords'], $input['seo_description'], $input['is_visible'] === '1', $input['list_template'], $input['content_template'], $input['seo_title_en'], $input['seo_keywords_en'], $input['seo_description_en']);
                $repo->saveCategorySubname($categoryId, $input['subname']);
                $repo->saveCategoryAccess($categoryId, $input['gcode'], $input['gtype'], $input['gnote'], $input['def1'], $input['def2'], $input['def3']);
                $media->setCategoryImage($categoryId, 'thumbnail', $imageIds['thumbnail_media_id']);
                $media->setCategoryImage($categoryId, 'banner', $imageIds['banner_media_id']);
                $pdo->commit();
            } catch (Throwable $error) {
                $pdo->rollBack();
                throw $error;
            }
            (new GeoJobs($pdo))->queueUrl('category', $categoryId, self::siteOrigin());
            $_SESSION['flash'] = '栏目已保存。';
            $this->redirect('/admin/categories');
        } catch (InvalidArgumentException $error) {
            $message = $error->getMessage();
        } catch (PDOException $error) {
            $message = '保存失败，请检查栏目别名是否重复。';
        }
        View::render('admin/category-form', $base + self::accessChoices($pdo) + array('page_title' => $id === null ? '新增菜单' : '修改菜单', 'category' => $input + array('id' => $id), 'parents' => $repo->parentChoices($id), 'models' => (new ContentModelRepository($pdo))->all(), 'templates' => SiteTemplate::choices(), 'media' => self::mediaOptionsForSelection($media, array($input['thumbnail_media_id'], $input['banner_media_id'])), 'error' => $message), 422);
    }

    private function savePost(PDO $pdo, ContentRepository $repo, ?int $id, array $base): void
    {
        $this->requireCsrf();
        $current = $id === null ? null : $repo->post($id);
        $input = array(
            'title' => self::postString('title'),
            'title_en' => self::postString('title_en'),            'slug' => self::postString('slug'),
            'body' => self::postString('body'),
            'body_en' => self::postString('body_en'),            'body_format' => self::postString('body_format') ?: (string) ($current['body_format'] ?? 'plain'),
            'published_at' => array_key_exists('published_at', $_POST) ? self::postString('published_at') : date('Y-m-d\TH:i', (int) ($current['published_at'] ?? time())),
            'sort_order' => array_key_exists('sort_order', $_POST) ? self::postString('sort_order') : (string) ($current['sort_order'] ?? 255),
            'status' => self::postString('status'),
            'category_id' => self::postString('category_id'),
            'visibility' => self::postString('visibility') ?: 'public',
            'sub_category_id' => array_key_exists('sub_category_id', $_POST) ? self::postString('sub_category_id') : (string) ($current['sub_category_id'] ?? '0'),
            'gcode' => array_key_exists('gcode', $_POST) ? self::postString('gcode') : (string) ($current['gcode'] ?? ''),
            'gtype' => array_key_exists('gtype', $_POST) ? self::postString('gtype') : (string) ($current['gtype'] ?? '4'),
            'gnote' => array_key_exists('gnote', $_POST) ? self::postString('gnote') : (string) ($current['gnote'] ?? ''),
            'cover_media_id' => self::postString('cover_media_id'),
            'extra' => $_POST['extra'] ?? array()
        );
        foreach (array('subtitle', 'subtitle_en', 'author', 'source', 'title_color', 'outlink', 'seo_keywords', 'seo_keywords_en', 'seo_description', 'seo_description_en', 'is_top', 'is_recommended', 'is_headline') as $name) {
            $input[$name] = array_key_exists($name, $_POST) ? self::postString($name) : (string) ($current[$name] ?? (str_starts_with($name, 'is_') ? '0' : ''));
        }
        $rawTags = $_POST['tag_ids'] ?? array();
        $selectedTags = is_array($rawTags) ? array_values(array_filter($rawTags, 'is_string')) : array();
        $rawGalleryIds = $_POST['gallery_media_ids'] ?? array();
        $rawGalleryTitles = $_POST['gallery_titles'] ?? array();
        $galleryIds = array();
        $galleryTitles = array();
        $uploadFile = is_array($_FILES['attachment'] ?? null) ? $_FILES['attachment'] : array();
        $newModelFiles = array();
        try {
            if (! is_array($rawGalleryIds) || ! is_array($rawGalleryTitles) || count($rawGalleryIds) !== count($rawGalleryTitles) || count($rawGalleryIds) > 30) {
                throw new InvalidArgumentException('多图数据无效。');
            }
            foreach ($rawGalleryIds as $position => $galleryId) {
                if (! is_string($galleryId) || ! isset($rawGalleryTitles[$position]) || ! is_string($rawGalleryTitles[$position])) {
                    throw new InvalidArgumentException('多图数据无效。');
                }
                if ($galleryId === '' && $rawGalleryTitles[$position] === '') {
                    continue;
                }
                $galleryIds[] = $galleryId;
                $galleryTitles[] = $rawGalleryTitles[$position];
            }
            if (! is_array($rawTags) || count($rawTags) > 30 || array_filter($rawTags, fn ($tag) => ! is_string($tag) || ! ctype_digit($tag))) {
                throw new InvalidArgumentException('文章标签无效。');
            }
            $categoryId = $input['category_id'] === '' ? null : filter_var($input['category_id'], FILTER_VALIDATE_INT);
            if ($categoryId === false || ($categoryId !== null && $categoryId < 1)) {
                throw new InvalidArgumentException('Category is invalid.');
            }
            $coverId = $input['cover_media_id'] === '' ? null : filter_var($input['cover_media_id'], FILTER_VALIDATE_INT, array('options' => array('min_range' => 1)));
            if ($coverId === false) {
                throw new InvalidArgumentException('封面图片无效。');
            }
            if (! is_array($input['extra']) || count($input['extra']) > 100) {
                throw new InvalidArgumentException('扩展字段无效。');
            }
            $publishDate = \DateTimeImmutable::createFromFormat('!Y-m-d\TH:i', $input['published_at']);
            if ($publishDate === false || $publishDate->format('Y-m-d\TH:i') !== $input['published_at']) {
                throw new InvalidArgumentException('发布时间无效。');
            }
            $input['published_at'] = (string) $publishDate->getTimestamp();
            $input['body'] = RichText::clean($input['body'], $input['body_format']);
            $tags = new TagRepository($pdo);
            $media = new MediaRepository($pdo, $this->root . '/public');
            $attachments = new AttachmentRepository($pdo, $this->root . '/var');
            $hasUpload = $uploadFile !== array() && ($uploadFile['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;
            if ($hasUpload) {
                $attachments->validateUpload($uploadFile);
            }
            $models = new ContentModelRepository($pdo);
            $modelFields = $models->fields((int) $models->modelForCategory($categoryId)['id']);
            $modelUploads = self::modelUploadFiles();
            $modelRemovals = $_POST['remove_extra_file'] ?? array();
            $oldFile = null;
            $oldModelFiles = array();
            $pdo->beginTransaction();
            try {
                $postId = $repo->savePost($id, $categoryId, $input['title'], $input['slug'], $input['body'], $input['status'], $input['title_en'], $input['body_en']);
                $repo->savePostMeta($postId, $input);
                $repo->setVisibility($postId, $input['visibility']);
                $tags->setForPost($postId, $rawTags);
                $media->setCover($postId, $coverId);
                $media->setGallery($postId, $galleryIds, $galleryTitles);
                $oldModelFiles = self::syncModelFiles($attachments, false, $postId, $modelFields, $modelUploads, $modelRemovals, $newModelFiles);
                $models->setValuesForPost($postId, $categoryId, $input['extra']);
                if (array_key_exists('geo_summary', $_POST)) {
                    (new GeoRepository($pdo))->saveMeta('post', $postId, self::postString('geo_summary'), self::postString('geo_faq'), self::postString('geo_schema_type'), self::postString('geo_reviewed_by'));
                }
                if ($hasUpload) {
                    $oldFile = $attachments->replace($postId, $uploadFile);
                } elseif (self::postString('remove_attachment') === '1') {
                    $oldFile = $attachments->remove($postId);
                }
                $pdo->commit();
            } catch (Throwable $error) {
                $pdo->rollBack();
                foreach ($newModelFiles as $path) {
                    $attachments->deleteFile($path);
                }
                throw $error;
            }
            $attachments->deleteFile($oldFile);
            foreach ($oldModelFiles as $path) {
                $attachments->deleteFile($path);
            }
            if ($input['status'] === 'published') {
                (new GeoJobs($pdo))->queueContent($postId, $categoryId, self::siteOrigin(), (int) $input['published_at']);
            }
            $_SESSION['flash'] = '文章已保存。';
            $this->redirect('/admin/posts');
        } catch (InvalidArgumentException $error) {
            $message = $error->getMessage();
        } catch (PDOException $error) {
            $message = '保存失败，请检查文章别名是否重复。';
        } catch (\RuntimeException $error) {
            $message = $error->getMessage();
        }
        $media = new MediaRepository($pdo, $this->root . '/public');
        $gallery = array();
        foreach ($galleryIds as $position => $galleryId) {
            $image = ctype_digit((string) $galleryId) ? $media->byId((int) $galleryId) : null;
            $gallery[] = array('media_id' => $galleryId, 'title' => $galleryTitles[$position] ?? '', 'path' => $image['path'] ?? '');
        }
        View::render('admin/post-form', $base + array('geo_meta' => self::geoFormInput()) + self::accessChoices($pdo) + array('all_categories' => $repo->categories()) + self::postModelTab($pdo, null, ctype_digit((string) ($input['category_id'] ?? '')) ? (int) $input['category_id'] : null) + array('page_title' => $id === null ? '新建文章' : '编辑文章', 'post' => $input + array('id' => $id), 'categories' => $repo->categories(), 'tags' => (new TagRepository($pdo))->all(), 'media' => $media->all(), 'gallery' => $gallery, 'attachment' => $id === null ? null : (new AttachmentRepository($pdo, $this->root . '/var'))->forPost($id), 'selected_tags' => $selectedTags, 'extra_values' => is_array($input['extra']) ? $input['extra'] : array(), 'extra_files' => $id === null ? array() : (new AttachmentRepository($pdo, $this->root . '/var'))->modelFilesForPost($id), 'model_form' => self::postModelForm(new ContentModelRepository($pdo), $repo, $input), 'error' => $message), 422);
    }

    private static function activeFileField(ContentModelRepository $models, ?int $categoryId, string $name): ?array
    {
        foreach ($models->fields((int) $models->modelForCategory($categoryId)['id']) as $field) {
            if ($field['name'] === $name && $field['field_type'] === 'file') {
                return $field;
            }
        }
        return null;
    }

    private static function modelUploadFiles(): array
    {
        $raw = $_FILES['extra_file'] ?? array();
        if ($raw === array()) {
            return array();
        }
        if (! is_array($raw) || ! is_array($raw['name'] ?? null) || ! is_array($raw['tmp_name'] ?? null)
            || ! is_array($raw['error'] ?? null) || ! is_array($raw['size'] ?? null) || count($raw['name']) > 100) {
            throw new InvalidArgumentException('扩展附件数据无效。');
        }
        $uploads = array();
        foreach ($raw['name'] as $fieldId => $name) {
            if (! ctype_digit((string) $fieldId) || ! is_string($name)
                || ! is_string($raw['tmp_name'][$fieldId] ?? null)
                || ! is_int($raw['error'][$fieldId] ?? null)
                || ! is_int($raw['size'][$fieldId] ?? null)) {
                throw new InvalidArgumentException('扩展附件数据无效。');
            }
            $uploads[(int) $fieldId] = array('name' => $name, 'tmp_name' => $raw['tmp_name'][$fieldId], 'error' => $raw['error'][$fieldId], 'size' => $raw['size'][$fieldId]);
        }
        return $uploads;
    }

    private static function syncModelFiles(AttachmentRepository $attachments, bool $category, int $ownerId, array $fields, array $uploads, mixed $removals, array &$newPaths): array
    {
        if (! is_array($removals) || count($removals) > 100) {
            throw new InvalidArgumentException('扩展附件操作无效。');
        }
        $allowed = array();
        foreach ($fields as $field) {
            if ($field['field_type'] === 'file') {
                $allowed[(int) $field['id']] = $field;
            }
        }
        foreach (array_keys($uploads + $removals) as $fieldId) {
            if (! ctype_digit((string) $fieldId) || ! isset($allowed[(int) $fieldId])) {
                throw new InvalidArgumentException('扩展附件字段无效。');
            }
        }
        $oldPaths = array();
        foreach ($allowed as $fieldId => $field) {
            $upload = $uploads[$fieldId] ?? null;
            if ($upload !== null && $upload['error'] !== UPLOAD_ERR_NO_FILE) {
                $changed = $attachments->replaceModelFile($category, $ownerId, $fieldId, $upload);
                $newPaths[] = $changed['new'];
                if ($changed['old'] !== null) {
                    $oldPaths[] = $changed['old'];
                }
            } elseif (($removals[$fieldId] ?? '') === '1') {
                $old = $attachments->removeModelFile($category, $ownerId, $fieldId);
                if ($old !== null) {
                    $oldPaths[] = $old;
                }
            }
        }
        return $oldPaths;
    }

    private static function postModelForm(ContentModelRepository $models, ContentRepository $repo, ?array $post): array
    {
        $defaultId = (int) $models->defaultModel()['id'];
        $categoryModels = array();
        foreach ($repo->categories() as $category) {
            $categoryModels[(int) $category['id']] = (int) ($category['model_id'] ?: $defaultId);
        }
        $activeCategory = (int) ($post['category_id'] ?? 0);
        $fields = array();
        foreach ($models->all() as $model) {
            $fields[(int) $model['id']] = $models->fields((int) $model['id']);
        }
        return array('default_id' => $defaultId, 'category_models' => $categoryModels, 'active_id' => $categoryModels[$activeCategory] ?? $defaultId, 'fields' => $fields);
    }

    private function modelAdminRoute(string $path, string $method, PDO $pdo, ContentModelRepository $models, array $base): void
    {
        if ($path === '/admin/fields' && $method === 'GET') {
            $modelId = is_string($_GET['model_id'] ?? null) && ctype_digit($_GET['model_id']) ? (int) $_GET['model_id'] : null;
            View::render('admin/fields', $base + array('page_title' => '模型字段', 'fields' => $models->allFields($modelId), 'models' => $models->all(), 'model_id' => $modelId));
            return;
        }
        if ($path === '/admin/fields/new' && $method === 'GET') {
            View::render('admin/model-field-form', $base + array('page_title' => '扩展字段新增', 'model' => null, 'models' => $models->all(), 'field' => null, 'error' => null));
            return;
        }
        if ($path === '/admin/fields' && $method === 'POST') {
            $model = ctype_digit(self::postString('model_id')) ? $models->model((int) self::postString('model_id')) : null;
            if ($model === null) {
                $this->requireCsrf();
                View::render('admin/model-field-form', $base + array('page_title' => '扩展字段新增', 'model' => null, 'models' => $models->all(), 'field' => null, 'error' => '请选择内容模型。'), 422);
                return;
            }
            $this->saveModelField($models, $model, null, $base);
            return;
        }
        if ($path === '/admin/models' && $method === 'GET') {
            View::render('admin/models', $base + array('page_title' => '内容模型', 'models' => $models->all()));
            return;
        }
        if ($path === '/admin/models/new' && $method === 'GET') {
            View::render('admin/model-form', $base + array('page_title' => '新建模型', 'model' => null, 'fields' => array(), 'templates' => SiteTemplate::choices(), 'error' => null));
            return;
        }
        if ($path === '/admin/models' && $method === 'POST') {
            $this->saveContentModel($models, null, $base);
            return;
        }
        if (preg_match('#^/admin/models/([1-9][0-9]*)/edit$#D', $path, $match)) {
            $id = (int) $match[1];
            $model = $models->model($id);
            if ($model === null) {
                $this->notFound();
            }
            if ($method === 'GET') {
                View::render('admin/model-form', $base + array('page_title' => '编辑模型', 'model' => $model, 'fields' => $models->fields($id), 'templates' => SiteTemplate::choices(), 'error' => null));
            } elseif ($method === 'POST') {
                $this->saveContentModel($models, $id, $base);
            } else {
                $this->notFound();
            }
            return;
        }
        if (preg_match('#^/admin/models/([1-9][0-9]*)/delete$#D', $path, $match) && $method === 'POST') {
            $this->requireCsrf();
            try {
                $attachments = new AttachmentRepository($pdo, $this->root . '/var');
                $modelFiles = array();
                foreach ($models->fields((int) $match[1]) as $field) {
                    foreach ($attachments->modelFilePathsForField((int) $field['id']) as $file) {
                        $modelFiles[] = $file;
                    }
                }
                $models->deleteModel((int) $match[1]);
                foreach ($modelFiles as $file) {
                    $attachments->deleteFile($file);
                }
                $_SESSION['flash'] = '内容模型已删除。';
            } catch (InvalidArgumentException $error) {
                $_SESSION['flash'] = '操作失败：' . $error->getMessage();
            }
            $this->redirect('/admin/models');
        }
        if (preg_match('#^/admin/models/([1-9][0-9]*)/fields/new$#D', $path, $match)) {
            $model = $models->model((int) $match[1]);
            if ($model === null) {
                $this->notFound();
            }
            if ($method === 'GET') {
                View::render('admin/model-field-form', $base + array('page_title' => '新建扩展字段', 'model' => $model, 'field' => null, 'error' => null));
            } elseif ($method === 'POST') {
                $this->saveModelField($models, $model, null, $base);
            } else {
                $this->notFound();
            }
            return;
        }
        if (preg_match('#^/admin/models/([1-9][0-9]*)/fields/([1-9][0-9]*)/edit$#D', $path, $match)) {
            $model = $models->model((int) $match[1]);
            $field = $models->field((int) $match[2]);
            if ($model === null || $field === null || (int) $field['model_id'] !== (int) $model['id']) {
                $this->notFound();
            }
            if ($method === 'GET') {
                View::render('admin/model-field-form', $base + array('page_title' => '编辑扩展字段', 'model' => $model, 'field' => $field, 'error' => null));
            } elseif ($method === 'POST') {
                $this->saveModelField($models, $model, (int) $field['id'], $base);
            } else {
                $this->notFound();
            }
            return;
        }
        if (preg_match('#^/admin/models/([1-9][0-9]*)/fields/([1-9][0-9]*)/delete$#D', $path, $match) && $method === 'POST') {
            $this->requireCsrf();
            try {
                $attachments = new AttachmentRepository($pdo, $this->root . '/var');
                $modelFiles = $attachments->modelFilePathsForField((int) $match[2]);
                $models->deleteField((int) $match[1], (int) $match[2]);
                foreach ($modelFiles as $file) {
                    $attachments->deleteFile($file);
                }
                $_SESSION['flash'] = '扩展字段已删除。';
                if (self::postString('back') === '/admin/fields') {
                    $this->redirect('/admin/fields');
                }
            } catch (InvalidArgumentException $error) {
                $_SESSION['flash'] = '操作失败：' . $error->getMessage();
            }
            $this->redirect('/admin/models/' . (int) $match[1] . '/edit');
        }
        $this->notFound();
    }

    private function saveContentModel(ContentModelRepository $models, ?int $id, array $base): void
    {
        $this->requireCsrf();
        $existing = $id === null ? null : $models->model($id);
        $input = array('id' => $id, 'name' => self::postString('name'), 'slug' => self::postString('slug'), 'type' => array_key_exists('type', $_POST) ? self::postString('type') : ($existing['type'] ?? 'list'), 'list_template' => array_key_exists('list_template', $_POST) ? self::postString('list_template') : ($existing['list_template'] ?? ''), 'content_template' => array_key_exists('content_template', $_POST) ? self::postString('content_template') : ($existing['content_template'] ?? ''));
        try {
            $models->saveModel($id, $input['name'], $input['slug'], $input['type'], $input['list_template'], $input['content_template']);
            $_SESSION['flash'] = '内容模型已保存。';
            $this->redirect('/admin/models');
        } catch (InvalidArgumentException $error) {
            $message = $error->getMessage();
        } catch (PDOException $error) {
            $message = '模型标识已存在。';
        }
        View::render('admin/model-form', $base + array('page_title' => $id === null ? '新建模型' : '编辑模型', 'model' => $input, 'fields' => $id === null ? array() : $models->fields($id), 'templates' => SiteTemplate::choices(), 'error' => $message), 422);
    }

    private function saveModelField(ContentModelRepository $models, array $model, ?int $id, array $base): void
    {
        $this->requireCsrf();
        $input = array('id' => $id, 'model_id' => $model['id'], 'name' => self::postString('name'), 'label' => self::postString('label'), 'field_type' => self::postString('field_type'), 'options_text' => self::postString('options_text'), 'is_required' => isset($_POST['is_required']) ? 1 : 0, 'sort_order' => self::postString('sort_order'));
        try {
            $sortOrder = filter_var($input['sort_order'], FILTER_VALIDATE_INT);
            if ($sortOrder === false) {
                throw new InvalidArgumentException('字段排序必须是整数。');
            }
            $models->saveField($id, (int) $model['id'], $input['name'], $input['label'], $input['field_type'], $input['options_text'], (bool) $input['is_required'], $sortOrder);
            $_SESSION['flash'] = '扩展字段已保存。';
            $this->redirect(self::postString('back') === '/admin/fields' ? '/admin/fields' : '/admin/models/' . (int) $model['id'] . '/edit');
        } catch (InvalidArgumentException $error) {
            $message = $error->getMessage();
        } catch (PDOException $error) {
            $message = '字段标识已存在。';
        }
        View::render('admin/model-field-form', $base + array('page_title' => $id === null ? '新建扩展字段' : '编辑扩展字段', 'model' => $model, 'models' => $models->all(), 'field' => $input, 'error' => $message), 422);
    }

    private function tagAdminRoute(string $path, string $method, TagRepository $tags, array $base): void
    {
        if ($path === '/admin/tags' && $method === 'GET') {
            View::render('admin/tags', $base + array('page_title' => '标签管理', 'tags' => $tags->all()));
            return;
        }
        if ($path === '/admin/tags/new' && $method === 'GET') {
            View::render('admin/tag-form', $base + array('page_title' => '新建标签', 'tag' => null, 'error' => null));
            return;
        }
        if ($path === '/admin/tags' && $method === 'POST') {
            $this->saveTag($tags, null, $base);
            return;
        }
        if (preg_match('#^/admin/tags/([1-9][0-9]*)/edit$#D', $path, $match)) {
            $id = (int) $match[1];
            $tag = $tags->byId($id);
            if ($tag === null) {
                $this->notFound();
            }
            if ($method === 'POST') {
                $this->saveTag($tags, $id, $base);
            } elseif ($method === 'GET') {
                View::render('admin/tag-form', $base + array('page_title' => '编辑标签', 'tag' => $tag, 'error' => null));
            } else {
                $this->notFound();
            }
            return;
        }
        if (preg_match('#^/admin/tags/([1-9][0-9]*)/delete$#D', $path, $match) && $method === 'POST') {
            $this->requireCsrf();
            $tags->delete((int) $match[1]);
            $_SESSION['flash'] = '标签已删除。';
            $this->redirect('/admin/tags');
        }
        $this->notFound();
    }

    private function saveTag(TagRepository $tags, ?int $id, array $base): void
    {
        $this->requireCsrf();
        $input = array('id' => $id, 'name' => self::postString('name'), 'name_en' => self::postString('name_en'), 'slug' => self::postString('slug'));
        try {
            $tags->save($id, $input['name'], $input['slug'], $input['name_en']);
            $_SESSION['flash'] = '标签已保存。';
            $this->redirect('/admin/tags');
        } catch (InvalidArgumentException $error) {
            $message = $error->getMessage();
        } catch (PDOException $error) {
            $message = '标签别名已存在。';
        }
        View::render('admin/tag-form', $base + array('page_title' => $id === null ? '新建标签' : '编辑标签', 'tag' => $input, 'error' => $message), 422);
    }

    private static function deliverMemberToken(string $email, string $type, string $token): void
    {
        if (SmtpMailer::configured()) {
            SmtpMailer::send($email, $type, $token);
            return;
        }
        $directory = getenv('FANGDAYS_TEST_MAIL_DIR');
        if (! is_string($directory) || $directory === '') {
            throw new \RuntimeException('mail transport unavailable');
        }
        if (! is_dir($directory)) {
            mkdir($directory, 0700, true);
        }
        $payload = array('email' => $email, 'type' => $type, 'token' => $token, 'url' => '/member/' . ($type === 'reset' ? 'reset' : 'verify') . '?token=' . rawurlencode($token), 'created_at' => time());
        file_put_contents($directory . '/last.json', json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR), LOCK_EX);
    }

    private function memberRoute(string $path, string $method, PDO $pdo, array $base): void
    {
        $members = new MemberRepository($pdo);
        if ($path === '/member/verify' && $method === 'GET') {
            $memberId = $members->consumeToken((string) ($_GET['token'] ?? ''), 'verify');
            if ($memberId === null) {
                View::render('member/verify', $base + array('page_title' => '邮件验证', 'error' => '验证链接无效或已过期。'), 422);
                return;
            }
            $members->markVerified($memberId);
            $_SESSION['flash'] = '邮箱验证已完成，请登录。';
            $this->redirect(View::localizedPath('/member/login'));
        }
        if ($path === '/member/forgot') {
            $error = null;
            $sent = false;
            if ($method === 'POST') {
                $this->requireCsrf();
                $email = self::postString('email');
                $token = $members->issueToken($email, 'reset', 1800);
                try {
                    if ($token !== null) {
                        self::deliverMemberToken($email, 'reset', $token);
                    }
                    $sent = true;
                } catch (Throwable $exception) {
                    if ($token !== null) {
                        $members->revokeToken($token, 'reset');
                    }
                    $error = '邮件暂时无法发送，请稍后再试。';
                }
            } elseif ($method !== 'GET') {
                $this->notFound();
            }
            View::render('member/forgot', $base + array('page_title' => '找回密码', 'error' => $error, 'sent' => $sent, 'email' => self::postString('email')), $error ? 422 : 200);
            return;
        }
        if ($path === '/member/reset') {
            $token = is_string($_GET['token'] ?? null) ? (string) $_GET['token'] : self::postString('token');
            $error = null;
            if ($method === 'POST') {
                $this->requireCsrf();
                $memberId = $members->consumeToken($token, 'reset');
                try {
                    if ($memberId === null) {
                        throw new InvalidArgumentException('找回密码链接无效或已过期。');
                    }
                    $members->resetPassword($memberId, self::postString('password'));
                    $_SESSION['flash'] = '密码已重置，请登录。';
                    $this->redirect(View::localizedPath('/member/login'));
                } catch (InvalidArgumentException $exception) {
                    $error = $exception->getMessage();
                }
            } elseif ($method !== 'GET') {
                $this->notFound();
            }
            View::render('member/reset', $base + array('page_title' => '重置密码', 'error' => $error, 'token' => $token), $error ? 422 : 200);
            return;
        }
        if ($path === '/member/logout' && $method === 'POST') {
            $this->requireCsrf();
            Auth::memberLogout();
            $this->redirect(View::localizedPath('/'));
        }
        if ($path === '/member/register') {
            if ($base['member'] !== null) {
                $this->redirect(View::localizedPath('/member/profile'));
            }
            $error = null;
            if ($method === 'POST') {
                $this->requireCsrf();
                $email = self::postString('email');
                $identity = (string) ($_SERVER['REMOTE_ADDR'] ?? '') . '|' . strtolower($email);
                $limited = ! (new RateLimiter($this->root . '/var/rate-limits'))->configuredAllow('member-register', $identity, 5, 600);
                try {
                    if ($limited) {
                        throw new InvalidArgumentException('注册尝试次数过多，请稍后再试。');
                    }
                    if (! (new PbootConfig($pdo))->on('register_status')) {
                        throw new InvalidArgumentException('系统已经关闭注册功能，请到后台开启再试！');
                    }
                    if (($captchaError = Captcha::error('register', self::postString('checkcode'))) !== null) {
                        throw new InvalidArgumentException($captchaError);
                    }
                    $id = $members->register($email, self::postString('display_name'), self::postString('password'), $_POST);
                    $verificationToken = $members->issueToken($email, 'verify', 86400);
                    try {
                        if ($verificationToken !== null) {
                            self::deliverMemberToken($email, 'verify', $verificationToken);
                        }
                    } catch (Throwable $exception) {
                        if ($verificationToken !== null) {
                            $members->revokeToken($verificationToken, 'verify');
                        }
                        throw new InvalidArgumentException('邮件暂时无法发送，请稍后再试。');
                    }
                    session_regenerate_id(true);
                    $_SESSION['member_id'] = $id;
                    $this->redirect(View::localizedPath('/member/profile'));
                } catch (InvalidArgumentException $exception) {
                    $error = $exception->getMessage();
                } catch (PDOException $exception) {
                    $error = '该邮箱已注册。';
                }
            } elseif ($method !== 'GET') {
                $this->notFound();
            }
            View::render('member/register', $base + array('page_title' => '会员注册', 'error' => $error, 'email' => self::postString('email'), 'display_name' => self::postString('display_name'), 'fields' => (new MemberFieldRepository($pdo))->all(true)), $error ? 422 : 200);
            return;
        }
        if ($path === '/member/login') {
            if ($base['member'] !== null) {
                $this->redirect(View::localizedPath('/member/profile'));
            }
            $error = null;
            if ($method === 'POST') {
                $this->requireCsrf();
                $email = self::postString('email');
                $identity = (string) ($_SERVER['REMOTE_ADDR'] ?? '') . '|' . strtolower($email);
                $limited = ! (new RateLimiter($this->root . '/var/rate-limits'))->configuredAllow('member-login', $identity, 10, 300);
                if (! (new PbootConfig($pdo))->on('login_status')) {
                    $error = '系统已经关闭登录功能，请到后台开启再试！';
                } elseif (($error = Captcha::error('login', self::postString('checkcode'))) === null) {
                    if (! $limited && Auth::memberLogin($pdo, $email, self::postString('password'))) {
                        $this->redirect(View::localizedPath('/member/profile'));
                    }
                    $error = '邮箱或密码错误，账号已停用，或尝试次数过多。';
                }
            } elseif ($method !== 'GET') {
                $this->notFound();
            }
            View::render('member/login', $base + array('page_title' => '会员登录', 'error' => $error), $error ? 422 : 200);
            return;
        }
        if ($path === '/member/submissions' || str_starts_with($path, '/member/submissions/')) {
            if ($base['member'] === null) { $this->redirect(View::localizedPath('/member/login')); }
            $submissionRepo = new MemberSubmissionRepository($pdo); $memberId=(int)$base['member']['id'];
            if ($path === '/member/submissions' && $method === 'GET') { View::render('member/submissions',$base+array('page_title'=>'我的投稿','submissions'=>$submissionRepo->forMember($memberId))); return; }
            if ($path === '/member/submissions/new' && $method === 'GET') { View::render('member/submission-form',$base+array('page_title'=>'新建投稿','submission'=>null,'error'=>null)); return; }
            if (($path === '/member/submissions' || preg_match('#^/member/submissions/([1-9][0-9]*)/edit$#D',$path,$match)) && $method === 'POST') { $this->requireCsrf(); $id=isset($match[1])?(int)$match[1]:null; try { $submissionRepo->save($id,$memberId,self::postString('title'),self::postString('body'),(in_array(self::postString('status')?:'pending',array('draft','pending'),true)?(self::postString('status')?:'pending'):throw new InvalidArgumentException('会员投稿只能保存为草稿或待审。')),self::postString('access_group_id')!==''?(int)self::postString('access_group_id'):null); $_SESSION['flash']='投稿已保存，等待审核。'; $this->redirect('/member/submissions'); } catch (InvalidArgumentException $e) { View::render('member/submission-form',$base+array('page_title'=>$id===null?'新建投稿':'编辑投稿','submission'=>$_POST,'error'=>$e->getMessage()),422); } return; }
            if (preg_match('#^/member/submissions/([1-9][0-9]*)/delete$#D',$path,$m) && $method==='POST') { $this->requireCsrf(); $submissionRepo->delete((int)$m[1],$memberId); $this->redirect('/member/submissions'); }
        }

        if ($path === '/member/comments') {
            if ($base['member'] === null) {
                $this->redirect(View::localizedPath('/member/login'));
            }
            if ($method !== 'GET') {
                $this->notFound();
            }
            View::render('member/comments', $base + array('page_title' => '我的评论', 'comments' => (new CommentRepository($pdo))->forMember((int) $base['member']['id'])));
            return;
        }
        if ($path === '/member/profile') {
            if ($base['member'] === null) {
                $this->redirect(View::localizedPath('/member/login'));
            }
            $error = null;
            if ($method === 'POST') {
                $this->requireCsrf();
                try {
                    $members->updateProfile((int) $base['member']['id'], self::postString('display_name'), $_POST);
                    $_SESSION['flash'] = '资料已更新。';
                    $this->redirect(View::localizedPath('/member/profile'));
                } catch (InvalidArgumentException $exception) {
                    $error = $exception->getMessage();
                }
            } elseif ($method !== 'GET') {
                $this->notFound();
            }
            View::render('member/profile', $base + array('page_title' => '会员中心', 'error' => $error, 'member' => $members->byId((int) $base['member']['id']), 'fields' => (new MemberFieldRepository($pdo))->values((int) $base['member']['id'])), $error ? 422 : 200);
            return;
        }
        if ($path === '/member/password' && $method === 'POST') {
            if ($base['member'] === null) {
                $this->redirect(View::localizedPath('/member/login'));
            }
            $this->requireCsrf();
            try {
                $members->changePassword((int) $base['member']['id'], self::postString('current_password'), self::postString('new_password'));
                $_SESSION['flash'] = '密码已更新。';
                $this->redirect(View::localizedPath('/member/profile'));
            } catch (InvalidArgumentException $error) {
                View::render('member/profile', $base + array('page_title' => '会员中心', 'error' => $error->getMessage()), 422);
                return;
            }
        }
        $this->notFound();
    }

    private function memberAdminRoute(string $path, string $method, PDO $pdo, MemberRepository $members, array $base): void
    {
        $fields = new MemberFieldRepository($pdo);
        $submissions = new MemberSubmissionRepository($pdo);
        if ($path === '/admin/members/fields' && $method === 'GET') {
            $editing = is_string($_GET['edit'] ?? null) && ctype_digit($_GET['edit']) ? $fields->byId((int) $_GET['edit']) : null;
            View::render('admin/member-fields', $base + array('page_title' => '会员字段', 'fields' => $fields->all(), 'editing' => $editing, 'error' => null));
            return;
        }
        if ($path === '/admin/members/fields' && $method === 'POST') { $this->requireCsrf(); try { $fields->save(null, $_POST); $_SESSION['flash']='会员字段已创建。'; $this->redirect('/admin/members/fields'); } catch (InvalidArgumentException $e) { View::render('admin/member-fields',$base+array('page_title'=>'会员字段','fields'=>$fields->all(),'editing'=>null,'error'=>$e->getMessage()),422); } return; }
        if (preg_match('#^/admin/members/fields/([1-9][0-9]*)/edit$#D',$path,$m) && $method==='POST') { $this->requireCsrf(); try { $fields->save((int)$m[1],$_POST); $_SESSION['flash']='会员字段已更新。'; } catch (InvalidArgumentException $e) { $_SESSION['flash']=$e->getMessage(); } $this->redirect('/admin/members/fields'); }
        if (preg_match('#^/admin/members/fields/([1-9][0-9]*)/toggle$#D', $path, $m) && $method === 'POST') {
            $this->requireCsrf();
            $pdo->prepare('UPDATE member_fields SET status = ? WHERE id = ?')->execute(array(self::switchValue() ? 'active' : 'disabled', (int) $m[1]));
            $_SESSION['flash'] = '修改成功！';
            $this->redirect('/admin/members/fields');
        }
        if (preg_match('#^/admin/members/fields/([1-9][0-9]*)/delete$#D',$path,$m) && $method==='POST') { $this->requireCsrf(); $fields->delete((int)$m[1]); $_SESSION['flash']='会员字段已删除。'; $this->redirect('/admin/members/fields'); }
        if ($path === '/admin/submissions' && $method === 'GET') { View::render('admin/submissions',$base+array('page_title'=>'会员投稿审核','submissions'=>$submissions->all($_GET['status']??null))); return; }
        if (preg_match('#^/admin/submissions/([1-9][0-9]*)/status$#D',$path,$m) && $method==='POST') { $this->requireCsrf(); $submissions->review((int)$m[1],self::postString('status')); $this->redirect('/admin/submissions'); }
        if (preg_match('#^/admin/submissions/([1-9][0-9]*)/delete$#D',$path,$m) && $method==='POST') { $this->requireCsrf(); $submissions->delete((int)$m[1]); $this->redirect('/admin/submissions'); }
        if ($path === '/admin/members' && $method === 'GET') {
            $keyword = is_string($_GET['q'] ?? null) ? mb_substr(trim($_GET['q']), 0, 100) : '';
            View::render('admin/members', $base + array('page_title' => '会员管理', 'members' => $members->adminList($keyword), 'keyword' => $keyword));
            return;
        }
        if ($path === '/admin/members/new' || ($path === '/admin/members' && $method === 'POST') || preg_match('#^/admin/members/([1-9][0-9]*)/edit$#D', $path, $match)) {
            $id = isset($match[1]) ? (int) $match[1] : null;
            $row = $id === null ? null : $members->adminRow($id);
            if ($id !== null && $row === null) {
                $this->notFound();
            }
            $error = null;
            if ($method === 'POST') {
                $this->requireCsrf();
                try {
                    $members->adminSave($id, $_POST + array('fields' => $_POST));
                    $_SESSION['flash'] = '会员已保存。';
                    $this->redirect('/admin/members');
                } catch (InvalidArgumentException $exception) {
                    $error = $exception->getMessage();
                }
                $row = array('id' => $id) + array_intersect_key($_POST, array_flip(array('username', 'email', 'mobile', 'display_name', 'headpic', 'score', 'status', 'group_id')));
            } elseif ($method !== 'GET') {
                $this->notFound();
            }
            $values = $id === null ? array() : array_column($fields->values($id), 'value', 'name');
            View::render('admin/member-form', $base + array('page_title' => $id === null ? '会员新增' : '会员修改', 'account' => $row, 'groups' => $pdo->query('SELECT id, code, name FROM member_groups ORDER BY code, id')->fetchAll(), 'member_fields' => $fields->all(true), 'field_values' => $error === null ? $values : $_POST, 'error' => $error), $error === null ? 200 : 422);
            return;
        }
        if (preg_match('#^/admin/members/([1-9][0-9]*)/delete$#D', $path, $match) && $method === 'POST') {
            $this->requireCsrf();
            $members->delete((int) $match[1]);
            $_SESSION['flash'] = '会员已删除。';
            $this->redirect('/admin/members');
        }
        if (preg_match('#^/admin/members/([1-9][0-9]*)/status$#D', $path, $match) && $method === 'POST') {
            $this->requireCsrf();
            $id = (int) $match[1];
            if ($members->byId($id) === null) {
                $this->notFound();
            }
            $members->setStatus($id, self::postString('status'));
            $_SESSION['flash'] = '会员状态已更新。';
            $this->redirect('/admin/members');
        }
        $this->notFound();
    }

    private function accessAdminRoute(string $path, string $method, AccessRepository $access, array $base): void
    {
        if ($path === '/admin/profile') {
            $error = null;
            $profile = $base['user'];
            if ($method === 'POST') {
                $this->requireCsrf();
                try {
                    $access->updateProfile((int) $base['user']['id'], self::postString('display_name'), self::postString('email'));
                    $_SESSION['flash'] = '个人资料已保存。';
                    $this->redirect('/admin/profile');
                } catch (InvalidArgumentException | PDOException $exception) {
                    $error = $exception->getMessage();
                }
            } elseif ($method !== 'GET') {
                $this->notFound();
            }
            View::render('admin/profile', $base + array('page_title' => '个人资料', 'profile' => $profile, 'error' => $error), $error ? 422 : 200);
            return;
        }
        if (str_starts_with($path, '/admin/menu')) {
            $menus = new MenuRepository($access->pdo());
            if ($path === '/admin/menu' && $method === 'GET') {
                View::render('admin/menus', $base + array('page_title' => '后台菜单', 'menus' => $menus->all(), 'error' => null));
                return;
            }
            if ($path === '/admin/menu' && $method === 'POST') {
                $this->requireCsrf();
                try {
                    $menus->save(null, $_POST);
                    $_SESSION['flash'] = '管理菜单已创建。';
                    $this->redirect('/admin/menu');
                } catch (InvalidArgumentException | PDOException $exception) {
                    View::render('admin/menus', $base + array('page_title' => '后台菜单', 'menus' => $menus->all(), 'error' => $exception->getMessage()), 422);
                }
                return;
            }
            if (preg_match('#^/admin/menu/([1-9][0-9]*)/toggle$#D', $path, $match) && $method === 'POST') {
                $this->requireCsrf();
                $menus->setVisible((int) $match[1], self::switchValue());
                $_SESSION['flash'] = '修改成功！';
                $this->redirect('/admin/menu');
            }
            if (preg_match('#^/admin/menu/([1-9][0-9]*)/edit$#D', $path, $match)) {
                $id = (int) $match[1];
                $editing = array_values(array_filter($menus->all(), static fn (array $menu): bool => (int) $menu['id'] === $id))[0] ?? null;
                if ($editing === null) {
                    $this->notFound();
                }
                $error = null;
                if ($method === 'POST') {
                    $this->requireCsrf();
                    try {
                        $menus->save($id, $_POST);
                        $_SESSION['flash'] = '管理菜单已保存。';
                        $this->redirect('/admin/menu');
                    } catch (InvalidArgumentException | PDOException $exception) {
                        $error = $exception->getMessage();
                    }
                    $editing = array_merge($editing, array_intersect_key($_POST, $editing));
                }
                View::render('admin/menus', $base + array('page_title' => '后台菜单', 'menus' => $menus->all(), 'editing' => $editing, 'error' => $error), $error === null ? 200 : 422);
                return;
            }
            if (preg_match('#^/admin/menu/([1-9][0-9]*)/delete$#D', $path, $match) && $method === 'POST') {
                $this->requireCsrf();
                $menus->delete((int) $match[1]);
                $_SESSION['flash'] = '管理菜单已删除。';
                $this->redirect('/admin/menu');
            }
            $this->notFound();
        }
        if (preg_match('#^/admin/region/([1-9][0-9]*)$#D', $path, $match)) {
            $roleId = (int) $match[1];
            if ($access->role($roleId) === null) {
                $this->notFound();
            }
            if ($method === 'POST') {
                $this->requireCsrf();
                try {
                    $locales = $_POST['locales'] ?? array();
                    $access->saveLocales($roleId, is_array($locales) ? $locales : array());
                    $_SESSION['flash'] = '区域授权已保存。';
                    $this->redirect('/admin/roles');
                } catch (InvalidArgumentException $exception) {
                    View::render('admin/region-form', $base + array('page_title' => '区域授权', 'role' => $access->role($roleId), 'locales' => $access->locales($roleId), 'error' => $exception->getMessage()), 422);
                }
                return;
            }
            if ($method === 'GET') {
                View::render('admin/region-form', $base + array('page_title' => '区域授权', 'role' => $access->role($roleId), 'locales' => $access->locales($roleId), 'error' => null));
                return;
            }
        }

        if ($path === '/admin/roles' && $method === 'GET') {
            View::render('admin/roles', $base + array('page_title' => '角色权限', 'roles' => $access->roles()));
            return;
        }
        if ($path === '/admin/roles/new' && $method === 'GET') {
            View::render('admin/role-form', $base + array('page_title' => '新建角色', 'role' => null, 'grants' => array(), 'error' => null));
            return;
        }
        if ($path === '/admin/roles' && $method === 'POST') {
            $this->saveRole($access, null, $base);
            return;
        }
        if (preg_match('#^/admin/roles/([1-9][0-9]*)/edit$#D', $path, $match)) {
            $id = (int) $match[1];
            $role = $access->role($id);
            if ($role === null || $role['slug'] === 'owner') {
                $this->notFound();
            }
            if ($method === 'POST') {
                $this->saveRole($access, $id, $base);
            } elseif ($method === 'GET') {
                View::render('admin/role-form', $base + array('page_title' => '编辑角色', 'role' => $role, 'grants' => $access->grants($id), 'error' => null));
            } else {
                $this->notFound();
            }
            return;
        }
        if (preg_match('#^/admin/roles/([1-9][0-9]*)/delete$#D', $path, $match) && $method === 'POST') {
            $this->requireCsrf();
            try {
                $access->deleteRole((int) $match[1]);
                $_SESSION['flash'] = '角色已删除。';
            } catch (InvalidArgumentException $error) {
                $_SESSION['flash'] = $error->getMessage();
            }
            $this->redirect('/admin/roles');
        }
        if ($path === '/admin/admins') {
            if ($method === 'POST') {
                $this->requireCsrf();
                try {
                    if (self::postString('password') !== self::postString('rpassword')) {
                        throw new InvalidArgumentException('确认密码不正确。');
                    }
                    $created = $access->createAdmin(self::postString('username'), self::postString('password'), (int) self::postString('role_id'), $base['user']['role_slug'] === 'owner');
                    $access->saveAdminDetails($created, self::postString('display_name'), self::postString('status') === 'disabled' ? 'disabled' : 'active', (int) $base['user']['id']);
                    $_SESSION['flash'] = '后台账号已创建。';
                    $this->redirect('/admin/admins');
                } catch (InvalidArgumentException $error) {
                    $message = $error->getMessage();
                } catch (PDOException $error) {
                    $message = '后台账号已存在。';
                }
                View::render('admin/admins', $base + array('page_title' => '系统用户', 'admins' => $access->admins(), 'roles' => $access->roles(), 'error' => $message), 422);
                return;
            }
            if ($method === 'GET') {
                View::render('admin/admins', $base + array('page_title' => '系统用户', 'admins' => $access->admins(), 'roles' => $access->roles(), 'error' => null));
                return;
            }
        }
        if (preg_match('#^/admin/admins/([1-9][0-9]*)/toggle$#D', $path, $match) && $method === 'POST') {
            $this->requireCsrf();
            $admin = $access->admin((int) $match[1]);
            if ($admin === null) {
                $this->notFound();
            }
            try {
                $access->saveAdminDetails((int) $admin['id'], (string) $admin['display_name'], self::switchValue() ? 'active' : 'disabled', (int) $base['user']['id']);
                $_SESSION['flash'] = '修改成功！';
            } catch (InvalidArgumentException $exception) {
                $_SESSION['flash'] = '操作失败：' . $exception->getMessage();
            }
            $this->redirect('/admin/admins');
        }
        if (preg_match('#^/admin/admins/([1-9][0-9]*)/edit$#D', $path, $match)) {
            $id = (int) $match[1];
            $admin = $access->admin($id);
            if ($admin === null) {
                $this->notFound();
            }
            if ($admin['role_slug'] === 'owner' && $base['user']['role_slug'] !== 'owner') {
                View::render('forbidden', $base + array('page_title' => '无权访问'), 403);
                return;
            }
            $error = null;
            if ($method === 'POST') {
                $this->requireCsrf();
                try {
                    if (self::postString('new_password') !== self::postString('rpassword')) {
                        throw new InvalidArgumentException('确认密码不正确。');
                    }
                    $access->updateAdmin($id, (int) self::postString('role_id'), self::postString('new_password'), $base['user']['role_slug'] === 'owner');
                    $access->saveAdminDetails($id, self::postString('display_name'), self::postString('status') === 'disabled' ? 'disabled' : 'active', (int) $base['user']['id']);
                    $_SESSION['flash'] = '后台账号已更新。';
                    $this->redirect('/admin/admins');
                } catch (InvalidArgumentException $exception) {
                    $error = $exception->getMessage();
                }
            } elseif ($method !== 'GET') {
                $this->notFound();
            }
            View::render('admin/admin-form', $base + array('page_title' => '编辑后台账号', 'account' => $admin, 'roles' => $access->roles(), 'error' => $error), $error ? 422 : 200);
            return;
        }
        if (preg_match('#^/admin/admins/([1-9][0-9]*)/delete$#D', $path, $match) && $method === 'POST') {
            $this->requireCsrf();
            try {
                $access->deleteAdmin((int) $match[1], (int) $base['user']['id']);
                $_SESSION['flash'] = '后台账号已删除。';
            } catch (InvalidArgumentException $error) {
                $_SESSION['flash'] = $error->getMessage();
            }
            $this->redirect('/admin/admins');
        }
        $this->notFound();
    }

    private function saveRole(AccessRepository $access, ?int $id, array $base): void
    {
        $this->requireCsrf();
        $raw = $_POST['permissions'] ?? array();
        $grants = is_array($raw) ? $raw : array();
        $role = array('id' => $id, 'name' => self::postString('name'), 'slug' => self::postString('slug'), 'description' => self::postString('description'));
        try {
            if (! is_array($raw)) {
                throw new InvalidArgumentException('权限列表无效。');
            }
            $roleId = $access->saveRole($id, $role['name'], $role['slug'], $grants);
            $access->saveRoleDetails($roleId, $role['description'], $id === null);
            $_SESSION['flash'] = '角色权限已保存。';
            $this->redirect('/admin/roles');
        } catch (InvalidArgumentException $error) {
            $message = $error->getMessage();
        } catch (PDOException $error) {
            $message = '角色标识已存在。';
        }
        View::render('admin/role-form', $base + array('page_title' => $id === null ? '新建角色' : '编辑角色', 'role' => $role, 'grants' => $grants, 'error' => $message), 422);
    }

    private function requireCsrf(): void
    {
        $token = $_POST['_csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? null);
        if (! Auth::validCsrf(is_string($token) ? $token : null)) {
            http_response_code(403);
            exit('CSRF verification failed.');
        }
    }

    private static function postString(string $key): string
    {
        return is_string($_POST[$key] ?? null) ? $_POST[$key] : '';
    }

    private static function pageNumber(): int
    {
        $input = $_GET['page'] ?? '1';
        if (! is_string($input) && ! is_int($input)) {
            return 1;
        }
        $page = filter_var($input, FILTER_VALIDATE_INT, array('options' => array('min_range' => 1, 'max_range' => 100000)));
        return $page === false ? 1 : $page;
    }

    private static function boundedPage(int $totalPages): int
    {
        return min(self::pageNumber(), max(1, $totalPages));
    }

    private static function firstAdminPath(array $can): string
    {
        foreach (array(
            'dashboard.view' => '/admin',
            'content.view' => '/admin/posts',
            'taxonomy.manage' => '/admin/categories',
            'content.manage' => '/admin/posts/new',
            'media.manage' => '/admin/media',
            'operations.manage' => '/admin/slides',
            'members.manage' => '/admin/members',
            'access.manage' => '/admin/roles',
            'settings.manage' => '/admin/settings',
            'license.manage' => '/admin/license'
        ) as $permission => $path) {
            if ($can[$permission] ?? false) {
                return $path;
            }
        }
        return '/admin';
    }

    private function redirect(string $path): never
    {
        if ($this->routePrefix !== null && str_starts_with($path, '/admin')) {
            $path = '/' . $this->routePrefix . $path;
        }
        header('Location: ' . $path, true, 303);
        exit;
    }

    private function notFound(): never
    {
        View::render('not-found', array('page_title' => '页面不存在', 'bare' => true), 404);
        exit;
    }
}
