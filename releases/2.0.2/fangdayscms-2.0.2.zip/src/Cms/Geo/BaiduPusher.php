<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Geo;

/** Baidu 普通收录 / 快速收录 link submission. */
final class BaiduPusher
{
    /**
     * @param string $site the `site` query value, normally the site address as registered in Baidu's webmaster platform
     * @return array{status: int, body: string, data: array<string, mixed>|null, error: string} data is Baidu's decoded answer, null when it was not JSON
     */
    public static function post(string $site, string $token, array $urls, bool $daily = false): array
    {
        $api = (getenv('FANGDAYS_BAIDU_PUSH_API') ?: 'http://data.zz.baidu.com/urls') . '?site=' . rawurlencode($site) . '&token=' . rawurlencode($token) . ($daily ? '&type=daily' : '');
        $answer = GeoHttp::request('POST', $api, "Content-Type: text/plain\r\n", implode("\n", $urls));
        $data = json_decode($answer['body'], true);
        return array('status' => $answer['status'], 'body' => $answer['body'], 'data' => is_array($data) ? $data : null, 'error' => $answer['error']);
    }

    /** @return array<string, mixed>|null Baidu's decoded answer, null when it could not be reached. */
    public static function send(string $site, string $token, array $urls, bool $daily = false): ?array
    {
        return self::post($site, $token, $urls, $daily)['data'];
    }
}
