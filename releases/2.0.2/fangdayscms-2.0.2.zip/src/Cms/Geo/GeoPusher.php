<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Geo;

use FangdaysCMS\Cms\Pboot\PbootConfig;
use PDO;

/**
 * Link submission to search engines that offer a general-purpose API. Google's Indexing API only
 * accepts job and livestream pages, so Google gets the sitemap through Search Console instead.
 */
final class GeoPusher
{
    public const URL_ENGINES = array('baidu' => '百度普通收录', 'baidu_daily' => '百度快速收录', 'indexnow' => 'IndexNow（Bing 等）');

    private readonly PbootConfig $config;

    public function __construct(private readonly PDO $pdo)
    {
        $this->config = new PbootConfig($pdo);
    }

    /** @return list<string> engines that take single addresses and are set up on this site */
    public function urlEngines(): array
    {
        $engines = array();
        if ($this->config->get('baidu_zz_token') !== '') {
            $engines[] = 'baidu';
        }
        if ($this->config->get('baidu_ks_token') !== '' && $this->config->on('geo_baidu_daily')) {
            $engines[] = 'baidu_daily';
        }
        if ($this->config->on('geo_indexnow')) {
            $engines[] = 'indexnow';
        }
        return $engines;
    }

    public function googleReady(): bool
    {
        return $this->config->get('geo_google_site') !== '' && $this->config->get('geo_google_account') !== '';
    }

    /** The value Baidu receives as `site`: the address as registered in its webmaster platform, unless the site owner overrides it. */
    public function baiduSite(string $origin): string
    {
        $custom = trim($this->config->get('geo_baidu_site'));
        return $custom !== '' ? $custom : $origin;
    }

    /** The key is public by design: search engines read it back from /{key}.txt. */
    public function indexNowKey(): string
    {
        $key = $this->config->get('geo_indexnow_key');
        if ($key === '') {
            $key = bin2hex(random_bytes(16));
            $this->config->store(array('geo_indexnow_key' => $key));
        }
        return $key;
    }

    /** @return array{ok: bool, quota: bool, message: string, http: int, detail: string} */
    public function send(string $engine, string $origin, string $url): array
    {
        return match ($engine) {
            'baidu', 'baidu_daily' => $this->baidu($engine === 'baidu_daily', $origin, $url),
            'indexnow' => $this->indexNow($origin, $url),
            default => self::result(false, false, '未知推送渠道'),
        };
    }

    /** @return array{ok: bool, quota: bool, message: string, http: int, detail: string} */
    public function submitSitemap(string $origin): array
    {
        $account = json_decode($this->config->get('geo_google_account'), true);
        if (! is_array($account) || ! is_string($account['client_email'] ?? null) || ! is_string($account['private_key'] ?? null)) {
            return self::result(false, false, 'Google 服务账号 JSON 无效');
        }
        if (! extension_loaded('openssl')) {
            return self::result(false, false, '服务器缺少 openssl 扩展');
        }
        $base = rtrim((string) (getenv('FANGDAYS_GOOGLE_API') ?: ''), '/');
        $tokenUrl = $base !== '' ? $base . '/token' : 'https://oauth2.googleapis.com/token';
        $now = time();
        $segment = static fn (array $data): string => rtrim(strtr(base64_encode((string) json_encode($data)), '+/', '-_'), '=');
        $unsigned = $segment(array('alg' => 'RS256', 'typ' => 'JWT')) . '.' . $segment(array('iss' => $account['client_email'], 'scope' => 'https://www.googleapis.com/auth/webmasters', 'aud' => $tokenUrl, 'iat' => $now, 'exp' => $now + 3000));
        $signature = '';
        if (! @openssl_sign($unsigned, $signature, $account['private_key'], 'sha256WithRSAEncryption')) {
            return self::result(false, false, 'Google 服务账号私钥无效');
        }
        [$status, $body, $error] = self::request('POST', $tokenUrl, "Content-Type: application/x-www-form-urlencoded\r\n", http_build_query(array('grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer', 'assertion' => $unsigned . '.' . rtrim(strtr(base64_encode($signature), '+/', '-_'), '='))));
        $token = json_decode($body, true)['access_token'] ?? null;
        if (! is_string($token)) {
            // The token answer is deliberately not stored: on success it would hold a live access token.
            return self::result(false, false, $status === 0 ? 'Google 授权接口无法访问：' . self::reason($error) : 'Google 授权失败（HTTP ' . $status . '）', $status);
        }
        $feed = $origin . '/sitemap.xml';
        $submit = ($base !== '' ? $base : 'https://www.googleapis.com/webmasters/v3') . '/sites/' . rawurlencode($this->config->get('geo_google_site')) . '/sitemaps/' . rawurlencode($feed);
        [$status, $body, $error] = self::request('PUT', $submit, "Authorization: Bearer " . $token . "\r\nContent-Length: 0\r\n", '');
        $detail = self::detail('sitemap=' . $feed, $body);
        if ($status >= 200 && $status < 300) {
            return self::result(true, false, 'Google 已接收 Sitemap（HTTP ' . $status . '）', $status, $detail);
        }
        return self::result(false, $status === 429, $status === 0 ? 'Google 提交接口无法访问：' . self::reason($error) : 'Google 提交失败（HTTP ' . $status . '），请确认服务账号已加入 Search Console 站点', $status, $detail);
    }

    private function baidu(bool $daily, string $origin, string $url): array
    {
        $token = $this->config->get($daily ? 'baidu_ks_token' : 'baidu_zz_token');
        if ($token === '') {
            return self::result(false, false, '未配置百度 token');
        }
        $site = $this->baiduSite($origin);
        $answer = BaiduPusher::post($site, $token, array($url), $daily);
        $http = $answer['status'];
        $data = $answer['data'];
        $detail = self::detail('site=' . $site . ($daily ? ' type=daily' : ''), $answer['body']);
        if ($data === null) {
            return $http === 0
                ? self::result(false, false, '百度接口无法访问：' . self::reason($answer['error']), 0, $detail)
                : self::result(false, false, '百度返回了无法识别的内容（HTTP ' . $http . '）', $http, $detail);
        }
        if (isset($data['error'])) {
            $message = (string) ($data['message'] ?? $data['error']);
            return self::result(false, stripos($message, 'over quota') !== false, $message, $http, $detail);
        }
        // A 200 answer can still reject the address: Baidu lists those under not_same_site / not_valid and counts none as sent.
        if (! empty($data['not_same_site'])) {
            return self::result(false, false, '百度拒绝：该地址不属于 site 参数对应的站点（not_same_site），当前 site=' . $site . '，请核对百度搜索资源平台里添加的站点', $http, $detail);
        }
        if (! empty($data['not_valid'])) {
            return self::result(false, false, '百度拒绝：地址格式无效（not_valid）', $http, $detail);
        }
        $sent = $data[$daily ? 'success_daily' : 'success'] ?? $data['success'] ?? null;
        $remain = $data[$daily ? 'remain_daily' : 'remain'] ?? $data['remain'] ?? null;
        if ($sent === null) {
            return self::result(false, false, '百度的返回里没有成功数量，无法确认是否已接收', $http, $detail);
        }
        if ((int) $sent >= 1) {
            return self::result(true, false, '百度已接收' . ($remain === null ? '' : '，今日剩余额度 ' . (int) $remain), $http, $detail);
        }
        if ($remain !== null && (int) $remain <= 0) {
            return self::result(false, true, '百度今日额度已用完', $http, $detail);
        }
        return self::result(false, false, '百度没有接收该地址（success=0）', $http, $detail);
    }

    private function indexNow(string $origin, string $url): array
    {
        $host = (string) parse_url($origin, PHP_URL_HOST);
        $key = $this->indexNowKey();
        [$status, $body, $error] = self::request('POST', (getenv('FANGDAYS_INDEXNOW_API') ?: 'https://api.indexnow.org/indexnow'), "Content-Type: application/json; charset=utf-8\r\n", (string) json_encode(array('host' => $host, 'key' => $key, 'keyLocation' => $origin . '/' . $key . '.txt', 'urlList' => array($url))));
        $detail = self::detail('host=' . $host, $body);
        if ($status === 200 || $status === 202) {
            return self::result(true, false, 'IndexNow 已接收（HTTP ' . $status . '）', $status, $detail);
        }
        return self::result(false, $status === 429, $status === 0 ? 'IndexNow 无法访问：' . self::reason($error) : 'IndexNow 返回 HTTP ' . $status, $status, $detail);
    }

    /** @return array{0: int, 1: string, 2: string} status (0 when nothing arrived), body, transport error */
    private static function request(string $method, string $url, string $headers, string $content): array
    {
        $answer = GeoHttp::request($method, $url, $headers, $content);
        return array($answer['status'], $answer['body'], $answer['error']);
    }

    private static function reason(string $error): string
    {
        return $error !== '' ? $error : '没有收到响应';
    }

    /** What was asked and what came back, kept short enough for the push log. */
    private static function detail(string $request, string $body): string
    {
        $body = trim($body);
        return $request . ($body === '' ? '' : "\n" . mb_substr($body, 0, 500));
    }

    private static function result(bool $ok, bool $quota, string $message, int $http = 0, string $detail = ''): array
    {
        return array('ok' => $ok, 'quota' => $quota, 'message' => $message, 'http' => $http, 'detail' => $detail);
    }
}
