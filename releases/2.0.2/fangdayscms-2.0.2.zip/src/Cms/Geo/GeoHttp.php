<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Geo;

/** One HTTP call for every push channel, with the reason spelled out when no answer arrives. */
final class GeoHttp
{
    /**
     * @param string $headers raw header lines separated by CRLF
     * @return array{status: int, body: string, error: string} status 0 means no answer arrived and error says why
     */
    public static function request(string $method, string $url, string $headers, string $content, int $timeout = 10): array
    {
        return function_exists('curl_init')
            ? self::viaCurl($method, $url, $headers, $content, $timeout)
            : self::viaStream($method, $url, $headers, $content, $timeout);
    }

    private static function viaCurl(string $method, string $url, string $headers, string $content, int $timeout): array
    {
        $handle = curl_init($url);
        if ($handle === false) {
            return array('status' => 0, 'body' => '', 'error' => 'curl 初始化失败');
        }
        $lines = array_values(array_filter(array_map('trim', explode("\n", $headers)), static fn (string $line): bool => $line !== ''));
        $lines[] = 'Expect:';
        curl_setopt_array($handle, array(
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $lines,
            CURLOPT_POSTFIELDS => $content,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => $timeout,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_FOLLOWLOCATION => false,
        ));
        $body = curl_exec($handle);
        $status = (int) curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
        $error = $body === false ? curl_error($handle) : '';
        unset($handle);
        return array('status' => $status, 'body' => is_string($body) ? $body : '', 'error' => $error);
    }

    private static function viaStream(string $method, string $url, string $headers, string $content, int $timeout): array
    {
        if (! filter_var(ini_get('allow_url_fopen'), FILTER_VALIDATE_BOOLEAN)) {
            return array('status' => 0, 'body' => '', 'error' => '服务器关闭了 allow_url_fopen 且没有安装 curl 扩展，无法访问外部接口');
        }
        $body = @file_get_contents($url, false, stream_context_create(array('http' => array('method' => $method, 'header' => $headers, 'content' => $content, 'timeout' => $timeout, 'ignore_errors' => true))));
        $status = isset($http_response_header[0]) && preg_match('#\s(\d{3})\s?#', $http_response_header[0], $found) === 1 ? (int) $found[1] : 0;
        $error = $body === false && $status === 0 ? (string) (error_get_last()['message'] ?? '连接失败') : '';
        return array('status' => $status, 'body' => is_string($body) ? $body : '', 'error' => $error);
    }
}
