<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Geo;

use FangdaysCMS\Cms\Pboot\PbootConfig;
use PDO;

/** Background work: publishing queues a job, bin/geo.php (or an admin visit) runs it. */
final class GeoJobs
{
    private const BACKOFF = array(300, 1800, 7200);
    private const STALE_AFTER = 600;

    public function __construct(private readonly PDO $pdo)
    {
    }

    public function queuePush(int $postId, string $origin, int $publishAt): void
    {
        $this->queueUrl('post', $postId, $origin, $publishAt);
    }

    /** A published post also changes its category and the home page. */
    public function queueContent(int $postId, ?int $categoryId, string $origin, int $publishAt): void
    {
        $this->queueUrl('post', $postId, $origin, $publishAt);
        if ($categoryId !== null) {
            $this->queueUrl('category', $categoryId, $origin, $publishAt);
        }
        $this->queueUrl('home', 0, $origin, $publishAt);
    }

    /** One push per page, engine and day, so repeated saves spend no extra quota. */
    public function queueUrl(string $kind, int $id, string $origin, int $publishAt = 0): int
    {
        if (! (new PbootConfig($this->pdo))->on('geo_auto_push')) {
            return 0;
        }
        return $this->enqueue($kind, $id, $origin, $publishAt);
    }

    /** Every public page, for a first sync or after a migration. The manual button ignores the auto switch. */
    public function queueAll(string $origin): int
    {
        $count = 0;
        foreach ((new GeoUrl($this->pdo))->publicTargets() as [$kind, $id]) {
            $count += $this->enqueue($kind, $id, $origin, 0);
        }
        return $count;
    }

    private function enqueue(string $kind, int $id, string $origin, int $publishAt): int
    {
        $pusher = new GeoPusher($this->pdo);
        $count = 0;
        $runAfter = max(time(), $publishAt);
        foreach ($pusher->urlEngines() as $engine) {
            $count += $this->insert($engine, $kind, $id, $origin, $runAfter);
        }
        // The sitemap covers the whole site, so one submission a day is enough.
        return $count + ($pusher->googleReady() ? $this->insert('google', 'sitemap', 0, $origin, $runAfter) : 0);
    }

    private function insert(string $engine, string $kind, int $id, string $origin, int $runAfter): int
    {
        $mysql = $this->pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql';
        $now = time();
        $stmt = $this->pdo->prepare(($mysql ? 'INSERT IGNORE' : 'INSERT OR IGNORE') . " INTO geo_jobs (type, payload, dedupe_key, status, attempts, run_after, last_error, created_at, updated_at) VALUES ('push', ?, ?, 'pending', 0, ?, '', ?, ?)");
        $stmt->execute(array(json_encode(array('engine' => $engine, 'kind' => $kind, 'id' => $id, 'origin' => $origin)), 'push:' . $engine . ':' . $kind . ':' . $id . ':' . date('Ymd', $runAfter), $runAfter, $now, $now));
        return $stmt->rowCount();
    }

    /** @return array{done: int, failed: int, retry: int} */
    public function run(int $limit = 20, ?string $type = null): array
    {
        $now = time();
        $this->pdo->prepare("UPDATE geo_jobs SET status = 'pending', updated_at = ? WHERE status = 'running' AND updated_at < ?")->execute(array($now, $now - self::STALE_AFTER));
        $stmt = $this->pdo->prepare("SELECT * FROM geo_jobs WHERE status = 'pending' AND run_after <= ?" . ($type === null ? '' : ' AND type = ?') . ' ORDER BY run_after, id LIMIT ' . max(1, $limit));
        $stmt->execute($type === null ? array($now) : array($now, $type));
        $counts = array('done' => 0, 'failed' => 0, 'retry' => 0);
        $claim = $this->pdo->prepare("UPDATE geo_jobs SET status = 'running', updated_at = ? WHERE id = ? AND status = 'pending'");
        foreach ($stmt->fetchAll() as $job) {
            $claim->execute(array($now, $job['id']));
            if ($claim->rowCount() !== 1) {
                continue;
            }
            $counts[$job['type'] === 'sample' ? $this->sampleJob($job) : $this->pushJob($job)]++;
        }
        (new GeoPushLog($this->pdo))->prune();
        return $counts;
    }

    /**
     * After Baidu's daily quota resets (Beijing midnight), wake deferred push jobs and drain a
     * larger batch. Wire as: `5 0 * * * php bin/geo.php push-daily`
     *
     * @return array{done: int, failed: int, retry: int, released: int}
     */
    public function pushDaily(int $limit = 200): array
    {
        $released = $this->releaseQuotaDeferred();
        return $this->run($limit, 'push') + array('released' => $released);
    }

    /** Make quota-parked push jobs runnable now (Baidu default API quota refreshes daily). */
    public function releaseQuotaDeferred(): int
    {
        $now = time();
        $stmt = $this->pdo->prepare("UPDATE geo_jobs SET run_after = ?, updated_at = ? WHERE status = 'pending' AND type = 'push' AND last_error LIKE ?");
        $stmt->execute(array($now, $now, '%配额%'));
        return $stmt->rowCount();
    }

    public function stats(): array
    {
        $counts = array('pending' => 0, 'running' => 0, 'done' => 0, 'failed' => 0);
        foreach ($this->pdo->query('SELECT status, COUNT(*) AS total FROM geo_jobs GROUP BY status') as $row) {
            $counts[(string) $row['status']] = (int) $row['total'];
        }
        return $counts;
    }

    /**
     * Pushes that are waiting or in flight, soonest first, so a queued page is visible before it has an answer.
     *
     * @return list<array<string, mixed>>
     */
    public function queued(int $limit = 20): array
    {
        $rows = $this->pdo->query("SELECT id, payload, status, attempts, run_after, last_error FROM geo_jobs WHERE type = 'push' AND status IN ('pending', 'running') ORDER BY run_after, id LIMIT " . max(1, $limit))->fetchAll();
        $urls = new GeoUrl($this->pdo);
        foreach ($rows as &$row) {
            $payload = json_decode((string) $row['payload'], true);
            $payload = is_array($payload) ? $payload : array();
            $kind = (string) ($payload['kind'] ?? 'post');
            $path = $kind === 'sitemap' ? '/sitemap.xml' : $urls->publicPath($kind, (int) ($payload['id'] ?? $payload['post_id'] ?? 0));
            $row['engine'] = (string) ($payload['engine'] ?? 'baidu');
            $row['url'] = $path === null ? '' : (string) ($payload['origin'] ?? '') . $path;
        }
        unset($row);
        return $rows;
    }

    /** Pushes that fell due more than $minutes ago and still have not run: the sign that nothing is running the queue. */
    public function overdue(int $minutes = 15): int
    {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM geo_jobs WHERE type = 'push' AND status = 'pending' AND run_after <= ?");
        $stmt->execute(array(time() - $minutes * 60));
        return (int) $stmt->fetchColumn();
    }

    public function failures(int $limit = 10): array
    {
        return $this->pdo->query("SELECT id, type, payload, attempts, last_error, updated_at FROM geo_jobs WHERE status = 'failed' ORDER BY id DESC LIMIT " . max(1, $limit))->fetchAll();
    }

    /**
     * Compact push queue for the admin workbench: counts plus the next open jobs.
     *
     * @return array{pending: int, due: int, waiting: int, failed: int, done_today: int, jobs: list<array{id: int, engine: string, engine_label: string, kind: string, target: string, status: string, status_label: string, note: string, run_after: int, due: bool}>}
     */
    public function pushBoard(int $limit = 8): array
    {
        $now = time();
        $dayStart = (new \DateTimeImmutable('today', new \DateTimeZone('Asia/Shanghai')))->getTimestamp();
        $pending = 0;
        $due = 0;
        $waiting = 0;
        $failed = 0;
        foreach ($this->pdo->query("SELECT status, run_after, COUNT(*) AS total FROM geo_jobs WHERE type = 'push' GROUP BY status, run_after") as $row) {
            $total = (int) $row['total'];
            $status = (string) $row['status'];
            if ($status === 'failed') {
                $failed += $total;
            } elseif ($status === 'pending' || $status === 'running') {
                $pending += $total;
                if ((int) $row['run_after'] <= $now) {
                    $due += $total;
                } else {
                    $waiting += $total;
                }
            }
        }
        $doneToday = (int) $this->pdo->query('SELECT COUNT(*) FROM geo_jobs WHERE type = \'push\' AND status = \'done\' AND updated_at >= ' . (int) $dayStart)->fetchColumn();
        $stmt = $this->pdo->prepare("SELECT id, payload, status, attempts, run_after, last_error FROM geo_jobs WHERE type = 'push' AND status IN ('pending', 'running') ORDER BY CASE WHEN run_after <= ? THEN 0 ELSE 1 END, run_after, id LIMIT " . max(1, $limit));
        $stmt->execute(array($now));
        $jobs = array();
        foreach ($stmt->fetchAll() as $row) {
            $jobs[] = $this->describePushJob($row, $now);
        }
        return array('pending' => $pending, 'due' => $due, 'waiting' => $waiting, 'failed' => $failed, 'done_today' => $doneToday, 'jobs' => $jobs);
    }

    /** @param array<string, mixed> $job */
    private function describePushJob(array $job, int $now): array
    {
        $payload = json_decode((string) $job['payload'], true);
        $payload = is_array($payload) ? $payload : array();
        $kind = (string) ($payload['kind'] ?? 'post');
        $engine = (string) ($payload['engine'] ?? 'baidu');
        $id = (int) ($payload['id'] ?? $payload['post_id'] ?? 0);
        $runAfter = (int) $job['run_after'];
        $status = (string) $job['status'];
        $note = (string) $job['last_error'];
        if ($status === 'pending' && $runAfter > $now && $note === '') {
            $note = '未到推送时间';
        }
        $statusLabel = match ($status) {
            'running' => '进行中',
            'pending' => $runAfter > $now ? '已延期' : '待推送',
            default => $status,
        };
        return array(
            'id' => (int) $job['id'],
            'engine' => $engine,
            'engine_label' => self::engineLabel($engine),
            'kind' => $kind,
            'target' => $this->targetLabel($kind, $id),
            'status' => $status,
            'status_label' => $statusLabel,
            'note' => $note,
            'run_after' => $runAfter,
            'due' => $runAfter <= $now,
        );
    }

    private static function engineLabel(string $engine): string
    {
        return match ($engine) {
            'baidu' => '百度普通',
            'baidu_daily' => '百度快速',
            'indexnow' => 'IndexNow',
            'google' => 'Google Sitemap',
            default => $engine,
        };
    }

    private function targetLabel(string $kind, int $id): string
    {
        if ($kind === 'home') {
            return '首页';
        }
        if ($kind === 'sitemap') {
            return 'Sitemap';
        }
        if ($id <= 0) {
            return $kind;
        }
        $sql = match ($kind) {
            'post' => 'SELECT title FROM posts WHERE id = ?',
            'page' => 'SELECT title FROM pages WHERE id = ?',
            'category' => 'SELECT name FROM categories WHERE id = ?',
            default => null,
        };
        if ($sql === null) {
            return $kind . ' #' . $id;
        }
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(array($id));
        $title = $stmt->fetchColumn();
        return is_string($title) && $title !== '' ? $title : $kind . ' #' . $id;
    }

    private function pushJob(array $job): string
    {
        $payload = json_decode((string) $job['payload'], true);
        $payload = is_array($payload) ? $payload : array();
        // Jobs queued before multi-engine push carried only post_id.
        $kind = (string) ($payload['kind'] ?? 'post');
        $engine = (string) ($payload['engine'] ?? 'baidu');
        $origin = (string) ($payload['origin'] ?? '');
        $pusher = new GeoPusher($this->pdo);
        $log = new GeoPushLog($this->pdo);
        $targetId = (int) ($payload['id'] ?? $payload['post_id'] ?? 0);
        $attempt = (int) $job['attempts'] + 1;
        if ($kind === 'sitemap') {
            $url = $origin . '/sitemap.xml';
            $result = $pusher->submitSitemap($origin);
        } else {
            $path = (new GeoUrl($this->pdo))->publicPath($kind, $targetId);
            // Hidden, deleted or unpublished since it was queued: nothing to announce.
            if ($path === null) {
                $log->record('job', (int) $job['id'], $engine, $kind, $targetId, '', 'skipped', 0, '内容已不公开，跳过推送', '', $attempt);
                $this->finish((int) $job['id'], 'done', (int) $job['attempts'], '内容已不公开，跳过推送');
                return 'done';
            }
            $url = $origin . $path;
            $result = $pusher->send($engine, $origin, $url);
        }
        $log->record('job', (int) $job['id'], $engine, $kind, $targetId, $url, $result['ok'] ? 'ok' : ($result['quota'] ? 'quota' : 'failed'), $result['http'], $result['message'], $result['detail'], $attempt);
        if ($result['ok']) {
            $this->finish((int) $job['id'], 'done', (int) $job['attempts'] + 1, '');
            return 'done';
        }
        if ($result['quota']) {
            $this->reschedule((int) $job['id'], (int) $job['attempts'], self::nextQuotaWindow(), '配额已用完，明日继续');
            return 'retry';
        }
        return $this->failed($job, $result['message']);
    }

    private function sampleJob(array $job): string
    {
        $payload = json_decode((string) $job['payload'], true);
        $monitor = new GeoMonitor($this->pdo);
        $question = is_array($payload) ? $monitor->question((int) ($payload['question_id'] ?? 0)) : null;
        if ($question === null || $question['status'] !== 'active') {
            $this->finish((int) $job['id'], 'done', (int) $job['attempts'], '问题已归档，跳过抽样');
            return 'done';
        }
        try {
            $result = (new GeoAi($this->pdo))->chat((string) $payload['provider'], (string) $question['question']);
            $monitor->record($question, (string) $payload['provider'], 'api', $result['answer'], $result['citations'], 0);
        } catch (GeoBudgetExceeded $error) {
            $this->reschedule((int) $job['id'], (int) $job['attempts'], self::nextQuotaWindow(), $error->getMessage());
            return 'retry';
        } catch (\RuntimeException | \InvalidArgumentException $error) {
            return $this->failed($job, $error->getMessage());
        }
        $this->finish((int) $job['id'], 'done', (int) $job['attempts'] + 1, '');
        return 'done';
    }

    /** Baidu's default push quota resets at Beijing midnight. */
    private static function nextQuotaWindow(): int
    {
        try {
            return (new \DateTimeImmutable('tomorrow', new \DateTimeZone('Asia/Shanghai')))->getTimestamp();
        } catch (\Exception) {
            return (int) (strtotime('tomorrow') ?: time() + 86400);
        }
    }

    private function failed(array $job, string $message): string
    {
        $attempts = (int) $job['attempts'] + 1;
        if (! isset(self::BACKOFF[$attempts - 1])) {
            $this->finish((int) $job['id'], 'failed', $attempts, $message);
            return 'failed';
        }
        $this->reschedule((int) $job['id'], $attempts, time() + self::BACKOFF[$attempts - 1], $message);
        return 'retry';
    }

    private function finish(int $id, string $status, int $attempts, string $error): void
    {
        $this->pdo->prepare('UPDATE geo_jobs SET status = ?, attempts = ?, last_error = ?, updated_at = ? WHERE id = ?')->execute(array($status, $attempts, mb_substr($error, 0, 255), time(), $id));
    }

    private function reschedule(int $id, int $attempts, int $runAfter, string $error): void
    {
        $this->pdo->prepare("UPDATE geo_jobs SET status = 'pending', attempts = ?, run_after = ?, last_error = ?, updated_at = ? WHERE id = ?")->execute(array($attempts, $runAfter, mb_substr($error, 0, 255), time(), $id));
    }
}
