<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms\Geo;

use PDO;

/** Every push attempt with what was sent and what the search engine answered, so a result never has to be guessed. */
final class GeoPushLog
{
    public const OUTCOMES = array('ok' => '成功', 'failed' => '失败', 'quota' => '额度用尽', 'skipped' => '已跳过');
    public const SOURCES = array('job' => '自动', 'test' => '测试');
    private const KEEP = 2000;

    public function __construct(private readonly PDO $pdo)
    {
    }

    public function record(string $source, int $jobId, string $engine, string $kind, int $targetId, string $url, string $outcome, int $http, string $message, string $detail, int $attempt): void
    {
        $this->pdo->prepare('INSERT INTO geo_push_log (job_id, source, engine, kind, target_id, url, outcome, http_status, message, detail, attempt, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')->execute(array(
            $jobId, $source, $engine, $kind, $targetId, mb_substr($url, 0, 500), $outcome, $http, mb_substr($message, 0, 255), mb_substr($detail, 0, 1000), $attempt, time(),
        ));
    }

    /** @return array{rows: list<array<string, mixed>>, total: int} newest first */
    public function page(int $page, int $perPage, string $engine = '', string $outcome = ''): array
    {
        $where = array();
        $args = array();
        foreach (array('engine' => $engine, 'outcome' => $outcome) as $column => $value) {
            if ($value !== '') {
                $where[] = $column . ' = ?';
                $args[] = $value;
            }
        }
        $clause = $where === array() ? '' : ' WHERE ' . implode(' AND ', $where);
        $count = $this->pdo->prepare('SELECT COUNT(*) FROM geo_push_log' . $clause);
        $count->execute($args);
        $rows = $this->pdo->prepare('SELECT * FROM geo_push_log' . $clause . ' ORDER BY id DESC LIMIT ' . max(1, $perPage) . ' OFFSET ' . (max(1, $page) - 1) * max(1, $perPage));
        $rows->execute($args);
        return array('rows' => $rows->fetchAll(), 'total' => (int) $count->fetchColumn());
    }

    /** @return array{ok: int, failed: int, quota: int, last_ok: int} attempts in the last 24 hours and the time of the latest success */
    public function summary(): array
    {
        $summary = array('ok' => 0, 'failed' => 0, 'quota' => 0, 'last_ok' => 0);
        $stmt = $this->pdo->prepare('SELECT outcome, COUNT(*) AS total FROM geo_push_log WHERE created_at >= ? GROUP BY outcome');
        $stmt->execute(array(time() - 86400));
        foreach ($stmt->fetchAll() as $row) {
            if (isset($summary[(string) $row['outcome']])) {
                $summary[(string) $row['outcome']] = (int) $row['total'];
            }
        }
        $summary['last_ok'] = (int) $this->pdo->query("SELECT COALESCE(MAX(created_at), 0) FROM geo_push_log WHERE outcome = 'ok'")->fetchColumn();
        return $summary;
    }

    /** Keeps the newest rows only, so the table cannot grow without bound. */
    public function prune(): void
    {
        $edge = $this->pdo->query('SELECT id FROM geo_push_log ORDER BY id DESC LIMIT 1 OFFSET ' . self::KEEP)->fetchColumn();
        if ($edge !== false) {
            $this->pdo->prepare('DELETE FROM geo_push_log WHERE id <= ?')->execute(array((int) $edge));
        }
    }
}
