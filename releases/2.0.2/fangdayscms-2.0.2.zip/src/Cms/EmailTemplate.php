<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

/** Render admin-editable HTML mail templates for interaction notifications. */
final class EmailTemplate
{
    public const KINDS = array('message', 'form', 'comment', 'test');

    /** @var array<string, array{subject: string, body: string}> */
    private const DEFAULTS = array(
        'message' => array(
            'subject' => '【{site_name}】新留言通知',
            'body' => '{fields}<br><br>来自网站 {site_url} （{datetime}）',
        ),
        'form' => array(
            'subject' => '【{site_name}】新的{form_name}',
            'body' => '{fields}<br><br>来自网站 {site_url} （{datetime}）',
        ),
        'comment' => array(
            'subject' => '【{site_name}】新评论通知',
            'body' => '{fields}<br><br>来自网站 {site_url} （{datetime}）',
        ),
        'test' => array(
            'subject' => '【{site_name}】邮件通知测试',
            'body' => '这是一封来自 {site_name} 的测试邮件，收到说明邮件通知配置正确。<br><br>发送时间：{datetime}<br>站点：{site_url}',
        ),
    );

    /**
     * @param array<string, string> $config PbootConfig::all()
     * @param array<string, string> $fields labeled values for {fields} and named placeholders
     * @param array<string, string> $vars extra vars such as form_name / site_name / site_url
     * @return array{subject: string, body: string}
     */
    public static function render(array $config, string $kind, array $fields = array(), array $vars = array()): array
    {
        if (! isset(self::DEFAULTS[$kind])) {
            $kind = 'message';
        }
        $subjectTpl = trim((string) ($config[$kind . '_mail_subject'] ?? ''));
        $bodyTpl = trim((string) ($config[$kind . '_mail_body'] ?? ''));
        if ($subjectTpl === '') {
            $subjectTpl = self::DEFAULTS[$kind]['subject'];
        }
        if ($bodyTpl === '') {
            $bodyTpl = self::DEFAULTS[$kind]['body'];
        }

        $plain = array(
            'site_name' => (string) ($vars['site_name'] ?? 'FangdaysCMS'),
            'site_url' => (string) ($vars['site_url'] ?? ''),
            'datetime' => (string) ($vars['datetime'] ?? date('Y-m-d H:i:s')),
            'form_name' => (string) ($vars['form_name'] ?? ''),
        );
        foreach ($fields as $label => $value) {
            $key = self::placeholderKey((string) $label);
            if ($key !== '') {
                $plain[$key] = (string) $value;
            }
        }
        foreach (array('name', 'email', 'phone', 'content') as $alias) {
            if (! isset($plain[$alias])) {
                $plain[$alias] = (string) ($fields[self::aliasLabel($alias)] ?? $fields[$alias] ?? '');
            }
        }

        $subjectMap = array();
        $bodyMap = array('{fields}' => self::fieldsHtml($fields));
        foreach ($plain as $key => $value) {
            $subjectMap['{' . $key . '}'] = $value;
            $bodyMap['{' . $key . '}'] = nl2br(View::e($value));
        }

        return array(
            'subject' => self::apply($subjectTpl, $subjectMap, false),
            'body' => self::apply($bodyTpl, $bodyMap, true),
        );
    }

    /** @return array{subject: string, body: string} */
    public static function defaults(string $kind): array
    {
        return self::DEFAULTS[$kind] ?? self::DEFAULTS['message'];
    }

    /** @param array<string, string> $fields */
    private static function fieldsHtml(array $fields): string
    {
        if ($fields === array()) {
            return '';
        }
        $html = '';
        foreach ($fields as $label => $value) {
            $html .= View::e((string) $label) . '：' . nl2br(View::e((string) $value)) . '<br>';
        }
        return $html;
    }

    /** @param array<string, string> $replacements */
    private static function apply(string $template, array $replacements, bool $htmlBody): string
    {
        $out = strtr($template, $replacements);
        // Strip unknown {placeholders} so unfinished templates stay readable.
        $out = preg_replace('/\{[a-zA-Z0-9_\x{4e00}-\x{9fff}]+\}/u', '', $out) ?? $out;
        if (! $htmlBody) {
            $out = trim(html_entity_decode(strip_tags($out), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
            $out = preg_replace('/\s+/u', ' ', $out) ?? $out;
        }
        return $out;
    }

    private static function placeholderKey(string $label): string
    {
        $label = trim($label);
        if ($label === '') {
            return '';
        }
        $map = array(
            '联系人' => 'name',
            '姓名' => 'name',
            '邮箱' => 'email',
            '电话' => 'phone',
            '手机' => 'phone',
            '留言内容' => 'content',
            '评论内容' => 'content',
            '内容' => 'content',
        );
        if (isset($map[$label])) {
            return $map[$label];
        }
        if (preg_match('/^[a-zA-Z][a-zA-Z0-9_]*$/D', $label) === 1) {
            return strtolower($label);
        }
        return $label;
    }

    private static function aliasLabel(string $alias): string
    {
        return match ($alias) {
            'name' => '联系人',
            'email' => '邮箱',
            'phone' => '电话',
            'content' => '留言内容',
            default => $alias,
        };
    }
}
