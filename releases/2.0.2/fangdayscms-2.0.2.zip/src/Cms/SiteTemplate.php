<?php
declare(strict_types=1);

namespace FangdaysCMS\Cms;

use InvalidArgumentException;

/** Filesystem-backed, non-executable HTML templates with a small Pboot tag vocabulary. */
final class SiteTemplate
{
    private const DIRECTORY = 'templates/site';

    public static function names(): array
    {
        $directory = dirname(__DIR__, 2) . '/' . self::DIRECTORY;
        $names = array();
        if (! is_dir($directory)) {
            return $names;
        }
        foreach (scandir($directory) ?: array() as $name) {
            if (self::validName($name) && is_file($directory . '/' . $name) && ! is_link($directory . '/' . $name)) {
                $names[] = $name;
            }
        }
        sort($names, SORT_STRING);
        return $names;
    }

    /** Built-in templates plus page templates of installed Pboot themes (selectable for categories and models). */
    public static function choices(): array
    {
        $root = dirname(__DIR__, 2);
        $names = self::names();
        foreach (Pboot\Theme::names($root) as $theme) {
            foreach ((new Pboot\Theme($root, $theme))->pages() as $page) {
                if (self::validName($page)) {
                    $names[] = $page;
                }
            }
        }
        $names = array_values(array_unique($names));
        sort($names, SORT_STRING);
        return $names;
    }

    public static function check(string $name): void
    {
        if ($name !== '' && (! self::validName($name) || ! in_array($name, self::choices(), true))) {
            throw new InvalidArgumentException('请选择现有的 HTML 模板文件。');
        }
    }

    public static function source(string $name): string
    {
        return self::readSource($name);
    }

    public static function save(string $name, string $source): void
    {
        if (! self::validName($name) || ! in_array($name, self::names(), true)) {
            throw new InvalidArgumentException('请选择现有的 HTML 模板文件。');
        }
        if ($source === '' || strlen($source) > 500000 || str_contains(strtolower($source), '<?php')) {
            throw new InvalidArgumentException('模板内容不能为空、不能超过 500 KB，且不得包含 PHP 代码。');
        }
        $path = dirname(__DIR__, 2) . '/' . self::DIRECTORY . '/' . $name;
        if (file_put_contents($path, $source, LOCK_EX) === false) {
            throw new InvalidArgumentException('模板文件保存失败。');
        }
    }

    public static function exportArchive(string $root): never
    {
        if (! class_exists('ZipArchive')) {
            throw new InvalidArgumentException('当前 PHP 未启用 ZIP 扩展。');
        }
        $tmp = tempnam($root . '/var', 'templates-');
        if ($tmp === false) {
            throw new InvalidArgumentException('模板压缩包创建失败。');
        }
        $zip = new \ZipArchive();
        if ($zip->open($tmp, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
            @unlink($tmp);
            throw new InvalidArgumentException('模板压缩包打开失败。');
        }
        foreach (self::names() as $name) {
            $path = dirname(__DIR__, 2) . '/' . self::DIRECTORY . '/' . $name;
            $zip->addFile($path, 'templates/site/' . $name);
        }
        $zip->addFromString('templates/manifest.json', (string) json_encode(array('product' => 'FangdaysCMS', 'format' => 1, 'generated_at' => gmdate('c'), 'files' => self::names()), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
        $zip->close();
        $filename = 'fangdays-templates-' . date('Ymd-His') . '.zip';
        header('Content-Type: application/zip');
        header('Content-Length: ' . (string) filesize($tmp));
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        readfile($tmp);
        @unlink($tmp);
        exit;
    }

    public static function importArchive(string $root, string $archivePath): int
    {
        if (! class_exists('ZipArchive') || ! is_file($archivePath)) {
            throw new InvalidArgumentException('模板压缩包不可用。');
        }
        $zip = new \ZipArchive();
        if ($zip->open($archivePath) !== true) {
            throw new InvalidArgumentException('模板压缩包无法打开。');
        }
        $files = array();
        $manifestFiles = null;
        $totalBytes = 0;
        for ($index = 0; $index < $zip->numFiles; $index++) {
            $entry = $zip->statIndex($index);
            $name = (string) ($entry['name'] ?? '');
            if (str_ends_with($name, '/')) {
                continue;
            }
            if ($name === 'templates/manifest.json') {
                $manifest = json_decode((string) $zip->getFromIndex($index), true);
                if (! is_array($manifest) || (int) ($manifest['format'] ?? 0) !== 1 || (($manifest['product'] ?? 'FangdaysCMS') !== 'FangdaysCMS') || ! is_array($manifest['files'] ?? null)) {
                    $zip->close();
                    throw new InvalidArgumentException('模板 manifest.json 无效。');
                }
                $manifestFiles = array_values($manifest['files']);
                continue;
            }
            if (! str_starts_with($name, 'templates/site/') || str_contains($name, '\\') || str_contains($name, '../')) {
                $zip->close();
                throw new InvalidArgumentException('压缩包包含非法模板路径。');
            }
            $templateName = substr($name, strlen('templates/site/'));
            if (! self::validName($templateName) || str_contains($templateName, '/')) {
                $zip->close();
                throw new InvalidArgumentException('压缩包包含非法模板文件名。');
            }
            $bytes = (int) ($entry['size'] ?? 0);
            $totalBytes += $bytes;
            if (count($files) >= 100 || $bytes > 500000 || $totalBytes > 5000000) {
                $zip->close();
                throw new InvalidArgumentException('模板压缩包超出文件数量或大小限制。');
            }
            $source = $zip->getFromIndex($index);
            if ($source === false || str_contains(strtolower($source), '<?php')) {
                $zip->close();
                throw new InvalidArgumentException('模板压缩包包含无效内容。');
            }
            $files[$templateName] = $source;
        }
        $zip->close();
        if ($manifestFiles !== null) {
            foreach ($manifestFiles as $manifestName) {
                if (! is_string($manifestName) || ! self::validName($manifestName) || ! array_key_exists($manifestName, $files)) {
                    throw new InvalidArgumentException('模板 manifest 文件清单不匹配。');
                }
            }
            foreach (array_keys($files) as $fileName) {
                if (! in_array($fileName, $manifestFiles, true)) {
                    throw new InvalidArgumentException('模板 manifest 文件清单不匹配。');
                }
            }
        }
        if (! $files) {
            throw new InvalidArgumentException('压缩包中没有 HTML 模板。');
        }
        $originals = array();
        $created = array();
        try {
            foreach ($files as $name => $source) {
                $path = dirname(__DIR__, 2) . '/' . self::DIRECTORY . '/' . $name;
                if (is_file($path)) {
                    $originals[$path] = file_get_contents($path);
                } else {
                    $created[] = $path;
                }
                if (file_put_contents($path, $source, LOCK_EX) === false) {
                    throw new InvalidArgumentException('模板文件保存失败。');
                }
            }
        } catch (\Throwable $error) {
            foreach ($originals as $path => $source) {
                if (is_string($source)) {
                    @file_put_contents($path, $source, LOCK_EX);
                }
            }
            foreach ($created as $path) {
                @unlink($path);
            }
            throw $error;
        }
        return count($files);
    }

    public static function render(string $name, array $context): string
    {
        $source = self::readSource($name);
        if (($context['operations'] ?? null) instanceof OperationsRepository) {
            $source = OperationTags::html($source, $context['operations'], (array) ($context['custom_label_defs'] ?? $context['custom_labels'] ?? $context['labels'] ?? array()), (array) ($context['company'] ?? array()));
        }
        $source = ContentFilterTags::html($source, $context['filter_fields'] ?? array(), (string) ($context['page_path'] ?? '/'), $context['filter_params'] ?? array());
        $categories = $context['categories'] ?? array();
        $allCategories = $context['all_categories'] ?? $categories;
        $currentCategoryId = (int) (($context['category']['id'] ?? 0));
        $activeCategoryIds = array($currentCategoryId);
        foreach ($context['breadcrumb'] ?? array() as $ancestor) {
            $activeCategoryIds[] = (int) ($ancestor['id'] ?? 0);
        }
        $locale = (string) ($context['locale'] ?? 'zh-CN');
        $source = preg_replace_callback('~\{fd:nav(?:\s+[^{}]*)?\}(.*?)\{/fd:nav\}~si', static function (array $match) use ($categories, $allCategories, $currentCategoryId, $activeCategoryIds, $locale): string {
            $attributes = self::attributes($match[0]);
            $parent = array_key_exists('parent', $attributes) && ctype_digit($attributes['parent']) ? (int) $attributes['parent'] : null;
            $items = $parent === null ? $categories : array_values(array_filter($allCategories, static fn (array $category): bool => (int) ($category['parent_id'] ?? 0) === $parent));
            $start = isset($attributes['start']) && ctype_digit($attributes['start']) ? max(1, min(10000, (int) $attributes['start'])) : 1;
            $items = array_slice($items, $start - 1, self::loopLimit($attributes['num'] ?? null));
            $html = '';
            foreach ($items as $index => $category) {
                $isCurrent = $currentCategoryId > 0 && (int) ($category['id'] ?? 0) === $currentCategoryId;
                $hasChildren = (bool) array_filter($allCategories, static fn (array $candidate): bool => (int) ($candidate['parent_id'] ?? 0) === (int) ($category['id'] ?? 0));
                $fields = array('n' => $index, 'i' => $index + 1, 'scode' => $category['id'] ?? '', 'name' => $locale === 'en-US' && ($category['name_en'] ?? '') !== '' ? $category['name_en'] : ($category['name'] ?? ''), 'sortname' => $locale === 'en-US' && ($category['name_en'] ?? '') !== '' ? $category['name_en'] : ($category['name'] ?? ''), 'link' => View::categoryLink($category), 'type' => $category['type'] ?? 'list', 'parent' => $category['parent_id'] ?? '', 'isparent' => $hasChildren ? 1 : 0, 'current' => $isCurrent ? 1 : 0, 'active' => in_array((int) ($category['id'] ?? 0), $activeCategoryIds, true) ? 1 : 0);
                $item = self::renderConditions($match[1], 'nav', $fields);
                $html .= self::replaceSquareTags($item, 'nav', $fields);
            }
            return $html;
        }, $source) ?? $source;
        $posts = $context['posts'] ?? array();
        $listExtras = $context['list_extra_fields'] ?? array();
        $listGalleries = $context['list_galleries'] ?? array();
        $listTags = $context['list_tags'] ?? array();
        $source = preg_replace_callback('~\{fd:list(?:\s+[^{}]*)?\}(.*?)\{/fd:list\}~si', static function (array $match) use ($posts, $listExtras, $listGalleries, $listTags, $locale): string {
            $attributes = self::attributes($match[0]);
            $start = isset($attributes['start']) && ctype_digit($attributes['start']) ? max(1, min(10000, (int) $attributes['start'])) : 1;
            $limit = self::loopLimit($attributes['num'] ?? null);
            if (isset($attributes['scode']) && preg_match('/^[0-9]+(?:\s*,\s*[0-9]+)*$/', $attributes['scode'])) {
                $scopes = array_map('intval', preg_split('/\s*,\s*/', $attributes['scode']) ?: array());
                $posts = array_values(array_filter($posts, static fn (array $post): bool => in_array((int) ($post['category_id'] ?? 0), $scopes, true)));
            }
            foreach (array('istop' => 'is_top', 'isrecommend' => 'is_recommended', 'isheadline' => 'is_headline', 'islink' => 'outlink') as $attribute => $field) {
                if (! isset($attributes[$attribute]) || ! in_array($attributes[$attribute], array('0', '1'), true)) {
                    continue;
                }
                $expected = (int) $attributes[$attribute];
                $posts = array_values(array_filter($posts, static function (array $post) use ($field, $expected): bool {
                    $actual = $field === 'outlink' ? (trim((string) ($post[$field] ?? '')) !== '' ? 1 : 0) : (int) ($post[$field] ?? 0);
                    return $actual === $expected;
                }));
            }
            $posts = self::sortList($posts, (string) ($attributes['order'] ?? ''), $locale);
            $items = array_values(array_slice($posts, $start - 1, $limit));
            $html = '';
            foreach ($items as $index => $post) {
                $postId = (int) $post['id'];
                $extras = $listExtras[$postId] ?? array();
                $gallery = $listGalleries[$postId] ?? array();
                $tags = $listTags[$postId] ?? array();
                $fields = array(
                    'n' => $index,
                    'i' => $index + 1,
                    'id' => $postId,
                    'scode' => $post['category_id'] ?? '',
                    'sortname' => $locale === 'en-US' && ($post['category_name_en'] ?? '') !== '' ? $post['category_name_en'] : ($post['category_name'] ?? ''),
                    'sortlink' => isset($post['category_slug']) && $post['category_slug'] !== null ? View::categoryLink(array('id' => $post['category_id'] ?? null, 'slug' => $post['category_slug'], 'url_path' => $post['category_path'] ?? '')) : '',
                    'title' => $locale === 'en-US' && ($post['title_en'] ?? '') !== '' ? $post['title_en'] : $post['title'],
                    'titlecolor' => $post['title_color'] ?? '',
                    'subtitle' => $locale === 'en-US' && ($post['subtitle_en'] ?? '') !== '' ? $post['subtitle_en'] : ($post['subtitle'] ?? ''),
                    'author' => $post['author'] ?? '',
                    'source' => $post['source'] ?? '',
                    'link' => View::postLink($post),
                    'outlink' => $post['outlink'] ?? '',
                    'date' => date('Y-m-d', (int) $post['published_at']),
                    'ico' => $post['cover_path'] ?? '',
                    'isico' => ! empty($post['cover_path']) ? 1 : 0,
                    'pics' => implode(',', array_column($gallery, 'path')),
                    'ispics' => $gallery ? 1 : 0,
                    'tags' => implode(',', array_map(static fn (array $tag): string => $locale === 'en-US' && ($tag['name_en'] ?? '') !== '' ? (string) $tag['name_en'] : (string) ($tag['name'] ?? ''), $tags)),
                    'keywords' => $locale === 'en-US' && ($post['seo_keywords_en'] ?? '') !== '' ? $post['seo_keywords_en'] : ($post['seo_keywords'] ?? ''),
                    'description' => ($locale === 'en-US' && ($post['seo_description_en'] ?? '') !== '') ? $post['seo_description_en'] : ($post['seo_description'] ?: RichText::summary($post['body'], $post['body_format'], 120)),
                    'content' => RichText::summary($locale === 'en-US' && ($post['body_en'] ?? '') !== '' ? $post['body_en'] : $post['body'], $post['body_format'], 120),
                    'islink' => ! empty($post['outlink']) ? 1 : 0,
                    'istop' => $post['is_top'] ?? 0,
                    'isrecommend' => $post['is_recommended'] ?? 0,
                    'isheadline' => $post['is_headline'] ?? 0,
                );
                foreach ($extras as $field) {
                    $fields[$field['name']] = $field['value'];
                }
                $item = self::renderCheckboxes($match[1], $postId, $extras, '[list:id]');
                $item = self::renderPictures($item, $postId, $gallery, $extras, '[list:id]');
                $item = self::renderTags($item, $postId, $tags, array(), '[list:id]', (string) ($context['locale'] ?? 'zh-CN'));
                $item = self::renderConditions($item, 'list', $fields);
                $html .= self::replaceSquareTags($item, 'list', $fields);
            }
            return $html;
        }, $source) ?? $source;

        $category = $context['category'] ?? array();
        $sort = array(
            'scode' => $category['id'] ?? '',
            'name' => $locale === 'en-US' && ($category['name_en'] ?? '') !== '' ? $category['name_en'] : ($category['name'] ?? ''),
            'link' => $category ? View::categoryLink($category) : '',
            'type' => ($category['type'] ?? '') === 'single' ? '1' : '2',
            'ico' => $category['thumbnail_path'] ?? '',
            'pic' => $category['banner_path'] ?? '',
            'title' => $locale === 'en-US' && ($category['seo_title_en'] ?? '') !== '' ? $category['seo_title_en'] : ($category['seo_title'] ?? ''),
            'keywords' => $locale === 'en-US' && ($category['seo_keywords_en'] ?? '') !== '' ? $category['seo_keywords_en'] : ($category['seo_keywords'] ?? ''),
            'description' => $locale === 'en-US' && ($category['seo_description_en'] ?? '') !== '' ? $category['seo_description_en'] : ($category['seo_description'] ?? ''),
            'listtpl' => $context['list_template'] ?? '',
            'contenttpl' => $context['content_template'] ?? '',
        );
        $post = $context['post'] ?? array();
        $single = ($category['type'] ?? '') === 'single' && ! $post;
        $coverPath = $single ? ($context['cover']['path'] ?? '') : ($post['cover_path'] ?? '');
        $attachment = $context['attachment'] ?? null;
        $content = array(
            'id' => $single ? ($category['id'] ?? '') : ($post['id'] ?? ''),
            'scode' => $single ? ($category['id'] ?? '') : ($post['category_id'] ?? ''),
            'sortname' => $locale === 'en-US' && ($category['name_en'] ?? '') !== '' ? $category['name_en'] : ($category['name'] ?? ''),
            'sortlink' => $category ? View::categoryLink($category) : '',
            'title' => $single ? (($locale === 'en-US' && ($category['single_title_en'] ?? '') !== '') ? $category['single_title_en'] : ($category['single_title'] ?? '')) : ($locale === 'en-US' && ($post['title_en'] ?? '') !== '' ? $post['title_en'] : ($post['title'] ?? '')),
            'titlecolor' => $post['title_color'] ?? '',
            'subtitle' => $locale === 'en-US' && ($post['subtitle_en'] ?? '') !== '' ? $post['subtitle_en'] : ($post['subtitle'] ?? ''),
            'author' => $post['author'] ?? '',
            'source' => $post['source'] ?? '',
            'link' => $single ? View::categoryLink($category) : ($post ? View::postLink($post) : ''),
            'outlink' => $post['outlink'] ?? '',
            'date' => $post ? date('Y-m-d', (int) $post['published_at']) : '',
            'ico' => $coverPath,
            'isico' => $coverPath !== '' ? 1 : 0,
            'pics' => implode(',', array_column($context['gallery'] ?? array(), 'path')),
            'ispics' => ! empty($context['gallery']) ? 1 : 0,
            'tags' => implode(',', array_map(static fn (array $tag): string => $locale === 'en-US' && ($tag['name_en'] ?? '') !== '' ? (string) $tag['name_en'] : (string) ($tag['name'] ?? ''), $context['tags'] ?? array())),
            'enclosure' => $attachment === null ? '' : View::localizedPath($single ? '/category/' . (($category['url_path'] ?? '') !== '' ? $category['url_path'] : rawurlencode((string) $category['slug'])) . '/attachment' : '/post/' . rawurlencode((string) $post['slug']) . '/attachment'),
            'enclosuresize' => $attachment['bytes'] ?? 0,
            'keywords' => $single ? ($locale === 'en-US' && ($category['seo_keywords_en'] ?? '') !== '' ? $category['seo_keywords_en'] : ($category['seo_keywords'] ?? '')) : ($locale === 'en-US' && ($post['seo_keywords_en'] ?? '') !== '' ? $post['seo_keywords_en'] : ($post['seo_keywords'] ?? '')),
            'description' => $single ? ($locale === 'en-US' && ($category['seo_description_en'] ?? '') !== '' ? $category['seo_description_en'] : ($category['seo_description'] ?? '')) : ($locale === 'en-US' && ($post['seo_description_en'] ?? '') !== '' ? $post['seo_description_en'] : ($post['seo_description'] ?? '')),
            'content' => $single ? RichText::summary((string) ($locale === 'en-US' && ($category['single_body_en'] ?? '') !== '' ? $category['single_body_en'] : ($category['single_body'] ?? '')), (string) ($category['single_body_format'] ?? 'plain'), 120) : ($post ? RichText::summary((string) ($locale === 'en-US' && ($post['body_en'] ?? '') !== '' ? $post['body_en'] : $post['body']), (string) $post['body_format'], 120) : ''),
            'islink' => ! empty($post['outlink']) ? 1 : 0,
            'istop' => $post['is_top'] ?? 0,
            'isrecommend' => $post['is_recommended'] ?? 0,
            'isheadline' => $post['is_headline'] ?? 0,
        );
        $contentExtras = array();
        foreach ($context['extra_fields'] ?? array() as $field) {
            $content[$field['name']] = $field['value'];
            $contentExtras[$field['name']] = $field;
        }
        $source = self::renderCheckboxes($source, (int) $content['id'], $contentExtras, '{content:id}');
        $source = self::renderPictures($source, (int) $content['id'], $context['gallery'] ?? array(), $contentExtras, '{content:id}');
        $source = self::renderTags($source, $post ? (int) $post['id'] : 0, $context['tags'] ?? array(), $context['all_tags'] ?? array(), '{content:id}', (string) ($context['locale'] ?? 'zh-CN'));
        $body = $single
            ? RichText::render((string) ($locale === 'en-US' && ($category['single_body_en'] ?? '') !== '' ? $category['single_body_en'] : ($category['single_body'] ?? '')), (string) ($category['single_body_format'] ?? 'plain'))
            : ($post ? RichText::render((string) ($locale === 'en-US' && ($post['body_en'] ?? '') !== '' ? $post['body_en'] : $post['body']), (string) $post['body_format']) : '');
        $source = self::renderConditions($source, 'sort', $sort);
        $conditionContent = $content;
        $conditionContent['content'] = $body;
        $source = self::renderConditions($source, 'content', $conditionContent);
        $member = is_array($context['member'] ?? null) ? $context['member'] : array();
        $source = self::renderConditions($source, 'member', array('id' => $member['id'] ?? '', 'name' => $member['display_name'] ?? '', 'email' => $member['email'] ?? '', 'logged' => isset($member['id']) ? 1 : 0));
        $source = preg_replace_callback('/\{(?:sort|content):[a-z][a-z0-9_]*\}/i', static function (array $match) use ($sort, $content, $contentExtras, $body): string {
            [$kind, $field] = explode(':', substr($match[0], 1, -1), 2);
            $field = strtolower($field);
            if ($kind === 'content' && $field === 'content') {
                return $body;
            }
            if ($kind === 'content' && ($contentExtras[$field]['type'] ?? '') === 'editor') {
                return RichText::render((string) $contentExtras[$field]['value'], 'html');
            }
            return View::e(($kind === 'sort' ? $sort : $content)[$field] ?? '');
        }, $source) ?? $source;
        $company = is_array($context['company'] ?? null) ? $context['company'] : array();
        $labels = is_array($context['custom_labels'] ?? ($context['labels'] ?? null)) ? ($context['custom_labels'] ?? $context['labels']) : array();
        $source = preg_replace_callback('/\{label:([A-Za-z][A-Za-z0-9_]*)\}/', static fn (array $match): string => View::e($labels[$match[1]] ?? ''), $source) ?? $source;
        $source = preg_replace_callback('/\{fd:customerservice(?:\s+[^}]*)?\}/i', static function () use ($company): string {
            return CustomerService::embed($company);
        }, $source) ?? $source;
        $source = preg_replace_callback('/\{fd:company([\w]+)((?:\s+[^}]*)?)\}/', static function (array $match) use ($company): string {
            $field = strtolower($match[1]);
            if ($field === 'map') {
                $height = 320;
                if (preg_match('/\bheight\s*=\s*["\']?(\d+)/i', $match[2] ?? '', $found) === 1) {
                    $height = (int) $found[1];
                }
                return CompanyMap::embed($company, $height, (string) ($company['name'] ?? ''));
            }
            return View::e($company[$field] ?? '');
        }, $source) ?? $source;
        $globals = array(
            'sitepath' => (string) ($context['locale_prefix'] ?? ''),
            'siteurl' => View::localizedPath('/'),
            'register' => View::localizedPath('/register'),
            'login' => View::localizedPath('/login'),
            'membercenter' => View::localizedPath('/member/profile'),
            'logout' => View::localizedPath('/member/logout'),
            'companyname' => $company['name'] ?? '',
            'companyaddress' => $company['address'] ?? '',
            'companypostcode' => $company['postcode'] ?? '',
            'companycontact' => $company['contact'] ?? '',
            'companymobile' => $company['mobile'] ?? '',
            'companyphone' => $company['phone'] ?? '',
            'companyfax' => $company['fax'] ?? '',
            'companyemail' => $company['email'] ?? '',
            'companyqq' => $company['qq'] ?? '',
            'companyweixin' => $company['weixin'] ?? '',
            'companyblicense' => $company['blicense'] ?? '',
            'companyother' => $company['other'] ?? '',
            'companymapprovider' => $company['map_provider'] ?? '',
            'companybaidulng' => $company['map_baidu_lng'] ?? '',
            'companybaidulat' => $company['map_baidu_lat'] ?? '',
            'companyamaplng' => $company['map_amap_lng'] ?? '',
            'companyamaplat' => $company['map_amap_lat'] ?? '',
            'sitetitle' => $context['site_name'] ?? 'FangdaysCMS',
            'pagetitle' => ($context['seo_title'] ?? '') ?: (($context['page_title'] ?? '') . ' · ' . ($context['site_name'] ?? 'FangdaysCMS')),
            'pagekeywords' => $context['seo_keywords'] ?? '',
            'pagedescription' => $context['seo_description'] ?? ($context['site_description'] ?? ''),
            'pagebar' => View::pagination((int) ($context['page'] ?? 1), (int) ($context['total_pages'] ?? 0), (string) ($context['page_path'] ?? '/'), $context['filter_params'] ?? array(), $locale),
            'scaction' => (string) ($context['locale_prefix'] ?? '') . '/search',
            'keyword' => is_array($context['search'] ?? null) ? (string) (($context['search']['keyword'] ?? '') ?: ($context['search']['legacy_query'] ?? '')) : (string) ($context['keyword'] ?? ''),
            'memberid' => is_array($context['member'] ?? null) ? (string) ($context['member']['id'] ?? '') : '',
            'membername' => is_array($context['member'] ?? null) ? (string) ($context['member']['display_name'] ?? '') : '',
            'memberemail' => is_array($context['member'] ?? null) ? (string) ($context['member']['email'] ?? '') : '',
            'membergroupid' => is_array($context['member'] ?? null) ? (string) ($context['member']['group_id'] ?? '') : '',
            'memberstatus' => is_array($context['member'] ?? null) ? (string) ($context['member']['status'] ?? '') : '',
            'memberlogged' => is_array($context['member'] ?? null) && isset($context['member']['id']) ? '1' : '0',
        );
        return preg_replace_callback('/\{fd:([a-z]+)\}/i', static function (array $match) use ($globals): string {
            $key = strtolower($match[1]);
            return $key === 'pagebar' ? ($globals[$key] ?? '') : View::e($globals[$key] ?? '');
        }, $source) ?? $source;
    }

    public static function currentListOptions(string $name): array
    {
        $source = self::readSource($name);
        preg_match_all('~\{fd:list(?:\s+([^{}]*))?\}~i', $source, $matches, PREG_SET_ORDER);
        foreach ($matches as $match) {
            $attributes = self::attributes($match[1] ?? '');
            if (isset($attributes['scode'])) {
                continue;
            }
            $num = $attributes['num'] ?? '';
            $start = $attributes['start'] ?? '';
            return array(
                'num' => ctype_digit($num) && (int) $num >= 1 && (int) $num <= 100 ? (int) $num : 20,
                'start' => ctype_digit($start) && (int) $start >= 1 && (int) $start <= 10000 ? (int) $start : 1,
                'order' => $attributes['order'] ?? '',
            );
        }
        return array('num' => 20, 'start' => 1, 'order' => '');
    }

    private static function readSource(string $name): string
    {
        if ($name !== '' && (! self::validName($name) || ! in_array($name, self::names(), true))) {
            throw new InvalidArgumentException('请选择现有的 HTML 模板文件。');
        }
        if ($name === '') {
            throw new InvalidArgumentException('未选择 HTML 模板。');
        }
        $source = file_get_contents(dirname(__DIR__, 2) . '/' . self::DIRECTORY . '/' . $name);
        if ($source === false || strlen($source) > 500000) {
            throw new InvalidArgumentException('HTML 模板无法读取或文件过大。');
        }
        return TemplateTags::normalize($source);
    }

    private static function replaceSquareTags(string $source, string $prefix, array $fields): string
    {
        return preg_replace_callback('/\[' . preg_quote($prefix, '/') . ':([a-z][a-z0-9_]*)\]/i', static fn (array $match): string => View::e($fields[strtolower($match[1])] ?? ''), $source) ?? $source;
    }

    private static function renderCheckboxes(string $source, int $currentId, array $fields, string $placeholder): string
    {
        return preg_replace_callback('~\{fd:checkbox\s+((?:[^{}]|\{content:id\})*)\}(.*?)\{/fd:checkbox\}~si', static function (array $match) use ($currentId, $fields, $placeholder): string {
            $attributes = self::attributes($match[1]);
            $id = $attributes['id'] ?? '';
            $name = $attributes['field'] ?? '';
            if ($currentId < 1 || ! in_array($id, array((string) $currentId, $placeholder), true)
                || ! preg_match('/^ext_[A-Za-z][A-Za-z0-9_]*$/D', $name)
                || ($fields[$name]['type'] ?? '') !== 'multi') {
                return '';
            }
            $limit = self::loopLimit($attributes['num'] ?? null);
            $start = self::loopStart($attributes['start'] ?? null);
            $html = '';
            $choices = array_values(array_filter(explode(',', (string) $fields[$name]['value']), static fn (string $value): bool => $value !== ''));
            foreach (array_values(array_slice($choices, $start - 1, $limit)) as $index => $value) {
                $html .= self::replaceSquareTags($match[2], 'checkbox', array('n' => $index, 'i' => $index + 1, 'text' => $value, 'value' => $value));
            }
            return $html;
        }, $source) ?? $source;
    }

    private static function renderPictures(string $source, int $currentId, array $gallery, array $fields, string $placeholder): string
    {
        return preg_replace_callback('~\{fd:pics\s+((?:[^{}]|\{content:id\})*)\}(.*?)\{/fd:pics\}~si', static function (array $match) use ($currentId, $gallery, $fields, $placeholder): string {
            $attributes = self::attributes($match[1]);
            if ($currentId < 1 || ! in_array($attributes['id'] ?? '', array((string) $currentId, $placeholder), true)) {
                return '';
            }
            $name = $attributes['field'] ?? 'pics';
            if ($name !== 'pics') {
                if (! preg_match('/^ext_[A-Za-z][A-Za-z0-9_]*$/D', $name) || ($fields[$name]['type'] ?? '') !== 'images') {
                    return '';
                }
                $gallery = $fields[$name]['items'] ?? array();
            }
            $limit = self::loopLimit($attributes['num'] ?? null);
            $start = self::loopStart($attributes['start'] ?? null);
            $html = '';
            foreach (array_values(array_slice($gallery, $start - 1, $limit)) as $index => $image) {
                $html .= self::replaceSquareTags($match[2], 'pics', array('n' => $index, 'i' => $index + 1, 'src' => $image['path'] ?? '', 'title' => $image['title'] ?? ''));
            }
            return $html;
        }, $source) ?? $source;
    }

    private static function renderTags(string $source, int $currentId, array $tags, array $allTags, string $placeholder, string $locale = 'zh-CN'): string
    {
        return preg_replace_callback('~\{fd:tags(?:\s+((?:[^{}]|\{content:id\})*))?\}(.*?)\{/fd:tags\}~si', static function (array $match) use ($currentId, $tags, $allTags, $placeholder, $locale): string {
            $attributes = self::attributes($match[1] ?? '');
            if (isset($attributes['id']) && ($currentId < 1 || ! in_array($attributes['id'], array((string) $currentId, $placeholder), true))) {
                return '';
            }
            $limit = self::loopLimit($attributes['num'] ?? null);
            $start = self::loopStart($attributes['start'] ?? null);
            $items = isset($attributes['id']) ? $tags : $allTags;
            $html = '';
            foreach (array_values(array_slice($items, $start - 1, $limit)) as $index => $tag) {
                $html .= self::replaceSquareTags($match[2], 'tags', array('n' => $index, 'i' => $index + 1, 'link' => View::localizedPath('/tag/' . rawurlencode((string) ($tag['slug'] ?? ''))), 'text' => $locale === 'en-US' && ($tag['name_en'] ?? '') !== '' ? $tag['name_en'] : ($tag['name'] ?? ''), 'name' => $locale === 'en-US' && ($tag['name_en'] ?? '') !== '' ? $tag['name_en'] : ($tag['name'] ?? '')));
            }
            return $html;
        }, $source) ?? $source;
    }

    private static function renderConditions(string $source, string $prefix, array $fields): string
    {
        return preg_replace_callback('~\{fd:if\s*\((.*?)\)\}(.*?)\{/fd:if\}~si', static function (array $match) use ($prefix, $fields): string {
            $condition = trim($match[1]);
            if (! str_contains(strtolower($condition), '[' . strtolower($prefix) . ':')) {
                return $match[0];
            }
            $condition = preg_replace_callback('/\[' . preg_quote($prefix, '/') . ':([a-z][a-z0-9_]*)\]/i', static fn (array $field): string => (string) ($fields[strtolower($field[1])] ?? ''), $condition) ?? $condition;
            $evaluate = static function (string $expression): bool {
                $expression = trim($expression);
                if (preg_match('/^\s*(.*?)\s*(>=|<=|!=|==|=|>|<)\s*(.*?)\s*$/s', $expression, $comparison)) {
                    $left = trim($comparison[1], " \t\n\r\x27\"");
                    $right = trim($comparison[3], " \t\n\r\x27\"");
                    if (is_numeric($left) && is_numeric($right)) {
                        $leftValue = (float) $left;
                        $rightValue = (float) $right;
                    } else {
                        $leftValue = $left;
                        $rightValue = $right;
                    }
                    return match ($comparison[2]) {
                        '!=' => $leftValue != $rightValue,
                        '>' => $leftValue > $rightValue,
                        '<' => $leftValue < $rightValue,
                        '>=' => $leftValue >= $rightValue,
                        '<=' => $leftValue <= $rightValue,
                        default => $leftValue == $rightValue,
                    };
                }
                $value = trim($expression, " \t\n\r\x27\"");
                return $value !== '' && (! is_numeric($value) || (float) $value != 0.0);
            };
            $result = false;
            foreach (preg_split('/\s*(?:\|\||\bor\b)\s*/i', $condition) ?: array($condition) as $orPart) {
                $andResult = true;
                foreach (preg_split('/\s*(?:&&|\band\b)\s*/i', $orPart) ?: array($orPart) as $andPart) {
                    $andResult = $andResult && $evaluate($andPart);
                }
                $result = $result || $andResult;
            }
            $branches = explode('{else}', $match[2], 2);
            return $result ? $branches[0] : ($branches[1] ?? '');
        }, $source) ?? $source;
    }
    private static function sortList(array $posts, string $rawOrder, string $locale = 'zh-CN'): array
    {
        $parts = preg_split('/\s+/', strtolower(trim($rawOrder))) ?: array();
        $field = $parts[0] ?? '';
        $allowed = array('sorting' => 'sort_order', 'sort' => 'sort_order', 'date' => 'published_at', 'published' => 'published_at', 'id' => 'id', 'istop' => 'is_top', 'top' => 'is_top', 'isrecommend' => 'is_recommended', 'recommend' => 'is_recommended', 'isheadline' => 'is_headline', 'headline' => 'is_headline', 'title' => 'title');
        if (! isset($allowed[$field])) {
            return $posts;
        }
        $column = $allowed[$field];
        $direction = strtolower($parts[1] ?? '') === 'asc' ? 1 : -1;
        usort($posts, static function (array $left, array $right) use ($column, $direction, $locale): int {
            $a = $column === 'title' && $locale === 'en-US' && ($left['title_en'] ?? '') !== '' ? $left['title_en'] : ($left[$column] ?? '');
            $b = $column === 'title' && $locale === 'en-US' && ($right['title_en'] ?? '') !== '' ? $right['title_en'] : ($right[$column] ?? '');
            if ($column === 'title') {
                $result = strnatcasecmp((string) $a, (string) $b);
            } else {
                $result = ((int) $a <=> (int) $b);
            }
            return $result * $direction;
        });
        return $posts;
    }

    private static function loopLimit(?string $raw): int
    {
        if ($raw === null) {
            return 100;
        }
        return ctype_digit($raw) && (int) $raw >= 1 && (int) $raw <= 100 ? (int) $raw : 0;
    }

    private static function loopStart(?string $raw): int
    {
        return $raw !== null && ctype_digit($raw) ? max(1, min(10000, (int) $raw)) : 1;
    }

    private static function attributes(string $source): array
    {
        preg_match_all('~\b([a-z]+)\s*=\s*(?:"([^"]*)"|\x27([^\x27]*)\x27|(\{content:id\}|[^\s}]+))~i', $source, $matches, PREG_SET_ORDER);
        $attributes = array();
        foreach ($matches as $match) {
            $attributes[strtolower($match[1])] = $match[2] !== '' ? $match[2] : ($match[3] !== '' ? $match[3] : ($match[4] ?? ''));
        }
        return $attributes;
    }

    private static function validName(string $name): bool
    {
        return (bool) preg_match('/^[A-Za-z][A-Za-z0-9-]{0,63}\.html$/D', $name);
    }
}
