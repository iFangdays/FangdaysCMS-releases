# FangdaysCMS

FangdaysCMS 是独立开发的 PHP 内容管理系统，目标是在功能上逐步覆盖 PbootCMS 的主要 CMS 能力。后端与授权码独立实现；默认前台主题适配了 PbootCMS 自带样式，来源与许可见 [THIRD_PARTY.md](THIRD_PARTY.md)。

## 当前功能

- 快速安装：一条命令配置 SQLite、管理员、初始栏目、文章与单页；在持有厂商签发私钥的机器上同时自动激活授权。也可用安装向导选择 MySQL。
- 后台：分组侧栏导航与概览、列表/单页/跳转栏目管理及文章数量、栏目 SEO 设置、单页栏目内容编辑与发布、文章按关键词/栏目/状态/置顶/推荐/头条检索、草稿与发布、批量发布/转草稿/删除/复制/移动、本页排序保存、授权码激活。文章可设置副标题、作者、来源、标题颜色、跳转链接、发布时间、排序值、SEO 关键词与描述，并管理多图标题、顺序和单个附件。
- 前台：首页、栏目页、单页栏目、文章页、独立单页、标签页、搜索页；跳转栏目与跳转文章使用已配置链接，栏目及文章 SEO 元信息进入页面。已公开文章按置顶、推荐、头条、排序值和发布时间排序；旧文章正文继续按纯文本转义，新富文本正文经服务端白名单清理后展示。
- 授权：厂商用 Ed25519 私钥签发 `FD1` 离线授权码，网站用内置于程序的厂商公钥本地验签，检查产品、域名和有效期，不联网。未激活时前台和后台都不可用，只保留登录和「离线授权」激活页；本地运行源码同样需要为 `localhost`/`127.0.0.1` 签发的授权码。
- 内容组织：多级栏目、标签、文章草稿与发布、公开或会员可见范围、搜索和每页 20 条的分页；父栏目可汇总子栏目文章并显示面包屑。内容模型可绑定栏目，设置文本、多行、下拉单选、单选按钮、多选、日期、富文本、单张图片、多张图片和附件扩展字段，文章与单页栏目编辑后在前台展示。图片字段从媒体库选择，多图最多 30 张并可调整顺序及标题；附件字段支持上传、替换、移除与受控下载，允许 PDF、TXT、ZIP、DOCX、XLSX、PPTX，单文件最大 20 MB；富文本字段在保存时清理危险 HTML。模型区分列表与单页类型，并可指定默认 HTML 模板；栏目可覆盖模板选择。列表栏目可按下拉单选、单选按钮、多选扩展字段组合筛选，默认栏目筛选片段支持 Pboot 风格的 `selectall`、`select` 标签；全站搜索可按关键词匹配字段、栏目树和具名内容/扩展字段组合条件查询，分页保留条件。
- 会员：邮箱注册、登录、资料与密码修改；管理员可停用或恢复会员。注册按 IP/邮箱固定窗口限流，登录按 IP/邮箱独立限流。停用后既有会话也无法继续阅读会员内容。
- 后台权限：固定的站点所有者角色、可编辑的角色权限、后台账号创建/编辑/删除。权限在路由执行前检查。
- 站点设置：管理员可修改站点名称、页面简介和页脚文字；单页可单独排序并进入前台导航。
- 菜单管理：网站菜单（栏目）从内容管理独立出来，列表可逐级折叠、全部展开折叠和搜索，折叠状态按浏览器记住；批量新增按大纲书写，一行一个菜单，缩进表示下级，`名称 | 模型名` 单独指定内容模型，右侧实时预览层级。
- 表单联动：配置参数、栏目、内容字段等只显示当前选项需要的字段，规则写在 `data-show-when`（`PbootConfig::DEPENDS` 集中列出配置项依赖）；隐藏字段的值保留并照常提交。英文字段只在启用 English 区域后出现，站点信息按语言版本切换。
- GEO 优化：概览页给出 5 步上手进度、内容平均分、体检结果和示例成果；品牌事实、收录推送（合并原配置参数中的百度接口和 GEO 分组）、推送记录、内容评分、效果监控、AI 接口各占一页。收录推送页管渠道配置与待推送队列；推送记录页列出逐条提交结果（地址、HTTP 状态、搜索引擎原始回答，保留最近 2000 条，可按渠道和结果筛选），并提供“测试推送首页”立即验证渠道配置；百度回答 `not_same_site`、`not_valid` 或成功数为 0 时记为失败，不再当作成功；`site` 参数默认取当前站点地址，可在“百度 site 参数”中改成与百度搜索资源平台一致的写法；已到期的任务超过 15 分钟没有执行时页面会提示配置定时任务。内容评分满分 100 分，80 分优秀、60 分及格，并与站点平均比较。效果监控在没有样本时展示标明“示例数据”的报表。
- 内容运营：后台可维护按分组、排序的轮播图和友情链接，编辑公司信息与纯文本自定义标签。公司信息支持百度地图与高德地图分别打点，可配置前台默认展示；主题用 `{fd:companymap}`（可选 `height=320`）嵌入地图，也可用 `{fd:companymap_baidu_lng}` 等读取坐标。地图选点密钥在「配置参数 → 百度接口」填写百度地图 AK / 高德地图 Key。首页展示第 1 组轮播图，页脚展示第 1 组友链及公司名称、电话；页脚文字可使用 `{label:home_slogan}`、`{fd:companyphone}` 等纯文本占位符。默认主题的轮播和友链片段使用 `{fd:slide gid=1 num=20}`、`{fd:link gid=1 num=30}` 循环，可用 `start` 调整起始位置，循环内支持常见字段及非空判断。轮播图片和友链 Logo 从媒体库选择，被引用时不能删除。
- 富文本与媒体图片：文章、独立单页和单页栏目复用 PbootCMS 的 UEditor 资源，可编辑段落、文字样式、列表与链接，并选择已有图片或上传新图片插入正文。服务端以 HTML Purifier 清理富文本；旧单页保持纯文本展示，首次通过编辑器保存时转换为富文本。后台上传 JPG、PNG、WebP、GIF 图片用于封面、正文和多图；上传文件会校验 MIME、图片尺寸与大小，使用随机文件名。被正文引用的图片不能直接删除。文章附件支持 PDF、TXT、ZIP、DOCX、XLSX、PPTX，最大 20 MB，存放在非公开目录；下载时检查文章发布状态与会员权限。
- 前台设备模板：站点可配置 PC 与手机模板，支持 User-Agent 自动识别及 `device=mobile|tablet|desktop` 强制选择；平板请求复用手机模板。

- 公开 API：提供站点设置、公司资料、自定义标签、轮播、友情链接、已发布表单与字段、已审核留言、已审核评论、文章/栏目/标签列表与详情、搜索、分页、栏目/标签/特征筛选、多语言 SEO 和规范链接；认证会员可通过 `/api/member` 获取资料兼容字段，并通过 `/api/member/comments` 获取自己的评论及分页；未登录返回稳定错误码；API 响应统一为 JSON，并带 Content-Language、缓存控制、Vary、ETag 和安全响应头，支持匹配的 If-None-Match 条件请求。
- RSS 与站点地图：`/rss.xml`、`/sitemap.xml` 及语言前缀路由返回 XML 内容，并提供 `ETag` 与 `If-None-Match` 条件请求支持；匿名响应使用 `public, max-age=300`，认证会员响应自动切换为 `private, no-store` 并按 Cookie 区分。
- 页面缓存：匿名公开 HTML GET 页面使用 60 秒文件缓存，语言前缀和查询参数独立键控；附件等非 HTML 响应和错误页面不进入页面缓存；后台 POST 自动使缓存版本失效并清理旧缓存，支持按语言、路径和查询参数定向清理单个页面缓存，缓存统计会清理过期条目，会员、后台、API 和带 flash 的响应不缓存，缓存响应通过 `X-Fangdays-Cache` 标识命中或未命中并返回 `ETag`，支持 `If-None-Match` 条件请求；拥有 `settings.manage` 权限的管理员可在「页面缓存」查看占用并手动清理，也可使用 `php bin/cache.php stats|clear` 运维。
- 互动防滥用：管理员/会员登录、在线留言、评论和自定义表单使用按 IP 与账号或会员身份的固定窗口限流，并以文件锁保护并发计数；留言、评论和表单含隐藏字段蜜罐，提供过期记录清理；默认次数和窗口可通过 `FANGDAYS_RATE_<SCOPE>_LIMIT/WINDOW` 环境变量按作用域调整，非法配置回退默认值；超限或蜜罐命中请求提示稍后重试。
- 升级：已有 SQLite/MySQL 安装会增加新表并保留原文章和管理员；在线升级基础支持签名清单、HTTPS 包地址、版本前进检查、SHA-256/大小校验、ZIP 路径检查、旧文件备份、失败回滚和升级历史记录，可通过 `php bin/upgrade.php verify|fetch-verify|download-stage|install` 执行受控校验、包下载暂存与安装，并用 `php bin/upgrade.php history SQLITE_PATH [LIMIT]` 查看升级记录。下载暂存限制 50 MB，按块报告进度，完成哈希校验后原子替换目标文件；安装成功后写入并校验 `var/installed-version.json`，该标记纳入失败回滚。
- 页面缓存 CLI：`php bin/cache.php stats` 查看占用，`php bin/cache.php clear` 清理缓存，`php bin/cache.php --help` 查看用法。- 静态生成：可使用 `php bin/static.php warm BASE_URL OUTPUT_DIR / /category/news /post/first-post` 从公开页面生成静态 `index.html` 文件；使用 `php bin/static.php --help`、`-h` 或 `help` 查看用法；命令只接受 HTTP(S) 基地址和绝对站内路径（支持尾斜线并统一输出为目录 `index.html`，等价路径只生成一次），每次最多 500 个路径、单路径最多 2048 个字符，最多跟随 5 次重定向，查询字符串、fragment、反斜杠和符号链接输出会被拒绝，失败时返回非零状态并清理临时文件。
- 在线升级后台页面位于「系统设置 → 在线升级」，仅展示最近升级历史；升级清单校验和包安装继续通过受控 CLI 执行。
- 会员页面：`/member/*` 页面使用 `Cache-Control: private, no-store` 和 `Vary: Accept-Encoding, Cookie`，避免登录状态或会员资料被浏览器及代理缓存。
- 后台页面：`/admin/*` 页面使用 `Cache-Control: private, no-store` 和 `Vary: Accept-Encoding, Cookie`，避免后台账号权限和操作数据进入共享缓存。
- 公开评论 API：`GET /api/posts/{slug}/comments` 支持 `num` 与 `page` 参数，并返回 `total`、`total_pages`；响应不包含评论邮箱。


自定义标签目前只支持纯文本。`templates/default/` 中的可信 HTML 片段支持轮播/友链的 `gid`、`num`、`start` 和 `[slide:*]`、`[link:*]` 常见字段，以及 `{label:*}`、`{fd:company*}` 与循环内 `{fd:if([slide:link])}` 形式的非空判断。`templates/site/` 中的 HTML 文件可作为模型默认、栏目覆盖或独立搜索模板；文件名限字母开头的字母、数字、连字符并以 `.html` 结尾，不执行 PHP。模板支持 `{fd:nav}`、`{fd:list}`、`{fd:selectall}`、`{fd:select}`、`{fd:slide}`、`{fd:link}`、`{fd:tags}`、`{fd:checkbox}`、`{fd:pics}`、`{fd:pagebar}`、成员状态条件及全局标签 `{fd:memberid}`、`{fd:membername}`、`{fd:memberemail}`、`{fd:membergroupid}`、`{fd:memberstatus}`、`{fd:memberlogged}`，以及常见 `[nav:*]`、`[list:*]`、`[sort:*]`、`[content:*]`、`[tags:*]` 字段。列表和详情可读取当前模型的 `ext_*` 字段；全站标签循环、`start/num`、多栏目范围、特征过滤、排序别名和英文分页均有覆盖。

模板标签统一使用 `{fd:*}` 前缀（如 `{fd:sitetitle}`、`{fd:list}…{/fd:list}`、`{fd:2if}`）。为兼容从 PbootCMS 迁移的主题，读取模板文件、HTML 片段、配置标题和自定义标签时会把旧的 `{pboot:*}` 自动识别为 `{fd:*}`；在后台编辑并保存站点模板后即转为新写法。内容、留言等用户数据中的标签文本不会被解析。

编辑器无法加载时保留正文输入框。旧文章和旧单页初次在编辑器中保存后转为富文本；富文本仅允许常见排版元素及 http(s)/mailto 链接，脚本、事件属性和危险 URL 会被过滤。正文图片由具备 `media.manage` 权限的后台账号上传；其他有对应编辑权限的账号仍可选用媒体库已有图片。

后台「模板管理」列出系统模板和已安装主题的全部 HTML（含公共片段与手机端），编辑页使用 Monaco Editor，提供语法高亮、缩进、代码折叠、查找替换、格式化和 Pboot 标签高亮与补全；编辑器加载失败时退回文本框。

扩展字段富文本使用同一编辑器和 HTML 白名单，文章及单页栏目可从媒体库选择已有图片或上传新图片插入当前字段；图片字段只接受媒体库中的图片路径，日期字段只接受 `YYYY-MM-DD` 格式的真实日期。内容详情模板中的 `{content:ext_*}` 富文本值会作为已清理的 HTML 展示，列表模板中的 `[list:ext_*]` 仍按文本转义。`templates/site/detail-extension-fields.html` 展示这几种字段的调用方法。图片或富文本字段引用媒体时，媒体库会阻止删除该图片。
附件扩展字段在详情模板中可用 `{content:ext_manual}` 取得受控下载地址，后台默认表单显示原文件名并允许替换或移除。附件文件存放于 `var/attachments`，不会被 Web 服务器直接公开；草稿或会员专享文章的下载遵守内容访问权限。删除文章、栏目或字段时会清理不再被引用的文件。
文章和栏目单页的普通附件可在内容 HTML 模板中使用 `{content:enclosure}` 取得受控下载地址，`{content:enclosuresize}` 取得原始字节数。没有附件时分别输出空字符串和 `0`，可据此判断附件是否存在。

文章列表可选中本页最多 20 篇文章，指定列表栏目后复制或移动。副本保留正文、发布状态、可见范围、标签、封面、文章属性与扩展字段，并自动生成唯一 URL 别名；移动保留原 URL 别名。目标栏目的模型不同时，原扩展字段仍保存在数据库中，但只显示目标模型中已有的字段值。文章列表可直接调整本页排序值，数值越小越靠前；置顶、推荐和头条仍优先于排序值。将已发布文章的发布时间设为未来时，后台显示“待发布”，到时自动在前台列表与详情开放，无需定时任务。发布时间按北京时间（`Asia/Shanghai`）输入和显示，与 PbootCMS 原版一致。

文章的跳转链接仅接受 http(s) 地址或站内绝对路径；会员可见文章即使配置跳转，直接访问文章地址仍须先通过会员权限检查。文章属性数据通过增量迁移添加，未设置新属性的旧文章保持原有展示。

栏目可以指定上级，列表栏目页展示下级入口并汇总后代文章。单页栏目保存后在「编辑内容」中填写并发布正文；草稿单页不进入前台导航，直接访问返回 404。跳转栏目只接受 http(s) 地址或站内绝对路径。已有直属文章的栏目不能改为单页或跳转类型，需先移动文章。删除含子栏目的栏目会被拒绝；删除叶子栏目后，其文章保留为未分类。

## 环境

PHP 8.2+，启用 `json`、`mbstring`、`fileinfo`、`DOM`、`libxml`、`PDO`，以及 `pdo_sqlite` 或 `pdo_mysql`。Web 服务器的**文档根目录必须指向 `public/`**；`config/` 和 `var/` 不可作为公开目录。`public/uploads/` 必须对 PHP 进程可写，并在 Web 服务器中禁止该目录执行脚本。MySQL 使用已存在的空数据库，安装器负责建表。 建议启用 `sodium`；主机没有这个扩展时，授权校验改用随项目提供的纯 PHP 库 `third_party/sodium_compat`，每次请求会慢约 150 毫秒。

本项目当前位于原 PbootCMS 目录内。如果原站仍把该父目录作为 Web 根目录，务必在其 Web 服务器中拒绝外部访问整个 `/FangdaysCMS/` 路径；FangdaysCMS 使用单独站点或虚拟主机，将根目录指向 `FangdaysCMS/public/`。项目内敏感目录附带 Apache `.htaccess` 拒绝规则，但 Nginx 不读取这些规则，需要在 Nginx 配置中单独拦截。不要依靠 PHP 路由保护可直接下载的数据库文件。

无需下载 Composer 包；`autoload.php` 可直接加载项目类。富文本清理库 HTML Purifier 的已许可源码随项目提供，来源见 [THIRD_PARTY.md](THIRD_PARTY.md)。`composer.json` 留作后续依赖管理和 IDE 识别。

## 新站点起步

`base` 分支是去掉开发过程资料后的干净代码，用作新站点的开发基线，功能与 `main` 一致：

```sh
git clone -b base --single-branch https://github.com/iFangdays/FangdaysCMS.git my-site
```

之后 `main` 的修复可在 `base` 上执行 `git merge main` 同步。

## 本地启动

在项目目录执行以下命令。macOS MAMP 示例 PHP 路径为 `/Applications/MAMP/bin/php/php8.2.0/bin/php`（以本机实际安装目录为准），也可换成其他 PHP 8.2+ 可执行文件。快速安装会配置 SQLite、管理员、示例栏目、文章和单页。

```sh
php bin/quickstart.php
php -S 127.0.0.1:8000 -t public public/router.php
```

浏览器打开 `http://127.0.0.1:8000/`。后台地址为 `/login`；安装命令只显示一次随机管理员密码。若本机 `~/.fangdayscms/issuer.key` 是受信任的厂商私钥，快速安装会顺带为当前域名签发并激活授权；否则站点保持未授权，需要在后台「离线授权」粘贴授权码。部署到其他域名时，可在安装前执行 `php bin/quickstart.php example.com "站点名称"`，并把 Web 服务器文档根目录指向 `public/`。

已经安装的站点不会被快速安装覆盖。需要使用 MySQL 时，打开 `/install` 使用安装向导；安装只需填写站点、域名、管理员与数据库，不再需要填写任何密钥。

## 离线授权

授权分两端：**厂商端**（你自己的电脑，持有私钥）签发授权码；**站点端**（客户服务器或本地源码）只校验。

站点认哪些签名由 `src/Licensing/TrustedKeys.php` 中内置的厂商公钥决定，站点配置无法添加或替换公钥，升级包清单也只认这些公钥。

厂商端首次准备私钥（只需一次；私钥必须放在项目目录之外并单独备份）：

```sh
mkdir -p ~/.fangdayscms
php tools/license_issuer.php keygen ~/.fangdayscms/issuer.key fd-2026 --trust
```

`--trust` 会把新公钥写入 `TrustedKeys.php` 并替换原有公钥；之后提交这一改动并重新发布。轮换密钥时加 `--add` 可保留旧公钥，让已发出的授权码继续有效；也可单独执行 `php tools/license_issuer.php trust 公钥 密钥ID [--add]`。

为客户签发授权码（`never` 表示永久，日期表示有效至当天 23:59:59 UTC；多个域名用逗号分隔，带不带 `www` 算同一个域名，国际化域名使用 Punycode）：

```sh
php tools/license_issuer.php issue ~/.fangdayscms/issuer.key example.com,temp.host.example 2027-12-31
php tools/license_issuer.php issue ~/.fangdayscms/issuer.key localhost,127.0.0.1 never
```

每次签发会在私钥同目录的 `issued.jsonl` 追加一行记录，作为签发台账。

日常也可以不敲命令，用本机授权管理页完成签发、查看台账和本机授权的取消与恢复：

```sh
php tools/license_console.php
```

页面只监听 `127.0.0.1`，需要启动时生成的一次性地址才能打开，按 Ctrl+C 关闭，不随发布包交付。客户名称、备注和作废标记保存在私钥同目录的 `license-marks.json`。授权是离线校验的，标记作废只改台账，已激活的站点要到授权到期才会失效；取消本机授权只是把 `var/license.code` 改名为 `var/license.code.bak`，可以一键恢复。

站点端激活：未授权时先显示提示页，点“已收到授权码？去激活”进入「离线授权」，页面会显示需要授权的当前域名，粘贴授权码即可。也可以用命令行：

```sh
php bin/license.php activate < license.code
php bin/license.php status
php bin/license.php verify example.com < license.code
```

部署站点时用 `tools/release.php` 打包，输出目录必须在项目之外：

```sh
php tools/release.php --domain=example.com,temp.host.example /项目外/输出目录
php tools/release.php --no-data /项目外/输出目录
```

默认打包已纳入 Git 的运行文件和本地站点数据：`var/content.sqlite` 快照、`public/static/upload/`、`public/uploads/`、全部模板，以及路径随部署位置自动解析的 `config/app.php`，上传后无需再走安装。`--domain` 写入站点域名，多个用逗号分隔：第一个是主域名（`site_domain`），其余写入 `site_aliases`，适合同时绑定虚拟主机的临时域名。带不带 `www` 算同一个域名，只写一个即可，要把访客统一到其中一个，在后台开启主域名跳转。不传 `--domain` 则沿用本地配置；部署后要增减域名，改 `config/app.php` 的这两项（域名用小写），否则访问会提示域名未绑定。授权码也要包含这些域名。包里的数据库保留本地管理员账号和全部内容，但会清空 `site_settings` 中以 `_key`、`_secret`、`_password`、`_token` 结尾的项，AI 接口、邮件和推送密钥需要在后台重新填写。只支持 SQLite；MySQL 站点请单独导出数据库并使用 `--no-data`。

给其他客户发空白程序时必须加 `--no-data`：只包含 Git 跟踪的运行文件，首次访问进入安装向导。两种方式都不包含 `tools/`（签发工具）、测试、文档、`storage/` 和授权码，新域名需要重新激活授权。

站点未授权或授权到期时，前台和后台都显示提示页，请访客联系建站负责人；已收到授权码的管理员可从提示页进入「离线授权」激活，未登录时登录后直接回到激活页。

**关于代码保护的边界**：PHP 是明文解释执行的，签名授权能防止伪造授权码、跨域名复用授权码，但无法阻止拿到源码的人直接删改校验代码。若需要更强的源码保护，应在 `tools/release.php` 打包后，用 ionCube、SourceGuardian 等工具对 `src/` 编码再交付。离线授权也无法远程撤销，并且无法防止把服务器时钟往回调来绕过到期。

## 虚拟主机部署

推荐把网站运行目录（文档根目录）设为 `public/`：程序代码、配置、数据库和授权码都在它之外，浏览器无法访问。

如果主机只能把整个程序放进固定的网站根目录、不能修改运行目录，就使用兼容模式：上传 `tools/release.php` 打出的完整发布包，所有请求会在服务器内部转进 `public/`，其他目录一律不可访问。

| 服务器 | 做法 |
|---|---|
| Apache / LiteSpeed（大多数虚拟主机） | 无需配置。根目录的 `.htaccess` 自动生效，需要主机支持 URL 重写（mod_rewrite）并允许 `.htaccess`。 |
| Nginx（宝塔等面板） | 把 `deploy/nginx.conf` 的全部内容粘贴到站点的「伪静态」，保存。 |
| IIS | 需要安装 URL Rewrite 模块，根目录的 `web.config` 会自动生效。该配置尚未在 IIS 上实测，部署后务必自检。 |

两种模式下都会额外阻止上传、缓存和静态资源目录执行 PHP，并拒绝访问 `.htaccess` 等隐藏文件。重写规则没有生效时，访问首页会显示「站点配置未完成（FD-REWRITE-MISSING）」，而不会暴露程序文件。

**部署后必须自检一次**。在后台「服务器信息」页点「开始自检」，或在有命令行的服务器上运行：

```sh
php bin/check.php https://example.com
```

自检会以访客身份请求本站，检查数据库、授权码、配置、程序代码、模板源文件能否被下载或执行，以及上传目录能否运行 PHP。出现「风险」时，按上表检查运行目录和重写规则，修正后重新自检。页面上的「部署模式」会显示当前是标准模式还是兼容模式。服务器信息页和管理概览还会检查 PHP 版本：低于已修复 php2shell 漏洞（CVE-2026-109618、CVE-2026-109619）的版本（8.2.35、8.3.36、8.4.27、8.5.12），或开启了 `session.upload_progress`（CVE-2026-115560 尚无补丁，本系统不需要该功能）时，会提示升级或关闭。

## 结构

| 路径 | 用途 |
| --- | --- |
| `public/` | 唯一 Web 文档根目录与前台入口 |
| `src/Cms/` | 安装、数据库、后台会话、路由和内容仓储 |
| `src/Licensing/` | 独立授权码格式、签名验证与本地激活 |
| `views/` | 可替换的 PHP 页面模板 |
| `templates/default/` | 默认前台轮播与友链的 Pboot 风格 HTML 标签片段 |
| `templates/site/` | 可由模型与栏目选用的前台 HTML 模板 |
| `public/assets/theme/` | 默认前台主题样式及许可文件 |
| `public/uploads/` | 后台上传的图片；只允许静态访问 |
| `bin/quickstart.php` | SQLite 与示例内容一键安装（持有厂商私钥时自动授权） |
| `bin/license.php` | 站点端授权激活、查询与验证 |
| `tools/license_issuer.php` | 厂商端密钥生成、公钥信任与授权签发；不随发布包交付 |
| `tools/license_console.php` | 厂商端本机授权管理页；不随发布包交付 |
| `tools/release.php` | 打包部署版（默认带本地数据库、上传文件和模板，`--no-data` 打空白版） |
| `tools/upgrade_release.php` | 厂商端升级包（`.zip`）打包与 `FDU1` 升级清单签名；不随发布包交付 |
| `bin/upgrade.php` | 站点端命令行升级检查、清单验签、升级包暂存与安装 |
| `bin/check.php`、`src/Cms/DeployCheck.php` | 部署安全自检（命令行与后台「服务器信息」页） |
| `.htaccess`、`web.config`、`deploy/nginx.conf`、根目录 `index.php` | 虚拟主机兼容模式：运行目录为程序根目录时，把请求限制在 `public/` |
| `bin/migrate.php` | 现有站点数据库升级命令 |
| `config/app.php` | 安装后生成的站点配置，不入库 |
| `var/` | SQLite 数据库和已激活授权码，不入库 |

授权码格式为 `FD1.base64url(payload).base64url(signature)`。私钥不部署到站点；受信任公钥只来自 `src/Licensing/TrustedKeys.php`，旧安装 `config/app.php` 中残留的 `license_public_keys` 会被忽略。

站点会把请求的 `Host` 与安装时配置的域名比较，并忽略 `X-Forwarded-Host`。正式部署还应在 Web 服务器中只接收已配置的站点域名。运行环境所有者能够修改本地程序，因此离线验签提供可验证的签发来源，不能替代服务器侧的访问控制。

## 验证

```sh
php tests/run.php
PHP_BINARY=/path/to/php python3 tests/http_smoke.py
PHP_BINARY=/path/to/php python3 tests/quickstart_smoke.py
php tests/release_smoke.php
```

GEO 能力见 [docs/GEO_DESIGN.md](docs/GEO_DESIGN.md)。启用自动推送需配置定时任务：`*/5 * * * * php /path/to/bin/geo.php run`；百度普通收录额度每日刷新后补推积压：`5 0 * * * php /path/to/bin/geo.php push-daily`。未配置时，打开后台“GEO优化”页会补跑少量推送任务，但不会执行 AI 抽样。内容评分和 App 人工校准不依赖外部接口；AI 辅助和 API 抽样需在“GEO优化 → AI 接口”填写自己的密钥，可先获取模型、测试连接再保存。收录推送渠道在“配置参数 → GEO优化”和“百度接口”设置。

`tests/run.php` 覆盖 SQLite 快速安装、旧库升级、内容、多图关联、富文本清理、单页、站点设置、内容运营、会员、权限、分页和授权。`tests/http_smoke.py` 在临时副本上走完安装、后台管理、图片与附件上传、多图与富文本发布、轮播、友链、公司信息、自定义标签、访问控制、会员访问及授权激活。测试在临时副本中生成并信任一次性密钥（见 `tests/licensing.py`），不会使用或修改仓库内的厂商公钥。MySQL 专项测试 `tests/mysql.php` 只允许连接名称以 `_test` 结尾的**空测试数据库**，需通过 `FANGDAYS_MYSQL_HOST`、`FANGDAYS_MYSQL_PORT`、`FANGDAYS_MYSQL_NAME`、`FANGDAYS_MYSQL_USER` 和 `FANGDAYS_MYSQL_PASSWORD` 指定连接。

## 在线升级与版本推送

厂商在发布新版本时，使用 `tools/upgrade_release.php` 打出仅含 Git 跟踪运行文件（不含 `config/app.php`、`var/` 数据库与授权码、`public/uploads/`、`tools/`、`tests/`）的升级 ZIP 包，并用厂商私钥（`~/.fangdayscms/issuer.key`）签发 `FDU1` 升级清单：

```sh
php tools/upgrade_release.php \
  --version=2.0.0 \
  --url=https://raw.githubusercontent.com/iFangdays/FangdaysCMS-releases/main/releases/2.0.0/fangdayscms-2.0.0.zip \
  --out=/项目外/fangdayscms-upgrade-2.0.0 \
  --notes="FangdaysCMS 2.0.0 正式版"
```

产出目录包含：
- `fangdayscms-<version>.zip`：升级包（只包含平面文件条目，兼容 1.0.0 与 2.0.0+ 在线安装器）
- `manifest.fdu1` / `latest.fdu1`：经 Ed25519 签名的 `FDU1` 升级清单
- `release.json`：构建元数据与 SHA-256 摘要

将 `fangdayscms-<version>.zip` 与 `latest.fdu1` 推送到公开 HTTPS 分发仓库（默认更新源 `https://raw.githubusercontent.com/iFangdays/FangdaysCMS-releases/main/latest.fdu1`）后：
- **已运行 2.0.0+ 的客户站点**：后台每 6 小时静默检测更新源，发现新版本并验签通过后，在后台顶部横幅与左侧「在线升级」菜单显示新版本提醒；管理员进入 `/admin/upgrade` 点击「下载并暂存新版本」→「安装升级」即可自动备份旧文件、原子替换并自动迁移数据库。
- **正在运行 1.0.0 的客户站点**：管理员进入后台「系统设置 → 在线升级」（`/admin/upgrade`），粘贴 `FDU1` 清单字符串，依次点击「校验清单」→「下载并暂存」→「安装升级」即可原地升级到 2.0.0，保留站点配置、SQLite/MySQL 数据、上传文件与已激活授权码。

部署新代码或命令行手动升级时，也可先备份 `config/app.php`、`var/` 和 MySQL 数据库（如使用 MySQL），然后在项目目录执行：

```sh
php bin/upgrade.php check
php bin/migrate.php
```

`bin/migrate.php` 为原有站点自动补齐最新数据库表结构；首次访问也会自动执行同一数据库迁移。SQLite 升级在事务内完成；MySQL 建表使用可重复执行的语句，升级不会删除原有数据。
