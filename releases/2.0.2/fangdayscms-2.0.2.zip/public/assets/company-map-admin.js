/* Company info map pins: Baidu (BD-09) and Amap (GCJ-02). */
(function () {
  var root = document.getElementById('company-map');
  if (!root) {
    return;
  }

  var addressInput = document.getElementById('company-address');
  var baiduAk = root.getAttribute('data-baidu-ak') || '';
  var amapKey = root.getAttribute('data-amap-key') || '';
  var state = { baidu: null, amap: null };
  var baiduStarted = false;
  var amapStarted = false;

  function field(id) {
    return document.getElementById(id);
  }

  function readPoint(provider) {
    var lng = field('map-' + provider + '-lng');
    var lat = field('map-' + provider + '-lat');
    if (!lng || !lat || !lng.value || !lat.value) {
      return null;
    }
    var x = Number(lng.value);
    var y = Number(lat.value);
    return isFinite(x) && isFinite(y) ? { lng: x, lat: y } : null;
  }

  function writePoint(provider, lng, lat) {
    field('map-' + provider + '-lng').value = String(lng);
    field('map-' + provider + '-lat').value = String(lat);
  }

  function clearPoint(provider) {
    writePoint(provider, '', '');
    var current = state[provider];
    if (current && current.clear) {
      current.clear();
    }
  }

  function showMapError(canvasId, message) {
    var canvas = document.getElementById(canvasId);
    if (!canvas || canvas.getAttribute('data-map-error') === '1') {
      return;
    }
    canvas.setAttribute('data-map-error', '1');
    canvas.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100%;padding:16px;text-align:center;color:#666;font-size:14px;line-height:1.6">'
      + (message || '地图加载失败')
      + '</div>';
  }

  function switchTab(name) {
    root.querySelectorAll('[data-map-tab]').forEach(function (button) {
      var active = button.getAttribute('data-map-tab') === name;
      button.classList.toggle('is-active', active);
      button.classList.toggle('layui-btn-primary', !active);
    });
    root.querySelectorAll('[data-map-pane]').forEach(function (pane) {
      var active = pane.getAttribute('data-map-pane') === name;
      pane.hidden = !active;
      pane.classList.toggle('is-active', active);
    });
    var current = state[name];
    if (current && current.resize) {
      setTimeout(current.resize, 50);
    }
  }

  function injectScript(src) {
    if (document.querySelector('script[data-company-map="' + src + '"]')) {
      return;
    }
    var script = document.createElement('script');
    script.src = src;
    script.async = true;
    script.setAttribute('data-company-map', src);
    script.addEventListener('error', function () {
      if (src.indexOf('map.baidu.com') !== -1) {
        showMapError('company-map-baidu', '百度地图脚本加载失败，请检查网络或 AK。');
      } else {
        showMapError('company-map-amap', '高德地图脚本加载失败，请检查网络或 Key。');
      }
    });
    document.head.appendChild(script);
  }

  function initBaidu() {
    var canvas = document.getElementById('company-map-baidu');
    if (!canvas || !baiduAk || typeof BMap === 'undefined' || typeof BMap.Map !== 'function') {
      return false;
    }
    try {
      var map = new BMap.Map(canvas);
      var marker = null;
      var point = readPoint('baidu') || { lng: 116.404, lat: 39.915 };
      var center = new BMap.Point(point.lng, point.lat);
      map.centerAndZoom(center, readPoint('baidu') ? 16 : 12);
      map.enableScrollWheelZoom(true);
      map.addControl(new BMap.NavigationControl());
      function place(lng, lat) {
        var next = new BMap.Point(lng, lat);
        if (marker) {
          marker.setPosition(next);
        } else {
          marker = new BMap.Marker(next);
          map.addOverlay(marker);
        }
        map.panTo(next);
        writePoint('baidu', lng, lat);
      }
      if (readPoint('baidu')) {
        place(point.lng, point.lat);
      }
      map.addEventListener('click', function (event) {
        place(event.point.lng, event.point.lat);
      });
      state.baidu = {
        resize: function () {
          try { map.checkResize(); } catch (e) {}
        },
        clear: function () {
          if (marker) {
            map.removeOverlay(marker);
            marker = null;
          }
        },
        locate: function (address) {
          new BMap.Geocoder().getPoint(address, function (result) {
            if (result) {
              place(result.lng, result.lat);
              map.centerAndZoom(result, 16);
            } else {
              window.alert('百度地图未能根据地址定位，请改用点击地图选点。');
            }
          });
        }
      };
      setTimeout(state.baidu.resize, 80);
      setTimeout(state.baidu.resize, 320);
      return true;
    } catch (error) {
      showMapError('company-map-baidu', '百度地图初始化失败，请检查 AK 与域名白名单。');
      return false;
    }
  }

  function initAmap() {
    var canvas = document.getElementById('company-map-amap');
    if (!canvas || !amapKey || typeof AMap === 'undefined') {
      return false;
    }
    try {
      var point = readPoint('amap') || { lng: 116.397428, lat: 39.90923 };
      var map = new AMap.Map(canvas, {
        zoom: readPoint('amap') ? 16 : 12,
        center: [point.lng, point.lat],
        viewMode: '2D'
      });
      var marker = null;
      function place(lng, lat) {
        if (marker) {
          marker.setPosition([lng, lat]);
        } else {
          marker = new AMap.Marker({ position: [lng, lat], map: map });
        }
        map.setCenter([lng, lat]);
        writePoint('amap', lng, lat);
      }
      if (readPoint('amap')) {
        place(point.lng, point.lat);
      }
      map.on('click', function (event) {
        place(event.lnglat.getLng(), event.lnglat.getLat());
      });
      state.amap = {
        resize: function () {
          try { map.resize(); } catch (e) {}
        },
        clear: function () {
          if (marker) {
            map.remove(marker);
            marker = null;
          }
        },
        locate: function (address) {
          AMap.plugin('AMap.Geocoder', function () {
            new AMap.Geocoder().getLocation(address, function (status, result) {
              if (status === 'complete' && result.geocodes && result.geocodes[0]) {
                var location = result.geocodes[0].location;
                place(location.lng, location.lat);
                map.setZoomAndCenter(16, [location.lng, location.lat]);
              } else {
                window.alert('高德地图未能根据地址定位，请改用点击地图选点。');
              }
            });
          });
        }
      };
      setTimeout(state.amap.resize, 80);
      return true;
    } catch (error) {
      showMapError('company-map-amap', '高德地图初始化失败，请检查 Key 与域名白名单。');
      return false;
    }
  }

  function startBaidu() {
    if (baiduStarted) {
      return;
    }
    if (typeof BMap === 'undefined' || typeof BMap.Map !== 'function') {
      return;
    }
    baiduStarted = true;
    if (!initBaidu()) {
      baiduStarted = false;
    }
  }

  function startAmap() {
    if (amapStarted) {
      return;
    }
    if (typeof AMap === 'undefined') {
      return;
    }
    amapStarted = true;
    if (!initAmap()) {
      amapStarted = false;
    }
  }

  root.querySelectorAll('[data-map-tab]').forEach(function (button) {
    button.addEventListener('click', function () {
      switchTab(button.getAttribute('data-map-tab'));
    });
  });

  root.querySelectorAll('[data-map-clear]').forEach(function (button) {
    button.addEventListener('click', function () {
      clearPoint(button.getAttribute('data-map-clear'));
    });
  });

  root.querySelectorAll('[data-map-locate]').forEach(function (button) {
    button.addEventListener('click', function () {
      var provider = button.getAttribute('data-map-locate');
      var address = addressInput ? addressInput.value.trim() : '';
      if (!address) {
        window.alert('请先填写公司地址。');
        return;
      }
      var current = state[provider];
      if (current && current.locate) {
        current.locate(address);
      } else {
        window.alert('请先配置对应地图密钥，或直接填写经纬度。');
      }
    });
  });

  if (baiduAk && document.getElementById('company-map-baidu')) {
    window.HOST_TYPE = '2';
    if (typeof BMap !== 'undefined' && typeof BMap.Map === 'function') {
      startBaidu();
    } else {
      window.__fdAdminBaiduReady = function () {
        startBaidu();
        try { delete window.__fdAdminBaiduReady; } catch (e) { window.__fdAdminBaiduReady = undefined; }
      };
      injectScript('https://api.map.baidu.com/api?v=3.0&ak=' + encodeURIComponent(baiduAk) + '&callback=__fdAdminBaiduReady');
      setTimeout(function () {
        if (!baiduStarted) {
          showMapError('company-map-baidu', '百度地图加载超时，请确认浏览器端 AK 已绑定当前域名（含 127.0.0.1 / localhost）。');
        }
      }, 12000);
    }
  }

  if (amapKey && document.getElementById('company-map-amap')) {
    if (typeof AMap !== 'undefined') {
      startAmap();
    } else {
      window.__fdAdminAmapReady = function () {
        startAmap();
        try { delete window.__fdAdminAmapReady; } catch (e) { window.__fdAdminAmapReady = undefined; }
      };
      injectScript('https://webapi.amap.com/maps?v=2.0&key=' + encodeURIComponent(amapKey) + '&callback=__fdAdminAmapReady');
      setTimeout(function () {
        if (!amapStarted) {
          showMapError('company-map-amap', '高德地图加载超时，请确认 Web端 Key 已绑定当前域名。');
        }
      }, 12000);
    }
  }
})();
