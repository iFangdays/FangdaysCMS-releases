// Code editor for the template form. The textarea stays as the submitted field and as the fallback if Monaco fails.
(() => {
  const textarea = document.querySelector('textarea[data-code-editor]');
  const host = document.getElementById('template-code-editor');
  if (!textarea || !host) {
    return;
  }
  const base = '/assets/monaco/vs';
  const tagPattern = /\{\/?(?:pboot|fd):[^}\n]*\}|\{(?:sort|content|label|page|user|nav):[A-Za-z0-9_]+\}|\{include\s[^}\n]*\}|\[(?:list|nav|sort|content|pics|tags|slide|link|search|loop|form|message|checkbox):[A-Za-z0-9_]+[^\]\n]*\]/g;
  const snippets = [
    ['{fd:list}', '{fd:list scode=${1:1} num=${2:10} order=${3:date}}\n\t<a href="[list:link]">[list:title]</a>$0\n{/fd:list}', '文章列表循环'],
    ['{fd:nav}', '{fd:nav num=${1:10} parent=${2:0}}\n\t<a href="[nav:link]">[nav:name]</a>$0\n{/fd:nav}', '栏目导航循环'],
    ['{fd:slide}', '{fd:slide num=${1:5} gid=${2:1}}\n\t<img src="[slide:src]" alt="">$0\n{/fd:slide}', '轮播图循环'],
    ['{fd:link}', '{fd:link num=${1:10} gid=${2:1}}\n\t<a href="[link:link]">[link:name]</a>$0\n{/fd:link}', '友情链接循环'],
    ['{fd:if}', '{fd:if(${1:条件})}\n\t$0\n{/fd:if}', '条件判断'],
    ['{fd:if else}', '{fd:if(${1:条件})}\n\t$2\n{else}\n\t$0\n{/fd:if}', '条件判断（含 else）'],
    ['{include}', '{include file=${1:head.html}}', '引入模板片段'],
    ['{fd:sitetplpath}', '{fd:sitetplpath}', '主题资源路径'],
    ['{fd:sitetitle}', '{fd:sitetitle}', '站点标题'],
    ['{fd:sitesubtitle}', '{fd:sitesubtitle}', '站点副标题'],
    ['{fd:sitelogo}', '{fd:sitelogo}', '站点 Logo'],
    ['{fd:position}', '{fd:position}', '当前位置'],
    ['{fd:msgaction}', '{fd:msgaction}', '留言提交地址'],
    ['{fd:scaction}', '{fd:scaction}', '搜索提交地址'],
    ['{fd:companyname}', '{fd:companyname}', '公司名称'],
    ['{fd:companymobile}', '{fd:companymobile}', '公司手机'],
    ['{content:title}', '{content:title}', '内容标题'],
    ['{content:content}', '{content:content}', '内容正文'],
    ['{content:date}', '{content:date}', '发布时间'],
    ['{content:ico}', '{content:ico}', '缩略图'],
    ['{sort:name}', '{sort:name}', '栏目名称'],
    ['{sort:link}', '{sort:link}', '栏目链接'],
    ['{page:bar}', '{page:bar}', '分页条'],
    ['{label:}', '{label:${1:name}}', '自定义标签'],
    ['[list:title]', '[list:title]', '列表标题'],
    ['[list:link]', '[list:link]', '列表链接'],
    ['[list:ico]', '[list:ico]', '列表缩略图'],
    ['[list:date]', '[list:date]', '列表日期'],
    ['[list:description]', '[list:description]', '列表简介'],
    ['[nav:name]', '[nav:name]', '导航名称'],
    ['[nav:link]', '[nav:link]', '导航链接'],
    ['[nav:scode]', '[nav:scode]', '导航栏目编号'],
    ['[slide:src]', '[slide:src]', '轮播图片'],
    ['[slide:link]', '[slide:link]', '轮播链接'],
  ];
  const storedTheme = () => {
    try {
      return localStorage.getItem('template-editor-theme') || 'vs-dark';
    } catch (error) {
      return 'vs-dark';
    }
  };

  const start = (monaco) => {
    monaco.languages.registerCompletionItemProvider('html', {
      triggerCharacters: ['{', '[', ':'],
      provideCompletionItems(model, position) {
        const line = model.getLineContent(position.lineNumber);
        const before = line.slice(0, position.column - 1);
        const typed = before.match(/[{[][^\s{}[\]]*$/);
        if (!typed) {
          return { suggestions: [] };
        }
        // The closing bracket the editor added belongs to the replaced text.
        const closing = line[position.column - 1] === (typed[0][0] === '{' ? '}' : ']') ? 1 : 0;
        const range = new monaco.Range(position.lineNumber, position.column - typed[0].length, position.lineNumber, position.column + closing);
        return {
          suggestions: snippets.map(([label, insertText, detail]) => ({
            label,
            detail,
            insertText,
            range,
            filterText: label,
            kind: monaco.languages.CompletionItemKind.Snippet,
            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
          })),
        };
      },
    });
    textarea.closest('label').style.display = 'none';
    host.hidden = false;
    const editor = monaco.editor.create(host.querySelector('.code-editor-surface'), {
      value: textarea.value,
      language: 'html',
      theme: storedTheme(),
      automaticLayout: true,
      fontSize: 14,
      tabSize: 4,
      wordWrap: 'off',
      renderWhitespace: 'selection',
      bracketPairColorization: { enabled: true },
      guides: { indentation: true, bracketPairs: true },
      linkedEditing: true,
      formatOnPaste: false,
      scrollBeyondLastLine: false,
    });
    let dirty = false;
    let decorations = editor.createDecorationsCollection();
    let timer = 0;
    const highlight = () => {
      const model = editor.getModel();
      const found = [];
      for (const match of model.getValue().matchAll(tagPattern)) {
        const from = model.getPositionAt(match.index);
        const to = model.getPositionAt(match.index + match[0].length);
        found.push({ range: new monaco.Range(from.lineNumber, from.column, to.lineNumber, to.column), options: { inlineClassName: 'code-editor-tag' } });
      }
      decorations.set(found);
    };
    highlight();
    editor.onDidChangeModelContent(() => {
      dirty = true;
      textarea.value = editor.getValue();
      clearTimeout(timer);
      timer = setTimeout(highlight, 120);
    });
    // HTML strings switch off Monaco's own trigger characters, so tags ask for suggestions themselves.
    editor.onDidType(() => {
      const position = editor.getPosition();
      if (/[{[][^\s{}[\]]*$/.test(editor.getModel().getLineContent(position.lineNumber).slice(0, position.column - 1))) {
        editor.trigger('template-tags', 'editor.action.triggerSuggest', {});
      }
    });
    const form = textarea.form;
    const save = () => {
      textarea.value = editor.getValue();
      dirty = false;
      form.requestSubmit();
    };
    form.addEventListener('submit', () => {
      textarea.value = editor.getValue();
      dirty = false;
    });
    window.addEventListener('beforeunload', (event) => {
      if (dirty) {
        event.preventDefault();
      }
    });
    editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, save);
    host.querySelector('[data-action="format"]').addEventListener('click', () => editor.getAction('editor.action.formatDocument').run());
    host.querySelector('[data-action="find"]').addEventListener('click', () => editor.getAction('actions.find').run());
    const wrap = host.querySelector('[data-action="wrap"]');
    wrap.addEventListener('click', () => {
      const on = editor.getOption(monaco.editor.EditorOption.wordWrap) === 'off';
      editor.updateOptions({ wordWrap: on ? 'on' : 'off' });
      wrap.setAttribute('aria-pressed', String(on));
    });
    host.querySelector('[data-action="theme"]').addEventListener('click', () => {
      const next = storedTheme() === 'vs-dark' ? 'vs' : 'vs-dark';
      monaco.editor.setTheme(next);
      try {
        localStorage.setItem('template-editor-theme', next);
      } catch (error) {
        return;
      }
    });
    const full = host.querySelector('[data-action="fullscreen"]');
    full.addEventListener('click', () => {
      const on = host.classList.toggle('is-fullscreen');
      document.body.classList.toggle('code-editor-open', on);
      full.textContent = on ? '退出全屏' : '全屏';
      editor.focus();
    });
    editor.focus();
  };

  const load = (src, ready) => {
    const script = document.createElement('script');
    script.src = src;
    script.onload = ready;
    document.body.appendChild(script);
  };
  // The language pack is a plain script that must run before the editor starts.
  load(base + '/nls/lang/zh-cn.js', () => load(base + '/loader.js', () => {
    window.require.config({ paths: { vs: base } });
    window.require(['vs/editor/editor.main'], (module) => start(window.monaco || module));
  }));
})();
