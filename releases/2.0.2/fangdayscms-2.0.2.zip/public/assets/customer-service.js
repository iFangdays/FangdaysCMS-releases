/* Floating customer-service rail + third-party chat hook. */
(function () {
  var root = document.getElementById('fd-customer-service');
  if (!root) {
    return;
  }

  var openers = [];
  var activeKind = '';

  function closest(node, selector) {
    return node && node.closest ? node.closest(selector) : null;
  }

  function setCard(kind, open) {
    root.querySelectorAll('[data-fd-cs-card]').forEach(function (card) {
      var match = card.getAttribute('data-fd-cs-card') === kind;
      card.hidden = !(open && match);
    });
    root.querySelectorAll('[data-fd-cs-open]').forEach(function (button) {
      var match = button.getAttribute('data-fd-cs-open') === kind;
      button.setAttribute('aria-expanded', open && match ? 'true' : 'false');
      button.classList.toggle('is-active', open && match);
    });
    activeKind = open ? kind : '';
    root.classList.toggle('is-open', !!open);
  }

  function closeAll() {
    setCard('', false);
  }

  function openChat() {
    var mode = root.getAttribute('data-fd-cs-chat-mode') || '';
    var url = root.getAttribute('data-fd-cs-chat-url') || '';
    var i;
    for (i = 0; i < openers.length; i += 1) {
      try {
        if (openers[i]() === true) {
          return true;
        }
      } catch (error) {}
    }
    if (mode === 'link' && url) {
      window.open(url, '_blank', 'noopener');
      return true;
    }
    if (mode === 'script') {
      // Common vendor fallbacks; integrators should prefer FangdaysCS.registerChatOpener.
      var candidates = [
        '#meiqia-container',
        '#meiqia-btn',
        '.meiQia-chat-button',
        '#ss-chat-p',
        '.crisp-client',
        '#chat-widget-container'
      ];
      for (i = 0; i < candidates.length; i += 1) {
        var node = document.querySelector(candidates[i]);
        if (node && typeof node.click === 'function') {
          node.click();
          return true;
        }
      }
      if (typeof window._MEIQIA === 'function') {
        try { window._MEIQIA('showPanel'); return true; } catch (error) {}
      }
      if (window.$crisp && typeof window.$crisp.push === 'function') {
        try { window.$crisp.push(['do', 'chat:open']); return true; } catch (error) {}
      }
    }
    return false;
  }

  window.FangdaysCS = window.FangdaysCS || {};
  window.FangdaysCS.openChat = openChat;
  window.FangdaysCS.registerChatOpener = function (fn) {
    if (typeof fn === 'function') {
      openers.push(fn);
    }
  };
  window.FangdaysCS.close = closeAll;

  root.addEventListener('click', function (event) {
    var chatBtn = closest(event.target, '[data-fd-cs-chat]');
    if (chatBtn) {
      event.preventDefault();
      closeAll();
      openChat();
      return;
    }
    var openBtn = closest(event.target, '[data-fd-cs-open]');
    if (openBtn) {
      event.preventDefault();
      var kind = openBtn.getAttribute('data-fd-cs-open') || '';
      setCard(kind, activeKind !== kind);
    }
  });

  document.addEventListener('click', function (event) {
    if (!root.contains(event.target)) {
      closeAll();
    }
  });

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
      closeAll();
    }
  });

  try {
    document.dispatchEvent(new CustomEvent('fd:cs:ready', { detail: { root: root, api: window.FangdaysCS } }));
  } catch (error) {}
})();
