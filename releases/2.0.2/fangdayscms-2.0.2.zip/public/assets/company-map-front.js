/* Front-end company map: Baidu / Amap base tiles with a single pin. */
(function () {
  var roots = document.querySelectorAll('.fd-company-map[data-provider]:not([data-ready])');
  if (!roots.length) {
    return;
  }

  var baiduWaiters = [];
  var baiduLoading = false;
  var amapWaiters = [];
  var amapLoading = false;

  var pinUrl = (function () {
    var script = document.currentScript;
    if (script && script.src) {
      return script.src.replace(/[^/]+$/, 'map-pin.png');
    }
    return '/assets/map-pin.png';
  })();

  function point(root) {
    var lng = Number(root.getAttribute('data-lng'));
    var lat = Number(root.getAttribute('data-lat'));
    return isFinite(lng) && isFinite(lat) ? { lng: lng, lat: lat } : null;
  }

  function fail(root, message) {
    if (!root || root.getAttribute('data-ready') === '1') {
      return;
    }
    var canvas = root.querySelector('.fd-company-map-canvas');
    var openUrl = root.getAttribute('data-open') || '';
    if (canvas) {
      canvas.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100%;padding:16px;text-align:center;color:#5b6b7f;background:#eef3f9;font-size:14px;line-height:1.6">'
        + (message || '地图暂不可用')
        + (openUrl ? '<br><a href="' + openUrl.replace(/"/g, '&quot;') + '" target="_blank" rel="noopener" style="margin-top:8px;display:inline-block;color:#1f6feb">打开地图</a>' : '')
        + '</div>';
    }
    root.setAttribute('data-ready', '1');
  }

  function flush(waiters, ok, message) {
    var list = waiters.splice(0, waiters.length);
    list.forEach(function (item) {
      if (ok) {
        item.ok();
      } else {
        fail(item.root, message);
      }
    });
  }

  function renderBaidu(root) {
    var canvas = root.querySelector('.fd-company-map-canvas');
    var pos = point(root);
    if (!canvas || !pos || typeof BMap === 'undefined') {
      fail(root, '百度地图加载失败，请确认 AK 为浏览器端，并已绑定当前访问域名（本地需含 127.0.0.1）。');
      return;
    }
    try {
      var map = new BMap.Map(canvas, { enableMapClick: false });
      var markerPoint = new BMap.Point(pos.lng, pos.lat);
      map.centerAndZoom(markerPoint, 16);
      map.enableScrollWheelZoom(false);
      map.disableDoubleClickZoom();
      map.addControl(new BMap.NavigationControl({
        type: BMAP_NAVIGATION_CONTROL_ZOOM,
        anchor: BMAP_ANCHOR_BOTTOM_RIGHT,
        offset: new BMap.Size(12, 12)
      }));
      var icon = new BMap.Icon(pinUrl, new BMap.Size(28, 36), {
        anchor: new BMap.Size(14, 34),
        imageSize: new BMap.Size(28, 36)
      });
      map.addOverlay(new BMap.Marker(markerPoint, { icon: icon }));
      root.setAttribute('data-ready', '1');
      function fit() {
        try {
          map.checkResize();
          map.panTo(markerPoint);
        } catch (e) {}
      }
      setTimeout(fit, 80);
      setTimeout(fit, 400);
    } catch (error) {
      fail(root, '百度地图初始化失败，请检查 AK 与域名白名单。');
    }
  }

  function renderAmap(root) {
    var canvas = root.querySelector('.fd-company-map-canvas');
    var pos = point(root);
    if (!canvas || !pos || typeof AMap === 'undefined') {
      fail(root, '高德地图加载失败，请确认 Key 为 Web端(JS API)，并已绑定当前访问域名。');
      return;
    }
    try {
      var map = new AMap.Map(canvas, {
        zoom: 16,
        center: [pos.lng, pos.lat],
        viewMode: '2D',
        dragEnable: true,
        zoomEnable: true,
        doubleClickZoom: false,
        scrollWheel: false,
        showLabel: true,
        mapStyle: 'amap://styles/whitesmoke'
      });
      map.add(new AMap.Marker({
        position: [pos.lng, pos.lat],
        title: root.getAttribute('data-title') || '',
        content: '<img src="' + pinUrl + '" width="28" height="36" alt="" style="display:block;transform:translate(-14px,-34px)">'
      }));
      root.setAttribute('data-ready', '1');
      setTimeout(function () {
        try { map.resize(); } catch (e) {}
      }, 80);
    } catch (error) {
      fail(root, '高德地图初始化失败，请检查 Key 与域名白名单。');
    }
  }

  function loadBaidu(ak, root, done) {
    if (typeof BMap !== 'undefined' && typeof BMap.Map === 'function') {
      done();
      return;
    }
    baiduWaiters.push({ root: root, ok: done });
    if (baiduLoading) {
      return;
    }
    baiduLoading = true;
    window.HOST_TYPE = '2';
    window.__fdBaiduMapReady = function () {
      baiduLoading = false;
      flush(baiduWaiters, typeof BMap !== 'undefined' && typeof BMap.Map === 'function', '百度地图脚本未就绪，请确认 AK 与域名白名单。');
      try { delete window.__fdBaiduMapReady; } catch (e) { window.__fdBaiduMapReady = undefined; }
    };
    var script = document.createElement('script');
    script.src = 'https://api.map.baidu.com/api?v=3.0&ak=' + encodeURIComponent(ak) + '&callback=__fdBaiduMapReady';
    script.async = true;
    script.addEventListener('error', function () {
      baiduLoading = false;
      flush(baiduWaiters, false, '百度地图脚本加载失败，请检查网络或 AK。');
    });
    document.head.appendChild(script);
    setTimeout(function () {
      if (baiduWaiters.length) {
        baiduLoading = false;
        flush(baiduWaiters, typeof BMap !== 'undefined' && typeof BMap.Map === 'function', '百度地图加载超时，请确认浏览器端 AK 已绑定当前域名（含 127.0.0.1 / localhost）。');
      }
    }, 12000);
  }

  function loadAmap(key, root, done) {
    if (typeof AMap !== 'undefined') {
      done();
      return;
    }
    amapWaiters.push({ root: root, ok: done });
    if (amapLoading) {
      return;
    }
    amapLoading = true;
    window.__fdAmapReady = function () {
      amapLoading = false;
      flush(amapWaiters, typeof AMap !== 'undefined', '高德地图脚本未就绪，请确认 Key 与域名白名单。');
      try { delete window.__fdAmapReady; } catch (e) { window.__fdAmapReady = undefined; }
    };
    var script = document.createElement('script');
    script.src = 'https://webapi.amap.com/maps?v=2.0&key=' + encodeURIComponent(key) + '&callback=__fdAmapReady';
    script.async = true;
    script.addEventListener('error', function () {
      amapLoading = false;
      flush(amapWaiters, false, '高德地图脚本加载失败，请检查网络或 Key。');
    });
    document.head.appendChild(script);
    setTimeout(function () {
      if (amapWaiters.length) {
        amapLoading = false;
        flush(amapWaiters, typeof AMap !== 'undefined', '高德地图加载超时，请确认 Web端 Key 已绑定当前域名。');
      }
    }, 12000);
  }

  function boot(root) {
    var provider = root.getAttribute('data-provider');
    var ak = root.getAttribute('data-ak') || '';
    if (!ak) {
      fail(root, provider === 'amap' ? '请先在「配置参数 → 地图接口」填写高德地图 Key' : '请先在「配置参数 → 地图接口」填写百度地图 AK');
      return;
    }
    if (provider === 'baidu') {
      loadBaidu(ak, root, function () { renderBaidu(root); });
      return;
    }
    if (provider === 'amap') {
      loadAmap(ak, root, function () { renderAmap(root); });
      return;
    }
    fail(root, '不支持的地图服务');
  }

  Array.prototype.forEach.call(roots, boot);
})();
